static UINT8 PlayerX = 0;

static UINT8 PlayerY = 0;

static UINT8 JumpTrigger = 0;

static UINT8 JumpCounter = 20;

static UINT8 Direction = 2;

static UINT8 ProjectileTrigger = 0;

static UINT8 ProjectileX = 0;

static UINT8 ProjectileY = 0;

static UINT8 ProjectileDirection = 2;

static UINT8 Moving = 0;

static UINT8 Acceloration = 0;

static UINT8 Hit = 0;

static UINT8 HitBlinker = 0;

static UINT8 TransitionFlag = 0;

static UINT8 PlayerHealth = 6;