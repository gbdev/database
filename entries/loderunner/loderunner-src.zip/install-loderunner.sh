#!/bin/sh
# -- setup of the Loderunner game and the supporting libraries

make all

