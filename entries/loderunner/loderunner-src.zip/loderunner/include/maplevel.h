/** Map Level module --
    This module provides all services for handling the retrieval of
    the map levels in a GameBoy game.

    Original version by Thomas Tensi, 2005-06
*/

#ifndef __MAPLEVEL_H
#define __MAPLEVEL_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/types.h>

/*========================================*/

#define MapLevel_maxIndex 80

/*--------------------*/

void MapLevel_load (in UINT8 level, out Map_ObjectKind *map);
  /** loads <map> with information for <level> */

#endif /* __MAPLEVEL_H */
