/** Opponent module --
    This module provides all services for handling the opponent
    objects in the LodeRunner GameBoy game.

    An opponent is a variant of a generic game object, so this module
    only defines extensions (like whether an opponent is carrying gold
    or not).

    Original version by Thomas Tensi, 2005-09
*/

#ifndef __OPPONENT_H
#define __OPPONENT_H

/*========================================*/

#include <gbextended/types.h>
#include <gbextended/palette.h>

#include "gameobject.h"

/*========================================*/

#define Opponent_maxCount 5

extern /* const */ GameObject_TypeDescriptor Opponent_typeDescriptor;
  /* could be const, but will be put in RAM for space reasons */

typedef enum {
  Opponent_State_carrying, Opponent_State_dropping,
  Opponent_State_blocked,  Opponent_State_unblocked
} Opponent_State;
  /** information whether opponent is carrying a treasure, is unloaded
      but cannot pickup a treasure, or is able to pickup a treasure */


/*========================================*/

void Opponent_initialize (void);
  /** initializes the opponent data; should be called first */

/*--------------------*/

void Opponent_finalize (void);
  /** cleans up the internal opponent data; should be called finally */

/*--------------------*/

void Opponent_resetAllVariantData (void);
  /** initializes all internal opponent information when a new level
      is loaded */

/*--------------------*/

void Opponent_setAppearance (in Palette_Colour bodyColour);
  /** defines the visual appearance of all opponents by setting their
      <bodyColour> */

/*--------------------*/

void Opponent_hide (in GameObject_Index opponent);
  /** makes <opponent> invisible */

/*--------------------*/

Opponent_State Opponent_state (in GameObject_Index opponent);
  /** tells the carrying state of <opponent> */

/*--------------------*/

void Opponent_setState (in GameObject_Index opponent,
			in Opponent_State state);
  /** defines carrying state of <opponent> as <state> */

#endif /* __OPPONENT_H */
