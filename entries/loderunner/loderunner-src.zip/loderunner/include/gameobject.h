/** GameObject module --
    This module dispatches all services for handling all objects of a
    GameBoy game.

    Original version by Thomas Tensi, 2005-03
*/

#ifndef __GAMEOBJECT_H
#define __GAMEOBJECT_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/screen.h>
#include <gbextended/types.h>

/*========================================*/

typedef enum { GameObject_Action_none,
	       GameObject_Action_runLeft, GameObject_Action_runRight,
	       GameObject_Action_clamberLeft, GameObject_Action_clamberRight,
               GameObject_Action_climbUp, GameObject_Action_climbDown,
	       GameObject_Action_fall,
	       GameObject_Action_shootLeft, GameObject_Action_shootRight
} GameObject_Action;
/** kinds of action a game object may do */

typedef enum {
  GameObject_LevelResult_running, GameObject_LevelResult_completed,
  GameObject_LevelResult_failed
} GameObject_LevelResult;
/** the outcome of a level played */


typedef UINT8 GameObject_Index;


typedef struct {
  MapCoordinate_Type moveSpeed;  /** speed of object per frame */
  Map_ObjectKind objectKind;     /** representation on map */
  Boolean isStatic;              /** tells whether this object moves */

  /* routines available for animated objects*/
  void (*setAnimation)(in GameObject_Index, in GameObject_Action action);
    /** routine to redefine the animation of <object> */
  void (*setAnimationState)(in GameObject_Index object, in Boolean isPaused);
    /** routine to either pause or continue with the animation for
        <object> */
  void (*move)(in GameObject_Index object,
	       inout Screen_Coordinate *x, inout Screen_Coordinate *y);
    /** routine to move <object> to visible position (x,y) on screen */
  void (*hide)(in GameObject_Index object);
    /** routine to make <object> invisible on screen */
  void (*handleTickEvent)(in GameObject_Index object);
    /** routine to tell <object> that a new frame has occured */
  GameObject_Action (*getNextAction)(in GameObject_Index object,
				     readonly Map_Position *position,
				     readonly void *otherData);
    /** returns the next action <object> will do based on his
        <position> on map and <otherData> */
} GameObject_TypeDescriptor;
/** the generic parts of a game object (game object type variables and
    functions) */

/*========================================*/

void GameObject_initialize (void);
  /** initializes the internal data; should be called first. */

/*--------------------*/

void GameObject_finalize (void);
  /** cleans up the internal data; should be called finally. */

/*--------------------*/

void GameObject_loadAllFromMap (void);
  /** reads current map and extracts all included static and dynamic
      objects */

/*--------------------*/

void GameObject_showScenery (void);
  /** centers map view around player and shows all visible objects */

/*--------------------*/

GameObject_LevelResult GameObject_handleTickEvent (void);
  /** does the processing for a single tick event triggered by a frame
      gap; check any player actions and tries to move enemies; returns
      the result whether and how the current level is completed */

#endif /* __GAMEOBJECT_H */
