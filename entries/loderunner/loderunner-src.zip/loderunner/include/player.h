/** Player module --
    This module provides all services for handling the player object
    in the LodeRunner GameBoy game.

    A player is a variant of a generic game object, so this module
    only defines extensions (like finding out the next action of a
    player by querying the user).

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __PLAYER_H
#define __PLAYER_H

/*========================================*/

#include <gbextended/palette.h>
#include <gbextended/types.h>
#include "gameobject.h"

/*========================================*/

typedef enum { Player_Kind_boy, Player_Kind_girl1, Player_Kind_girl2 
             } Player_Kind;
  /** kinds of player where each value of this type is visualized
      differently */


extern /* const */ GameObject_TypeDescriptor Player_typeDescriptor;
  /* could be const, but will be put in RAM for space reasons */

/*========================================*/

void Player_initialize (void);
  /** initializes the player data; should be called first */

/*--------------------*/

void Player_finalize (void);
  /** cleans up the internal player data. Should be called finally. */

/*--------------------*/

void Player_setAppearance (in Player_Kind kind,
			   in Palette_Colour hairColour,
			   in Palette_Colour topClothingColour,
			   in Palette_Colour bottomClothingColour,
			   in Palette_Colour shoeColour);
  /** defines the visual appearance of the player depending on his
      <kind>, <hairColour>, <topClothingColour>,
      <bottomClothingColour> and <shoeColour> */

/*--------------------*/

void Player_setNextAction (in UINT8 player, in GameObject_Action action);
  /** sets <action> to be the next action <player> will make according
      to the joypad keys pressed */

#endif /* __PLAYER_H */

