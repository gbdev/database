/** Concrete Map View Module --
    This module provides all services for handling the concrete view
    on a map of a GameBoy game. It relies on the map view framework.

    Original version by Thomas Tensi, 2005-08
*/

#ifndef __CONCRETEMAPVIEW_H
#define __CONCRETEMAPVIEW_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/mapview.h>
#include <gbextended/types.h>

/*========================================*/

void ConcreteMapView_initialize (void);
  /** initializes the data of the concrete map view; should be called
      first */

/*--------------------*/

void ConcreteMapView_finalize (void);
  /** cleans up the internal data of the concrete map view; should be
      called finally */

#endif /* __CONCRETEMAPVIEW_H */
