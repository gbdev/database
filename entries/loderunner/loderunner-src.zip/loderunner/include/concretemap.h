/** Concrete Map Module --
    Implementation of module providing all services for handling the
    concrete map of a GameBoy game. It relies on the map framework.

    Original version by Thomas Tensi, 2005-05
*/

#ifndef __CONCRETEMAP_H
#define __CONCRETEMAP_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/types.h>

/*========================================*/

typedef Map_ObjectKind ConcreteMap_ObjectKind;
#define ConcreteMap_ObjectKind_empty    '.'
#define ConcreteMap_ObjectKind_brick    'X'
#define ConcreteMap_ObjectKind_trap     'T'
#define ConcreteMap_ObjectKind_ladder   'H'
#define ConcreteMap_ObjectKind_hiddenL  'h'
#define ConcreteMap_ObjectKind_concrete '#'
#define ConcreteMap_ObjectKind_rod      '~'
#define ConcreteMap_ObjectKind_player   '+'
#define ConcreteMap_ObjectKind_opponent '-'
#define ConcreteMap_ObjectKind_gold     '$'
/* object kind not in initial map */
#define ConcreteMap_ObjectKind_hole     'O'
/* additional states of a hole */
#define ConcreteMap_ObjectKind_hole_1   '1'
#define ConcreteMap_ObjectKind_hole_2   '2'
/* information about remaining gold sacks */
#define ConcreteMap_ObjectKind_gold_0   'a'
#define ConcreteMap_ObjectKind_gold_1   'b'
#define ConcreteMap_ObjectKind_gold_2   'c'
#define ConcreteMap_ObjectKind_gold_3   'd'

extern Map_ObjectKind *ConcreteMap_objectKinds;
  /** list of all object kinds occuring in map */

/* dimensions and other properties of map */
#define ConcreteMap_columnCount 28U
#define ConcreteMap_rowCount 16U

/*========================================*/

void ConcreteMap_initialize (void);
  /** initializes the data of the concrete map; should be called
      first */

/*--------------------*/

void ConcreteMap_finalize (void);
  /** cleans up the internal data of the concrete map; should be
      called finally */

/*--------------------*/

Map_ObjectKind ConcreteMap_abstractObjectKind (in Map_ObjectKind kind);
  /** returns the abstraction of the object kind <kind> (e.g. when
      different object kinds represent the states of an animated
      object they have one parent representative object kind) */

/*--------------------*/

void ConcreteMap_loadLevel (in UINT8 level);
  /** loads the map with information for <level> */

#endif /* __CONCRETEMAP_H */
