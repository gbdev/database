/** Preferences module --
    This module provides all services for handling user specific
    options in a GameBoy game.

    Original version by Thomas Tensi, 2005-09
*/

#ifndef __PREFERENCES_H
#define __PREFERENCES_H

/*========================================*/

#include <gbextended/palette.h>
#include <gbextended/types.h>
#include "player.h"

/*========================================*/

#define Preferences_maxNameLength 8
#define Preferences_userCount 8

typedef struct {
  UINT8 level;  /* level this user has completed */
  char name[Preferences_maxNameLength+1];
  Player_Kind playerKind;
  Boolean isEasyMode;   /* flag to tell that shooting is not possible and 
			   the monsters are friendly */
  Boolean musicIsOn;
  Boolean soundIsOn;
  Palette_Colour hairColour;
  Palette_Colour topClothingColour;
  Palette_Colour bottomClothingColour;
  Palette_Colour shoeAndGunColour;
  Palette_Colour opponentColour;
} Preferences_UserData;

extern Preferences_UserData Preferences_currentUserData;

/*========================================*/

void Preferences_initialize (void);
  /* initializes the module by getting the data for all users */

/*--------------------*/

void Preferences_finalize (void);
  /* finalizes the module data */

/*--------------------*/

void Preferences_queryForName (void);
  /* asks the user for his name and sets <currentUserData> */

/*--------------------*/

void Preferences_getNameAndLevel (in UINT8 i,
				  out char *name, out UINT8 *level);
  /* returns <name> and <level> for user <i> */

/*--------------------*/

void Preferences_queryForSetup (void);
  /* asks the user for his setup parameters */

/*--------------------*/

void Preferences_storeUserData (void);
  /* stores <currentUserData> data permanently */

#endif /* __PREFERENCES_H */
