/** Concrete Map Animation module --
    This module provides all services for handling animations
    on the map of a concrete GameBoy game.

    Original version by Thomas Tensi, 2006-02
*/

#ifndef __CONCRETEMAPANIMATION_H
#define __CONCRETEMAPANIMATION_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/types.h>

/*========================================*/

typedef enum {
  ConcreteMapAnimation_Kind_destroyedBrick,
  ConcreteMapAnimation_Kind_noneLeft,
  ConcreteMapAnimation_Kind_oneLeft,
  ConcreteMapAnimation_Kind_twoLeft,
  ConcreteMapAnimation_Kind_threeLeft
} ConcreteMapAnimation_Kind;
  /* supported map animations */

/*========================================*/

void ConcreteMapAnimation_initialize (void);
  /** initializes the map animation data for the concrete game; should
      be called first */

/*--------------------*/

void ConcreteMapAnimation_finalize (void);
  /** cleans up the internal map animation data; should be called
      finally */

/*--------------------*/

void ConcreteMapAnimation_start (readonly Map_Position *position,
				 in ConcreteMapAnimation_Kind kind);
  /** starts animation of <kind> at <position> */

#endif /* __CONCRETEMAPANIMATION_H */

