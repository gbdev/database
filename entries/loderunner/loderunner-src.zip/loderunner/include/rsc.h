/** Ressource module --
    This module provides services for encapsulating the culture
    specific parts of a GameBoy game (like icons or strings).

    Those culture specific parts are called ressources and are
    identified by a unique number.

    Complex data structures like string lists are serialized.  That
    means that all information is returned in a byte sequence, where
    the first part contains the list pointers, and the data is
    contained after the pointers.

    Original version by Thomas Tensi, 2005-09
*/

#ifndef __RSC_H
#define __RSC_H

/*========================================*/

#include <gbextended/sound.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

typedef enum {
  Rsc_Game_L_choiceList,
  Rsc_Game_M_completed,
  Rsc_Game_M_enteredLevel,
  Rsc_Game_M_failed,
  Rsc_Game_M_help,
  Rsc_Game_M_highscore,
  Rsc_Game_M_info,
  Rsc_Game_M_title,
  Rsc_Game_M_titleEnd,
  Rsc_Opponent_BA_tileBitmaps,
  Rsc_Player_BA_tileBitmapsBoy,
  Rsc_Player_BA_tileBitmapsGirl,
  Rsc_Preferences_L_booleanNameList,
  Rsc_Preferences_L_choiceList1,
  Rsc_Preferences_L_choiceList2,
  Rsc_Preferences_L_colourNameList,
  Rsc_Preferences_L_colourList,
  Rsc_Preferences_L_playerKindNameList,
  Rsc_Preferences_L_setupItemList,
  Rsc_Preferences_L_yesNoList,
  Rsc_Preferences_M_greeting,
  Rsc_Preferences_M_nameQuery,
  Rsc_Preferences_M_resetQuery,
  Rsc_Preferences_M_setupTitle
} Rsc_Type;

/*========================================*/

void Rsc_initialize (void);
  /** initializes the data. Should be called first. */

/*--------------------*/

void Rsc_finalize (void);
  /** cleans up the internal data. Should be called finally. */

/*--------------------*/

void Rsc_getBitmap (in Rsc_Type ressource, in UINT8 i,
		    out Tile_Bitmap *bitmap);
  /** returns associated entry of bitmap array <ressource> with
      index <i> in <bitmap> */ 

/*--------------------*/

void Rsc_getInteger (in Rsc_Type ressource, out UINT16 *i);
  /** returns associated integer for <ressource> in <i> */ 

/*--------------------*/

void Rsc_getIntegerList (in Rsc_Type ressource, in UINT16 maxSize,
			 out UINT16 *integerPointerList[]);
  /** returns NULL-terminated associated <integerPointerList> for
      <ressource>; the size of list information plus data must be
      bounded by <maxSize>  */ 

/*--------------------*/

void Rsc_getString (in Rsc_Type ressource, in UINT16 maxSize,
		    out String_Type st);
  /** returns associated string for <ressource> in <st> where
      <maxSize> give the maximum allowed length for <st> (including
      the string terminator) */ 

/*--------------------*/

void Rsc_getStringList (in Rsc_Type ressource, in UINT16 maxSize,
			out String_List stringList);
  /** returns NULL-terminated associated <stringList> for <ressource>;
      the size of list information plus data must be bounded by
      <maxSize> */

/*--------------------*/

void Rsc_resetSong (void);
  /** resets song to the beginning */

/*--------------------*/

void Rsc_getSongEvent (out Sound_DeltaTime *deltaTime,
		       out Sound_Event *event,
		       out Boolean *isDone);
  /** returns next event of song for all active tracks in <event> by
      merging all track event lists; the time offset to this event is
      returned in <deltaTime>; <isDone> tells that no further event
      occurs in song */

/*--------------------*/

void Rsc_expand1 (inout String_Type st, in String_Type replacement1,
		  in UINT16 maxSize);
  /** replaces occurences of %1 in <st> by <replacement1>; if
      resulting length (including string terminator) exceeds
      <maxSize>, an error occurs */ 

/*--------------------*/

void Rsc_expand2 (inout String_Type st, in String_Type replacement1,
		  in String_Type replacement2, in UINT16 maxSize);
  /** replaces occurences of %1 in <st> by <replacement1> and
      occurences of %2 by <replacement2>; if resulting length
      (including string terminator) exceeds <maxSize>, an error
      occurs */ 

#endif /* __RSC_H */
