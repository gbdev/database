/** ConcreteMusic module --
    This module provides all services for handling music in a concrete
    GameBoy game.

    Original version by Thomas Tensi, 2005-10
*/

#ifndef __CONCRETEMUSIC_H
#define __CONCRETEMUSIC_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

void ConcreteMusic_initialize (void);
  /* initializes the music data; should be called first */

/*--------------------*/

void ConcreteMusic_finalize (void);
  /* cleans up the internal music data. Should be called finally. */

/*--------------------*/

void ConcreteMusic_start (void);
  /* starts playing the music for this game */

/*--------------------*/

void ConcreteMusic_stop (void);
  /* stops playing music for this game */

/*--------------------*/

void ConcreteMusic_addEvent (void);
  /* handles a tick event by putting another sound event into the
     sound event queue */

#endif /* __CONCRETEMUSIC_H */
