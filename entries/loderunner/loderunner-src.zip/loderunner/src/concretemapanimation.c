/** Concrete Map Animation module --
    Implementation of module providing all services for handling the
    concrete map animation of a GameBoy game. It relies on the map
    animation framework.

    Original version by Thomas Tensi, 2006-02
*/


#include "concretemapanimation.h"

/*========================================*/

#include "concretemap.h"
#include <gbextended/mapanimation.h>

/*========================================*/

static const MapAnimation_Phase ConcreteMapAnimation__destroyedBrick[] = {
  //  { -90, ConcreteMap_ObjectKind_brick  },
  { -85, ConcreteMap_ObjectKind_hole   },
  { -12, ConcreteMap_ObjectKind_hole_1 },
  {  -6, ConcreteMap_ObjectKind_hole_2 },
  {   0, ConcreteMap_ObjectKind_brick  }
};

static const MapAnimation_Phase ConcreteMapAnimation__gold0[] = {
  { -15, ConcreteMap_ObjectKind_gold_0 },
  { -13, ConcreteMap_ObjectKind_empty  },
  { -12, ConcreteMap_ObjectKind_gold_0 },
  { -10, ConcreteMap_ObjectKind_empty  },
  {  -9, ConcreteMap_ObjectKind_gold_0 },
  {  -7, ConcreteMap_ObjectKind_empty  },
  {  -6, ConcreteMap_ObjectKind_gold_0 },
  {   0, ConcreteMap_ObjectKind_empty  }
};

static const MapAnimation_Phase ConcreteMapAnimation__gold1[] = {
  { -15, ConcreteMap_ObjectKind_gold_1 },
  {   0, ConcreteMap_ObjectKind_empty  }
};

static const MapAnimation_Phase ConcreteMapAnimation__gold2[] = {
  { -15, ConcreteMap_ObjectKind_gold_2 },
  {   0, ConcreteMap_ObjectKind_empty  }
};

static const MapAnimation_Phase ConcreteMapAnimation__gold3[] = {
  { -15, ConcreteMap_ObjectKind_gold_3 },
  {   0, ConcreteMap_ObjectKind_empty  }
};

/*========================================*/

void ConcreteMapAnimation_initialize (void)
{
}

/*--------------------*/

void ConcreteMapAnimation_finalize (void)
{
}

/*--------------------*/

void ConcreteMapAnimation_start (readonly Map_Position *position,
				 in ConcreteMapAnimation_Kind kind)
{
  MapAnimation_Schedule schedule;

  switch (kind) {
    case ConcreteMapAnimation_Kind_destroyedBrick:
      schedule = ConcreteMapAnimation__destroyedBrick;  break;
    case ConcreteMapAnimation_Kind_threeLeft:
      schedule = ConcreteMapAnimation__gold3;  break;
    case ConcreteMapAnimation_Kind_twoLeft:
      schedule = ConcreteMapAnimation__gold2;  break;
    case ConcreteMapAnimation_Kind_oneLeft:
      schedule = ConcreteMapAnimation__gold1;  break;
    case ConcreteMapAnimation_Kind_noneLeft:
      schedule = ConcreteMapAnimation__gold0;  break;
  }

  MapAnimation_start(position, schedule);
}
