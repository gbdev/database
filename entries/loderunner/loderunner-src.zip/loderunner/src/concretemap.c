/** Concrete Map Module --
    Implementation of module providing all services for handling the
    concrete map of a GameBoy game. It relies on the map framework.

    Original version by Thomas Tensi, 2005-05
*/

#include "concreteMap.h"

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/matrix.h>
#include "maplevel.h"
#include <gbextended/types.h>

/*========================================*/

#define ConcreteMap__columnsAreCircular false
#define ConcreteMap__rowsAreCircular false

Map_ObjectKind *ConcreteMap_objectKinds = ".XTHh#~+-$O12abcd";

#define ConcreteMap__size \
  Matrix_size(ConcreteMap_rowCount, (ConcreteMap_columnCount+1), \
              Map_ObjectKind)
/** the matrix contains <rowCount> rows with <columnCount> objects and
    a terminating 0-object */

static Map_ObjectKind ConcreteMap__data[ConcreteMap__size];
  /** matrix of all static objects; it may be modified via
      Map_setEntry */

/*========================================*/
/*=====       LOCAL DEFINITIONS      =====*/
/*========================================*/

static Map_ObjectKind ConcreteMap__abstractObjectKind (
					       inout Map_ObjectKind kind)
{
  switch (kind) {
    case ConcreteMap_ObjectKind_hole_1:
    case ConcreteMap_ObjectKind_hole_2:
      kind = ConcreteMap_ObjectKind_hole;
      break;
    case ConcreteMap_ObjectKind_gold_0:
    case ConcreteMap_ObjectKind_gold_1:
    case ConcreteMap_ObjectKind_gold_2:
    case ConcreteMap_ObjectKind_gold_3:
      kind = ConcreteMap_ObjectKind_empty;
      break;
  }
  return kind;
}

/*========================================*/
/*=====     EXPORTED DEFINITIONS     =====*/
/*========================================*/

void ConcreteMap_initialize (void)
{
  Map_define(ConcreteMap_columnCount, ConcreteMap_rowCount,
	     ConcreteMap__columnsAreCircular, ConcreteMap__rowsAreCircular,
	     ConcreteMap_objectKinds, (Map_ObjectKind **) ConcreteMap__data,
	     ConcreteMap__abstractObjectKind);
}

/*--------------------*/

void ConcreteMap_finalize (void)
{
}

/*--------------------*/

void ConcreteMap_loadLevel (in UINT8 level)
{
  MapLevel_load(level, ConcreteMap__data);
}
