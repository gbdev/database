/** Opponent module --
    Implementation of module providing all services for handling the
    opponent objects in a GameBoy game.

    Original version by Thomas Tensi, 2005-08
*/


#include "opponent.h"

/*========================================*/

#include "concretemap.h"
#include <gbextended/map.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/palette.h>
#include "rsc.h"
#include <gbextended/screen.h>
#include <gbextended/sprite.h>
#include <gbextended/spriteanimation.h>
#include <gbextended/types.h>

/*========================================*/

#define Opponent__tileCount 4

static Screen_Coordinate Opponent__maxX, Opponent__maxY;

typedef UINT8 Opponent__Duration;
  /** duration in ticks */
#define Opponent__Duration_infinite 0
#define Opponent__Duration_carrying 255
  /** duration how long an opponent carries a treasure */
#define Opponent__Duration_blocked 255
  /** duration how long an opponent may not carry a treasure
      after having realeased one */

typedef struct {
  Sprite_Type sprite;  /* representing opponent figure */

  /* additional variables for the carrying state */
  Opponent_State state;
  Opponent__Duration stateDuration;
} Opponent__Descriptor;
/** contains the specific data for a single opponent */

static Opponent__Descriptor Opponent__data[Opponent_maxCount];
  /* containing all opponent figures */

/*--------------------*/

/* contains the colours for the tiles used by the opponents */
static Palette_Data Opponent__palettes[] = {
  { Palette_Colour_white, 495, 25, Palette_Colour_red },
  { Palette_Colour_white, 495, 25, Palette_Colour_red }
};

static Sprite_Offset Opponent__offsets[] = {
  { 0,  8}, { 8,  8}, { 0, 16}, { 8, 16}
};


typedef Tile_Type Opponent__TileVector[Opponent__tileCount];
typedef Tile_Attribute Opponent__AttributeVector[Opponent__tileCount];

#define Opponent__firstTileIndex 50
  /** position in tile table of first tile for opponent */

/*----------------------------------------*/
/* Schedule 1: running right */

static const Opponent__TileVector Opponent__S1_bitmaps[] = {
  { Opponent__firstTileIndex, Opponent__firstTileIndex,
    Opponent__firstTileIndex+2, Opponent__firstTileIndex+3 },
  { Opponent__firstTileIndex+1, Opponent__firstTileIndex+1,
    Opponent__firstTileIndex+3, Opponent__firstTileIndex+2 }
};

static const Opponent__AttributeVector Opponent__S1_attributes[] = { 
  { 0+4, 32+4,  0+4, 32+4 },
  { 0+4, 32+4,  0+4, 32+4 }
};

static const SpriteAnimation_Phase Opponent__S1_phases[] = {
  { 4, (Tile_Type *)&Opponent__S1_bitmaps[0][0],
       (Tile_Attribute *)&Opponent__S1_attributes[0][0],
       Opponent__offsets },
  { 4, (Tile_Type *)&Opponent__S1_bitmaps[1][0],
       (Tile_Attribute *)&Opponent__S1_attributes[1][0],
       Opponent__offsets }
};

static const SpriteAnimation_Schedule Opponent__S1_schedule = {
  2, (SpriteAnimation_Phase *)Opponent__S1_phases
};


/* schedule for an opponent which is carrying a treasure (only differs
   in palette selection) */
static const Opponent__AttributeVector Opponent__S2_attributes[] = { 
  { 1+4, 33+4,  1+4, 33+4 },
  { 1+4, 33+4,  1+4, 33+4 }
};

static const SpriteAnimation_Phase Opponent__S2_phases[] = {
  { 4, (Tile_Type *)&Opponent__S1_bitmaps[0][0],
       (Tile_Attribute *)&Opponent__S2_attributes[0][0],
       Opponent__offsets },
  { 4, (Tile_Type *)&Opponent__S1_bitmaps[1][0],
       (Tile_Attribute *)&Opponent__S2_attributes[1][0],
       Opponent__offsets }
};

static const SpriteAnimation_Schedule Opponent__S2_schedule = {
  2, (SpriteAnimation_Phase *)Opponent__S2_phases
};


/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static GameObject_Action Opponent__findPreferredAction (
				in Boolean isHorizontalDimension,
				readonly Map_Position *position,
				readonly Map_Position *targetPosition,
				in GameObject_Action actionA,
				in GameObject_Action actionB,
				out MapCoordinate_Type *distance)
  /** finds a preferred move action in a single dimension defined by
      <isHorizontalDimension> for moving from <position> towards
      <targetPosition>; possible actions are <actionA> (when
      coordinate of <position> is greater than <targetPosition>),
      <actionB> (when coordinate of <position> is smaller than
      <targetPosition>) and <GameObject_Action_none> when both are
      equal; the coordinate distance between <position> and
      <targetPosition> is returned in <distance>; the routine checks
      whether movement is unblocked, otherwise <distance> is set to 0
      and <GameObject_Action_none> is returned as action
  */
{
  MapCoordinate_Type temp;
  GameObject_Action result;
  Boolean isSubtractiveDirection = false;
  UINT8 affectedDimension;
  MapCoordinate_Type currentCoordinate;
  MapCoordinate_Type targetCoordinate;

  if (isHorizontalDimension) {
    currentCoordinate = position->x;
    targetCoordinate = targetPosition->x;
    affectedDimension = 0;
  } else {
    currentCoordinate = position->y;
    targetCoordinate = targetPosition->y;
    affectedDimension = 1;
  }

  if (currentCoordinate > targetCoordinate) {
    result = actionA;
    temp = currentCoordinate;  currentCoordinate = targetCoordinate; 
    targetCoordinate = temp;
    isSubtractiveDirection = true;
  } else if (currentCoordinate < targetCoordinate) {
    result = actionB;
    isSubtractiveDirection = false;
  } else {
    result = GameObject_Action_none;
  }

  *distance = MapCoordinate_addOperation(targetCoordinate, currentCoordinate,
					 true);

  if (*distance != 0) {
    MapCoordinate_Type *coordinatePtr;
    MapCoordinate_Type delta;
    Boolean isBlocked;
    Map_ObjectKind neighbourObjectKind;
    MapCoordinate_VectorArrayUnion neighbourPosition;
    UINT8 otherDimension;
    MapCoordinate_VectorArrayUnion supportingPosition;

    STRUCT_ASSIGN(supportingPosition.vector, *position);

    otherDimension = 1 - affectedDimension;
    coordinatePtr = &(supportingPosition.array[otherDimension]);
    *coordinatePtr = MapCoordinate_addOperation(*coordinatePtr,
						MapCoordinate_subunitCount / 2,
						false);

    STRUCT_ASSIGN(neighbourPosition.vector, supportingPosition.vector);

    if (isSubtractiveDirection) {
      delta = 1;
    } else {
      delta = MapCoordinate_subunitCount;
    }

    coordinatePtr = &(neighbourPosition.array[affectedDimension]);
    *coordinatePtr = MapCoordinate_addOperation(*coordinatePtr, delta,
						isSubtractiveDirection);

    /* check whether <neighbourPosition> is blocked */
    neighbourObjectKind = Map_getEntry(&neighbourPosition.vector);

    isBlocked = (neighbourObjectKind == ConcreteMap_ObjectKind_brick
		 || neighbourObjectKind == ConcreteMap_ObjectKind_concrete);

    if (!isBlocked && result == GameObject_Action_climbUp) {
      /* going up is only allowed when standing on a ladder */
      Map_ObjectKind supportingObjectKind;
/*    Boolean neighbourIsOkay; */

      coordinatePtr = &(supportingPosition.array[affectedDimension]);
      *coordinatePtr = MapCoordinate_addOperation(*coordinatePtr,
						MapCoordinate_subunitCount - 1,
						false);
      supportingObjectKind = Map_getEntry(&supportingPosition.vector);

/*    neighbourIsOkay = (neighbourObjectKind == ConcreteMap_ObjectKind_empty */
/*      || neighbourObjectKind == ConcreteMap_ObjectKind_rod */
/* 	|| neighbourObjectKind == ConcreteMap_ObjectKind_ladder); */

      isBlocked = (supportingObjectKind != ConcreteMap_ObjectKind_ladder);
      // || !neighbourIsOkay);
    }

    if (isBlocked) {
      *distance = 0;
      result = GameObject_Action_none;
    }
  }

  return result;
}

/*--------------------*/

static GameObject_Action Opponent__getNextAction (
			  in GameObject_Index opponent,
			  readonly Map_Position *position,
			  readonly Map_Position *playerPosition)
  /** returns the next action <opponent> will do based on his
      <position> and the <playerPosition> on map */
{
  /* try to minimize the distance of this opponent to player */
  MapCoordinate_Type distanceX;
  MapCoordinate_Type distanceY;
  GameObject_Action preferredXAction;
  GameObject_Action preferredYAction;
  GameObject_Action result;

  preferredXAction = Opponent__findPreferredAction(
					   true, position, playerPosition,
					   GameObject_Action_runLeft,
					   GameObject_Action_runRight,
					   &distanceX);

  preferredYAction = Opponent__findPreferredAction(
					   false, position, playerPosition,
					   GameObject_Action_climbUp,
					   GameObject_Action_climbDown,
					   &distanceY);


  if (distanceY != 0) {
    /* prefer vertical direction */
    result = preferredYAction;
  } else {
    result = preferredXAction;
  }
  
  return result;
}

/*--------------------*/

static void Opponent__handleTickEvent (in GameObject_Index opponent)
  /** tells that a new frame has occured */
{
  Opponent__Descriptor *opponentData = &Opponent__data[opponent];
  Opponent_State state = opponentData->state;
  Opponent__Duration stateDuration = opponentData->stateDuration;

  SpriteAnimation_handleTickEvent(opponentData->sprite);

  if (stateDuration == Opponent__Duration_infinite) {
    /* nothing has to happen */
  } else {
    /* count down finite duration */
    stateDuration--;
    opponentData->stateDuration = stateDuration;

    if (stateDuration == 0) {
      /* do a state transition when reaching zero */
      if (state == Opponent_State_carrying) {
	state = Opponent_State_dropping;
      } else if (state == Opponent_State_blocked) {
	state = Opponent_State_unblocked;
      }
      opponentData->state = state;
      opponentData->stateDuration = Opponent__Duration_infinite;
    }
  }
}

/*--------------------*/

static void Opponent__move (in GameObject_Index opponent,
			    inout Screen_Coordinate *x,
			    inout Screen_Coordinate *y)
  /** puts <opponent> to absolute screen position (<x>,<y>); adjusts
      coordinates when out of bounds */
{
  Sprite_moveAbsolute(Opponent__data[opponent].sprite, *x, *y);
}

/*--------------------*/

static void Opponent__setAnimation (in GameObject_Index opponent,
				    in GameObject_Action animationKind)
  /** defines the <animationKind> the <opponent> will do; when the
      kind of animation has changed, the new one starts in the next
      frame, otherwise the previous simply continues */
{
  SpriteAnimation_Schedule *schedule;
  Opponent__Descriptor *opponentData = &Opponent__data[opponent];
  Opponent_State state = opponentData->state;

  if (state >= Opponent_State_blocked) {
    schedule = (SpriteAnimation_Schedule *) &Opponent__S1_schedule;
  } else {
    schedule = (SpriteAnimation_Schedule *) &Opponent__S2_schedule;
  }

  SpriteAnimation_setSchedule(opponentData->sprite, schedule, false);
}

/*--------------------*/

static void Opponent__setAnimationState (in GameObject_Index opponent,
					 in Boolean isPaused)
  /** pauses or continues animation of <opponent> */
{
  SpriteAnimation_setState(Opponent__data[opponent].sprite, isPaused);
}


/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

GameObject_TypeDescriptor Opponent_typeDescriptor = {
  (MapCoordinate_subunitCount / 4), ConcreteMap_ObjectKind_opponent, false,
  &Opponent__setAnimation, &Opponent__setAnimationState, &Opponent__move,
  &Opponent_hide, &Opponent__handleTickEvent, &Opponent__getNextAction
};
  /* could be const, but will be put in RAM for space reasons */

/*--------------------*/

void Opponent_initialize (void)
{ 
  GameObject_Index i;
  UINT8 j;

  for (j = 0;  j != 4;  j++) {
    Tile_Bitmap tileBitmap;
    Rsc_getBitmap(Rsc_Opponent_BA_tileBitmaps, j, &tileBitmap);
    Tile_SpriteBitmaps_write(Opponent__firstTileIndex+j, 1, &tileBitmap);
  }

  Palette_setSpritePalettes(4, 2, Opponent__palettes);

  /* make the sprites */
  for (i = 0;  i != Opponent_maxCount;  i++) {
    Opponent__Descriptor *opponentData = &Opponent__data[i];
    opponentData->sprite = Sprite_make(Opponent__tileCount);
    SpriteAnimation_setSchedule(opponentData->sprite, &Opponent__S1_schedule, 
				true);
  }

  Sprite_getMaxCoordinates(Opponent__data[0].sprite,
			   &Opponent__maxX, &Opponent__maxY);
}

/*--------------------*/

void Opponent_finalize (void)
{
}

/*--------------------*/

void Opponent_resetAllVariantData (void)
{
  GameObject_Index i;

  for (i = 0;  i != Opponent_maxCount;  i++) {
    Opponent__Descriptor *opponentData = &Opponent__data[i];
    opponentData->state = Opponent_State_unblocked;
    opponentData->stateDuration = 0;
  }
}

/*--------------------*/

void Opponent_setAppearance (in Palette_Colour colour)
{
  Palette_Colour inverseColour = Palette_Colour_white - colour;  
  Opponent__palettes[0][3] = colour;
  Opponent__palettes[1][3] = inverseColour;
  Palette_setSpritePalettes(4, 2, Opponent__palettes);
}

/*--------------------*/

void Opponent_hide (in GameObject_Index opponent)
  /** makes <opponent> invisible */
{
  Sprite_hide(Opponent__data[opponent].sprite);
}

/*--------------------*/

Opponent_State Opponent_state (in GameObject_Index opponent)
{
  return Opponent__data[opponent].state;
}

/*--------------------*/

void Opponent_setState (in GameObject_Index opponent,
			in Opponent_State state)
{
  Opponent__Descriptor *opponentData = &Opponent__data[opponent];  
  Opponent__Duration stateDuration = Opponent__Duration_infinite;
  Boolean animationIsChanged = false;

  if (state == Opponent_State_carrying) {
    stateDuration = Opponent__Duration_carrying;
    animationIsChanged = true;
  } else if (state == Opponent_State_blocked) {
    stateDuration = Opponent__Duration_blocked;
    animationIsChanged = true;
  }

  opponentData->state = state;
  opponentData->stateDuration = stateDuration;

  if (animationIsChanged) {
    Opponent__setAnimation(opponent, GameObject_Action_none);
  }
}
