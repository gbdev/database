/** Preferences module --
    Implementation of module providing all services for handling user
    specific options in the LodeRunner GameBoy game.

    Original version by Thomas Tensi, 2005-09
*/

#include "preferences.h"

/*========================================*/

/* Gameboy modules */
#include <gbextended/dialog.h>
#include <gbextended/string.h>
#include <gbextended/types.h>

#include "player.h"
#include "rsc.h"

#include <gbextended/bugfix.h>

/*========================================*/

static UINT8 Preferences__user;
static UINT8 Preferences_level;

#define Preferences__magicConstant 0x12345678

#ifndef WINDOWS
static UINT32 at 0xB800 Preferences__magic;

static Preferences_UserData at 0xB804 Preferences__userData
                                        [Preferences_userCount];
#else
static UINT32 Preferences__magic;

static Preferences_UserData Preferences__userData
                                        [Preferences_userCount];
#endif

static const Preferences_UserData Preferences__defaultUserData = {
  /* level */ 0,
  /* name */ "_",
  /* playerKind */ Player_Kind_girl1,
  /* isEasyMode */ false,
  /* musicIsOn */ true,
  /* soundIsOn */ true,
  /* hairColour */ Palette_Colour_brown,
  /* topClothingColour */ Palette_Colour_green,
  /* bottomClothingColour */ Palette_Colour_red,
  /* shoeAndGunColour */ Palette_Colour_brown,
  /* opponentColour */ Palette_Colour_blue
};

Preferences_UserData Preferences_currentUserData;
  /** preferences for currently active user */

#define Preferences__bnBufferLength 30
static char Preferences__booleanNameBuffer[Preferences__bnBufferLength];
static char **Preferences__booleanNameList =
                       (char **)Preferences__booleanNameBuffer;
  /** list of canonical names for booleans */

#define Preferences__cnBufferLength 100
static char Preferences__colourNameBuffer[Preferences__cnBufferLength];
static char **Preferences__colourNameList =
                       (char **)Preferences__colourNameBuffer;
  /** list of canonical names for colours */

#define Preferences__pknBufferLength 20
static char Preferences__playerKindNameBuffer[Preferences__pknBufferLength];
static char **Preferences__playerKindNameList = 
                       (char **)Preferences__playerKindNameBuffer;
  /** list of canonical names for player kinds */

#define Preferences__colourBufferLength 50
static char Preferences__colourBuffer[Preferences__colourBufferLength];
static Palette_Colour **Preferences__colourList =
                       (Palette_Colour **)Preferences__colourBuffer;
  /** list of RGB values for canonical colours */

static UINT8 Preferences__colourListLength;


#define Preferences__tempBufferLength 150
static char Preferences__tempBuffer[Preferences__tempBufferLength];


static char Preferences__userName[Preferences_maxNameLength + 2];
#define Preferences__cursorCharacter '>'
#define Preferences__undefinedCursor (-11)
INT8 Preferences__userNameCursor;
  /** cursor position when editing user name */

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static Dialog_ItemResult Preferences__handleSelection (in Joypad_Key key,
					     inout String_Type *value,
					     in String_List stringList)
{
  UINT16 position;
  Dialog_ItemResult result;

  position = String_findInList(*value, stringList);

  if (position == String_notFound) {
    position = 0;
  }

  if (key != Joypad_Key_left && key != Joypad_Key_right) {
    result = Dialog_ItemResult_done;
  } else {
    String_Type previousValue = *value;

    if (key == Joypad_Key_left && position != 0) {
      position--;
    } else if (key == Joypad_Key_right) {
      position++;
    }
    
    *value = stringList[position];

    if (*value == NULL) {
      *value = previousValue;
    }

    result = Dialog_ItemResult_processing;
  }

  return result;
}

/*--------------------*/

static Dialog_ItemResult Preferences__handleBoolean (in Joypad_Key key,
						     inout String_Type *value)
{
  return Preferences__handleSelection(key, value,
				      Preferences__booleanNameList);
}

/*--------------------*/

static Dialog_ItemResult Preferences__handleColour (in Joypad_Key key,
						    inout String_Type *value)
{
  return Preferences__handleSelection(key, value,
				      Preferences__colourNameList);
}

/*--------------------*/

static Dialog_ItemResult Preferences__handlePlayerKind (in Joypad_Key key,
						      inout String_Type *value)
{
  return Preferences__handleSelection(key, value,
				      Preferences__playerKindNameList);
}

/*--------------------*/

static char Preferences__nextNameChar (in char currentChar, in INT8 delta)
  /** returns next character in name character sequence */
{
  String_Type Preferences__nameCharacters =
    " ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
  UINT8 lastNameCharacterPosition =
    String_length(Preferences__nameCharacters) - 1;
  UINT16 p = String_findCharacter(Preferences__nameCharacters, currentChar);
  INT16 position;

  if (p == String_notFound) {
    position = 0;
  } else {
    position = p;
  }

  position += delta;

  /* adjust to range */
  if (position < 0) {
    position = lastNameCharacterPosition;
  } else if (position > lastNameCharacterPosition) {
    position = 0;
  }

  return Preferences__nameCharacters[position];
}

/*--------------------*/

static void Preferences__removeCursor (inout String_Type st)
  /** removes any existing cursor in <st>  */
{
  static char pattern[2] = {Preferences__cursorCharacter, 0};
  String_globalReplace(st, pattern, "", Preferences_maxNameLength);
}

/*--------------------*/

static void Preferences__insertCursor (inout String_Type st,
				       in INT8 cursorPosition)
  /** sets a new cursor in <st> at <cursorPosition> */
{
  Preferences__removeCursor(st);

  if (cursorPosition >= 0) { 
    UINT8 length = Preferences_maxNameLength - cursorPosition;
    char *ptr = &st[cursorPosition];
    String_memoryMove(ptr + 1, ptr, length);
    *ptr = Preferences__cursorCharacter;
  }
}

/*--------------------*/

static Dialog_ItemResult Preferences__handleUserName (in Joypad_Key key,
						      inout String_Type *value)
{
  Boolean isDone = false;
  INT8 cursor = Preferences__userNameCursor;

  /* process key */
  if (key == Joypad_Key_a || key == Joypad_Key_b) {
    isDone = true;
  } else if (key == Joypad_Key_left || key == Joypad_Key_right) {
    if (cursor == Preferences__undefinedCursor) {
      cursor = 0;
    } else if (key == Joypad_Key_left) {
      cursor--;
      if (cursor < 0) {
	cursor = Preferences__undefinedCursor;
      }
    } else {
      cursor++;
      if (cursor > Preferences_maxNameLength) {
	cursor = Preferences_maxNameLength;
      }
    }

    Preferences__userNameCursor = cursor;
    isDone = (cursor == Preferences__undefinedCursor
	      || cursor == Preferences_maxNameLength);

    if (!isDone) {
      Preferences__insertCursor(*value, cursor);
    }
  } else if (key == Joypad_Key_up || key == Joypad_Key_down) {
    isDone = false;
    if (cursor >= 0 && cursor < Preferences_maxNameLength) {
      /* this is a correct cursor position */
      String_Type chPtr = &(*value)[cursor+1];
      INT8 delta = (key == Joypad_Key_up ? 1 : -1);

      *chPtr = Preferences__nextNameChar(*chPtr, delta);
      Preferences__userName[Preferences_maxNameLength + 1] = String_terminator;
    }
  }

  /* remove cursor when done */
  if (isDone) {
    Preferences__removeCursor(*value);
  }

  return (isDone ? Dialog_ItemResult_done : Dialog_ItemResult_processing);
}

/*--------------------*/

static char *Preferences__booleanToString (in Boolean b)
  /** maps <b> to external representation  */
{
  return Preferences__booleanNameList[(b ? 1 : 0)];
}

/*--------------------*/

static char *Preferences__colourToString (in Palette_Colour c)
  /** looks up colour name of colour <c> in <colourList> */
{
  UINT8 i = 0;
  Boolean isSearching = true;

  do {
    Palette_Colour *colourPointer = Preferences__colourList[i];
    if (colourPointer == NULL) {
      i = 0;
      isSearching = false;
    } else if (*colourPointer == c) {
      isSearching = false;
    } else {
      i++;
    }
  } while (isSearching);

  return Preferences__colourNameList[i];
}

/*--------------------*/

static char *Preferences__playerKindToString (in Player_Kind playerKind)
  /** maps <playerKind> to external representation  */
{
  return Preferences__playerKindNameList[playerKind];
}

/*--------------------*/

static Boolean Preferences__stringToBoolean (in String_Type st)
  /** returns boolean for external representation <st>; it is assumed
      that the pointer provided points into list of available
      booleans */
{
  return (st == Preferences__booleanNameList[1]);
}

/*--------------------*/

static Palette_Colour Preferences__stringToColour (in String_Type st)
  /** maps external representation <st> to RGB colour; it is assumed
      that the pointer provided points into list of available
      colours */
{
  Palette_Colour result;
  UINT16 index = String_findInList(st, Preferences__colourNameList);

  if (index == String_notFound) {
    result  = 0;
  } else {
    result = *Preferences__colourList[index];
  }

  return result;
}

/*--------------------*/

static Player_Kind Preferences__stringToPlayerKind (in String_Type st)
  /** maps <playerKind> to external representation */
{
  UINT16 index = String_findInList(st, Preferences__playerKindNameList);

  if (index == String_notFound) {
    index = 0;
  }

  return (Player_Kind) index;
}


/*========================================*/
/*            PUBLIC ROUTINES             */
/*========================================*/


void Preferences_initialize (void)
{
  UINT8 i;
  /* initialize module variables */
  Rsc_getIntegerList(Rsc_Preferences_L_colourList,
		     Preferences__colourBufferLength, Preferences__colourList);

  Rsc_getStringList(Rsc_Preferences_L_colourNameList,
		    Preferences__cnBufferLength, Preferences__colourNameList);

  Rsc_getStringList(Rsc_Preferences_L_playerKindNameList,
		    Preferences__pknBufferLength,
		    Preferences__playerKindNameList);

  Rsc_getStringList(Rsc_Preferences_L_booleanNameList,
		    Preferences__bnBufferLength, Preferences__booleanNameList);

  for (i = 0;  Preferences__colourNameList[i] != NULL;  i++) {
  }

  Preferences__colourListLength = i;

  /* validate user preference data */
  if (Preferences__magic == Preferences__magicConstant) {
    /* fine */
  } else { 
    /* there is junk in the persistent data ==> reset it */
    UINT8 i;
    Preferences_UserData *userData = &Preferences__userData[0];

    for (i = 0;  i != Preferences_userCount;  i++) {
      STRUCT_ASSIGN(*userData, Preferences__defaultUserData);
      userData++;
    }
    Preferences__magic = Preferences__magicConstant;
  }
}

/*--------------------*/

void Preferences_finalize (void)
{
}

/*--------------------*/

#define Preferences__nameQueryLength 20
#define Preferences__titleLength 90

typedef enum { Preferences__DialogState_atUserSelection,
	       Preferences__DialogState_atActionSelection,
	       Preferences__DialogState_done
} Preferences__DialogState;


void Preferences_queryForName (void)
{
  Preferences__DialogState dialogState 
    = Preferences__DialogState_atUserSelection;

  while (dialogState != Preferences__DialogState_done) {
    char **choiceList = (char **)Preferences__tempBuffer;
    UINT8 i;
    Boolean isLongMenu;
    char levelNumber[16];
    UINT8 playerLevel;
    Rsc_Type ressourceID;
    char st[Preferences__nameQueryLength];
    char title[Preferences__titleLength];
    String_Type userNameList[Preferences_userCount + 1];
    enum { SelectionKind_continue, SelectionKind_reset,
           SelectionKind_changeSettings, SelectionKind_changeUser } selection;

    switch (dialogState) {
      case Preferences__DialogState_atUserSelection:
	/* collect all user names into list */
	for (i = 0;  i != Preferences_userCount;  i++) {
	  userNameList[i] = (char *) &(Preferences__userData[i].name);
	}

	userNameList[i] = NULL;
	Rsc_getString(Rsc_Preferences_M_nameQuery, 
		      Preferences__nameQueryLength, st);

	selection = Dialog_noSelection;
	while (selection == Dialog_noSelection) {
	 selection = Dialog_showChoice(st, userNameList);
	}

	Preferences__user = selection;
	STRUCT_ASSIGN(Preferences_currentUserData, 
		      Preferences__userData[selection]);
	dialogState = Preferences__DialogState_atActionSelection;
	break;

      case Preferences__DialogState_atActionSelection:
	playerLevel = Preferences_currentUserData.level + 1;
	String_makeFromInteger((UINT16)playerLevel, levelNumber, 10);
	Rsc_getString(Rsc_Preferences_M_greeting, Preferences__titleLength,
		      title);
	Rsc_expand2(title, Preferences_currentUserData.name, levelNumber,
		    Preferences__titleLength);

	isLongMenu = (playerLevel != 1);
	ressourceID = (isLongMenu ? Rsc_Preferences_L_choiceList1
		       : Rsc_Preferences_L_choiceList2);
	Rsc_getStringList(ressourceID, Preferences__tempBufferLength,
			  choiceList);
	selection = Dialog_showChoice(title, choiceList);

	dialogState = Preferences__DialogState_done;

        if (selection == SelectionKind_continue) {
	  /* fine, use the stored data */
	} else {
#ifndef WINDOWS
	  SDCCBUGFIX(isLongMenu);
#endif

	  if (!isLongMenu) {
	    selection++;
	  }

	  switch (selection) {
  	    case SelectionKind_reset:
	      /* confirm the reset */
	      Rsc_getString(Rsc_Preferences_M_resetQuery,
			    Preferences__titleLength, title);
	      Rsc_expand1(title, Preferences_currentUserData.name,
			  Preferences__titleLength);
	      Rsc_getStringList(Rsc_Preferences_L_yesNoList,
				Preferences__tempBufferLength, choiceList);
	      selection = Dialog_showChoice(title, choiceList);

	      if (selection == 1) {
		/* confirmed */
		Preferences_currentUserData.level = 0;
		Preferences_storeUserData();
	      }
	      dialogState = Preferences__DialogState_atActionSelection;
	      break;
	    case SelectionKind_changeSettings:
	      Preferences_queryForSetup();
	      dialogState = Preferences__DialogState_atActionSelection;
	      break;
 	    case SelectionKind_changeUser:
	      dialogState = Preferences__DialogState_atUserSelection;
	  }
	}
    }
  }

}

/*--------------------*/

void Preferences_getNameAndLevel (in UINT8 i,
				  out char *name, out UINT8 *level)
{
  char *namePtr = "";
  *level = 0;

  if (i < Preferences_userCount) {
    Preferences_UserData *userData = &Preferences__userData[i];
    namePtr = (char *) &(userData->name);
    *level = userData->level;
  }

  String_boundedCopy(name, namePtr, Preferences_maxNameLength + 1);
}

/*--------------------*/

#define Preferences__numberOfSetupLines 10
void Preferences_queryForSetup (void)
{  
  UINT16 blankPosition;
  Dialog_ItemRoutine itemRoutineList[Preferences__numberOfSetupLines];
  char **parameterList = (char **)Preferences__tempBuffer;
  String_Type selectionList[Preferences__numberOfSetupLines];
  char title[20];
  Preferences_UserData *userData = &Preferences_currentUserData;

  /* get the current settings into the selection list for a change */
  Preferences__userNameCursor = Preferences__undefinedCursor;
  selectionList[0] = (char *) &Preferences__userName;
  String_boundedCopy(Preferences__userName, userData->name,
		    Preferences_maxNameLength + 1);
  String_concatenate(Preferences__userName, "         ",
		     Preferences_maxNameLength + 2);
  selectionList[1] = Preferences__playerKindToString(userData->playerKind);
  selectionList[2] = Preferences__colourToString(userData->hairColour);
  selectionList[3] = Preferences__colourToString(userData->topClothingColour);
  selectionList[4] = Preferences__colourToString(
					userData->bottomClothingColour);
  selectionList[5] = Preferences__colourToString(userData->shoeAndGunColour);
  selectionList[6] = Preferences__colourToString(userData->opponentColour);
  selectionList[7] = Preferences__booleanToString(userData->musicIsOn);
  selectionList[8] = Preferences__booleanToString(userData->soundIsOn);

  Rsc_getString(Rsc_Preferences_M_setupTitle, 20, title);
  Rsc_getStringList(Rsc_Preferences_L_setupItemList,
		    Preferences__tempBufferLength, parameterList);

  itemRoutineList[0] = Preferences__handleUserName;
  itemRoutineList[1] = Preferences__handlePlayerKind;
  itemRoutineList[2] = Preferences__handleColour;
  itemRoutineList[3] = Preferences__handleColour;
  itemRoutineList[4] = Preferences__handleColour;
  itemRoutineList[5] = Preferences__handleColour;
  itemRoutineList[6] = Preferences__handleColour;
  itemRoutineList[7] = Preferences__handleBoolean;
  itemRoutineList[8] = Preferences__handleBoolean;
  itemRoutineList[9] = NULL;

  Dialog_showCascadedChoice(title, parameterList, itemRoutineList,
			    selectionList);
  
  /* put the changed settings back */
  blankPosition = String_findCharacter(Preferences__userName, ' ');
  if (blankPosition != String_notFound) {
    Preferences__userName[blankPosition] = String_terminator;
  }

  String_boundedCopy(userData->name, selectionList[0],
		     Preferences_maxNameLength + 1);
  userData->playerKind = Preferences__stringToPlayerKind(selectionList[1]);
  userData->hairColour = Preferences__stringToColour(selectionList[2]);
  userData->topClothingColour = Preferences__stringToColour(selectionList[3]);
  userData->bottomClothingColour = Preferences__stringToColour(selectionList[4]);
  userData->shoeAndGunColour = Preferences__stringToColour(selectionList[5]);
  userData->opponentColour = Preferences__stringToColour(selectionList[6]);
  userData->musicIsOn = Preferences__stringToBoolean(selectionList[7]);
  userData->soundIsOn = Preferences__stringToBoolean(selectionList[8]);
  Preferences_storeUserData();
}

/*--------------------*/

void Preferences_storeUserData (void)
{
  STRUCT_ASSIGN(Preferences__userData[Preferences__user],
		Preferences_currentUserData);
}
