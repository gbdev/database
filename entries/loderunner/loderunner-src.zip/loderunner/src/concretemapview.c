/** Concrete Map View Module --
    Implementation of odule providing all services for handling the
    concrete view on a map of a GameBoy game. It relies on the map
    view framework.

    Original version by Thomas Tensi, 2005-08
*/

#include "concretemapview.h"

/*========================================*/

#include <gbextended/background.h>
#include "concretemap.h"
#include <gbextended/mapview.h>
#include <gbextended/palette.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

/** some palette colours */
#define white      0x7FFF
#define brown      0x0116
#define darkBrown  0x052D
#define darkGrey   0x294A
#define grey       0x4631
#define lightGrey  0x6318
#define lightBrown 0x03F9
#define blue       0xC400

/* contains the bitmaps for the tiles used by map view */
static const Palette_Data ConcreteMapView__palettes[] = {
  { white, brown, grey, darkGrey },
  { white, lightGrey, grey, darkGrey },
  { white, darkBrown, lightBrown, blue }
};

static const INT8 ConcreteMapView__tileIndexOffset = -128;
  /** offset of tile indices for map view in global background tile
      table */

static const Tile_Bitmap ConcreteMapView__tileBitmaps[] = {
  { /* empty */
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 },
  { /* brick */
    0xFD,0x02,0xFD,0x02,0xFD,0x02,0x00,0xFF,
    0xBF,0x40,0xBF,0x40,0xBF,0x40,0x00,0xFF },
  { /* ladder (left) */ 
    0x50,0x30,0x50,0x30,0x5F,0x30,0x50,0x3F,
    0x5F,0x3F,0x50,0x30,0x50,0x30,0x50,0x30 },
  { /* ladder (right) */ 
    0x0A,0x06,0x0A,0x06,0xFA,0x06,0x02,0xFE,
    0xFE,0xFE,0x0A,0x06,0x0A,0x06,0x0A,0x06 },
  { /* concrete */
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
    0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x00,0xFF },
  { /* rod */
    0x00,0x00,0xFF,0x00,0x00,0xFF,0xFF,0xFF,
    0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00 },
  { /* gold left upper part */
    0x0F,0x00,0x07,0x00,0x07,0x00,0x0F,0x00,
    0x1C,0x03,0x10,0x0F,0x21,0x1F,0x22,0x1F },
  { /* gold left lower part */
    0x44,0x3F,0x4F,0x3F,0xC4,0x3F,0xCF,0x3F,
    0xE4,0x1F,0x62,0x1F,0x71,0x0F,0x3C,0x03 },
  { /* gold right upper part */
    0xF0,0x00,0xE0,0x00,0xE0,0x00,0xF0,0x00,
    0x38,0xC0,0x08,0xF0,0xC4,0xF8,0x24,0xF8 },
  { /* gold right lower part */
    0x02,0xFC,0xC2,0xFC,0x03,0xFC,0xC3,0xFC,
    0x07,0xF8,0x26,0xF8,0xCE,0xF0,0x3C,0xC0 },
  { /* coin with 0 */
    0x00,0x3C,0x3C,0x7E,0x66,0xFF,0x66,0xFF,
    0x66,0xFF,0x66,0xFF,0x66,0x7E,0x3C,0x3C },
  { /* coin with 1 */
    0x00,0x3C,0x1C,0x7E,0x3C,0xFF,0x6C,0xFF,
    0x0C,0xFF,0x0C,0xFF,0x0C,0x7E,0x1E,0x3E },
  { /* coin with 2 */
    0x00,0x3C,0x3C,0x7E,0x66,0xFF,0x0C,0xFF,
    0x18,0xFF,0x30,0xFF,0x7E,0x7E,0x00,0x3C },
  { /* coin with 3 */
    0x00,0x3C,0x3C,0x7E,0x66,0xFF,0x06,0xFF,
    0x1E,0xFF,0x06,0xFF,0x66,0x7E,0x3C,0x3C }
};

/*--------------------*/

/* mapping from tile types into attributes */
static const Tile_Attribute ConcreteMapView__tileToAttribute[] = {
  /*empty*/ 0,
  /*brick*/ 0,
  /*ladder (left)*/ 1,
  /*ladder (right)*/ 1,
  /*concrete*/ 1,
  /*rod*/ 1,
  /* gold LU */ 2,
  /* gold LL */ 2,
  /* gold RU */ 2,
  /* gold RL */ 2,
  /* coin 0 */ 2,
  /* coin 1 */ 2,
  /* coin 2 */ 2,
  /* coin 3 */ 2
};

/*--------------------*/

#define ConcreteMapView__tileColumnsPerCell 2
#define ConcreteMapView__tileRowsPerCell    3

/*--------------------*/

static const Tile_Type ConcreteMapView__kindToTile[]
                  [ConcreteMapView__tileRowsPerCell]
                  [ConcreteMapView__tileColumnsPerCell]= {
  /*.*/ { { 0,  0}, { 0,  0}, { 0,  0} },
  /*X*/ { { 1,  1}, { 1,  1}, { 1,  1} },
  /*T*/ { { 1,  1}, { 1,  1}, { 1,  1} }, /* trap */
  /*H*/ { { 2,  3}, { 2,  3}, { 2,  3} },
  /*h*/ { { 0,  0}, { 0,  0}, { 0,  0} }, /* hidden ladder! */
  /*#*/ { { 4,  4}, { 4,  4}, { 4,  4} },
  /*~*/ { { 5,  5}, { 0,  0}, { 0,  0} },
  /*+*/ { { 0,  0}, { 0,  0}, { 0,  0} },
  /*-*/ { { 0,  0}, { 0,  0}, { 0,  0} },
  /*$*/ { { 0,  0}, { 6,  8}, { 7,  9} },
  /*O*/ { { 0,  0}, { 0,  0}, { 0,  0} }, /* hole */
  /*1*/ { { 0,  0}, { 0,  1}, { 1,  0} }, /* hole closing */
  /*2*/ { { 0,  0}, { 1,  1}, { 1,  1} }, /* hole closing */
  /*a*/ { {10,  0}, { 0,  0}, { 0,  0} }, /*  zero gold sacks remaining */
  /*b*/ { { 0, 11}, { 0,  0}, { 0,  0} }, /*   one gold sack  remaining */
  /*c*/ { { 0,  0}, {12,  0}, { 0,  0} }, /*   two gold sacks remaining */
  /*d*/ { { 0,  0}, { 0, 13}, { 0,  0} }  /* three gold sacks remaining */
};
  /* mapping from index of char in <Map_charsInMap>, relative cell row
     and column into tile index */

#define ConcreteMapView__tileColumnCount \
          (ConcreteMap_columnCount * ConcreteMapView__tileColumnsPerCell)

#define ConcreteMapView__tileRowCount \
          (ConcreteMap_rowCount * ConcreteMapView__tileRowsPerCell)

#ifdef WINDOWS
static Tile_Type ConcreteMapView__tileMatrix
  [ConcreteMapView__tileRowCount * ConcreteMapView__tileColumnCount];
#else
static Tile_Type at 0xA800 ConcreteMapView__tileMatrix
  [ConcreteMapView__tileRowCount * ConcreteMapView__tileColumnCount];
#endif

/*========================================*/
/*            PUBLIC ROUTINES            */
/*========================================*/

void ConcreteMapView_initialize (void)
{
  /* initialize tile tables with tile bitmaps for map view */
  Tile_BkgBitmaps_write(ConcreteMapView__tileIndexOffset, 14,
			ConcreteMapView__tileBitmaps);

  /* prepare the map view */
  Palette_setBkgPalettes(0, 3, ConcreteMapView__palettes);

  MapView_define(ConcreteMapView__tileColumnsPerCell,
		 ConcreteMapView__tileRowsPerCell,
		 ConcreteMapView__tileIndexOffset,
		 ConcreteMapView__tileMatrix,
		 (Tile_Type *) ConcreteMapView__kindToTile,
		 ConcreteMapView__tileToAttribute);
}

/*--------------------*/

void ConcreteMapView_finalize (void)
{
}
