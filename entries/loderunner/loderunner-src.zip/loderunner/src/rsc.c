/** Ressource module --
    Implementation of module providing all services for encapsulating
    the culture specific parts of a GameBoy game (like icons or
    strings).

    Original version by Thomas Tensi, 2005-09
*/

#include "rsc.h"

/*========================================*/

/* Gameboy modules */
#include <gbextended/midisong.h>
#include <gbextended/sound.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

extern const void * const RscData_ressourceList[];
extern const UINT8 *RscData__bass_partList[];
extern const UINT8 *RscData__guitar_partList[];
extern const UINT8 *RscData__drums_partList[];

#define Rsc__dataBufferLength 250
static char Rsc__dataBuffer[Rsc__dataBufferLength];
  /* buffer containing the strings of a string list */


typedef struct {
  UINT8 **partList;
  Boolean isActive;
  UINT8 partIndex;
  UINT16 remainingPartEventCount;
  UINT8 *eventStreamPtr;
  Sound_DeltaTime timeToNextEvent;
  Sound_Event nextEvent;
} Rsc__TrackDescriptor;

#define Rsc__trackCount 3

static Rsc__TrackDescriptor Rsc__trackInfo[Rsc__trackCount];

#define maxDeltaTime 0x7FFF


/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Rsc__resetSong (void)
  /** puts all parameters of song to initial values */
{
  MidiSong_setTrack(MidiSong_TrackKind_melody1, RscData__guitar_partList);
  MidiSong_setTrack(MidiSong_TrackKind_melody2, RscData__bass_partList);
  MidiSong_setTrack(MidiSong_TrackKind_drums, RscData__drums_partList);
  MidiSong_reset();
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Rsc_initialize (void)
{
  Rsc__resetSong();
}

/*--------------------*/

void Rsc_finalize (void)
{
}

/*--------------------*/

void Rsc_getBitmap (in Rsc_Type ressource, in UINT8 i,
		    out Tile_Bitmap *bitmap)
{
  Tile_Bitmap *bitmapList;
  bitmapList = (Tile_Bitmap *) RscData_ressourceList[ressource];
  STRUCT_ASSIGN(*bitmap, bitmapList[i]);
}

/*--------------------*/

void Rsc_getInteger (in Rsc_Type ressource, out UINT16 *i)
{
  UINT16 maxSize = sizeof(UINT16);
  String_serialize(i, RscData_ressourceList[ressource], false, 2, 0,
		   &maxSize);
}

/*--------------------*/

void Rsc_getIntegerList (in Rsc_Type ressource, in UINT16 maxSize,
			 out UINT16 *integerList[])
{
  void *sourceList = RscData_ressourceList[ressource];
  void *targetList = (void *)integerList;
  String_serialize(targetList, sourceList, false, 2, 1, &maxSize);
}

/*--------------------*/

void Rsc_getString (in Rsc_Type ressource, in UINT16 maxSize,
		    out String_Type st)
{
  void *sourceList = RscData_ressourceList[ressource];
  String_serialize(st, sourceList, true, 0, 0, &maxSize);
}

/*--------------------*/

void Rsc_getStringList (in Rsc_Type ressource, in UINT16 maxSize,
			out String_List stringList)
{
  void *sourceList = RscData_ressourceList[ressource];
  void *targetList = (void *)stringList;
  String_serialize(targetList, sourceList, true, 0, 1, &maxSize);
}

/*--------------------*/

void Rsc_getSongEvent (out Sound_DeltaTime *deltaTime,
		       out Sound_Event *event,
		       out Boolean *isDone)
{
  MidiSong_getNextEvent(deltaTime, event, isDone);
}

/*--------------------*/

void Rsc_expand1 (inout String_Type st, in String_Type replacement1,
		  in UINT16 maxSize)
{
  String_globalReplace(st, "%1", replacement1, maxSize);
}

/*--------------------*/

void Rsc_expand2 (inout String_Type st, in String_Type replacement1,
		  in String_Type replacement2, in UINT16 maxSize)
{
  Rsc_expand1(st, replacement1, maxSize);
  String_globalReplace(st, "%2", replacement2, maxSize);
}
