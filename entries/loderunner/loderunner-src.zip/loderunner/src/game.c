/** Game module --
    Implementation of module providing all services for handling the
    complete game of LodeRunner.

    Original version by Thomas Tensi, 2004-11
*/

/*========================================*/

//#define Profiler

/* technical Gameboy modules */
#include <gb/gb.h>

/* Gameboy modules */
#include <gbextended/background.h>
#include <gbextended/dialog.h>
#include <gbextended/font.h>
#include <gbextended/hardware.h>
#include <gbextended/joypad.h>
#include <gbextended/palette.h>
#include <gbextended/map.h>
#include <gbextended/mapanimation.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/mapview.h>
#include <gbextended/midisong.h>
#ifdef Profiler
#  include <gbextended/profiler.h>
#endif
#include <gbextended/screen.h>
#include <gbextended/set.h>
#include <gbextended/sound.h>
#include <gbextended/sprite.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>
#include <gbextended/window.h>

/* local modules */
#include "concretemap.h"
#include "concretemapanimation.h"
#include "concretemapview.h"
#include "concretemusic.h"
#include "gameobject.h"
#include "maplevel.h"
#include "opponent.h"
#include "player.h"
#include "preferences.h"
#include "rsc.h"

/*========================================*/

static UINT8 Game__level;
static UINT8 Game__newLevel;
  /** level selected by user which will become next game level */
static char Game__newLevelString[5];

typedef enum { Game__DialogState_atBegin,
	       Game__DialogState_atUserSelection,
	       Game__DialogState_atHighScore,
	       Game__DialogState_beforeLevel,
	       Game__DialogState_inLevel,
	       Game__DialogState_afterLevel,
	       Game__DialogState_done
} Game__DialogState;

static Game__DialogState Game__dialogState = Game__DialogState_atBegin;

#define Game__tempBufferLength 200
static char Game__tempBuffer[Game__tempBufferLength];
#define Game__titleEndMessageLength 50
static char Game__titleEndMessage[Game__titleEndMessageLength];

#define Game__messageDisplayDuration 2000
  /** duration of short message display */

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

extern Dialog_ItemResult BC_Game__handleLevelChange (in Joypad_Key key,
						     inout String_Type *value);
  /** nonbanked stub routine for Game__handleLevelChange */


static void Game__processUserSelection (void);
static void Game__setupLevel (in UINT8 level);
static void Game__showHighscoreTable (void);
static void Game__showRscMessage (in Rsc_Type ressource);
static void Game__viewCurrentLevel (void);

/*--------------------*/

static void Game__closeMessageDialog (void)
  /** closes currently open message dialog and asks user to press the
      start button; alternatively the A button is accepted */
{
  char titleEndMessage[50];
  Joypad_KeySet startKeySet = Set_makeSet(Joypad_Key_start);

  //  Set_include(startKeySet, Joypad_Key_a);
  Rsc_getString(Rsc_Game_M_titleEnd, sizeof(titleEndMessage),
		titleEndMessage);
  Dialog_closeMessage(titleEndMessage, startKeySet);
}

/*--------------------*/

static GameObject_Action Game__findUserAction (void)
  /** finds the selected action from the keys pressed */
{
  Joypad_Key keyPressed;
  GameObject_Action result;
  GameObject_Action actionMapping[] = { 
    GameObject_Action_runRight,   GameObject_Action_runLeft,
    GameObject_Action_climbUp,    GameObject_Action_climbDown,
    GameObject_Action_shootRight, GameObject_Action_shootLeft,
    GameObject_Action_none,       GameObject_Action_none };

  if (!Joypad_getKeyPressed(&keyPressed)) {
    result = GameObject_Action_none;
  } else {
    result = actionMapping[keyPressed];

    if (keyPressed == Joypad_Key_select) {
      /* show help screen about the game */
      Game__showRscMessage(Rsc_Game_M_help);
    } else if (keyPressed == Joypad_Key_start) {
      Game__processUserSelection();
    }
  }

  return result;
}

/*--------------------*/

Dialog_ItemResult Game__handleLevelChange (in Joypad_Key key,
					   inout String_Type *value) NONBANKED
  /** updates value of current level by user selection */
{
  Dialog_ItemResult result;
  char *st = *value;
  char prefix[] = { ' ', String_terminator };
  char number[10];

  if (key > Joypad_Key_left) {
    result = Dialog_ItemResult_done;
  } else {
    if (key == Joypad_Key_right) {
      if (Game__newLevel == MapLevel_maxIndex) {
	Game__newLevel = 0;
      }
      Game__newLevel++;
    } else {
      Game__newLevel--;
      if (Game__newLevel == 0) {
	Game__newLevel = MapLevel_maxIndex;
      }
    }
    
    prefix[0] = '>';
    result = Dialog_ItemResult_processing;
  }

  String_makeFromInteger((UINT16) Game__newLevel, number, sizeof(number));
  String_boundedCopy(st, prefix, sizeof(Game__newLevelString));
  String_concatenate(st, number, sizeof(Game__newLevelString));
  String_concatenate(st, "\n", sizeof(Game__newLevelString));
  return result;
}

/*--------------------*/

static void Game__handleTickEvent (void)
{
  GameObject_Action userAction = Game__findUserAction();
  Player_setNextAction(0, userAction);

  if (Game__dialogState == Game__DialogState_inLevel) {
    GameObject_LevelResult levelResult = GameObject_handleTickEvent();

    if (levelResult != GameObject_LevelResult_running) {
      char st[40];
      ConcreteMusic_stop();
      Game__dialogState = Game__DialogState_afterLevel;

      if (levelResult == GameObject_LevelResult_failed) {
	delay(Game__messageDisplayDuration);
	Dialog_open();
	Rsc_getString(Rsc_Game_M_failed, sizeof(st), st);
	Dialog_showQuery(st);
      } else {
	UINT8 *bestLevel = &Preferences_currentUserData.level;
	Rsc_getString(Rsc_Game_M_completed, sizeof(st), st);
	Dialog_showMessage(st);
	delay(Game__messageDisplayDuration);

	if (Game__level == *bestLevel + 1) {
	  *bestLevel = Game__level;
	  Preferences_storeUserData();
	}

	if (Game__level != MapLevel_maxIndex) {
	  Game__level++;
	} else {
	  Game__level = 1;
	}
      }
      ConcreteMusic_start();
    }
    MapAnimation_handleTickEvent();
    ConcreteMusic_addEvent();
#ifdef WINDOWS
    Sound_handleTickEvent();
#endif
  }
}

/*--------------------*/

static void Game__updateUserSettings (void)
  /* sets presentations of player and opponent */
{
  Preferences_UserData *userData;
  userData = &Preferences_currentUserData;
  Player_setAppearance(userData->playerKind, userData->hairColour,
		       userData->topClothingColour,
		       userData->bottomClothingColour,
		       userData->shoeAndGunColour);
  Opponent_setAppearance(userData->opponentColour);
  Sound_setFlags(userData->musicIsOn, userData->soundIsOn);
}

/*--------------------*/

static void Game__processUserSelection (void)
{
  Boolean selectionIsRepeated;

  ConcreteMusic_stop();

  do {
    UINT8 selection;
    char **itemList = (char **)Game__tempBuffer;
    static Dialog_ItemRoutine routineList[] = {
      Game__handleLevelChange,    NULL, NULL, NULL, NULL, NULL, NULL
    };

    static String_List selectionList = {
      Game__newLevelString, NULL, NULL, NULL, NULL, NULL, NULL
    };
    char *ptr = Game__newLevelString;
    char emptyString = 0;

    selectionIsRepeated = true;
    Rsc_getStringList(Rsc_Game_L_choiceList, Game__tempBufferLength,
		      itemList);
    Game__newLevel = Game__level;
    *ptr++ = '\n';
    *ptr = String_terminator;
    
    selection = Dialog_showCascadedChoice(&emptyString, itemList,
					  routineList, selectionList);
    switch (selection) {
      case 0:
       	break;
      case 1:
        Game__viewCurrentLevel();
	break;
      case 2:
	Game__dialogState = Game__DialogState_beforeLevel;
	selectionIsRepeated = false;
	break;
      case 3:
	Preferences_queryForSetup();
	Game__updateUserSettings();
	break;
      case 4:
	Game__showHighscoreTable();
	break;
      case 5:
        Game__dialogState = Game__DialogState_atUserSelection;
      default:
	selectionIsRepeated = false;
	break;
    }
  } while (selectionIsRepeated);

  if (Game__level != Game__newLevel) {
    Game__level = Game__newLevel;
    Game__dialogState = Game__DialogState_beforeLevel;
  }

  if (Game__dialogState == Game__DialogState_inLevel) {
    ConcreteMusic_start();
  }
}

/*--------------------*/

static void Game__showRscMessage (in Rsc_Type ressource)
{
  char st[200];
  Rsc_getString(ressource, sizeof(st), st);
  Dialog_showMessage(st);
  Game__closeMessageDialog();
}

/*--------------------*/

static void Game__setupLevel (in UINT8 level)
{
  char st[20];
  char number[20];
  Rsc_getString(Rsc_Game_M_enteredLevel, sizeof(st), st);
  String_makeFromInteger((UINT16)level, number, 10);
  Rsc_expand1(st, number, sizeof(st));
  Dialog_showMessage(st);
  MapAnimation_reset();
  ConcreteMap_loadLevel(level);
  MapView_analyseLevel();
  GameObject_loadAllFromMap();
  GameObject_showScenery();
  /* make sure that the map is really visible */
  MapView_showInScreen();
  Game__closeMessageDialog();
}

/*--------------------*/

static void Game__showHighscoreTable (void)
  /** shows the highscores of the game */
{
  char highscoreMessage[200];
  UINT8 i;
  UINT8 levelList[Preferences_userCount];
  char nameList[Preferences_userCount][Preferences_maxNameLength+1];
  UINT8 position[Preferences_userCount];

  for (i = 0;  i != Preferences_userCount;  i++) {
    Preferences_getNameAndLevel(i, nameList[i], &levelList[i]);
    position[i] = i;
  }

  /* bubble sort in descending order of levels */
  for (i = Preferences_userCount - 1;  i != 0;  i--) {
    UINT8 j;
    UINT8 *ptrA = &position[0];
    UINT8 *ptrB = ptrA + 1;

    for (j = 0;  j != i;  j++) {
      if (levelList[*ptrA] < levelList[*ptrB]) {
	/* elements are out of order ==> swap position information */
	UINT8 temp = *ptrA;
	*ptrA = *ptrB;
	*ptrB = temp;
      }
      ptrA++;
      ptrB++;
    }
  }

  /* store the high score table in a string */
  Rsc_getString(Rsc_Game_M_highscore, sizeof(highscoreMessage), 
		highscoreMessage);

  for (i = 0;  i != Preferences_userCount;  i++) {
    UINT8 p = position[i];
    char number[5];
    char thisLine[20];
    String_makeFromInteger((UINT16)(i + 1), thisLine, 10);
    String_concatenate(thisLine, ". ", sizeof(thisLine));
    String_concatenate(thisLine, nameList[p], sizeof(thisLine));

    while (String_length(thisLine) < Preferences_maxNameLength + 5) {
      String_concatenate(thisLine, " ", sizeof(thisLine));
    }

    String_makeFromInteger((UINT16)levelList[p], number, 10);

    if (String_length(number) < 2) {
      String_concatenate(thisLine, " ", sizeof(thisLine));
    }

    String_concatenate(thisLine, number, sizeof(thisLine));
    String_concatenate(thisLine, "\n", sizeof(thisLine));
    String_concatenate(highscoreMessage, thisLine, sizeof(highscoreMessage));
  }

  Dialog_showMessage(highscoreMessage);
  Game__closeMessageDialog();
}

/*--------------------*/

static void Game__viewCurrentLevel (void)
{
  Map_Position position;
  Boolean isDone;

  Sprite_hideLayer();
  position.x = 0;
  position.y = 0;

  do {
    Joypad_Key keyPressed;

    Screen_waitForFrameGap();
    MapView_setViewport(&position);
    MapView_showInScreen();

    isDone = false;

    do {
      Joypad_waitForSomeKey(&keyPressed);
    } while (keyPressed == Joypad_Key_a || keyPressed == Joypad_Key_start);

    if (keyPressed >= Joypad_Key_a) {
      isDone = true;
    } else {
      switch(keyPressed) {
        case Joypad_Key_right:
	  position.x += MapCoordinate_unit;  break;
	case Joypad_Key_left:
	  if (position.x != 0) {
	    position.x -= MapCoordinate_unit;
	  }
	  break;
	case Joypad_Key_up:
	  if (position.y != 0) {
	    position.y -= MapCoordinate_unit;
	  }
	  break;
	case Joypad_Key_down:
	  position.y += MapCoordinate_unit;  break;
      }
    }
  } while (!isDone);

  Background_hideLayer();
  GameObject_showScenery();
  Background_showLayer();
  Sprite_showLayer();
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

extern char _current_bank;

void Game_initialize (void)
{
#ifndef WINDOWS
  char *bankPtr = (char *)0x0000;
  /* enable external cartridge RAM */
  *bankPtr = 0x0a;
  cpu_fast();
#endif

#ifdef Profiler
  Profiler_initialize();
#endif
  Hardware_initialize();
  Rsc_initialize();
  Preferences_initialize();
  Screen_initialize();
  Dialog_initialize();
  Screen_turnOff();
  Set_initialize();
  Palette_initialize();
  Tile_initialize();
  Sprite_initialize();
  Background_initialize();
  Font_initialize();
  Font_setCurrent("IBM");
  Window_initialize();
  Joypad_initialize();
  Player_initialize();
  Opponent_initialize();
  MapCoordinate_initialize();
  MapAnimation_initialize();
  ConcreteMapAnimation_initialize();
  Map_initialize();
  ConcreteMap_initialize();
  MapView_initialize();
  ConcreteMapView_initialize();
  Map_setObserver(MapView_updatePosition);
  GameObject_initialize();
  Screen_turnOn();
  Sprite_showLayer();
  Background_showLayer();
  Sound_initialize();
  MidiSong_initialize();
  ConcreteMusic_initialize();
  add_VBL(Sound_handleTickEvent);
}

/*--------------------*/

void Game_finalize (void)
{
  Screen_turnOff();
  ConcreteMusic_finalize();
  MidiSong_finalize();
  Sound_finalize();
  GameObject_finalize();
  ConcreteMapView_finalize();
  MapView_finalize();
  ConcreteMap_finalize();
  Map_finalize();
  ConcreteMapAnimation_finalize();
  MapAnimation_finalize();
  MapCoordinate_finalize();
  Opponent_finalize();
  Player_finalize();
  Joypad_finalize();
  Window_finalize();
  Font_finalize();
  Background_finalize();
  Sprite_finalize();
  Tile_finalize();
  Dialog_finalize();
  Screen_finalize();
  Palette_finalize();
  Set_finalize();
  Preferences_finalize();
  Rsc_finalize();
  Hardware_finalize();
#ifdef Profiler
  Profiler_finalize();
#endif
}

/*--------------------*/

int main (void)
{
  Game_initialize();
  Screen_waitForFrameGap();

  while (Game__dialogState != Game__DialogState_done) {
    if (Game__dialogState == Game__DialogState_atBegin) {
      Game__showRscMessage(Rsc_Game_M_title);
      Game__showRscMessage(Rsc_Game_M_info);
      Game__dialogState = Game__DialogState_atHighScore;
    } else if (Game__dialogState == Game__DialogState_atHighScore) {
      Game__showHighscoreTable();
      Game__dialogState = Game__DialogState_atUserSelection;
    } else if (Game__dialogState == Game__DialogState_atUserSelection) {
      Preferences_queryForName();
      Game__level = Preferences_currentUserData.level + 1;
      Game__updateUserSettings();
      Game__dialogState = Game__DialogState_beforeLevel;
    } else if (Game__dialogState == Game__DialogState_beforeLevel) {
      Game__setupLevel(Game__level);
      ConcreteMusic_start();
      Game__dialogState = Game__DialogState_inLevel;
    } else if (Game__dialogState == Game__DialogState_inLevel) {
      MapView_showInScreen();
      Game__handleTickEvent();
#ifdef Profiler
  break;
#endif
    } else if (Game__dialogState == Game__DialogState_afterLevel) {
      ConcreteMusic_stop();
      MapAnimation_reset();
      Game__dialogState = Game__DialogState_beforeLevel;
    }
  }

  Game_finalize();
  return 0;
}
