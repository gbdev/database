/** Player module --
    Implementation of module providing all services for handling the
    player object in a GameBoy game.

    Original version by Thomas Tensi, 2004-09
*/

#include "player.h"

/*========================================*/

#include "concretemap.h"
#include <gbextended/palette.h>
#include "rsc.h"
#include <gbextended/screen.h>
#include <gbextended/sprite.h>
#include <gbextended/spriteanimation.h>
#include <gbextended/tile.h>

#include <gb/gb.h>

/*========================================*/

#define Player__tileCount 6
#define Player__maxCount 1  /* only one player at the moment */

typedef struct {
  Sprite_Type sprite;  /** sprite representing player figure */
  GameObject_Action nextAction;  /** the next action player will make */
} Player__Descriptor;

static Player__Descriptor Player__data[Player__maxCount];
static Screen_Coordinate Player__maxX, Player__maxY;

/*--------------------*/

/* default colours for player */
#define Player__faceContourColour 0
#define Player__skinColour Palette_makeRGBColour(31,18,18)
#define Player__hairColour 5460
#define Player__topClothingColour 31
#define Player__bottomClothingColour 992
#define Player__shoeColour 0

/* contains the colours for the tiles used by player */
static Palette_Data Player__palettes[4] = {
  /* palette for face body part with skin, hair and face contour */
  { Palette_Colour_white, Player__skinColour,
    Player__hairColour, Player__faceContourColour },
  /* palette for upper body part with top clothes, skin and shoes */
  { Palette_Colour_white, Player__skinColour,
    Player__topClothingColour, Player__shoeColour },
  /* palette for lower body part with bottom clothes, skin and shoes */
  { Palette_Colour_white, Player__skinColour,
    Player__bottomClothingColour, Player__shoeColour },
  /* palette for climbing with hair, skin and top clothes */
  { Palette_Colour_white, Player__skinColour,
    Player__hairColour, Player__topClothingColour }
};

#define Player__setPalette(i, j, colour) \
  Player__palettes[i][j] = (colour)

static Sprite_Offset Player__offsets[] = {
  { 0,  0}, { 8,  0}, { 0,  8}, { 8,  8}, { 0, 16}, { 8, 16}
};


typedef Tile_Type Player__TileVector[Player__tileCount];
typedef Tile_Attribute Player__AttributeVector[Player__tileCount];

/*----------------------------------------*/
/* Schedule 1: running right */

static const Player__TileVector Player__S1_bitmaps[] = {
  {  1,  2,  3,  4,  5,  6 }, {  1,  2,  7,  8,  9, 10 }, 
  {  1,  2, 11, 12, 13, 14 }, {  1,  2,  7,  8,  9, 10 }
};

static const Player__AttributeVector Player__S1_attributes[] = {
  {  0+0,  0+0,  0+1,  0+1,  0+2,  0+2 },
  {  0+0,  0+0,  0+1,  0+1,  0+2,  0+2 },
  {  0+0,  0+0,  0+1,  0+1,  0+2,  0+2 },
  {  0+0,  0+0,  0+1,  0+1,  0+2,  0+2 }
};

static const SpriteAnimation_Phase Player__S1_phases[] = {
  { 1, (Tile_Type *)&Player__S1_bitmaps[0][0],
       (Tile_Attribute *)&Player__S1_attributes[0][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S1_bitmaps[1][0],
       (Tile_Attribute *)&Player__S1_attributes[1][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S1_bitmaps[2][0],
       (Tile_Attribute *)&Player__S1_attributes[2][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S1_bitmaps[3][0],
       (Tile_Attribute *)&Player__S1_attributes[3][0],
       Player__offsets }
};

static const SpriteAnimation_Schedule Player__S1_schedule = {
  4, (SpriteAnimation_Phase *)Player__S1_phases
};

/*----------------------------------------*/
/* Schedule 2: running left */

static const Player__TileVector Player__S2_bitmaps[] = {
  {  2,  1,  4,  3,  6,  5 }, {  2,  1,  8,  7, 10,  9 }, 
  {  2,  1, 12, 11, 14, 13 }, {  2,  1,  8,  7, 10,  9 }
};

static const Player__AttributeVector Player__S2_attributes[] = {
  { 32+0, 32+0, 32+1, 32+1, 32+2, 32+2 },
  { 32+0, 32+0, 32+1, 32+1, 32+2, 32+2 },
  { 32+0, 32+0, 32+1, 32+1, 32+2, 32+2 },
  { 32+0, 32+0, 32+1, 32+1, 32+2, 32+2 }
};

static const SpriteAnimation_Phase Player__S2_phases[] = {
  { 1, (Tile_Type *)&Player__S2_bitmaps[0][0],
       (Tile_Attribute *)&Player__S2_attributes[0][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S2_bitmaps[1][0],
       (Tile_Attribute *)&Player__S2_attributes[1][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S2_bitmaps[2][0],
       (Tile_Attribute *)&Player__S2_attributes[2][0],
       Player__offsets },
  { 1, (Tile_Type *)&Player__S2_bitmaps[3][0],
       (Tile_Attribute *)&Player__S2_attributes[3][0],
       Player__offsets },
};

static const SpriteAnimation_Schedule Player__S2_schedule = {
  4, (SpriteAnimation_Phase *)Player__S2_phases
};

/*----------------------------------------*/
/* Schedule 3: climbing up or down */

static const Player__TileVector Player__S3_bitmaps[] = {
  { 16, 16, 19, 19, 21, 21 }, { 15, 17, 18, 20, 21, 22 },
  { 16, 16, 19, 19, 21, 21 }, { 17, 15, 20, 18, 22, 21 }
};

static const Player__AttributeVector Player__S3_attributes[] = {
  {  0+3, 32+3,  0+1, 32+1,  0+2, 32+2 },
  {  0+3, 32+3,  0+1, 32+1,  0+2, 32+2 },
  {  0+3, 32+3,  0+1, 32+1,  0+2, 32+2 },
  {  0+3, 32+3,  0+1, 32+1,  0+2, 32+2 }
};

static const SpriteAnimation_Phase Player__S3_phases[] = {
  { 1, (Tile_Type *)&Player__S3_bitmaps[0][0],
       (Tile_Attribute *)&Player__S3_attributes[0][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S3_bitmaps[1][0],
       (Tile_Attribute *)&Player__S3_attributes[1][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S3_bitmaps[2][0],
       (Tile_Attribute *)&Player__S3_attributes[2][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S3_bitmaps[3][0],
       (Tile_Attribute *)&Player__S3_attributes[3][0],
        Player__offsets }
};

static const SpriteAnimation_Schedule Player__S3_schedule = {
  4, (SpriteAnimation_Phase *)Player__S3_phases
};

/*----------------------------------------*/
/* Schedule 4: clambering right */

static const Player__TileVector Player__S4_bitmaps[] = {
  { 23, 24, 25, 26,  9, 29 }, {  1, 27,  3, 28,  9, 29 },
  { 23, 24, 25, 26,  9, 29 }, { 30,  2, 31, 12,  9, 29, }
};

static const Player__AttributeVector Player__S4_attributes[] = {
  {  0+3,  0+0,  0+1,  0+1,  0+2,  0+2 }, 
  {  0+0,  0+3,  0+1,  0+1,  0+2,  0+2 },
  {  0+3,  0+0,  0+1,  0+1,  0+2,  0+2 }, 
  {  0+3,  0+0,  0+1,  0+1,  0+2,  0+2 }
};

static const SpriteAnimation_Phase Player__S4_phases[] = {
  { 1, (Tile_Type *)&Player__S4_bitmaps[0][0],
       (Tile_Attribute *)&Player__S4_attributes[0][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S4_bitmaps[1][0],
       (Tile_Attribute *)&Player__S4_attributes[1][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S4_bitmaps[2][0],
       (Tile_Attribute *)&Player__S4_attributes[2][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S4_bitmaps[3][0],
       (Tile_Attribute *)&Player__S4_attributes[3][0],
        Player__offsets }
};

static const SpriteAnimation_Schedule Player__S4_schedule = {
  4, (SpriteAnimation_Phase *)Player__S4_phases
};


/*----------------------------------------*/
/* Schedule 5: clambering left */

static const Player__TileVector Player__S5_bitmaps[] = {
  { 24, 23, 26, 25, 29,  9 }, { 27,  1, 28,  3, 29,  9 },
  { 24, 23, 26, 25, 29,  9 }, {  2, 30, 12, 31, 29,  9 }
};

static const Player__AttributeVector Player__S5_attributes[] = {
  { 32+0, 32+3, 32+1, 32+1, 32+2, 32+2 },
  { 32+3, 32+0, 32+1, 32+1, 32+2, 32+2 },
  { 32+0, 32+3, 32+1, 32+1, 32+2, 32+2 },
  { 32+0, 32+3, 32+1, 32+1, 32+2, 32+2 }
};

static const SpriteAnimation_Phase Player__S5_phases[] = {
  { 1, (Tile_Type *)&Player__S5_bitmaps[0][0],
       (Tile_Attribute *)&Player__S5_attributes[0][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S5_bitmaps[1][0],
       (Tile_Attribute *)&Player__S5_attributes[1][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S5_bitmaps[2][0],
       (Tile_Attribute *)&Player__S5_attributes[2][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S5_bitmaps[3][0],
       (Tile_Attribute *)&Player__S5_attributes[3][0],
        Player__offsets }
};

static const SpriteAnimation_Schedule Player__S5_schedule = {
  4, (SpriteAnimation_Phase *)Player__S5_phases
};

/*----------------------------------------*/
/* Schedule 6: jumping */

static const Player__TileVector Player__S6_bitmaps[] = {
  { 16, 16, 19, 19, 21, 21 }, { 16, 16, 19, 19, 14, 14 }
};

static const Player__AttributeVector Player__S6_attributes[] = {
  {  0+3, 32+3,  0+1, 32+1,  0+2, 32+2 },
  {  0+3, 32+3,  0+1, 32+1, 32+2,  0+2 }
};

static const SpriteAnimation_Phase Player__S6_phases[] = {
  { 200, (Tile_Type *)&Player__S6_bitmaps[0][0],
       (Tile_Attribute *)&Player__S6_attributes[0][0],
        Player__offsets },
  { 1, (Tile_Type *)&Player__S6_bitmaps[1][0],
       (Tile_Attribute *)&Player__S6_attributes[1][0],
        Player__offsets }
};

static const SpriteAnimation_Schedule Player__S6_schedule = {
  1, (SpriteAnimation_Phase *)Player__S6_phases
};

/*----------------------------------------*/
/* Schedule 7: shooting right */

static const Player__TileVector Player__S7_bitmaps[] = {
  {  1,  2,  3, 32,  5, 33 }
};

static const Player__AttributeVector Player__S7_attributes[] = { 
  {  0+0,  0+0,  0+1,  0+1,  0+2,  0+2 }
};

static const SpriteAnimation_Phase Player__S7_phases[] = {
  { 200, (Tile_Type *)&Player__S7_bitmaps[0][0],
         (Tile_Attribute *)&Player__S7_attributes[0][0],
        Player__offsets }
};

static const SpriteAnimation_Schedule Player__S7_schedule = {
  1, (SpriteAnimation_Phase *)Player__S7_phases
};

/*----------------------------------------*/
/* Schedule 8: shooting left */

static const Player__TileVector Player__S8_bitmaps[] = {
  {  2,  1, 32,  3, 33,  5 }
};

static const Player__AttributeVector Player__S8_attributes[] = { 
  { 32+0, 32+0, 32+1, 32+1, 32+2, 32+2 }
};

static const SpriteAnimation_Phase Player__S8_phases[] = {
  { 200, (Tile_Type *)&Player__S8_bitmaps[0][0],
         (Tile_Attribute *)&Player__S8_attributes[0][0],
         Player__offsets }
};

static const SpriteAnimation_Schedule Player__S8_schedule = {
  1, (SpriteAnimation_Phase *)Player__S8_phases
};


/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Player__adjustCoordinates (inout Screen_Coordinate *x,
				       inout Screen_Coordinate *y)
  /* adjusts test sprite coordinates such that they are okay for the
     gameboy screen */
{
  if (*x > Player__maxX) { *x = Player__maxX; }
  if (*y > Player__maxY) { *y = Player__maxY; }
}

/*--------------------*/

GameObject_Action Player__getNextAction (in GameObject_Index player,
					 readonly Map_Position *position,
					 readonly void *otherData)
  /** returns the next action <player> will do based on his <position>
      on map and <otherData> */
{
  return Player__data[player].nextAction;
}

/*--------------------*/

void Player__handleTickEvent (in GameObject_Index player)
  /** tells <player> object that a new frame has occured */
{
  SpriteAnimation_handleTickEvent(Player__data[player].sprite);
}

/*--------------------*/

void Player__hide (in GameObject_Index player)
  /** makes <player> invisible on screen */
{
  Sprite_hide(Player__data[player].sprite);
}

/*--------------------*/

void Player__move (in GameObject_Index player,
		   inout Screen_Coordinate *x, inout Screen_Coordinate *y)
  /** puts <player> to absolute screen position (<x>,<y>); adjusts
      coordinates when out of bounds */
{
  Player__adjustCoordinates(x, y);  
  Sprite_moveAbsolute(Player__data[player].sprite, *x, *y);
}

/*--------------------*/

void Player__setAnimation (in GameObject_Index player,
			   in GameObject_Action animationKind)
  /** defines the <animationKind> the player will do; when the kind of
      animation has changed, the new one starts in the next frame,
      otherwise the previous simply continues */
{
  SpriteAnimation_Schedule *schedule = NULL;
  Player__Descriptor *playerDescriptor = &Player__data[player];

  switch (animationKind) {
    case GameObject_Action_runRight:
      schedule = (SpriteAnimation_Schedule *) &Player__S1_schedule;  break;
    case GameObject_Action_runLeft:
      schedule = (SpriteAnimation_Schedule *) &Player__S2_schedule;  break;
    case GameObject_Action_climbDown:
    case GameObject_Action_climbUp:
      schedule = (SpriteAnimation_Schedule *) &Player__S3_schedule;  break;
    case GameObject_Action_clamberRight:
      schedule = (SpriteAnimation_Schedule *) &Player__S4_schedule;  break;
    case GameObject_Action_clamberLeft:
      schedule = (SpriteAnimation_Schedule *) &Player__S5_schedule;  break;
    case GameObject_Action_fall:
      schedule = (SpriteAnimation_Schedule *) &Player__S6_schedule;  break;
    case GameObject_Action_shootRight:
      schedule = (SpriteAnimation_Schedule *) &Player__S7_schedule;  break;
    case GameObject_Action_shootLeft:
      schedule = (SpriteAnimation_Schedule *) &Player__S8_schedule;  break;
  }

  SpriteAnimation_setSchedule(playerDescriptor->sprite, schedule, false);
}

/*--------------------*/

void Player__setAnimationState (in GameObject_Index player,
				in Boolean isPaused)
  /** pauses or continues animation of <player> */
{
  SpriteAnimation_setState(Player__data[player].sprite, isPaused);
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

GameObject_TypeDescriptor Player_typeDescriptor = {
  (MapCoordinate_subunitCount / 2), ConcreteMap_ObjectKind_player, false,
  &Player__setAnimation, &Player__setAnimationState, &Player__move,
  &Player__hide, &Player__handleTickEvent, &Player__getNextAction
};
  /* could be const, but will be put in RAM for space reasons */

/*--------------------*/

void Player_initialize (void)
{
  GameObject_Index i;

  for (i = 0;  i != Player__maxCount;  i++) {
    Player__Descriptor *playerDescriptor = &Player__data[i];
    Sprite_Type sprite;

    /* make the sprite */
    sprite = Sprite_make(Player__tileCount);
    playerDescriptor->sprite = sprite;
    SpriteAnimation_setSchedule(sprite, &Player__S3_schedule, true);

    if (i == 0) {
      Sprite_getMaxCoordinates(sprite, &Player__maxX, &Player__maxY);
    }
  }
}

/*--------------------*/

void Player_finalize (void)
{
}

/*--------------------*/

void Player_setAppearance (in Player_Kind kind,
			   in Palette_Colour hairColour,
			   in Palette_Colour topClothingColour,
			   in Palette_Colour bottomClothingColour,
			   in Palette_Colour shoeColour)
{
  Rsc_Type ressource;
  UINT8 i;

  if (kind == Player_Kind_boy) {
    ressource = Rsc_Player_BA_tileBitmapsBoy;
  } else {
    ressource = Rsc_Player_BA_tileBitmapsGirl;
  }

  for (i = 0;  i != 34;  i++) {
    Tile_Bitmap tileBitmap;
    Rsc_getBitmap(ressource, i, &tileBitmap);
    Tile_SpriteBitmaps_write(i, 1, &tileBitmap);
  }

  /* set the palette */
  Player__setPalette(0, 2, hairColour);
  Player__setPalette(3, 2, hairColour);
  Player__setPalette(1, 2, topClothingColour);
  Player__setPalette(3, 3, topClothingColour);
  Player__setPalette(2, 2, bottomClothingColour);
  Player__setPalette(1, 3, shoeColour);
  Player__setPalette(2, 3, shoeColour);

  Palette_setSpritePalettes(0, 4, Player__palettes);
}

/*--------------------*/

void Player_setNextAction (in GameObject_Index player,
			   in GameObject_Action action)
{
  Player__data[player].nextAction = action;
}
