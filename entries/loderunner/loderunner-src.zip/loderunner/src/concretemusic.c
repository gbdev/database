/** Music module --
    Implementation of module providing all services for music
    in a GameBoy game.

    Original version by Thomas Tensi, 2005-10
*/

#include "concretemusic.h"

/*========================================*/

#include <gb/gb.h>
#include "rsc.h"
#include <gbextended/sound.h>
#include <gbextended/types.h>

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void ConcreteMusic__addSoundEvents (in UINT8 count)
  /* adds at most <count> events to sound queue */
{
  while (count != 0) {
    Sound_DeltaTime deltaTime;
    Sound_Event event;
    Boolean isDone;

    Rsc_getSongEvent(&deltaTime, &event, &isDone);

    if (isDone) {
      break;
    } else {
      Sound_putEventInQueue(deltaTime, &event);
      count--;
    }
  }
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void ConcreteMusic_initialize (void)
{
}

/*--------------------*/

void ConcreteMusic_finalize (void)
{
}

/*--------------------*/

void ConcreteMusic_start (void)
{
  UINT8 remainingSlots = Sound_slotsInEventQueue();
  ConcreteMusic__addSoundEvents(remainingSlots);
  Sound_startMusic(1);
}

/*--------------------*/

void ConcreteMusic_stop (void)
{
  Sound_stopMusic();
}

/*--------------------*/

void ConcreteMusic_addEvent (void)
{
  UINT8 remainingSlots = Sound_slotsInEventQueue();
  UINT8 eventCount;

  if (remainingSlots != 0) {
    if (remainingSlots == 1) {
      eventCount = 1;
    } else if (remainingSlots < Sound_maxSlotsInEventQueue / 2) {
      eventCount = 2;
    } else {
      eventCount = 16;
    }

    ConcreteMusic__addSoundEvents(eventCount);
  }  
}
