/** GameObject module --
    Implementation of module dispatching all services for handling all
    objects of a GameBoy game.

    Original version by Dr. Thomas Tensi, 2005-07
*/

#include "gameobject.h"

/*========================================*/

#include <gbextended/types.h>

#include <gbextended/assertion.h>
#include <gbextended/map.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/mapview.h>
#include <gbextended/screen.h>
#include <gbextended/spriteanimation.h>
#include <gbextended/string.h>
#include <gbextended/window.h>

#include "concretemap.h"
#include "concretemapanimation.h"
#include "player.h"
#include "opponent.h"

/*========================================*/

typedef enum {GameObject__Direction_none  = GameObject_Action_none,
	      GameObject__Direction_left  = GameObject_Action_runLeft, 
	      GameObject__Direction_right = GameObject_Action_runRight,
	      GameObject__Direction_up    = GameObject_Action_climbUp,
	      GameObject__Direction_down  = GameObject_Action_climbDown
} GameObject__Direction;


typedef struct {
  GameObject_TypeDescriptor *type;
  Map_Position position;
  UINT8 number; /* within all objects */
  GameObject_Index index;  /* within this kind */
  GameObject__Direction forcedDirection;  /* e.g. when falling down */
  UINT8 animationKind;
} GameObject__T;


#define GameObject__maxCount 50
  /** maximum allowed number of objects including player, opponents
      and static objects */

#define GameObject__playerIndex 0
  /** index of player in Game__objectList */

static UINT8 GameObject__count;
static INT8 GameObject__treasureCount;
static GameObject__T GameObject__list[GameObject__maxCount];
  /** list of game objects including static objects */

static const GameObject_TypeDescriptor GameObject__goldTypeDescriptor = {
  0, ConcreteMap_ObjectKind_gold, true, 
  NULL, NULL, NULL, NULL, NULL, NULL
};

//static String_Type GameObject__errMsg_staticObject
// = "cannot move static object";

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

#define GameObject__fallSpeed (3 * MapCoordinate_subunitCount / 4)

/*--------------------*/

static Boolean GameObject__isSupportedAtPosition (
					  readonly Map_Position *position);

static Boolean GameObject__overlapsWithOpponent (in GameObject__T *gameObject,
						 readonly Map_Position *p);

/*--------------------*/

static void GameObject__checkForForce (inout GameObject__T *gameObject)
  /** finds whether <gameObject> is forced in some direction (currently
      only by falling down) and updates <gameObject.forcedDirection>
      accordingly */
{
  GameObject__Direction forcedDirection;

  if (GameObject__isSupportedAtPosition(&(gameObject->position))) {
    forcedDirection = GameObject__Direction_none;
  } else {
    forcedDirection = GameObject__Direction_down;
  }

  gameObject->forcedDirection = forcedDirection;
}

/*--------------------*/

static void GameObject__checkForCollision (in GameObject__T *gameObject,
					   readonly Map_Position *position,
					   inout Boolean *isStopped,
					   inout Boolean *isBlocked)
   /** checks whether a collision occurs for <gameObject> when moving
       to <position>; <isStopped> is set when this collision stops
       movement, <isBlocked> when no further movement is okay */
{
  GameObject_TypeDescriptor *type = gameObject->type;

  if (type->objectKind == ConcreteMap_ObjectKind_player) {
    /* collision with gold stops movement */
    Map_ObjectKind backgroundObjectKind = Map_getEntry(position);
    if (backgroundObjectKind == ConcreteMap_ObjectKind_gold) {
      *isStopped = true;
    }
  } else if (type->objectKind == ConcreteMap_ObjectKind_opponent) {
    if (GameObject__overlapsWithOpponent(gameObject, position)) {
      *isBlocked = true;
    }
  }
}

/*--------------------*/

static void GameObject__checkForMoveBreak (
				   readonly Map_Position *position,
 				   in GameObject__Direction moveDirection,
				   in Boolean isTraversedCell,
				   in Boolean moveIsForced,
				   inout Boolean *isStopped,
				   inout Boolean *isBlocked)
  /** checks whether cell at <position> blocks or stops movement in
      direction <moveDirection> which is forced and may be traversing
      cell completely; returns this information in <isStopped> (for a
      forced move stopped at a rod) and <isBlocked> */
{
  /* make sure that no move can leave map */
  if (!MapCoordinate_isInRectangle(&Map_boundingBox, position)) {
    *isBlocked = true;
  } else {
    Boolean blocked;
    Map_ObjectKind objectKind = Map_getEntry(position);
    Boolean stopped = false;

    blocked = (objectKind == ConcreteMap_ObjectKind_concrete
	       || objectKind == ConcreteMap_ObjectKind_brick
	       || (objectKind == ConcreteMap_ObjectKind_trap
		   && !moveIsForced));

    if (!blocked && moveIsForced) {
      blocked = (objectKind == ConcreteMap_ObjectKind_ladder);
    }

    /* jumping up is not possible */
    if (!blocked && moveDirection == GameObject__Direction_up
	  && !moveIsForced) {
      // && (objectKind == ConcreteMap_ObjectKind_empty ||
      // objectKind == ConcreteMap_ObjectKind_ladder )) {
      /* moving up is only possible from a ladder */
      Map_Position previousPosition;
      previousPosition.x = position->x;
      previousPosition.y = position->y + MapCoordinate_unit;
      objectKind = Map_getEntry(&previousPosition);
      blocked = (objectKind != ConcreteMap_ObjectKind_ladder);
    }

    /* a move is stopped by a rod, when it is a cell traversed or for
       a forced move */
    if (!blocked && objectKind == ConcreteMap_ObjectKind_rod 
	&& (moveIsForced || isTraversedCell)) {
      stopped = true;
    }

    *isBlocked = blocked;
    *isStopped = stopped;
  }
}

/*--------------------*/

static void GameObject__doShooting (inout GameObject__T *gameObject,
				    out Map_Position *newPosition,
				    in GameObject_Action shootingAction)
  /** does <shootingAction> for <gameObject> */
{
  Boolean isOkay;
  Map_ObjectKind objectKind;
  Map_Position brickPosition;

  STRUCT_ASSIGN(*newPosition, gameObject->position);
  MapCoordinate_round(&newPosition->x);
  MapCoordinate_round(&newPosition->y);

  /* check whether shooting is possible: a brick must be the target
     and it must be covered by an empty space or a rod */
  brickPosition.y = newPosition->y + MapCoordinate_unit;
  brickPosition.x = newPosition->x;

  if (shootingAction == GameObject_Action_shootLeft) {
    brickPosition.x -= MapCoordinate_unit;
  } else {
    brickPosition.x += MapCoordinate_unit;
  }

  objectKind = Map_getEntry(&brickPosition);
  isOkay = (objectKind == ConcreteMap_ObjectKind_brick);

  if (isOkay) {
    Map_Position coveringPosition;
    coveringPosition.x = brickPosition.x;
    coveringPosition.y = brickPosition.y - MapCoordinate_unit;
    objectKind = Map_getEntry(&coveringPosition);
    isOkay = (objectKind == ConcreteMap_ObjectKind_empty
	      || objectKind == ConcreteMap_ObjectKind_hole
	      || objectKind == ConcreteMap_ObjectKind_rod);
  }

  if (isOkay) {
    ConcreteMapAnimation_start(&brickPosition,
			       ConcreteMapAnimation_Kind_destroyedBrick);
  }
}

/*--------------------*/

static void GameObject__findCentrePos (readonly Map_Position *position,
				       out Map_Position *centrePosition)
  /** finds center position of object at <position> and returns it in
      <centrePosition> */
{
  MapCoordinate_vectorAddOp(position, &MapCoordinate_halfCellVector,
			    false, centrePosition);
}

/*--------------------*/

static void GameObject__findNewPosition (
				 inout GameObject__T *gameObject,
				 in GameObject__Direction moveDirection,
				 in MapCoordinate_Type moveOffset,
				 in Boolean moveIsForced,
				 out Map_Position *newPosition,
				 out Boolean *isBlocked)
  /** finds potential new position for <gameObject> when moving in
      <moveDirection> with <moveOffset> units and returns it in
      <newPosition>; when it is not possible to move at all in this
      direction <isBlocked> is set to true; <moveIsForced> tells
      whether the move is forced which changes the kinds of objects
      which stop this move; this routine also takes care that moving
      objects are forced to the cell raster in the dimension orthogonal
      to the movement */
{
  /* TODO: the algorithm is quite complicated because we do not have
     negative coordinate values and there are gaps in the allowed
     coordinates */
  *isBlocked = false;
  STRUCT_ASSIGN(*newPosition, gameObject->position);

  if (moveDirection != GameObject__Direction_none) {
    UINT8 affectedDimension;
    MapCoordinate_Type coordinateOffset;
    MapCoordinate_Type finalCoordinate;
    Boolean isAdditiveDirection;
    Boolean isIntraCellMove;
    MapCoordinate_Type offsetToCellBoundary;
    MapCoordinate_VectorArrayUnion position;
    MapCoordinate_Type remainingOffset;
    MapCoordinate_Type startCoordinate;

    STRUCT_ASSIGN(position.vector, gameObject->position);

    isAdditiveDirection = (moveDirection == GameObject__Direction_right
			   || moveDirection == GameObject__Direction_down);

    if (moveDirection == GameObject__Direction_left
	|| moveDirection == GameObject__Direction_right) {
      affectedDimension = 0;
    } else {
      affectedDimension = 1;
    }

    MapCoordinate_round(&(position.array[1 - affectedDimension]));
    startCoordinate = position.array[affectedDimension];

    /* adjust <moveOffset> when going to boundary */
    if (isAdditiveDirection || moveOffset <= startCoordinate) {
      remainingOffset = moveOffset;
    } else {
      /* move goes to upper or left boundary */
      remainingOffset = startCoordinate;
      if (startCoordinate == 0) {
	*isBlocked = true;
      }
    }

    /* check whether we are crossing any cell boundaries */
    coordinateOffset = MapCoordinate_fractionalPart(startCoordinate);

    if (isAdditiveDirection && coordinateOffset != 0) {
      offsetToCellBoundary = MapCoordinate_subunitCount - coordinateOffset;
    } else {
      offsetToCellBoundary = coordinateOffset;
    }

    isIntraCellMove = (remainingOffset <= offsetToCellBoundary);

    /* calculate the final position */
    if (isIntraCellMove) {
      /* this is an intra-cell move
	 ==> no check for stops or blockages necessary */
      finalCoordinate = MapCoordinate_addOperation(startCoordinate,
						   remainingOffset,
						   !isAdditiveDirection);
    } else {
      /* this move crosses at least one cell boundary, so we have to
	 check for stops or blockages */
      MapCoordinate_Type enteredCellCoordinate;
      UINT8 enteredCellCount;
      UINT8 traversedCellCount = 0;
      UINT8 i;
      Boolean isStopped;
      MapCoordinate_FractionalPart offset;

      /* shift start coordinate to adjacent boundary in direction of
	 the move and adjust offset accordingly */
      if (offsetToCellBoundary != 0) {
	startCoordinate = MapCoordinate_addOperation(startCoordinate,
						     offsetToCellBoundary,
						     !isAdditiveDirection);
	remainingOffset = MapCoordinate_addOperation(remainingOffset,
						     offsetToCellBoundary,
						     true);
      }

      enteredCellCount = MapCoordinate_integerPart(remainingOffset) + 1;
      offset = MapCoordinate_fractionalPart(remainingOffset);

      enteredCellCoordinate = startCoordinate;

      for (i = 0;  i != enteredCellCount;  i++) {
	/* iterate over all entered cells */
	Boolean isTraversedCell;

	traversedCellCount = i;
	isTraversedCell = (i < enteredCellCount - 1);
	enteredCellCoordinate = MapCoordinate_addOperation(
						  enteredCellCoordinate,
						  MapCoordinate_subunitCount,
						  !isAdditiveDirection);
	position.array[affectedDimension] = enteredCellCoordinate;
	GameObject__checkForMoveBreak(&position.vector, moveDirection,
				     isTraversedCell, moveIsForced,
				     &isStopped, isBlocked);
	GameObject__checkForCollision(gameObject, &position.vector, &isStopped,
				      isBlocked);

	if (isStopped || *isBlocked) {
	  if (!*isBlocked) {
	    traversedCellCount++;
	  }
	  offset = 0;
	  break;
	}
      }

      remainingOffset = MapCoordinate_make(traversedCellCount, offset);
      finalCoordinate = MapCoordinate_addOperation(startCoordinate, 
						   remainingOffset,
						   !isAdditiveDirection);
      if (offsetToCellBoundary != 0) {
	/* remove blocked status, when an intra-cell move was done */
	*isBlocked = false;
      }
    }

    position.array[affectedDimension] = finalCoordinate;
    STRUCT_ASSIGN(*newPosition, position.vector);
  }
}

/*--------------------*/

static void GameObject__getObjectsOfKind (in Map_ObjectKind kind,
					  in Boolean isStatic)
  /** gets all objects of kind <kind> from map and updates
      <GameObject.list> accordingly */
{
  UINT8 index = 0;
  Boolean success;

  Map_resetPositionIterator(kind);

  do {
    Map_Position position;

    success = Map_getNextPosition(&position);
    if (success) {
      if (GameObject__count == GameObject__maxCount) {
	Assertion_DEBUG(false, "GameObject__getObjectsOfKind", 
			"more than maxCount objects");
	success = false;
      } else {
	GameObject__T *gameObject = &GameObject__list[GameObject__count];
	switch (kind) {
	case ConcreteMap_ObjectKind_player:
	  gameObject->type = &Player_typeDescriptor;  break;
	case ConcreteMap_ObjectKind_opponent:
	  gameObject->type = &Opponent_typeDescriptor;  break;
	case ConcreteMap_ObjectKind_gold:
	  gameObject->type = &GameObject__goldTypeDescriptor;  break;
	}
	gameObject->number = GameObject__count;
	GameObject__count++;
	gameObject->index = index;
	index++;
	STRUCT_ASSIGN(gameObject->position, position);
	gameObject->forcedDirection = GameObject__Direction_none;
	gameObject->animationKind = 0;
      }
    }
  } while (success);

  if (!isStatic) {
    Map_globalReplaceInMap (kind, ConcreteMap_ObjectKind_empty, false);
  }
}

/*--------------------*/

static void GameObject__handleCollision (in GameObject__T *gameObject,
					 inout GameObject_LevelResult *result)
   /** handles the collisions of <gameObject> with other objects with
       higher index and the background */
{
  Map_Position *position = &(gameObject->position);
  Map_ObjectKind backgroundObjectKind = Map_getEntry(position);
  Boolean isAtGold = (backgroundObjectKind == ConcreteMap_ObjectKind_gold);
  GameObject_TypeDescriptor *objectType = gameObject->type;
  Boolean isPlayer = (objectType == &Player_typeDescriptor);
  Boolean isOpponent = (objectType == &Opponent_typeDescriptor);

  if (isPlayer) {
    /* check whether player is caught by opponent or in brick */
    if (GameObject__overlapsWithOpponent(gameObject, position)
	|| backgroundObjectKind == ConcreteMap_ObjectKind_brick) {
      *result = GameObject_LevelResult_failed;
    }

    /* grab gold */
    if (isAtGold) {
      GameObject__treasureCount--;
      if (GameObject__treasureCount >= 4) {
	Map_setEntry(position, ConcreteMap_ObjectKind_empty);
      } else {
	ConcreteMapAnimation_Kind animationKind;
	animationKind = GameObject__treasureCount
	                  + ConcreteMapAnimation_Kind_noneLeft;
        ConcreteMapAnimation_start(position, animationKind);
      }
    }
  } else if (isOpponent) {
    GameObject_Index opponent = gameObject->index;
    Opponent_State state = Opponent_state(opponent);

    if (isAtGold && state == Opponent_State_unblocked) {
      Opponent_setState(opponent, Opponent_State_carrying);
      Map_setEntry(position, ConcreteMap_ObjectKind_empty);
    } else if (backgroundObjectKind == ConcreteMap_ObjectKind_brick) {
      /* opponent is in brick ==> push him to the top */
      if (position->y != 0) {
	position->y = 0;
      } else {
	position->x = Map_boundingBox.diagonalVector.x / 4;
      }
    }
  }
}

/*--------------------*/

static Boolean GameObject__isSupportedAtPosition (
                                    readonly Map_Position *position)
  /** tells whether some object may safely stay at <position>
      without being force into another (e.g. by falling) */
{
  Boolean isSupported;

  if (MapCoordinate_integerPart(position->y) == ConcreteMap_rowCount - 1) {
    /* this object is already at the bottom ==> no forced movement */
    isSupported = true;
  } else {
    Map_ObjectKind backgroundObjectKind;
    Map_Position referencePosition;

    referencePosition.x = MapCoordinate_addOperation(
					  position->x,
					  MapCoordinate_subunitCount / 2,
					  false);

    /* first check for grabbing of a rod or a ladder */
    referencePosition.y = position->y;
    backgroundObjectKind = Map_getEntry(&referencePosition);

    if (backgroundObjectKind == ConcreteMap_ObjectKind_ladder) {
      isSupported = true;
    } else if (backgroundObjectKind == ConcreteMap_ObjectKind_rod
	       && MapCoordinate_fractionalPart(referencePosition.y) == 0) {
      isSupported = true;
    } else {
      /* now check for standing on a ladder */
      referencePosition.y = MapCoordinate_addOperation(position->y,
					    MapCoordinate_subunitCount,
					    false);
      backgroundObjectKind = Map_getEntry(&referencePosition);

      if (backgroundObjectKind == ConcreteMap_ObjectKind_ladder) {
	isSupported = true;
      } else {
	Map_ObjectKind supportingObjectKind;
	/* look at cell one down of the object */
	referencePosition.y = MapCoordinate_addOperation(position->y,
					      MapCoordinate_subunitCount,
					      false);
	supportingObjectKind = Map_getEntry(&referencePosition);

	if (supportingObjectKind == ConcreteMap_ObjectKind_empty
	    || supportingObjectKind == ConcreteMap_ObjectKind_hole
	    || supportingObjectKind == ConcreteMap_ObjectKind_rod
	    || supportingObjectKind == ConcreteMap_ObjectKind_hiddenL
	    || supportingObjectKind == ConcreteMap_ObjectKind_trap
	    || supportingObjectKind == ConcreteMap_ObjectKind_gold) {
	  isSupported = false;
	} else {
	  isSupported = true;
	}
      }
    }
  }

  return isSupported;
}

/*--------------------*/

static void GameObject__move (inout GameObject__T *gameObject,
			      in GameObject_Action action,
			      readonly Map_Position *newPosition)
  /** moves <gameObject> to <newPosition> while performing <action>;
      also changes animation and takes care of speed */
{
  GameObject_Action animation;
  Map_ObjectKind backgroundObjectKind;
  GameObject_Index objectIndex = gameObject->index;
  Map_Position position;
  GameObject_TypeDescriptor *gameObjectType = gameObject->type;

  //Assertion_PRE(!gameObject->type->isStatic,
  //		"GameObject__move", GameObject__errMsg_staticObject);

  STRUCT_ASSIGN(position, *newPosition);
  STRUCT_ASSIGN(gameObject->position, position);

  backgroundObjectKind = Map_getEntry(&position);

  switch (action) {
    case GameObject_Action_climbUp:
    case GameObject_Action_climbDown:
      if (gameObject->forcedDirection == GameObject__Direction_none) {
	animation = action;
      } else {
	animation = GameObject_Action_fall;
      }
      break;
    case GameObject_Action_runLeft:
    case GameObject_Action_runRight:
      if (backgroundObjectKind != ConcreteMap_ObjectKind_rod) {
	animation = action;
      } else if (action == GameObject_Action_runLeft) {
	animation = GameObject_Action_clamberLeft;
      } else {
	animation = GameObject_Action_clamberRight;
      }
      break;
    case GameObject_Action_shootLeft:
    case GameObject_Action_shootRight:
      animation = action;  break;
  }

  gameObjectType->setAnimation(objectIndex, animation);
  /* start with animation */
  gameObjectType->setAnimationState(objectIndex, false);
}

/*--------------------*/

static Boolean GameObject__overlapsWithOpponent (in GameObject__T *gameObject,
					 readonly Map_Position *position)
  /** checks whether <gameObject> at <position> overlaps with some
      opponent or not */
{
  UINT8 i;
  Boolean result = false;
  MapCoordinate_Rectangle gameObjectRectangle;
  MapCoordinate_Rectangle otherRectangle;

  STRUCT_ASSIGN(gameObjectRectangle.diagonalVector,
		MapCoordinate_unitVector);
  STRUCT_ASSIGN(gameObjectRectangle.upperLeftCorner, *position);
  STRUCT_ASSIGN(otherRectangle.diagonalVector, MapCoordinate_unitVector);

  /* iterate over all opponents */
  for (i = 1;  i != GameObject__maxCount;  i++) {
    if (i != gameObject->number) {
      GameObject__T *otherObject = &(GameObject__list[i]);

      if (otherObject->type->objectKind != ConcreteMap_ObjectKind_opponent) {
	break;
      } else {
	MapCoordinate_Rectangle intersection;

	STRUCT_ASSIGN(otherRectangle.upperLeftCorner, otherObject->position);
	MapCoordinate_clipRectangle(&gameObjectRectangle, &otherRectangle,
				    &intersection);
	if (!MapCoordinate_isEmptyRect(&intersection)) {
	  result = true;
	  break;
	}
      }
    }
  }
  return result;
}

/*--------------------*/

static void GameObject__updateScenery (void)
  /** updates the positions of all non-static objects */
{
  Map_Position centrePosition;
  MapCoordinate_Rectangle gameObjectRectangle;
  UINT8 i;
  GameObject__T *player = &(GameObject__list[GameObject__playerIndex]);

  STRUCT_ASSIGN(gameObjectRectangle.diagonalVector, MapCoordinate_unitVector);
  GameObject__findCentrePos(&(player->position), &centrePosition);
  MapView_centreViewport(&centrePosition);

  for (i = 0;  i != GameObject__count;  i++) {
    /* iterate over all non-static objects */
    GameObject__T *gameObject = &GameObject__list[i];
    GameObject_TypeDescriptor *gameObjectType = gameObject->type;

    if (!gameObjectType->isStatic) {
      GameObject_Index gameObjectIndex = gameObject->index;
      Boolean isVisible;

      STRUCT_ASSIGN(gameObjectRectangle.upperLeftCorner,
		    gameObject->position);
      
      isVisible = MapView_isVisible(&gameObjectRectangle);

      if (!isVisible) {
	gameObjectType->hide(gameObjectIndex);
      } else {
	Screen_Coordinate screenX, screenY;
	MapView_findCoordInView(&(gameObject->position),
				&screenX, &screenY);
	gameObjectType->move(gameObjectIndex, &screenX, &screenY);
      }
    }
  }
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void GameObject_initialize (void)
{
  GameObject__count = 0;
  GameObject__treasureCount = 0;
}

/*--------------------*/

void GameObject_finalize (void)
{
}

/*--------------------*/

void GameObject_loadAllFromMap (void)
{
  GameObject__count = 0;
  GameObject__getObjectsOfKind(ConcreteMap_ObjectKind_player, false);
  GameObject__count = 1;
  GameObject__getObjectsOfKind(ConcreteMap_ObjectKind_opponent, false);

  if (GameObject__count > Opponent_maxCount) {
    GameObject__count = Opponent_maxCount;
  }

  Opponent_resetAllVariantData();

  GameObject__treasureCount = GameObject__count;
  GameObject__getObjectsOfKind(ConcreteMap_ObjectKind_gold, true);
  GameObject__treasureCount = GameObject__count - GameObject__treasureCount;
}

/*--------------------*/

void GameObject_showScenery (void)
{
  GameObject_Index i;
  GameObject_Index opponent;

  for (opponent = 0;  opponent != Opponent_maxCount;  opponent++) {
    Opponent_hide(opponent);
  }

  for (i = 0;  i != GameObject__count;  i++) {
    GameObject__T *gameObject = &GameObject__list[i];
    GameObject_TypeDescriptor *gameObjectType = gameObject->type;

    if (!gameObjectType->isStatic) {
      gameObjectType->setAnimation(gameObject->index,
				   GameObject_Action_runLeft);
    }
  }
  GameObject__updateScenery();
}

/*--------------------*/

GameObject_LevelResult GameObject_handleTickEvent (void)
{
  GameObject_Index i;
  GameObject_LevelResult levelResult = GameObject_LevelResult_running;
  GameObject__T *playerObject = &GameObject__list[0];
  Map_Position playerPosition;

  /* make changes on map */
  if (GameObject__treasureCount == 0) {
    Map_globalReplaceInMap(ConcreteMap_ObjectKind_hiddenL,
			   ConcreteMap_ObjectKind_ladder, true);
    GameObject__treasureCount--;
  }

  /* iterate over all animated objects */
  for (i = 0;  i != GameObject__count;  i++) {
    GameObject__T *gameObject = &GameObject__list[i];
    GameObject_TypeDescriptor *gameObjectType = gameObject->type;

    if (gameObjectType->isStatic) {
      /* forget about static objects */
    } else {
      Boolean isActive;
      Boolean isBlocked;
      Boolean isPlayer;
      Boolean isShooting;
      Boolean moveIsForced = false;
      MapCoordinate_Type moveOffset = 0;
      Map_Position *oldPosition;
      Map_Position newPosition;
      GameObject_Action objectAction;
      GameObject_Index objectIndex = gameObject->index;

      isPlayer = (gameObjectType->objectKind == ConcreteMap_ObjectKind_player);
      oldPosition = &gameObject->position;

      if (gameObject->forcedDirection != GameObject__Direction_none) {
	/* gameObject does not move freely */
	objectAction = gameObject->forcedDirection;
	moveOffset = GameObject__fallSpeed;
	moveIsForced = true;
	isShooting = false;
      } else {
	objectAction = gameObjectType->getNextAction(objectIndex,
						     oldPosition,
						     &playerPosition);

	isShooting = (objectAction >= GameObject_Action_shootLeft);

	if (isShooting) {
	  moveOffset = 0;
	} else {
	  moveOffset = gameObjectType->moveSpeed;
	}
      }

      isActive = (objectAction != GameObject_Action_none);

      if (!isPlayer) {
	/* check whether opponent is dropping gold */
	Opponent_State state = Opponent_state(objectIndex);
	Map_ObjectKind backgroundObjectKind;
	backgroundObjectKind = Map_getEntry(&gameObject->position);

	if (state == Opponent_State_dropping
	    && (objectAction == GameObject_Action_runLeft
	        || objectAction == GameObject_Action_runRight)
	    && backgroundObjectKind == ConcreteMap_ObjectKind_empty) {
	  Opponent_setState(objectIndex, Opponent_State_blocked);
	  Map_setEntry(oldPosition, ConcreteMap_ObjectKind_gold);
	}
      }

      if (isShooting) {
	/* process shoot */
	GameObject__doShooting(gameObject, &newPosition, objectAction);
	isBlocked = false;
      } else if (!isActive) {
	isBlocked = true;
      } else {
	/* process ordinary move */
        GameObject__findNewPosition(gameObject, objectAction,
				    moveOffset, moveIsForced,
				    &newPosition, &isBlocked);
      }

      if (isBlocked) {
	gameObject->forcedDirection = GameObject__Direction_none;
	isActive = false;
      }

      if (isActive) {
	GameObject__move(gameObject, objectAction, &newPosition);
      } else {
	/* pause with animation */
	gameObjectType->setAnimationState(objectIndex, true);
      }

      gameObjectType->handleTickEvent(objectIndex);
      GameObject__checkForForce(gameObject);

      if (isPlayer) {
	STRUCT_ASSIGN(playerPosition, gameObject->position);
      }
      GameObject__handleCollision(gameObject, &levelResult);
    }
  }

  GameObject__updateScenery();

  /* are we already done? */
  if (levelResult == GameObject_LevelResult_running 
      && GameObject__treasureCount < 0 && playerObject->position.y == 0) {
    levelResult = GameObject_LevelResult_completed;
    SpriteAnimation_stopAll();
  }

  return levelResult;
}
