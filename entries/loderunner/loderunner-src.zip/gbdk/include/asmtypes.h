/** @file asmtypes.h
    Shared types definitions.
*/
#ifndef ASM_TYPES_INCLUDE
#define ASM_TYPES_INCLUDE

/*--------------------*/

#define NONBANKED	nonbanked
#define BANKED		banked

/** some parameter modes merely for documentation */
#define in
#define out
#define inout
#define readonly

/** Signed eight bit.
 */
typedef char          	INT8;
/** Unsigned eight bit.
 */
typedef unsigned char 	UINT8;
/** Signed sixteen bit.
 */
typedef int           	INT16;
/** Unsigned sixteen bit.
 */
typedef unsigned int  	UINT16;
/** Signed 32 bit.
 */
typedef long          	INT32;
/** Unsigned 32 bit.
 */
typedef unsigned long 	UINT32;

#ifndef _SIZE_T_DEFINED
# define _SIZE_T_DEFINED
  typedef int	      	size_t;
#endif

/** Returned from clock
    @see clock
*/
typedef UINT16		clock_t;

/** TRUE or FALSE.
 */
typedef INT8		BOOLEAN;

#if BYTE_IS_UNSIGNED
  typedef UINT8		BYTE;
  typedef UINT16	WORD;
  typedef UINT32	DWORD;
#else
  /** Signed 8 bit. */
  typedef INT8         	BYTE;
  /** Unsigned 8 bit. */
  typedef UINT8        	UBYTE;
  /** Signed 16 bit */
  typedef INT16      	WORD;
  /** Unsigned 16 bit */
  typedef UINT16       	UWORD;
  /** Signed 32 bit */
  typedef INT32       	LWORD;
  /** Unsigned 32 bit */
  typedef UINT32      	ULWORD;
  /** Signed 32 bit */
  typedef INT32	   	DWORD;
  /** Unsigned 32 bit */
  typedef UINT32	   	UDWORD;

  /** Useful definition for fixed point values */
  typedef union _fixed {
    struct {
      UBYTE l;
      UBYTE h;
    } b;
    UWORD w;
  } fixed;
#endif

#endif
