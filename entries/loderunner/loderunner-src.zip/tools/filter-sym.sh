#!/bin/sh
#=============================================================
# filters junk lines from sym file for NO$GMB emulator
#
# usage: filter-sym fileName
#
#  fileName       prefix of GB symbol file (without extension)
#=============================================================

tempFile=$1.xxx
${GAWK_PROGRAM} -f ${TOOLS_DIR}/filter-sym.awk $1.sym >${tempFile}
${CP_PROGRAM} $1.sym $1.sym.old
${CP_PROGRAM} ${tempFile} $1.sym
${RM_PROGRAM} ${tempFile}
