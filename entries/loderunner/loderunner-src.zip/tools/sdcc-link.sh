#!/bin/sh
# ====================================================================
# wrapper for the SDCC-Linker
#
# usage: sdcc-link mainObjectFileName { objectFileName }
#
#     mainObjectFileName  name of object file determining the main program
#     objectFileName      name of supporting object file
#
#   external environment variables
#     SDCC_LIBRARIES: list of available libraries
#     SDCC_STANDARD_OBJECTS: name of main wrapper object (like crt.o)
#     SDCC_USER_LINK_OPTIONS: additional user options for linker
# ====================================================================

sdccObjects=$*
mainFileName="`dirname $1`/`basename $1 .o`"

# *** add to link options ***
# set color gameboy, 8kB external cartridge RAM enabled
sdccLinkOptions="${SDCC_USER_LINK_OPTIONS} -yp0x143=0xC0 -yp0x149=0x02"

echo "=== linking ${mainFileName} ==="
sdccLinker=rev-link-gbz80.exe
${sdccLinker} -n -- -u -j -z ${sdccLinkOptions} ${mainFileName}.gb ${SDCC_STANDARD_OBJECTS} ${SDCC_LIBRARIES} ${sdccObjects}
