#!/bin/bash
#============================================================
# wrapper for the SDCC-Compiler
#
# usage: sdcc-compile [-o directory] [-s directory] [--debug]
#                     [--prof] [-code bank] [--OLD] cFileBaseName
# 
#   -o       specifies the directory for the object files
#   -s       specifies the directory of the source file
#   --debug  tells that intermediate files are kept for debugging
#   --prof   adds prologue and epilogue code for profiling
#   --code   specifies the bank number where the code should later be
#            linked to
#
#   external environment variables
#       GAWK_PROGRAM:             path of executable for gawk
#       MV_PROGRAM:               path of executable for mv
#       KEEP_LIST_FILES:          tells that assembly list files are kept
#       RM_PROGRAM:               path of executable for rm
#       SDCC_PATH:                root directory of SDCC compiler
#       SDCC_USER_DEFINES:        options for SDCC compiler
#       TARGET_INCLUDE_DIR:       include directory for current compilation
#       TARGET_INCLUDE_ROOT_DIR:  include directory for current compilation
#       TOOLS_DIR:                directory for tools and gawk scripts
#
#============================================================

#--------------------
compile()
{
  # compile with SDCC and suppress the "from type ... to type ..."
  # message in SDCC; return result in <compilationResult>
  local tempFile=temp

  ${SDCC_PATH}/bin/sdcc ${sdccAllOptions} ${sdccSourceFileName} \
     >${tempFile} 2>&1 
  compilationResult=$?

  cat ${tempFile} | grep -v "^from type " | grep -v "^to type "
  ${RM_PROGRAM} ${tempFile}
}

#--------------------


# -- set variables --
sdccIncludeOptions="-I${TARGET_INCLUDE_DIR} \
                    -I${TARGET_INCLUDE_ROOT_DIR} \
                    -I${SDCC_PATH}/include"
sdccDefines="-DSDCC_PORT=gbz80 -DSDCC_MODEL_SMALL -DGB -D__gbz80 \
             -D_gbz80 -Dgbz80  -DGAMEBOY -DINT_16_BITS -DBUGFIX \
             ${SDCC_USER_DEFINES}"

# -- set compilation options --
sdccOptions="-S -lang-c99 -mgbz80 --debug --i-code-in-asm --opt-code-size"

# -- skip certain warnings --
#    18  different levels of indirection
#    85  unreferenced function argument
#   126 unreachable code (optimized away)
sdccOptions="${sdccOptions} --disable-warning 18"
sdccOptions="${sdccOptions} --disable-warning 85"
sdccOptions="${sdccOptions} --disable-warning 126"

# -- remove some optimizations --
sdccOptions="${sdccOptions} --nogcse"

sdccObjectDirectory=.
sdccSourceDirectory=.
sdccCodeSegment="--codeseg BASE --constseg BASE"
sdccIsDebugging="false"
sdccFileName="???"

# -- parse options --
PARAMCOUNT=$#

for (( i=1;  i <= ${PARAMCOUNT};  i++ )); do
  if [ "$1" == "-o" ]; then
    shift
    let i++
    sdccObjectDirectory="$1"
  elif [ "$1" == "-s" ]; then
    shift
    let i++
    sdccSourceDirectory="$1"
  elif [ "$1" == "--debug" ]; then
    sdccIsDebugging="true"
  elif [ "$1" == "--prof" ]; then
    sdccOptions="${sdccOptions} --profile"
  elif [ "$1" == "--code" ]; then
    shift
    let i++
    sdccCodeSegment="--codeseg CODE_$1 --constseg CODE_$1"
  else
    sdccFileName="$1"
  fi

  shift
done

sdccObjectFileName="${sdccObjectDirectory}/${sdccFileName}.o"
sdccSourceFileName="${sdccSourceDirectory}/${sdccFileName}.c"
sdccOptions="${sdccOptions} ${sdccCodeSegment}"

# -- test for existence of target and whether it is older than source
if [ -e ${sdccObjectFileName} -a ${sdccObjectFileName} -nt ${sdccSourceFileName} ]; then
  updateIsNecessary="false"
else
  updateIsNecessary="true"
fi

# recompile when update is necessary
if [ "${updateIsNecessary}" == "false" ]; then
  echo "=== ${sdccFileName}.o is current ==="
else
  # -- do the compilation and assembly --
  sdccAllOptions="${sdccIncludeOptions} ${sdccDefines} ${sdccOptions}"

  echo "=== Compile ${sdccFileName}.c ==="
  compile

  if [ ${compilationResult} != 0 ]; then
    echo "=== ### compilation failed ### ==="
    exit 1
  else
    echo "=== Assemble ${sdccFileName}.asm ==="
    ${GAWK_PROGRAM} -f ${TOOLS_DIR}/rmAsmJunk.awk ${sdccFileName}.asm \
       >${sdccFileName}.xxx
    ${SDCC_PATH}/bin/as-gbz80 -pogl ${sdccFileName}.o ${sdccFileName}.xxx

    ${MV_PROGRAM} ${sdccFileName}.o ${sdccObjectDirectory}
    ${RM_PROGRAM} ${sdccFileName}.i

    if [ "${KEEP_LIST_FILES}" == "true" ]; then
      ${MV_PROGRAM} ${sdccFileName}.lst ${sdccObjectDirectory}
    else
      ${RM_PROGRAM} ${sdccObjectDirectory}/${sdccFileName}.lst
    fi

    ${RM_PROGRAM} ${sdccFileName}.map ${sdccFileName}.ihx
  fi
fi

# --- clean up ---
${RM_PROGRAM} ${sdccObjectDirectory}/${sdccFileName}.adb
${RM_PROGRAM} ${sdccObjectDirectory}/${sdccFileName}.asm
${RM_PROGRAM} ${sdccObjectDirectory}/${sdccFileName}.xxx

if [ ${sdccIsDebugging} == "false" ]; then
  ${RM_PROGRAM} ${sdccFileName}.adb ${sdccFileName}.asm
  ${RM_PROGRAM} ${sdccFileName}.lst ${sdccFileName}.xxx
else
  ${MV_PROGRAM} ${sdccFileName}.adb ${sdccObjectDirectory}
  ${MV_PROGRAM} ${sdccFileName}.asm ${sdccObjectDirectory}
  ${MV_PROGRAM} ${sdccFileName}.lst ${sdccObjectDirectory}
  ${MV_PROGRAM} ${sdccFileName}.xxx ${sdccObjectDirectory}
fi
