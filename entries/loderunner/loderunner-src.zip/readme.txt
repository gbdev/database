======================================
Loderunner for GBC Source Distribution
======================================

This is the source suite for the Loderunner game for the Gameboy
Color for compilation with the SDCC-C-Compiler.

-------------
Preconditions
-------------

Ensure that you have the following software available:

  - a current installation of the SDCC compiler for your platform,

  - an AWK program (e.g. GNU awk) and

  - the revised GBZ80 linker (replacing the one in the SDCC
    distribution).

The latter is necessary because it supports link-time banking
configuration, which the original SDCC linker does not.

------------------
Installation Steps
------------------

For installation you should proceed as follows:

  1. Edit the file "configure.mk" for the Unix platform or the file
     "configure.bat" for the Windows platform (see below for details).

  2. For Windows start the file "install-loderunner.bat", for Unix
     start the file "install-loderunner.sh".  The preparation and
     installation starts and will take a few minutes.

  3. When you have correctly configured everything the Gameboy image
     is placed into the appropriate directory ready for use.  You can
     either start it with an emulator or transfer it to some cartridge
     for the Gameboy.


---------------------------------
Setting up the configuration file
---------------------------------

The configuration file is a makefile for Unix and a batch file for
Windows.  Here you can set the directories for sources and target
files, the names of the programs in your environment etc.

Note that the source files are in principle copied to some other
place.  Normally you specify some directory for the installation that
has subdirectories for the include files, the sources and the objects
plus the final executable.

Hence the following variables have to be defined:

  - installationRootDir:
    the parent directory of all target directories

  - TARGET_INCLUDE_ROOT_DIR:
    the root directory of the C include files; normally set to
    installationRootDir/install

  - TARGET_SOURCE_ROOT_DIR:
    the root directory of the C src files; normally set to
    installationRootDir/lib-src

  - TARGET_OBJECT_ROOT_DIR:
    the root directory of the generated object files; normally set to
    installationRootDir/objects

  - CP_PROGRAM:
    the path name of the copy program; "cp" on Unix and "copy" on
    Windows

  - GAWK_PROGRAM:
    the path name of the GAWK program

  - MKDIR_PROGRAM:
    the path name of the directory creation program (MKDIR)

  - MV_PROGRAM:
    the path name of the file movement program; "mv" on Unix and
    "move" on Windows

  - RM_PROGRAM: 
    the path name of the file deletion program; "rm" on Unix and "del"
    on Windows

  - TOOLS_DIR:
    the path name of the directory containing the specific tools for
    installation (like Shell or AWK scripts); typically it is the
    "tools" subdirectory of the main installation directory

  - SDCC_PATH:
    the directory of the SDCC compiler

  - TARGET_LANGUAGE_IS_ENGLISH:
    variable selecting whether English or German should be used as the
    game language compiled into the executable ("true"/"false")

  - KEEP_LIST_FILES:
    tells whether assembly list files should be kept in objects
    directory ("true"/"false"); otherwise they will be thrown away

  - SDCC_LIBRARIES:
    the library paths and files for SDCC (provided as SDCC
    commandline options)

  - SDCC_STANDARD_OBJECTS:
    the main object file for SDCC containing the base runtime system;
    typically this is "crt.o" in some appropriate path
