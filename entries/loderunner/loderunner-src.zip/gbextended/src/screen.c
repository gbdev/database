/** Screen module --
    Implementation of module providing basic services for handling the
    screen of a GameBoy.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/screen.h>

/*========================================*/

#include <gb/hardware.h>
#include <gb/gb.h>

/*========================================*/

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Screen_initialize (void)
{
}

/*--------------------*/

void Screen_finalize (void)
{
}

/*--------------------*/

Boolean Screen_isInFrameGap (void)
{
  return (LY_REG >= 145);
}

/*--------------------*/

void Screen_waitForFrameGap (void)
{
  wait_vbl_done();
}

/*--------------------*/

void Screen_turnOffInFrameGap (void)
{
  display_off();
}

/*--------------------*/

void Screen_turnOn (void)
{
  LCDC_REG |= 0x80U;
}
