/** Palette module --
    Implementation of module providing services for handling the
    palettes of a GameBoy Color.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/palette.h>

/*========================================*/

#include <gb/cgb.h>

/*========================================*/

void Palette_initialize (void)
{
}

/*--------------------*/

void Palette_finalize (void)
{
}

/*--------------------*/


void Palette_setBkgPalettes (in Palette_Type firstPalette,
			     in UINT8 count,
			     in Palette_Data *paletteDataList)
{
  UINT8 i;
  for (i = 0;  i != count;  i++) {
    set_bkg_palette(firstPalette + i, 1, paletteDataList[i]);
  }
}

/*--------------------*/

void Palette_setSpritePalettes (in Palette_Type firstPalette,
				in UINT8 count,
				in Palette_Data *paletteDataList)
{
  UINT8 i;
  for (i = 0;  i != count;  i++) {
    set_sprite_palette(firstPalette + i, 1, paletteDataList[i]);
  }
}

/*--------------------*/

void Palette_setBkgPaletteEntry (in Palette_Type palette,
				 in UINT8 entry,
				 in Palette_Colour colour)
{
  set_bkg_palette_entry(palette, entry, colour);
}


/*--------------------*/

void Palette_setSprPaletteEntry (in Palette_Type palette,
				 in UINT8 entry,
				 in Palette_Colour colour)
{
  set_sprite_palette_entry(palette, entry, colour);
}
