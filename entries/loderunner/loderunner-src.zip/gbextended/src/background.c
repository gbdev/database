/** Background module --
    Implementation of module providing services for handling the
    background of a GameBoy Color.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/background.h>

/*========================================*/

#include <gbextended/assertion.h>
#include <gbextended/hardware.h>
#include <gbextended/screen.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

#include <gbextended/bugfix.h>

/*========================================*/

/* variables storing the data to be copied into background during frame
   gap */
#ifdef SDCC
static Tile_Type at 0xA000 Background__tileBuffer[1024];
static Tile_Attribute at 0xA400 Background__attributeBuffer[1024];
#else
static Tile_Type Background__tileBuffer[1024];
static Tile_Attribute Background__attributeBuffer[1024];
#endif

/*--------------------*/

typedef struct {
  Background_TilePosition upperLeftCorner;
  Background_PixelOffset pixelOffset;
  /* 0 <= pixelOffset.deltaX < Tile_width */
  /* 0 <= pixelOffset.deltaY < Tile_width */
  UINT8 rowCount;
  UINT8 columnCount;
} Background__VPType;

static Background__VPType Background__viewport;

/*--------------------*/

typedef struct {
  Background_TilePosition lowerRightCorner;
  Boolean rowsAreCircular;
  Boolean columnsAreCircular;
  Background_UpdateProc updateProc;
} Background__Descriptor;


static Background__Descriptor Background__current;
  /** single variable storing the information of current background */

static Background_TilePosition Background__zeroPosition = { 0, 0 };
static Background_PixelOffset Background__zeroOffset = { 0, 0 };

UINT8 Background_tilesPerRow;
UINT8 Background_tilesPerColumn;

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Background__updateVP (
			  readonly Background_TilePosition *upperLeftCorner,
			  readonly Background_PixelOffset *pixelOffset)
{
  STRUCT_ASSIGN(Background__viewport.upperLeftCorner, *upperLeftCorner);
  STRUCT_ASSIGN(Background__viewport.pixelOffset, *pixelOffset);
}

/*--------------------*/

static void Background__fillViewport (
			in Background_TileCoordinate leftColumn,
			in Background_TileCoordinate topRow,
			in Background_TileCoordinate leftColumnInViewport,
			in Background_TileCoordinate topRowInViewport, 
			in UINT8 columnCount,
			in UINT8 rowCount)
  /** updates the viewport by reading the tiles in map view from
      (leftColumn,topRow) to
      (leftColumn+columnCount-1,topRow+rowCount-1) into relative
      positions (leftColumnInViewport,topRowInViewport) in viewport */
{
  Background_TilePosition *lowerRightCorner;
  Background_TilePosition upperLeftCorner;
  Background_TilePosition upperLeftCornerInViewport;
  Background_TilePosition lowerRightUpdateCorner;
  INT8 wraparoundCount; /** number of units viewport has to wrap
			    around in this dimension */
  UINT8 newColumnCount;
  UINT8 newRowCount;
  UINT8 newTopRow;
  UINT8 newLeftColumn;
  Background_TileCoordinate newLeftColumnInViewport;
  Background_TileCoordinate newTopRowInViewport; 

  lowerRightCorner = &(Background__current.lowerRightCorner);

  /* split along rows when row wrap-around occurs */
  wraparoundCount = topRow + rowCount - 1 - lowerRightCorner->row;

  if (wraparoundCount <= 0) {
    newTopRow = topRow;
    newRowCount = rowCount;
    newTopRowInViewport = topRowInViewport;
  } else {
    UINT8 otherRowCount;

    otherRowCount = rowCount - wraparoundCount;
    Background__fillViewport(leftColumn, topRow,
			     leftColumnInViewport, topRowInViewport, 
			     columnCount, otherRowCount);
    newRowCount = wraparoundCount;
    newTopRow = 0;
    newTopRowInViewport = otherRowCount;
  }

  /* split along columns when column wrap-around occurs */
  wraparoundCount = leftColumn + columnCount - 1 - lowerRightCorner->column;

  if (wraparoundCount <= 0) {
    newLeftColumn = leftColumn;
    newColumnCount = columnCount;
    newLeftColumnInViewport = leftColumnInViewport;
  } else {
    UINT8 otherColumnCount;

    otherColumnCount = columnCount - wraparoundCount;
    Background__fillViewport(leftColumn, topRow,
			     leftColumnInViewport, topRowInViewport, 
			     otherColumnCount, rowCount);
    newColumnCount = wraparoundCount;
    newLeftColumn = 0;
    newLeftColumnInViewport = otherColumnCount;
  }

  /* all splits done ==> execute the update */
  upperLeftCorner.row    = newTopRow;
  upperLeftCorner.column = newLeftColumn;
  lowerRightUpdateCorner.row    = newTopRow + newRowCount - 1;
  lowerRightUpdateCorner.column = newLeftColumn + newColumnCount - 1;
  upperLeftCornerInViewport.row    = newTopRowInViewport;
  upperLeftCornerInViewport.column = newLeftColumnInViewport;

  (*Background__current.updateProc)(&upperLeftCorner,
				    &lowerRightUpdateCorner,
				    &upperLeftCornerInViewport,
				    Hardware_tilesPerBufferRow,
				    Background__tileBuffer,
				    Background__attributeBuffer);
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Background_initialize (void)
{
  Background_TilePosition *lowerRightBGCorner;

 /* initialize current background and viewport */
  Background_tilesPerRow    = Screen_graphicsHeight / Tile_width;
  Background_tilesPerColumn = Screen_graphicsWidth / Tile_width;

  lowerRightBGCorner = &(Background__current.lowerRightCorner);
  lowerRightBGCorner->column = 0;
  lowerRightBGCorner->row    = 0;
  Background__current.updateProc = NULL;

  Background__updateVP(&Background__zeroPosition, &Background__zeroOffset);

  Background__viewport.columnCount = Background_tilesPerColumn;
  Background__viewport.rowCount    = Background_tilesPerRow;
}

/*--------------------*/

void Background_finalize (void)
{
}

/*--------------------*/

void Background_showLayer (void)
{
  Hardware_Bkg_show();
}

/*--------------------*/

void Background_hideLayer (void)
{
  Hardware_Bkg_hide();
}

/*--------------------*/

void Background_define (readonly Background_TilePosition *lowerRightCorner,
			in Boolean columnsAreCircular,
			in Boolean rowsAreCircular,
			in Background_UpdateProc updateProc)
{
  STRUCT_ASSIGN(Background__current.lowerRightCorner, *lowerRightCorner);
  Background__current.columnsAreCircular = columnsAreCircular;
  Background__current.rowsAreCircular = rowsAreCircular;
  Background__current.updateProc = updateProc;
  Background__updateVP(&Background__zeroPosition, &Background__zeroOffset);
}

/*--------------------*/

void Background_getViewport (out Background_TilePosition *upperLeftCorner,
			     out Background_TilePosition *diagonalVector,
			     out Background_PixelOffset *pixelOffset)
{
  STRUCT_ASSIGN(*upperLeftCorner, Background__viewport.upperLeftCorner);
  diagonalVector->column = Background__viewport.columnCount;
  diagonalVector->row    = Background__viewport.rowCount;
  STRUCT_ASSIGN(*pixelOffset, Background__viewport.pixelOffset);
}

/*--------------------*/

void Background_setViewport (
		     readonly Background_TilePosition *upperLeftCorner,
		     readonly Background_PixelOffset *pixelOffset)
{
  { /* precondition */
    Background_TilePosition lastAllowedCorner;

    Background_lastCorner(&lastAllowedCorner);

    Assertion_PRE(upperLeftCorner->row <= lastAllowedCorner.row,
		  "Background_setViewport", "row out of bounds");
    Assertion_PRE(upperLeftCorner->column <= lastAllowedCorner.column,
		  "Background_setViewport", "column out of bounds");
  }

  { /* normal processing */
    Background__updateVP(upperLeftCorner, pixelOffset);
  }
}

/*--------------------*/

void Background_showInScreen (void)
{
  UINT8 columnCount = Background__viewport.columnCount;
  UINT8 rowCount    = Background__viewport.rowCount;
  UINT8 deltaX = Background__viewport.pixelOffset.deltaX;
  UINT8 deltaY = Background__viewport.pixelOffset.deltaY;

  /* increase tiles to fetch when pixel offset is not zero */
  if (deltaX != 0) { columnCount++; }
  if (deltaY != 0) { rowCount++; }

  /* get data into the tile and attribute buffer */
  Background__fillViewport(Background__viewport.upperLeftCorner.column,
			   Background__viewport.upperLeftCorner.row,
			   0, 0,
			   columnCount, rowCount);

  Hardware_Bkg_updateAttribs(&Background__attributeBuffer);

  /* move the background for a partial tile  */
  Hardware_Bkg_move(deltaX, deltaY);

  Hardware_Bkg_updateTiles(&Background__tileBuffer);
}

/*--------------------*/

void Background_lastCorner (out Background_TilePosition *tilePosition)
{
  Background_TileCoordinate row;
  Background_TileCoordinate column;

  row = Background__current.lowerRightCorner.row;
  column = Background__current.lowerRightCorner.column;

  if (!Background__current.rowsAreCircular) {
    row -= (Background__viewport.rowCount - 1);
  }

  tilePosition->row = row;

  if (!Background__current.columnsAreCircular) {
    column -= (Background__viewport.columnCount - 1);
  }
  
  tilePosition->column = column;
}

