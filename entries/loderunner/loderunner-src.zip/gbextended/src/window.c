/** Window module --
    Implementation of module providing services for handling the
    window layer of a GameBoy Color.

    Original version by Thomas Tensi, 2004-11
*/

#include <gbextended/window.h>

/*========================================*/

#include <gbextended/font.h>
#include <gbextended/palette.h>
#include <gbextended/set.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>
#include <gb/gb.h>

#ifdef WINDOWS
#include <stdio.h>
#endif

/*========================================*/

#define Window__columnCount 20
  /** total number of columns for window */
#define Window__rowCount 18
  /** total number of rows for window */

static Boolean Window__borderIsEnabled;
static UINT8 Window__effectiveColCount;
static UINT8 Window__effectiveRowCount;
static UINT8 Window__frameWidth;
static UINT8 Window__frameHeight;

#define Window__effectiveTileCount 360

static Tile_Type Window__tempTiles[Window__effectiveTileCount];

static char Window__tempString[256];

static UINT8 Window__row;
  /** row within window draw area (i.e., the border is ignored) */
static UINT8 Window__column;
  /** column within window draw area (i.e., the border is ignored) */

static Tile_Type Window__tileList[Window__columnCount];
static char Window__currentLine[Window__columnCount + 1];

/* contains the bitmaps for the tiles used by map view */
static const Palette_Data Window__palettes[] = {
  { 0x7FFF, 0, 0, 0 }
};

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Window__makeRowWithBoundary (UINT8 row)
  /** puts out single row <row> in window from contents in
      <Window__tileList> where the windows boundary is also put out */
{
  set_win_tiles(0, row, Window__columnCount, 1, Window__tileList);
}

/*--------------------*/

static void Window__makeRow (UINT8 column, Tile_Type *tileList)
  /** puts out contents window row specified by <Window__row> in up to
      <column> from <tileList> */
{
  set_win_tiles(Window__frameWidth, Window__row + Window__frameHeight,
		column, 1, tileList);
}

/*--------------------*/

static void Window__makeFrame (void)
  /** clears window contents and sets the window tile attributes; when
      <Window__borderIsEnabled> is set, also draws a border around
      window */
{
  const char barCharacter = '|';
  const char minusCharacter = '-';
  const char plusCharacter = '+';
  UINT8 i;

  /* set attributes of window tiles: the palette is the last
     background palette */
  VBK_REG = 1;
  String_setMemory(Window__tileList, 7, Window__columnCount);
  for (i = 0;  i != Window__rowCount;  i++) {
    Window__makeRowWithBoundary(i);
  }

  /* set tiles */  
  VBK_REG = 0;
  Window__currentLine[Window__columnCount] = String_terminator;
  String_setMemory(Window__currentLine, ' ', Window__columnCount);

  if (Window__borderIsEnabled) {
    Window__currentLine[0] = barCharacter;
    Window__currentLine[Window__columnCount - 1] = barCharacter;
  }

  Font_convertToTiles(Window__currentLine, Window__tileList);

  for (i = 0;  i != Window__effectiveRowCount;  i++) {
    Window__makeRowWithBoundary(i + Window__frameHeight);
  }

  if (Window__borderIsEnabled) {
    String_setMemory(Window__currentLine, minusCharacter,
		     Window__columnCount);
    Window__currentLine[0] = plusCharacter;
    Window__currentLine[Window__columnCount - 1] = plusCharacter;
    Font_convertToTiles(Window__currentLine, Window__tileList);
    Window__makeRowWithBoundary(0);
    Window__makeRowWithBoundary(Window__rowCount - 1);
  }
}

/*--------------------*/

void Window__setBorderStatus (in Boolean isEnabled)
  /** based on <isEnabled> defines whether window has a one-character
      border; note that all operations are clipped at the border, when
      it is enabled */
{
  if (isEnabled) {
    Window__frameWidth = 1;
    Window__frameHeight = 1;
  } else {
    Window__frameWidth = 0;
    Window__frameHeight = 0;
  }

  Window__effectiveColCount = Window__columnCount - 2 * Window__frameWidth;
  Window__effectiveRowCount = Window__rowCount - 2 * Window__frameHeight;
  Window__borderIsEnabled = isEnabled;
}

/*--------------------*/

static void Window__writeTempString (void)
  /** puts out contents of <Window__tempString> to window */
{
  char *ptr;

#ifdef WINDOWS
  printf("%s", Window__tempString);
#else
  VBK_REG = 0;

  /* break up <tempString> into single lines */
  for (ptr = Window__tempString;  *ptr != String_terminator ;  ptr++) {
    const char ch = *ptr;
    Boolean newlineIsNeeded = false;

    if (ch == '\n') {
      newlineIsNeeded = true;
    } else {
      Window__currentLine[Window__column] = ch;
      Window__column++;
      newlineIsNeeded = (Window__column == Window__effectiveColCount);
    }

    if (newlineIsNeeded) {
      if (Window__column != Window__frameWidth) {
	Font_convertToTiles(Window__currentLine, Window__tileList);
	Window__makeRow(Window__column, Window__tileList);
	Window__column = 0;
      }

      Window__row++;

      if (Window__row == Window__effectiveRowCount) {
	/* scroll window */
	get_win_tiles(Window__frameWidth, Window__frameHeight + 1,
		      Window__effectiveColCount,
		      Window__effectiveRowCount - 1,
		      Window__tempTiles);
	set_win_tiles(Window__frameWidth, Window__frameHeight,
		      Window__effectiveColCount,
		      Window__effectiveRowCount - 1,
		      Window__tempTiles);
	String_setMemory(Window__tempTiles, 0, Window__effectiveColCount);
	Window__row--;
	Window__makeRow(Window__effectiveColCount, Window__tempTiles);
      }
    }
  }

  if (Window__column != 0) {
    Font_convertToTiles(Window__currentLine, Window__tileList);
    Window__makeRow(Window__column, Window__tileList);
  }
#endif
}

/*--------------------*/

static void Window__writeNumber (in UINT16 number, in UINT8 base)
{
  String_makeFromInteger(number, Window__tempString, base);
  Window__writeTempString();
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Window_initialize (void)
{
  /* the last palette is white and black */
  Palette_setBkgPalettes(7, 1, Window__palettes);
  move_win(7, 0);
  Window__borderIsEnabled = true;
  Window__setBorderStatus(false);
}

/*--------------------*/

void Window_finalize (void)
{
}

/*--------------------*/

void Window_showLayer (void)
{
  LCDC_REG |= 0x20U;
}

/*--------------------*/

void Window_hideLayer (void)
{
  LCDC_REG &= 0xDFU;
}

/*--------------------*/

void Window_clear (in Boolean borderIsEnabled)
{
  Window__setBorderStatus(borderIsEnabled);
  Window__makeFrame();
  String_setMemory(Window__currentLine, 0, Window__columnCount); 

  Window__row = 0;
  Window__column = 0;
}

/*--------------------*/

void Window_clearLine (void)
{
  UINT8 column = Window__column;
  UINT8 row = Window__row;
  UINT8 i;
  UINT8 j;
  UINT8 lastColumn = Window__effectiveColCount;

  for (j = 0, i = column;  i != lastColumn;  i++, j++) {
    Window__tempString[j] = ' ';
  }
  Window__tempString[j] = String_terminator;
  Window__writeTempString();
  Window__column = column;
  Window__row = row;
}

/*--------------------*/

void Window_gotoRowColumn (in UINT8 row, in UINT8 column)
{
  Window__row = row;
  Window__column = column;

  /* set currentLine accordingly */
  get_win_tiles(Window__frameWidth, row + Window__frameHeight,
		Window__frameWidth + column, 1, Window__tileList);
  Font_convertFromTiles(Window__tileList, column, Window__currentLine);
}

/*--------------------*/

void Window_writeLine (void)
{
  Window_writeChar('\n');
}

/*--------------------*/

void Window_writeChar (in char ch)
{
  Window__tempString[0] = ch;
  Window__tempString[1] = String_terminator;
  Window__writeTempString();
}

/*--------------------*/

void Window_writeString (in char *st)
{
  String_boundedCopy(Window__tempString, st, sizeof(Window__tempString));
  Window__writeTempString();
}

/*--------------------*/

void Window_writeCard (in UINT16 u)
{
  Window__writeNumber(u, 10);
}

/*--------------------*/

void Window_writeInt (in INT16 i)
{
  if (i < 0) {
    i = -i;
    Window_writeChar('-');
  }

  Window_writeCard(i);
}
