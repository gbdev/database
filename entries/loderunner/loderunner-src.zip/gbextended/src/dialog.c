/** Dialog module --
    Implementation of module providing all services for handling the
    user dialogs in a GameBoy game.

    Original version by Thomas Tensi, 2005-07
*/

#include <gbextended/dialog.h>

/*========================================*/

#include <gbextended/joypad.h>
#include <gbextended/screen.h>
#include <gbextended/set.h>
#include <gbextended/sprite.h>
#include <gbextended/string.h>
#include <gbextended/types.h>
#include <gbextended/window.h>

/*========================================*/

#define Dialog__tempStringLength 20
static char Dialog__tempString[Dialog__tempStringLength];

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Dialog__showCascadedChoice (in String_Type message,
					in String_List itemList,
					in Dialog_ItemRoutine routineList[],
					out UINT8 *selectedItem,
					inout String_List selectionList)
  /* shows dialog window for a cascaded menu; <message> gives the
     lead-in text, each top level item is characterized by a string in
     the <itemList>; <routineList> is an array of routine pointers
     which handle any keypresses within a specific item;
     <selectionList> gives the initial and final values as a string
     pointer per item; if a specific element of <routineList> is NULL,
     then no subitems can be selected for the given item; if
     <routineList> is NULL altogether, then all items have no
     subitems; <selectedItem> gives the index of the last item
     selected */
{
  Boolean currentItemHasSubitems;
  UINT8 currentItemIndex = 0;
  String_Type *currentSubitem = NULL;
  Boolean cursorIsOnTopLevel = true;
  Boolean listHasSubitems = (routineList != NULL);
  UINT8 itemCount;
  Boolean isDone = false;

  Dialog_open();

  while (!isDone) {
    UINT8 i = 0;
    Dialog_ItemResult itemResult;
    Dialog_ItemRoutine itemRoutine = NULL;
    Joypad_Key keyPressed;

    /* update the display */
    Screen_waitForFrameGap();
    Window_gotoRowColumn(0, 0);
    Window_writeString(message);
    Window_writeLine();

    for (;;) {
      String_Type itemString = itemList[i];
      String_Type st;

      if (itemString == NULL) break;

      if (i == currentItemIndex) {
	st = ">";
      } else {
	st = " ";
      }

      String_boundedCopy(Dialog__tempString, st, Dialog__tempStringLength);
      Window_writeString(Dialog__tempString);
      Window_writeString(itemString);

      if (listHasSubitems && routineList[i] != NULL) {
	Window_clearLine();
	Window_writeString(selectionList[i]);
      }
      Window_writeLine();
      i++;
    }

    itemCount = i;

    if (!listHasSubitems) {
      currentItemHasSubitems = false;
    } else {
      itemRoutine = routineList[currentItemIndex];
      currentItemHasSubitems = (itemRoutine != NULL);

      if (currentItemHasSubitems) {
	currentSubitem = &selectionList[currentItemIndex];
      }
    }

    /* wait for key press and process it */
    Joypad_waitForSomeKey(&keyPressed);

    if (!cursorIsOnTopLevel) {
      /* process key within subselection */
      itemResult = itemRoutine(keyPressed, currentSubitem);
      cursorIsOnTopLevel = (itemResult == Dialog_ItemResult_done);
      if ((keyPressed == Joypad_Key_left || keyPressed == Joypad_Key_right)
	  && cursorIsOnTopLevel) {
	keyPressed = Joypad_Key_a;
      }
    }

    if (cursorIsOnTopLevel) {
      /* there is no subitem currently active */
      if (keyPressed == Joypad_Key_up) {
	if (currentItemIndex == 0) {
	  currentItemIndex = itemCount;
	}
	currentItemIndex--;
      } else if (keyPressed == Joypad_Key_down) {
	currentItemIndex++;
	if (currentItemIndex == itemCount) {
	  currentItemIndex = 0;
	}
      } else if (currentItemHasSubitems) {
	itemResult = itemRoutine(keyPressed, currentSubitem);
	cursorIsOnTopLevel = (itemResult == Dialog_ItemResult_done);
	isDone = (itemResult == Dialog_ItemResult_breakingOut);
      } else {
	/* no subitems within this item */
	if (keyPressed == Joypad_Key_a) {
	  isDone = true;
	} else if (keyPressed == Joypad_Key_b) {
	  isDone = true;
	  currentItemIndex = Dialog_noSelection;
	}
      }
    }
  }

  Joypad_waitForNoKey();
  Dialog_close();
  *selectedItem = currentItemIndex;
}

/*========================================*/
/*            PUBLIC ROUTINES             */
/*========================================*/

void Dialog_initialize (void)
{
}

/*--------------------*/

void Dialog_finalize (void)
{
}

/*--------------------*/

void Dialog_open (void)
{
  Sprite_hideLayer();
  Window_showLayer();
  Window_clear(true);
}

/*--------------------*/

void Dialog_close (void)
{
  Window_hideLayer();
  Sprite_showLayer();
}

/*--------------------*/

void Dialog_showMessage (in String_Type message)
{
  Dialog_open();
  Window_writeString(message);
}

/*--------------------*/

void Dialog_closeMessage (in String_Type continuationMessage,
			  in Joypad_KeySet continuationButtonSet)
{
  Window_writeString(continuationMessage);
  Joypad_waitForAllKeys(continuationButtonSet);
  Joypad_waitForNoKey();
  Dialog_close();
}

/*--------------------*/

Joypad_Key Dialog_showQuery (in String_Type message)
{
  Joypad_Key keyPressed;

  Screen_waitForFrameGap();
  Window_gotoRowColumn(0, 0);
  Window_writeLine();
  Window_writeString(message);
  Joypad_waitForSomeKey(&keyPressed);
  Joypad_waitForNoKey();
  return keyPressed;
}

/*--------------------*/

UINT8 Dialog_showChoice (in String_Type message, in String_List choiceList)
{
  UINT8 result;
  Dialog__showCascadedChoice(message, choiceList, NULL, &result, NULL);
  return result;
}

/*--------------------*/

UINT8 Dialog_showCascadedChoice (in String_Type message,
				 in String_List prefixList,
				 in Dialog_ItemRoutine routineList[],
				 inout String_List selectionList)
{
  UINT8 result;
  Dialog__showCascadedChoice(message, prefixList, routineList, &result,
			     selectionList);
  return result;
}
