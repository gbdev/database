/** Tile module --
    Implementation of module providing services for handling the
    tiles of a GameBoy Color.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/tile.h>

/*========================================*/

#include <gb/gb.h>

/*========================================*/

void Tile_initialize (void)
{
}

/*--------------------*/

void Tile_finalize (void)
{
}

/*--------------------*/

void Tile_SpriteBitmaps_write (in Tile_Type firstTile, in UINT8 count,
			       in Tile_Bitmap *bitmapList) NONBANKED
{
  UINT8 i;
  for (i = 0;  i < count;  i++) {
    set_sprite_data(firstTile + i, 1, *bitmapList++);
  }
}

/*--------------------*/

void Tile_SpriteBitmaps_read (in Tile_Type firstTile, in UINT8 count,
			      out Tile_Bitmap *bitmapList)
{
  UINT8 i;
  for (i = 0;  i < count;  i++) {
    get_sprite_data(firstTile + i, 1, *bitmapList++);
  }
}

/*--------------------*/

void Tile_BkgBitmaps_write (in Tile_Type firstTile, in UINT8 count,
			    in Tile_Bitmap *bitmapList)
{
  UINT8 i;
  for (i = 0;  i < count;  i++) {
    set_bkg_data(firstTile + i, 1, *bitmapList++);
  }
}

/*--------------------*/

void Tile_WinBitmaps_write (in Tile_Type firstTile, in UINT8 count,
			    in Tile_Bitmap *bitmapList)
{
  Tile_BkgBitmaps_write(firstTile, count, bitmapList);
}
