/** Font module --
    Implementation of module providing services for multiple fonts for
    the GameBoy.

    by Thomas Tensi, 2005-09
*/

#include <gbextended/font.h>

/*========================================*/

#include <gbextended/screen.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>

/*========================================*/

/* static const UINT8 Font__ansiCharMap[] = { */
/*   /\* 0x20 *\/ */
/*    0, 1, 2, 3, 4, 5, 6, 7, 8, 9,10,11,12,13,14,15, */
/*   16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31, */
/*  /\* 0x40 *\/ */
/*   32,33,34,35,36,37,38,39,40,41,42,43,44,45,46,47, */
/*   48,49,50,51,52,53,54,55,56,57,58,59,60,61,62,63, */
/*  /\* 0x60 *\/ */
/*   64,65,66,67,68,69,70,71,72,73,74,75,76,77,78,79, */
/*   80,81,82,83,84,85,86,87,88,89,90,91,92,93,94,95 */
/* }; */

typedef UINT8 FontRsc_CompressedBitmap[Tile_width];
#define FontRsc_bitmapCount 103

extern const FontRsc_CompressedBitmap FontRsc_ansiBitmapList[];

#define Font__firstPrintableCharacter ' '
#define Font__lastASCIICharacter 0x7F

#define Font__isASCIICharacter(ch) ( 0 <= ch && ch <= Font__lastASCIICharacter)

static char *Font__germanCharacters = "�������";

/*========================================*/

void Font_finalize (void)
{
}

/*--------------------*/

void Font_initialize (void)
{
  Tile_Type tile = 0;
  UINT8 i;

  for (i = 0;  i != FontRsc_bitmapCount;  i++) {
    UINT8 j;
    UINT8 k = 0;
    const UINT8 *ptr;
    Tile_Bitmap tileBitmap;

    ptr = &FontRsc_ansiBitmapList[i][0];
    for (j = 0;  j != Tile_width;  j++) {
      UINT8 inBitmap = ptr[j];
      tileBitmap[k++] = inBitmap;
      tileBitmap[k++] = inBitmap;
    }

    Screen_waitForFrameGap();
    Tile_BkgBitmaps_write(tile, 1, &tileBitmap);
    tile++;
  }
}

/*--------------------*/

void Font_setCurrent (in Font_Descriptor descriptor)
{
}

/*--------------------*/

void Font_convertFromTiles (in Tile_Type *tileList, in UINT8 length,
			    out char *st)
{
  UINT8 i;

  for (i = 0;  i != length;  i++) {
    char ch = *tileList++ + Font__firstPrintableCharacter;

    if (Font__isASCIICharacter(ch)) {
      /* nothing to do */
    } else {
      ch = Font__germanCharacters[ch - Font__lastASCIICharacter - 1];
    }

    *st++ = ch;
  }

  *st = '\0';
}

/*--------------------*/

void Font_convertToTiles (in char *st, out Tile_Type *tileList)
{
  while (*st != 0) {
    char ch = *st++;
    if (!Font__isASCIICharacter(ch)) {
      UINT16 position = String_findCharacter(Font__germanCharacters,  ch);
    
      if (position != String_notFound) {
	ch = Font__lastASCIICharacter + 1 + position;
      }
    }

    *tileList++ = ch - Font__firstPrintableCharacter;
                  //Font__ansiCharMap[ch - Font__firstPrintableCharacter];
  }
}
