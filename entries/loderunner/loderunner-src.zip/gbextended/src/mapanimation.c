/** MapAnimation module --
    Implementation of module providing all generic services for
    handling animations on the map of a GameBoy game.

    Original version by Thomas Tensi, 2005-08
*/


#include <gbextended/mapanimation.h>

/*========================================*/

#include <gbextended/assertion.h>
#include <gbextended/types.h>
#include <gbextended/map.h>

/*========================================*/

typedef struct {
  INT16 time;
  Map_Position position;
  MapAnimation_Phase *nextPhase;
} MapAnimation__Cell;

#define MapAnimation__cellsMaxCount 32

MapAnimation__Cell MapAnimation__cellList[MapAnimation__cellsMaxCount];

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void MapAnimation__CellList_enter (readonly Map_Position *position,
				          in MapAnimation_Schedule schedule)
{
  Boolean found = false;
  UINT8 i = 0;
  UINT8 newPosition = 0;
  INT16 maximumTime = -30000;
  MapAnimation__Cell *animatedCell;

  /* check whether entry for this position already exists */
  for (i = 0;  i != MapAnimation__cellsMaxCount;  i++) {
    animatedCell = &(MapAnimation__cellList[i]);

    if (animatedCell->time != 0
	&& animatedCell->position.x == position->x
	&& animatedCell->position.y == position->y) {
      found = true;
      break;
    } else if (animatedCell->time > maximumTime) {
      maximumTime = animatedCell->time;
      newPosition = i;
    }
  }

  if (found) {
    /* ignore another animation request for the same cell */
  } else if (maximumTime != 0) {
    /* ignore a new animation request when buffer is full */
  } else {
    animatedCell = &(MapAnimation__cellList[newPosition]);
    animatedCell->time = schedule[0].startTime;
    STRUCT_ASSIGN(animatedCell->position, *position);
    Map_setEntry(&(animatedCell->position), schedule[0].kind);
    animatedCell->nextPhase = &schedule[1];
  }
}

/*--------------------*/

static void MapAnimation__CellList_free (in UINT8 i)
  /** sets <i>-th entry in cell list in status unused */
{
  MapAnimation__cellList[i].time = 0;
}

/*--------------------*/

static MapAnimation__Cell *MapAnimation__CellList_get (in UINT8 i)
{
  return &MapAnimation__cellList[i];
}

/*--------------------*/

static Boolean MapAnimation__CellList_isUsed (in UINT8 i)
{
  return (MapAnimation__cellList[i].time != 0);
}

/*========================================*/
/*     PUBLIC ROUTINES AND DATA           */
/*========================================*/

void MapAnimation_initialize (void)
{
  MapAnimation_reset();
}

/*--------------------*/

void MapAnimation_finalize (void)
{
}

/*--------------------*/

void MapAnimation_reset (void)
{
  UINT8 i;

  for (i = 0;  i != MapAnimation__cellsMaxCount;  i++) {
    MapAnimation__CellList_free(i);
  }
}

/*--------------------*/

void MapAnimation_handleTickEvent (void)
{
  UINT8 i;

  for (i = 0;  i != MapAnimation__cellsMaxCount;  i++) {
    if (MapAnimation__CellList_isUsed(i)) {
      MapAnimation__Cell *animatedCell = &MapAnimation__cellList[i];
      MapAnimation_Phase *nextPhase = animatedCell->nextPhase;

      animatedCell->time++;
      if (animatedCell->time == nextPhase->startTime) {
	Map_setEntry(&(animatedCell->position), nextPhase->kind);
	if (animatedCell->time != 0) {
	  animatedCell->nextPhase++;
	} else {
	  /* remove animation */
	  MapAnimation__CellList_free(i);
	}
      }
    }
  }
}

/*--------------------*/

void MapAnimation_start (readonly Map_Position *position,
			 in MapAnimation_Schedule schedule)
{
  MapAnimation__CellList_enter(position, schedule);
}

