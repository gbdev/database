/** Profiler module --
    Implementation of module providing services for handling the entry
    and exit interrupts when profiling a program for a GameBoy Color.

    Original version by Thomas Tensi, 2005-08
*/

#include <gbextended/profiler.h>

/*========================================*/

#include <gbextended/string.h>
#include <gbextended/types.h>
#include <gb/gb.h>

/*========================================*/

extern UINT8  _profile_flag;
extern UINT16 _profile_pc;
extern UINT8 Banking__currentBank;

extern DEBUG_write (in char *message);

static char Profiler__st[30];

/*========================================*/
/*          PRIVATE ROUTINES              */
/*========================================*/

static void Profiler__handleInterrupt (void)
  /** puts out profiling information */
{
  char *otherSt;
  UINT8 bank;

  DEBUG_write(">> at %totalclks%");
  if (_profile_flag == 3) {
    otherSt = "enter 00";
    _profile_pc -= 3; /* skip back over three profiling code bytes */
  } else {
    otherSt = "exit  00";
  }

  String_boundedCopy(Profiler__st, otherSt, 30);
  if (_profile_pc < 0x4000 || _profile_pc >0x7FFF) {
    bank = 0;
  } else {
    bank = Banking__currentBank;
  }

  String_makeFromInteger(bank, &Profiler__st[7], 16);
  Profiler__st[8] = ':';
  String_makeFromInteger(_profile_pc, &Profiler__st[9], 16);
  DEBUG_write(Profiler__st);
  DEBUG_write("<< at %totalclks%");
}

/*========================================*/
/*           PUBLIC ROUTINES              */
/*========================================*/

void Profiler_initialize (void)
{
  /* profiling will be done by handleInterrupt function */
  add_PROF(Profiler__handleInterrupt);
}


/*--------------------*/

void Profiler_finalize (void)
{
}
