/** Sound module --
    Implementation of module providing all services for playing
    melodies or noises in a GameBoy game.

    Original version by Thomas Tensi, 2005-09
*/

#include <gbextended/sound.h>

/*========================================*/

#include <gbextended/hardware.h>

/*========================================*/

static UINT8 Sound__elapsedTimeSubunits;
static UINT8 Sound__timeScale;
static Sound_DeltaTime Sound__timeToNextEvent;
static Sound_Event Sound__nextEvent;
static Boolean Sound__isActive;
static Boolean Sound__musicIsOn = false;
static Boolean Sound__soundsAreOn = false;

typedef struct {
  Sound_DeltaTime deltaTime;
  Sound_Event event;
} Sound__TimedEvent;

static Sound__TimedEvent Sound__eventQueue[Sound_maxSlotsInEventQueue + 1];
static UINT8 Sound__eventQueueReadPos = 0;
static UINT8 Sound__eventQueueWritePos = 0;

#define Sound__queueIsEmpty() \
  (Sound__eventQueueWritePos == Sound__eventQueueReadPos)

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

#define moduleBaseNum 10

void Sound__getQueuedEvent (out Sound_DeltaTime *deltaTime,
			    out Sound_Event *event,
			    out Boolean *isActive)
{
  Boolean isDone = Sound__queueIsEmpty();

  if (!isDone) {
    Sound__TimedEvent *timedEvent = 
      &Sound__eventQueue[Sound__eventQueueReadPos++];
    Sound__eventQueueReadPos &= Sound_maxSlotsInEventQueue;
    *deltaTime = timedEvent->deltaTime;
    STRUCT_ASSIGN(*event, timedEvent->event);
  }

  *isActive = !isDone;
}

/*--------------------*/

static void Sound__handleEvent (readonly Sound_Event *event)
  /* plays note given by <event> */
{
  Hardware_Sound_play(event->channel, event->pitch, event->volume);
}

/*--------------------*/

static void Sound__getNextEvent (void)
  /* calls callback routine to get next sound event */
{
  Sound_Event event;

  do {
    Sound__getQueuedEvent(&Sound__timeToNextEvent, &event, &Sound__isActive);

    if (Sound__isActive && Sound__timeToNextEvent == 0) {
      Sound__handleEvent(&event);
    } else {
      break;
    }
  } while (true);

  if (Sound__isActive) {
    STRUCT_ASSIGN(Sound__nextEvent, event);
  }
}

/*========================================*/
/*            PUBLIC ROUTINES             */
/*========================================*/

void Sound_initialize (void)
{
  Sound_stopMusic();
}

/*--------------------*/

void Sound_finalize (void)
{
}

/*--------------------*/

void Sound_setFlags (in Boolean musicIsOn, in Boolean soundsAreOn)
{
  Sound__musicIsOn   = musicIsOn;
  Sound__soundsAreOn = soundsAreOn;
}

/*--------------------*/

void Sound_startMusic (in UINT8 timeScale)
{
  if (Sound__musicIsOn) {
    Hardware_Sound_enable();
    Sound__timeScale = (timeScale == 0 ? 1 : timeScale);
    Sound__isActive = true;
    Sound__getNextEvent();
  }
}

/*--------------------*/

void Sound_stopMusic (void)
{
  Sound__isActive = false;
  Hardware_Sound_disable();
}

/*--------------------*/

void Sound_handleTickEvent (void)
{
  if (!Sound__isActive) {
    /* skip */
  } else if (Sound__timeToNextEvent != 0 || Sound__elapsedTimeSubunits != 0) {
    Sound__elapsedTimeSubunits++;
    if (Sound__elapsedTimeSubunits == Sound__timeScale) {
      Sound__elapsedTimeSubunits = 0;
      Sound__timeToNextEvent--;
    }
  } else {
    /* handle event and get another one */
    Sound__handleEvent(&Sound__nextEvent);
    Sound__getNextEvent();
  }
}

/*--------------------*/

UINT8 Sound_slotsInEventQueue (void)
{
  UINT8 size = (Sound__eventQueueWritePos - Sound__eventQueueReadPos)
                 & Sound_maxSlotsInEventQueue;
  return (Sound_maxSlotsInEventQueue - size);
}

/*--------------------*/

void Sound_putEventInQueue (in Sound_DeltaTime deltaTime,
			     readonly Sound_Event *event)
{
  //assert Sound_slotsInEventQueue() != 0;
  Sound__TimedEvent *timedEvent =
    &Sound__eventQueue[Sound__eventQueueWritePos++];
  Sound__eventQueueWritePos &= Sound_maxSlotsInEventQueue;
  timedEvent->deltaTime = deltaTime;
  STRUCT_ASSIGN(timedEvent->event, *event);
}
