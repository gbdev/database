/** MapView module --
    Implementation of module providing all services for presenting the
    map object in a GameBoy game.

    Original version by Thomas Tensi, 2004-10
*/


#include <gbextended/mapview.h>

/*========================================*/

#include <gbextended/assertion.h>
#include <gbextended/background.h>
#include <gbextended/map.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/string.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>
#include <gbextended/window.h>

#include <gbextended/bugfix.h>

/*========================================*/

//const UINT8 MapView__debugLevel = 1;
#define MapView__debugLevel 0

#ifdef GAMEBOY
#  define MapView__systemIsGameboy true
#else
#  define MapView__systemIsGameboy false
#endif


typedef struct {
  /* --- size and topology of concrete map view --- */
  UINT8 tileColumnsPerCell;
  UINT8 tileRowsPerCell;
  UINT8 tileColumnCount;
  UINT8 tileRowCount;
  Boolean mapColumnsAreCircular;
  Boolean mapRowsAreCircular;

  /* --- parameters and mappings for the graphical representation --- */
  INT8 tileIndexOffset;      /** offset within tile map */
  Map_ObjectKind *kindsInMap;
    /** list of allowed object kinds in concrete map */
  Tile_Type *tileMatrix;     /** matrix of tiles for map
				 representation in row-major order */
  Tile_Type *kindToTile;
    /** mapping from object kind to its tile representations within a cell */
  Tile_Attribute *tileToAttribute;
    /** mapping from tile kind to its color attributes a cell */

  /* --- derived properties --- */
  Map_Position lastAllowedCornerInView;
    /** maximum allowed value for a left upper corner of map view (in
        map coordinates) */
  MapCoordinate_Rectangle viewport;
    /** current background viewport rectangle (in map coordinates) */
} MapView__Descriptor;

static MapView__Descriptor MapView__current;

/* lookup tables for multiplication, division and modulo with
   tileColumnsPerCell and tileRowsPerCell */
static UINT8 MapView__divCTPC[255];
static UINT8 MapView__modCTPC[255];
static UINT8 MapView__multCTPC[255];
static UINT8 MapView__divRTPC[255];
static UINT8 MapView__modRTPC[255];
static UINT8 MapView__multRTPC[255];
static UINT16 MapView__multTCC[255];

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

#ifdef mulDivAreAvoided
#  define MapView__currentTileMatrix(column, row) \
   MapView__current.tileMatrix[ (column) + MapView__multTCC[row] ]

#  define MapView__currentKindToTile(kindIndex, columnOffset, rowOffset) \
   MapView__current.kindToTile[ (columnOffset) + \
           MapView__multCTPC[MapView__multRTPC[kindIndex] + rowOffset] ]

#else

#  define MapView__currentTileMatrix(column, row) \
   MapView__current.tileMatrix[ (column) + \
				(row) * MapView__current.tileColumnCount ]

#  define MapView__currentKindToTile(kindIndex, columnOffset, rowOffset) \
  MapView__current.kindToTile[ (columnOffset) + \
      (kindIndex * MapView__current.tileRowsPerCell + rowOffset) \
          * MapView__current.tileColumnsPerCell ]
#endif


#if (MapView__debugLevel != 0)

static void MapView__writeTwoInts (in char *title,
				   in UINT16 c1, in char *s1,
				   in UINT16 c2, in char *s2)
{
  Window_writeString(title);
  Window_writeString("=(");
  Window_writeCard(c1);  Window_writeString(s1);
  Window_writeCard(c2);  Window_writeString(s2);
}

/*--------------------*/

#define MapView__writeFourInts(title, c1, s1,c2, s2, c3, s3, c4, s4) \
{\
  MapView__writeTwoInts(title, c1, s1, c2, s2);\
  Window_writeCard(c3);  Window_writeString(s3);\
  Window_writeCard(c4);  Window_writeString(s4);\
}

/*--------------------*/

static void MapView__writePosition (in char *title, in Map_Position *position)
{
  MapView__writeFourInts(title,
			 (UINT16)MapCoordinate_integerPart(position->x),
			 ".",
			 (UINT16)MapCoordinate_fractionalPart(position->x),
			 "/",
			 (UINT16)MapCoordinate_integerPart(position->y),
			 ".",
			 (UINT16)MapCoordinate_fractionalPart(position->y),
			 ")");
}

/*--------------------*/

static void MapView__writeBGPosition (in char *title,
			      readonly Background_TilePosition *tilePosition,
			      readonly Background_PixelOffset *pixelOffset)
{
  MapView__writeFourInts(title,
			 (UINT16)tilePosition->column, ".",
			 (UINT16)pixelOffset->deltaX, "/",
			 (UINT16)tilePosition->row, ".",
			 (UINT16)pixelOffset->deltaY, ")");
}

/*--------------------*/

static void MapView__writeScreenPos (in char *title,
			             in Screen_Coordinate screenX,
			             in Screen_Coordinate screenY)
{
  MapView__writeTwoInts(title, (UINT16)screenX, "/", (UINT16)screenY, ")");
}
#else /* MapView__debugLevel != 0 */
#  define MapView__writePosition(title, position)
#  define MapView__writeBGPosition(title, tilePosition, pixelOffset)
#  define MapView__writeScreenPos(title, screenX, screenY)
#endif /* MapView__debugLevel != 0 */

/*--------------------*/

static void MapView__adjustInterval (in Boolean isCircular,
				     inout MapCoordinate_Type *lowValue,
				     in MapCoordinate_Type maxValue,
				     in MapCoordinate_Type intervalLength)
{
  if (!isCircular) {
    MapCoordinate_Type highValue =
      MapCoordinate_addOperation(*lowValue, intervalLength, false);

    if (maxValue < highValue) {
      *lowValue  = MapCoordinate_addOperation(maxValue, intervalLength,
					      true);
    }
  }
}

/*--------------------*/

static INT8 MapView__charPosition (in char ch, in char *str)
  /** a strchr replacement which returns an index instead of a
      pointer */
{ 
  INT8 index = 0;
  for (;;) {
    char otherChar;
    otherChar = *str;
    if (otherChar == '\0') {
      return -1;
    } else if (otherChar == ch) {
      return index;
    } else {
      index++;  str++;
    }
  }
}

/*--------------------*/

static Tile_Type MapView__getTileForCell (in Map_ObjectKind objectKind,
					  in UINT8 columnOffset,
					  in UINT8 rowOffset)
 /** finds tile in cell for <objectKind> given by offset
      (<columnOffset>,<rowOffset>) */
{
  INT8 kindIndex;
  Tile_Type tile;

  kindIndex = MapView__charPosition(objectKind, MapView__current.kindsInMap);

  if (kindIndex < 0) {
    tile = 0;
  } else {
    tile = MapView__currentKindToTile(kindIndex, columnOffset, rowOffset);
  }

  return tile;
}

/*--------------------*/

static UINT8 MapView__log2 (UINT8 x)
  /** calculates the ceiling of the binary logarithm of <x> */
{
  UINT8 result;
  UINT16 i;

  result = 0;
  i = 1;
  while (i < x) {
    result++;
    i = i + i;
  }
  return result;
}

/*--------------------*/

static void MapView__setupMultDivTables (void)
  /* set the tables for fast modulo and division operations */
{
  UINT8 i, j, k;

  j = 0;  k = 0;
  for (i = 0;  i != 255;  i++) {
    if (k == MapView__current.tileRowsPerCell) {
      MapView__multRTPC[j] = i - k;
      k = 0;  j++;
    }
    MapView__divRTPC[i] = j;
    MapView__modRTPC[i] = k;
    k++;
  }

  j = 0;  k = 0;
  for (i = 0;  i != 255;  i++) {
    if (k == MapView__current.tileColumnsPerCell) {
      MapView__multCTPC[j] = i - k;
      k = 0;  j++;
    }
    MapView__divCTPC[i] = j;
    MapView__modCTPC[i] = k;
    k++;
  }

# ifdef mulDivAreAvoided
  {
    UINT8 row;
    UINT16 *ptr = MapView__multTCC;
    UINT16 multiplicationValue = 0;

    for (row = 0;  row != MapView__current.tileRowCount;  row++) {
      *ptr++ = multiplicationValue;
      multiplicationValue += MapView__current.tileColumnCount;
    }
  }
# endif
}

/*--------------------*/

static void MapView__setupTileCache (void)
   /** initializes tile cache for quick access to map representation */
{
  Background_TileCoordinate tileRow;

  for (tileRow = 0;  tileRow != MapView__current.tileRowCount;  tileRow++) {
    MapCoordinate_IntegerPart cellPosY;
    Map_Position position;
    UINT8 rowOffset;
    Background_TileCoordinate tileColumn;

    cellPosY = MapView__divRTPC[tileRow];
    position.y = MapCoordinate_make(cellPosY, 0);
    rowOffset = MapView__modRTPC[tileRow];

    for (tileColumn = 0;  tileColumn != MapView__current.tileColumnCount;
	 tileColumn++) {
      UINT8 columnOffset;
      MapCoordinate_IntegerPart cellPosX;
      Map_ObjectKind objectKind;
      Tile_Type tile;

      cellPosX = MapView__divCTPC[tileColumn];
      position.x = MapCoordinate_make(cellPosX, 0);
      columnOffset = MapView__modCTPC[tileColumn];

      objectKind = Map_getEntry(&position);
      tile = MapView__getTileForCell(objectKind, columnOffset, rowOffset);
      MapView__currentTileMatrix(tileColumn, tileRow) = tile;
    }
  }
}

/*--------------------*/

static UINT8 MapView__count;
static char *MapView__bufferPtr;
static char *MapView__tilePtr;
static char *MapView__attributePtr;
static char MapView__tileToAttributeMap[20];

static void MapView__update (
	     readonly Background_TilePosition *upperLeftCorner,
	     readonly Background_TilePosition *lowerRightCorner,
	     readonly Background_TilePosition *upperLeftCornerInViewport,
	     in Background_TileCoordinate tilesPerHWBufferRow,
	     out Tile_Type *tileList,
	     out Tile_Attribute *attributeList)
  /** callback routine called when the background must be updated */
{
  UINT8 tileIndexOffset = MapView__current.tileIndexOffset;
  UINT16 destinationOffset;

  if (MapView__systemIsGameboy) {
    tilesPerHWBufferRow = 32;
  }

  destinationOffset =
      upperLeftCornerInViewport->row * tilesPerHWBufferRow
      + upperLeftCornerInViewport->column;

#ifndef useOptimizedCode
  {
    Background_TileCoordinate tileRow;

    for (tileRow = upperLeftCorner->row;  tileRow <= lowerRightCorner->row;
	 tileRow++) {
      Background_TileCoordinate tileColumn;
      Tile_Attribute *attributeDestPtr;
      Tile_Type *tileDestPtr;

      tileDestPtr = tileList + destinationOffset;
      attributeDestPtr = attributeList + destinationOffset;
      destinationOffset += tilesPerHWBufferRow;

      for (tileColumn = upperLeftCorner->column; 
	   tileColumn <= lowerRightCorner->column;  tileColumn++) {
	Tile_Type tile;
	//tile = MapView__currentTileMatrix(tileColumn, tileRow);
	tile = MapView__current.tileMatrix[tileColumn +
		   tileRow * MapView__current.tileColumnCount];
	*tileDestPtr++ = tile + tileIndexOffset;
	*attributeDestPtr++ = MapView__current.tileToAttribute[tile];
      }
    }
  }
#else /* speed optimized version */
  {
    UINT8 rowCount = lowerRightCorner->row - upperLeftCorner->row + 1;

    Tile_Type *tileSrcPtrRowStart =
      &MapView__currentTileMatrix(upperLeftCorner->column,
				  upperLeftCorner->row);

    UINT8 columnCount = lowerRightCorner->column
			    - upperLeftCorner->column + 1;

    while (rowCount-- != 0) {

#ifndef GAMEBOY
      Tile_Type *tileSrcPtr;
      Tile_Attribute *attributeDestPtr;
      Tile_Type *tileDestPtr;

      tileDestPtr = tileList + destinationOffset;
      attributeDestPtr = attributeList + destinationOffset;
      tileSrcPtr = tileSrcPtrRowStart;

      while (columnCount-- != 0) {
	Tile_Type tile;
	tile = *tileSrcPtr++;
	*tileDestPtr++ = tile + tileIndexOffset;
	*attributeDestPtr++ = MapView__tileToAttributeMap[tile];
      }
#else
      MapView__count = columnCount;
      MapView__bufferPtr = tileSrcPtrRowStart;
      MapView__tilePtr = tileList + destinationOffset;
      MapView__attributePtr = attributeList + destinationOffset;

      _asm
	;; -- save all registers --
	;; ------------------------
	PUSH	AF
	PUSH	BC
	PUSH	DE
	PUSH	HL

	;; -- fill the tile list --
	;; ------------------------
	;; count + 1 in B
	;; mask in C
	;; bufferPtr in HL (as source)
	;; tilePtr in DE (as target)
	LD	HL,#_MapView__tilePtr
	LD	A,(HL+)
	LD	E,A
	LD	D,(HL)
	LD	HL,#_MapView__bufferPtr
	LD	A,(HL+)
	LD	H,(HL)
	LD	L,A
	LD	A,(_MapView__count)
	LD	B,A
	INC	B
	LD	C,#0x80

1$:    ;LOOP
	DEC	B		; if (--count == 0)
	JR	Z,2$		;   break
	LD	A,(HL+)		; tile = *sourcePtr++
	OR	C		; tile |= 0x80
	LD	(DE),A		; *destPtr++ = tile
	INC	DE
	JR	1$		; continue
2$:    ;ENDLOOP

	;; -- fill the attribute list --
	;; -----------------------------
	;; tileToAttributeMap in BC
	;; tilePtr in HL (as source)
	;; attributePtr in DE (as target)
	LD	BC,#_MapView__tileToAttributeMap
	LD	HL,#_MapView__attributePtr
	LD	A,(HL+)
	LD	E,A
	LD	D,(HL)
	LD	HL,#_MapView__bufferPtr
	LD	A,(HL+)
	LD	H,(HL)
	LD	L,A

3$:    ;LOOP
	LD	A,(_MapView__count)
	OR	A		; if (count-- == 0)
	JR	Z,5$		;   break
	DEC	A
	LD	(_MapView__count),A

	LD	A,(HL+)		; tile = *tilePtr++
	PUSH	BC
	ADC	C		; attribute = tileToAttributeMap[tile]
	JR	NC,4$
	INC	B
4$:
	LD	C,A
	LD	A,(BC)
	POP	BC
	LD	(DE),A		; *attributePtr++ = attribute
	INC	DE
	JR	3$		; continue
5$:    ;ENDLOOP

	;; -- restore all registers --
	;; ------------------------
	POP	HL
	POP	DE
	POP	BC
	POP	AF
      _endasm;
#endif /* GAMEBOY */

      tileSrcPtrRowStart += MapView__current.tileColumnCount;
      destinationOffset += tilesPerHWBufferRow;
    }
  }
#endif /* useOptimizedCode */
}

/*--------------------*/

static void MapView__convertToBgSystem (
				readonly Map_Position *mapPosition,
				out Background_TilePosition *tilePosition,
				out Background_PixelOffset *pixelOffset)
  /** converts map view position <mapPosition> to background tile
      position <tilePosition> and pixel offset on background
      <pixelOffset>*/
{
  MapCoordinate_FractionalPart offsetX, offsetY;
  MapCoordinate_IntegerPart cellPosX, cellPosY;
  UINT16 temp;
  
# if (MapView__debugLevel > 2)
    MapView__writePosition("MAP2BG in", mapPosition);
# endif

  offsetX = MapCoordinate_fractionalPart(mapPosition->x);
  cellPosX = MapCoordinate_integerPart(mapPosition->x);
  offsetY = MapCoordinate_fractionalPart(mapPosition->y);
  cellPosY = MapCoordinate_integerPart(mapPosition->y);

  /*
  temp = offsetX * MapView__current.tileColumnsPerCell * Tile_width
            / MapCoordinate_subunitCount;
  backgroundTile = cellPosX * MapView__current.tileColumnsPerCell
                           + (temp / Tile_width);
  backgroundOffset = temp % Tile_width;
  */
  temp = (MapView__multCTPC[offsetX] * Tile_width)
            / MapCoordinate_subunitCount;
  tilePosition->column = MapView__multCTPC[cellPosX]
                           + (UINT8) (temp / Tile_width);
  pixelOffset->deltaX = (UINT8) (temp % Tile_width);

  /*
  temp = offsetY * MapView__current.tileRowsPerCell * Tile_width
            / MapCoordinate_subunitCount;
  tilePosition->row = cellPosY * MapView__current.tileRowsPerCell
                           + (UINT8) (temp / Tile_width);
  pixelOffset->deltaY = (UINT8) (temp % Tile_width);
  */
  temp = (MapView__multRTPC[offsetY] * Tile_width)
            / MapCoordinate_subunitCount;
  tilePosition->row = MapView__multRTPC[cellPosY] 
                        + (UINT8) (temp / Tile_width);
  pixelOffset->deltaY = (UINT8) (temp % Tile_width);

# if (MapView__debugLevel > 2)
    MapView__writeBGPosition(", out", tilePosition, pixelOffset);
    Window_writeLine();
# endif
}

/*--------------------*/

static void MapView__convertToMapSystem (
			 readonly Background_TilePosition *tilePosition,
			 readonly Background_PixelOffset *pixelOffset,
			 out Map_Position *mapPosition)
  /** converts background tile position <tilePosition> to map view
      position <mapPosition> */
{
  UINT8 remainingPixels;
  MapCoordinate_IntegerPart cellPosX, cellPosY;
  MapCoordinate_FractionalPart offsetX, offsetY;
  UINT16 temp;

# if (MapView__debugLevel > 2)
    MapView__writeBGPosition("BG2MAP in", tilePosition, pixelOffset);
# endif

  cellPosX = MapView__divCTPC[tilePosition->column];
  cellPosY = MapView__divRTPC[tilePosition->row];

  remainingPixels = MapView__modCTPC[tilePosition->column] * Tile_width
                      + pixelOffset->deltaX;
  temp = (remainingPixels * MapCoordinate_subunitCount)
              / MapView__current.tileColumnsPerCell;
  offsetX = (MapCoordinate_FractionalPart)(temp / Tile_width);
  mapPosition->x = MapCoordinate_make(cellPosX, offsetX);

  remainingPixels = MapView__modRTPC[tilePosition->row] * Tile_width
                      + pixelOffset->deltaY;
  temp = (remainingPixels * MapCoordinate_subunitCount)
            / MapView__current.tileRowsPerCell;
  offsetY = (MapCoordinate_FractionalPart)(temp / Tile_width);
  mapPosition->y = MapCoordinate_make(cellPosY, offsetY);

# if (MapView__debugLevel > 2)
    MapView__writePosition(", out", mapPosition);
    Window_writeLine();
# endif
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void MapView_initialize (void)
{
}

/*--------------------*/

void MapView_finalize (void)
{
}

/*--------------------*/

void MapView_define (in UINT8 tileColumnsPerCell, in UINT8 tileRowsPerCell,
		     in INT8 tileIndexOffset,
		     in Tile_Type *tileMatrix,
		     in Tile_Type *kindToTile,
		     in Tile_Attribute *tileToAttribute)
{
  Background_TilePosition lowerRightCorner;
  MapView__Descriptor *current = &MapView__current;
  MapCoordinate_IntegerPart cellColumnCount;
  MapCoordinate_IntegerPart cellRowCount;
  Boolean mapColumnsAreCircular;
  Boolean mapRowsAreCircular;
  Map_ObjectKind *kindsInMap;
  UINT8 tileColumnCount;
  UINT8 tileRowCount;

  Map_getProperties(&cellColumnCount, &cellRowCount,
		    &mapColumnsAreCircular, &mapRowsAreCircular,
		    &kindsInMap);

  tileColumnCount = cellColumnCount * tileColumnsPerCell;
  current->tileColumnsPerCell = tileColumnsPerCell;
  current->tileColumnCount    = tileColumnCount;

  tileRowCount = cellRowCount * tileRowsPerCell;
  current->tileRowsPerCell    = tileRowsPerCell;
  current->tileRowCount       = tileRowCount;

  Assertion_DEBUG(tileColumnCount >= Background_tilesPerColumn
		  && tileRowCount >= Background_tilesPerRow,
		  "MapView_define", "map is too small");

  current->mapColumnsAreCircular = mapColumnsAreCircular;
  current->mapRowsAreCircular    = mapRowsAreCircular;

  current->tileIndexOffset = tileIndexOffset;
  current->kindsInMap      = kindsInMap;
  current->tileMatrix      = tileMatrix;
  current->kindToTile      = kindToTile;
  current->tileToAttribute = tileToAttribute;

  if (MapView__systemIsGameboy) {
    /* make a local static copy of tileToAttributeMap */
    String_memoryMove(MapView__tileToAttributeMap, tileToAttribute,
		      sizeof(MapView__tileToAttributeMap));
  }

  MapView__setupMultDivTables();

  lowerRightCorner.row = tileRowCount - 1;
  lowerRightCorner.column = tileColumnCount - 1;
  Background_define(&lowerRightCorner, mapColumnsAreCircular,
		    mapRowsAreCircular, MapView__update);
}

/*--------------------*/

void MapView_analyseLevel (void)
{
  const Background_PixelOffset zeroOffsetInBackground = {0, 0};

  Background_TilePosition lastAllowedCornerInBg;
  Background_TilePosition upperLeftBgCorner, diagonalVectorInBackground;
  Background_PixelOffset offsetInBackground;

  /* calculate the maximum allowed top left corner for a viewport */
  Background_lastCorner(&lastAllowedCornerInBg);
  MapView__convertToMapSystem(&lastAllowedCornerInBg,
			      &zeroOffsetInBackground,
			      &MapView__current.lastAllowedCornerInView);

  /* calculate current viewport (in map coordinates) */
  Background_getViewport(&upperLeftBgCorner, &diagonalVectorInBackground, 
			 &offsetInBackground);

  MapView__convertToMapSystem(&diagonalVectorInBackground,
			      &zeroOffsetInBackground,
			      &(MapView__current.viewport.diagonalVector));
  MapView__convertToMapSystem(&upperLeftBgCorner, &offsetInBackground,
			      &(MapView__current.viewport.upperLeftCorner));

  /* get all tiles and attributes in local cache */
  MapView__setupTileCache();
}

/*--------------------*/

void MapView_setViewport (inout Map_Position *position)
{
  Background_TilePosition positionInBackground;
  Background_PixelOffset offsetInBackground;

# if (MapView__debugLevel > 1)
    MapView__writePosition("vp-ulc(in)", position);
# endif

  Map_adjustToCorrectPosition(position);

  MapView__adjustInterval(MapView__current.mapColumnsAreCircular, &position->x,
			  Map_boundingBox.diagonalVector.x,
			  MapView__current.viewport.diagonalVector.x);


  MapView__adjustInterval(MapView__current.mapRowsAreCircular, &position->y,
			  Map_boundingBox.diagonalVector.y,
			  MapView__current.viewport.diagonalVector.y);

  MapView__convertToBgSystem(position,
			     &positionInBackground, &offsetInBackground);

  Background_setViewport(&positionInBackground, &offsetInBackground);

  /* update viewport rectangle */
  STRUCT_ASSIGN(MapView__current.viewport.upperLeftCorner, *position);

# if (MapView__debugLevel > 1)
    MapView__writePosition(", out", position);
    Window_writeLine();
# endif
}

/*--------------------*/

void MapView_findCoordInView (readonly Map_Position *position,
			      out Screen_Coordinate *screenX,
			      out Screen_Coordinate *screenY)
{
  Map_Position deltaPosition;
  Background_PixelOffset offsetInBackground;
  UINT8 offsetX;
  UINT8 offsetY;
  Map_Position p;
  Background_TilePosition positionInBackground;
  
# if (MapView__debugLevel != 0)
    MapView__writePosition("findCoord(in)", position);
# endif

  /* since subtraction is bounded by 0, we have to find some visible
     corner of the cell and subtract some pixel offset later */
  STRUCT_ASSIGN(p, *position);

  if (p.x >= MapView__current.viewport.upperLeftCorner.x) {
    offsetX = 0;
  } else {
    offsetX = MapView__current.tileColumnsPerCell * Tile_width;
    p.x += MapCoordinate_unit;
  }

  if (p.y >= MapView__current.viewport.upperLeftCorner.y) {
    offsetY = 0;
  } else {
    offsetY = MapView__current.tileRowsPerCell * Tile_width;
    p.y += MapCoordinate_unit;
  }

  MapCoordinate_vectorAddOp(&p, &MapView__current.viewport.upperLeftCorner,
			    true, &deltaPosition);
  MapView__convertToBgSystem(&deltaPosition, &positionInBackground,
			     &offsetInBackground);

  *screenX = positionInBackground.column * Tile_width
               + offsetInBackground.deltaX - offsetX;
  *screenY = positionInBackground.row * Tile_width
               + offsetInBackground.deltaY - offsetY;

# if (MapView__debugLevel != 0)
    MapView__writeScreenPos(", out", *screenX, *screenY);
    Window_writeLine();
# endif
}

/*--------------------*/

void MapView_centreViewport (readonly Map_Position *position)
{
  Map_Position temp;
  MapCoordinate_Rectangle newViewport;
  Map_Position *viewportCorner;

# if (MapView__debugLevel != 0)
    MapView__writePosition("ctr", position);
# endif

  STRUCT_ASSIGN(newViewport, MapView__current.viewport);
  viewportCorner = &(newViewport.upperLeftCorner);

  MapCoordinate_vectorShiftOp(&(newViewport.diagonalVector), -1, &temp);
  MapCoordinate_vectorAddOp(position, &temp, true, viewportCorner);

  MapView__adjustInterval(MapView__current.mapColumnsAreCircular,
			  &(viewportCorner->x),
			  Map_boundingBox.diagonalVector.x,
			  newViewport.diagonalVector.x);

  MapView__adjustInterval(MapView__current.mapRowsAreCircular,
			  &(viewportCorner->y),
			  Map_boundingBox.diagonalVector.y,
			  newViewport.diagonalVector.y);

  MapView_setViewport(viewportCorner);
}

/*--------------------*/

void MapView_getViewport (out MapCoordinate_Rectangle *viewport)
{
  STRUCT_ASSIGN(*viewport, MapView__current.viewport);
}

/*--------------------*/

void MapView_showInScreen (void)
{
  Background_showInScreen();
}

/*--------------------*/

void MapView_updatePosition (readonly Map_Position *position)
{
  MapCoordinate_IntegerPart cellPosX, cellPosY;
  Background_TileCoordinate firstTileColumn;  
  Map_ObjectKind objectKind;
  UINT8 rowOffset;
  Background_TileCoordinate tileRow;
  Tile_Type *destinationPtr;

  objectKind = Map_getEntry(position);
  cellPosY = MapCoordinate_integerPart(position->y);
  cellPosX = MapCoordinate_integerPart(position->x);

  tileRow = MapView__multRTPC[cellPosY];
  firstTileColumn = MapView__multCTPC[cellPosX];
  destinationPtr = &(MapView__currentTileMatrix(firstTileColumn, tileRow));

  for (rowOffset = 0;
       rowOffset != MapView__current.tileRowsPerCell;
       rowOffset++) {
    UINT8 columnOffset;
    Background_TileCoordinate tileColumn;

    tileColumn = firstTileColumn;

    for (columnOffset = 0;
	 columnOffset != MapView__current.tileColumnsPerCell;
	 columnOffset++) {
      Tile_Type tile;

      tile = MapView__getTileForCell(objectKind, columnOffset, rowOffset);
      /* MapView__currentTileMatrix(tileColumn, tileRow) = tile; */
      destinationPtr[columnOffset] = tile;
      tileColumn++;
    }
    destinationPtr += MapView__current.tileColumnCount;
    tileRow++;
  }
}

/*--------------------*/

Boolean MapView_isVisible (readonly MapCoordinate_Rectangle *rectangle)
{
#ifndef TEST
  MapCoordinate_Rectangle intersection;

  MapCoordinate_clipRectangle(rectangle, &MapView__current.viewport,
			      &intersection);
  return (!MapCoordinate_isEmptyRect(&intersection));
#else
  Boolean pointIsContained;

  pointIsContained = MapCoordinate_isInRectangle(&MapView__current.viewport,
						 &rectangle->upperLeftCorner);
  if (!pointIsContained) {
    MapCoordinate_Vector lowerRightCorner;
    MapCoordinate_vectorAddOp(&rectangle->upperLeftCorner,
			      &rectangle->diagonalVector, false,
			      &lowerRightCorner);
    pointIsContained = MapCoordinate_isInRectangle(&MapView__current.viewport,
						   &lowerRightCorner);
  }

  return pointIsContained;
#endif
}
