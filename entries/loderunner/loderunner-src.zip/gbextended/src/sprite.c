/** Sprite module --
    Implementation of module providing services for handling the
    sprites of a GameBoy.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/sprite.h>

/*========================================*/

#include <gb/gb.h>
#include <gb/hardware.h>
#include <gbextended/assertion.h>
#include <gbextended/set.h>
#include <gbextended/types.h>

/*========================================*/

#define Sprite__minX 8
#define Sprite__minY 16

#define Sprite__hardwareSpritesCount 32
/* note that it is 40 in principle, but we omit the last 8 for easier
   processing */

/** set of virtual sprites in use */
static Set_Type Sprite__virtualSpriteList;
static UINT8  Sprite__usedVirtualSpriteCount;

/** set of hardware sprites in use */
static Set_Type Sprite__hardwareSpriteList;
static UINT8  Sprite__usedHardwareSpriteCount;

typedef UINT8 Sprite__HardwareSprite;

typedef struct {
  UINT8 width;
  UINT8 height;
  UINT8 tileCount;
  Sprite__HardwareSprite *hardwareSpriteList;
  Sprite_Offset *offsetList;
  } Sprite__Descriptor;

/** list storing the mapping of virtual sprites into hardware
   sprites*/
static Sprite__Descriptor Sprite__descriptorList[Sprite_maxCount];

/** list storing all the hardware sprites allocated */
static Sprite__HardwareSprite Sprite__hwSpriteList[
                                 Sprite__hardwareSpritesCount];
static Sprite__HardwareSprite *Sprite__hwSpriteListPtr = Sprite__hwSpriteList;

/** list storing the offsets of all hardware sprites allocated */
static Sprite_Offset Sprite__offsetList[Sprite__hardwareSpritesCount];
static Sprite_Offset *Sprite__offsetListPtr = Sprite__offsetList;


static char *Sprite__errMsg_badSprite = "sprite unused";
static char *Sprite__errMsg_badSSprite = "sub sprite unused";

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Sprite__checkSprite (in char *procName, in Sprite_Type sprite)
{
  Assertion_PRE(Set_isElement(Sprite__virtualSpriteList, sprite),
		procName, Sprite__errMsg_badSprite);
}

/*--------------------*/

static void Sprite__checkSubsprite (in char *procName, in Sprite_Type sprite,
				    in UINT8 subspriteIndex)
{
  UINT8 tileCount;
  Sprite__checkSprite(procName, sprite);
  tileCount = Sprite__descriptorList[sprite].tileCount;
  Assertion_PRE(subspriteIndex < tileCount,
		procName, Sprite__errMsg_badSSprite);
}

/*--------------------*/

static UINT8 Sprite__maximum (in UINT8 a, in UINT8 b)
{
  return (a > b ? a : b);
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Sprite_initialize (void)
{
  UINT8 i;
  /* set sprite mode */
  LCDC_REG &= 0xFBU;  /* no large hardware sprites, use 8x8 pixels */

  /* initialize sprite lists */
  Set_clear(&Sprite__virtualSpriteList);
  Set_clear(&Sprite__hardwareSpriteList);
  Sprite__usedVirtualSpriteCount = 0;
  Sprite__usedHardwareSpriteCount = 0;

  /* hide all hardware sprites */
  for (i = 0;  i != 40;  i++) {
    move_sprite(i, 255, 255);
  }
}

/*--------------------*/

void Sprite_finalize (void)
{
}

/*--------------------*/

void Sprite_showLayer (void)
{
  LCDC_REG |= 0x02U;
}

/*--------------------*/

void Sprite_hideLayer (void)
{
  LCDC_REG &= 0xFDU;
}

/*--------------------*/

Boolean Sprite_canBeMade (in UINT8 tileCount)
{
  UINT16 hardwareSpritesUsed;
  hardwareSpritesUsed = Sprite__usedHardwareSpriteCount + tileCount;
  return (Sprite__usedVirtualSpriteCount < Sprite_maxCount
	  && hardwareSpritesUsed <= Sprite__hardwareSpritesCount);
}

/*--------------------*/

Sprite_Type Sprite_make (in UINT8 tileCount)
{
  { /* preconditions */
    Assertion_PRE(Sprite_canBeMade(tileCount),
		  "Sprite_make", "sprite cannot be made");
  }

  { /* normal processing */
    Sprite_Type virtualSprite;
    UINT8 hardwareSpritesUsed;
    Sprite__Descriptor *descriptor;
    UINT8 i;

    hardwareSpritesUsed = tileCount;
    virtualSprite = Set_firstElement(
			 Set_complement(Sprite__virtualSpriteList));
    Set_include(&Sprite__virtualSpriteList, virtualSprite);

    /* update descriptor of this virtual sprite */
    descriptor = &(Sprite__descriptorList[virtualSprite]);
    descriptor->tileCount = hardwareSpritesUsed;

    /* no dynamic allocation, use local lists instead */
    descriptor->hardwareSpriteList = Sprite__hwSpriteListPtr;
    Sprite__hwSpriteListPtr += hardwareSpritesUsed;
    descriptor->offsetList = Sprite__offsetListPtr;
    Sprite__offsetListPtr += hardwareSpritesUsed;

    /* now find all hardware sprites to use for this virtual sprite */
    for (i = 0;  i != hardwareSpritesUsed;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = Set_firstElement(
				Set_complement(Sprite__hardwareSpriteList));
      Set_include(&Sprite__hardwareSpriteList, hardwareSprite);
      descriptor->hardwareSpriteList[i] = hardwareSprite;
      descriptor->offsetList[i].deltaX = 0;
      descriptor->offsetList[i].deltaY = 0;
    }

    Sprite__usedHardwareSpriteCount += tileCount;
    Sprite__usedVirtualSpriteCount++;
    descriptor->width = Tile_width;
    descriptor->height = Tile_width;
    return virtualSprite;
  }
}

/*--------------------*/

void Sprite_discard (in Sprite_Type sprite)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_discard", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);

    /* free all hardware sprites */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = descriptor->hardwareSpriteList[i];
      Set_exclude(&Sprite__hardwareSpriteList, hardwareSprite);
    }

    Set_exclude(&Sprite__virtualSpriteList, sprite);
  }
}

/*--------------------*/

void Sprite_setOffsets (in Sprite_Type sprite, in Sprite_Offset *offsetList)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_setOffsets", sprite);
  }

  { /* normal processing */
    UINT8 width = 0;
    UINT8 height = 0;
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);

    for (i = 0;  i != descriptor->tileCount;  i++) {
      UINT8 deltaX, deltaY;
      deltaY = offsetList[i].deltaY;
      deltaX = offsetList[i].deltaX;
      descriptor->offsetList[i].deltaY = deltaY;
      descriptor->offsetList[i].deltaX = deltaX;
      width  = Sprite__maximum(width, deltaX + Tile_width);
      height = Sprite__maximum(height, deltaY + Tile_width);
    }
    descriptor->width = width;
    descriptor->height = height;
  }
}

/*--------------------*/

void Sprite_setTiles (in Sprite_Type sprite, in Tile_Type *tileList)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_setTiles", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);
    
    /* go through all the hardware sprites and assign the tiles */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = descriptor->hardwareSpriteList[i];
      set_sprite_tile(hardwareSprite, tileList[i]);
    }
  }
}

/*--------------------*/

void Sprite_setSubTile (in Sprite_Type sprite, in UINT8 subspriteIndex,
		        in Tile_Type tile)
{
  { /* preconditions */
    Sprite__checkSubsprite("Sprite_setSubTile", sprite, subspriteIndex);
  }

  { /* normal processing */
    Sprite__HardwareSprite hardwareSprite;
    hardwareSprite = Sprite__descriptorList[sprite]
                       .hardwareSpriteList[subspriteIndex];
    set_sprite_tile(hardwareSprite, tile);
  }
}

/*--------------------*/

void Sprite_setAttributes (in Sprite_Type sprite,
			   in Tile_Attribute *attributeList)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_setAttributes", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);
    
    /* go through all the hardware sprites and assign the tiles */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = descriptor->hardwareSpriteList[i];
      set_sprite_prop(hardwareSprite, attributeList[i]);
    }
  }
}

/*--------------------*/

void Sprite_setSubAttribute (in Sprite_Type sprite, in UINT8 subspriteIndex,
			     in Tile_Attribute attribute)
{
  { /* preconditions */
    Sprite__checkSubsprite("Sprite_setSubAttribute", sprite, subspriteIndex);
  }

  { /* normal processing */
    Sprite__HardwareSprite hardwareSprite;
    hardwareSprite = Sprite__descriptorList[sprite]
                       .hardwareSpriteList[subspriteIndex];
    set_sprite_prop(hardwareSprite, attribute);
  }
}

/*--------------------*/

void Sprite_hide (in Sprite_Type sprite)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_hide", sprite);
  }

  {
    /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);

    /* go through all the hardware sprites and move them to
       (255,255) */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = descriptor->hardwareSpriteList[i];
      move_sprite(hardwareSprite, 255, 255);
    }
  }
}

/*--------------------*/

void Sprite_getSize (in Sprite_Type sprite, 
		     out Screen_Coordinate *width,
		     out Screen_Coordinate *height)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_getMaxDimensions", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    descriptor = &(Sprite__descriptorList[sprite]);
    *width = descriptor->width;
    *height = descriptor->height;
  }
}

/*--------------------*/

void Sprite_getMaxCoordinates (in Sprite_Type sprite, 
			       out Screen_Coordinate *maxX,
			       out Screen_Coordinate *maxY)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_getMaxCoordinates", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 height, width;

    descriptor = &(Sprite__descriptorList[sprite]);
    width = descriptor->width;
    height = descriptor->height;
    *maxX = Screen_graphicsWidth - width;
    *maxY = Screen_graphicsHeight - height;
  }
}

/*--------------------*/

void Sprite_moveAbsolute (in Sprite_Type sprite,
			  in Screen_Coordinate x, in Screen_Coordinate y)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_moveAbsolute", sprite);
  }

  {
    /* normal processing */
    Sprite__Descriptor *descriptor;
    Sprite__HardwareSprite *hardwareSpritePtr;
    Sprite_Offset *offsetPtr;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);
    hardwareSpritePtr = &(descriptor->hardwareSpriteList[0]);
    offsetPtr = &(descriptor->offsetList[0]);

    /* go through all the hardware sprites and move them to
       (localX,localY) plus the appropriate offset */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Screen_Coordinate localX, localY;
      
      localY = y + offsetPtr->deltaY + Sprite__minY;
      localX = x + offsetPtr->deltaX + Sprite__minX;
      move_sprite(*hardwareSpritePtr, localX, localY);
      hardwareSpritePtr++;
      offsetPtr++;
    }
  }
}

/*--------------------*/

void Sprite_moveRelative (in Sprite_Type sprite,
			  in INT8 deltaX, in INT8 deltaY)
{
  { /* preconditions */
    Sprite__checkSprite("Sprite_moveRelative", sprite);
  }

  { /* normal processing */
    Sprite__Descriptor *descriptor;
    UINT8 i;

    descriptor = &(Sprite__descriptorList[sprite]);

    /* go through all the hardware sprites and move them by
       (deltaX,deltaY) */
    for (i = 0;  i != descriptor->tileCount;  i++) {
      Sprite__HardwareSprite hardwareSprite;
      hardwareSprite = descriptor->hardwareSpriteList[i];
      scroll_sprite(hardwareSprite, deltaX, deltaY);
    }
  }
}
