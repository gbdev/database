/** MapCoordinate module --
    Implementation of module providing all services for handling the
    the user coordinates on a map in a GameBoy game.

    Original version by Thomas Tensi, 2005-05
*/


#include <gbextended/mapcoordinate.h>

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

MapCoordinate_Vector MapCoordinate_unitVectorX
  = {MapCoordinate_unit, 0};

MapCoordinate_Vector MapCoordinate_unitVectorY
  = {0, MapCoordinate_unit};

MapCoordinate_Vector MapCoordinate_unitVector
  = {MapCoordinate_unit, MapCoordinate_unit};

MapCoordinate_Vector MapCoordinate_halfCellVector
  = {MapCoordinate_subunitCount / 2, MapCoordinate_subunitCount / 2};

/*--------------------*/

/* technical definitions for the map coordinate selectors and
   constructor routines */

#define MapCoordinate__subunitBitsCount (4)
  /* the number of bits used for the fractional part of a raster
     position; should be greater or equal to
     log2(MapCoordinate_subunitCount) */

#define MapCoordinate__subunitMask (0xF)
  /* the mask to get the fractional part of a raster position */

#define MapCoordinate__rasterMask (0xFFF0)
  /* the mask to remove the fractional part of a raster position */

/*========================================*/
/* PRIVATE ROUTINES                       */
/*========================================*/

static MapCoordinate_Type MapCoordinate__maximum (in MapCoordinate_Type a,
						  in MapCoordinate_Type b)
{
  return (a > b ? a : b);
}

/*--------------------*/

static MapCoordinate_Type MapCoordinate__minimum (in MapCoordinate_Type a,
						  in MapCoordinate_Type b)
{
  return (a < b ? a : b);
}

/*========================================*/
/* EXPORTED ROUTINES                      */
/*========================================*/

void MapCoordinate_initialize (void)
{
}

/*--------------------*/

void MapCoordinate_finalize (void)
{
}

/*--------------------*/

MapCoordinate_IntegerPart MapCoordinate_integerPart (in MapCoordinate_Type c)
{
  return (c >> MapCoordinate__subunitBitsCount);
}

/*--------------------*/

MapCoordinate_FractionalPart MapCoordinate_fractionalPart (
					   in MapCoordinate_Type c)
{
  return (c & MapCoordinate__subunitMask);
}

/*--------------------*/

MapCoordinate_Type MapCoordinate_make (in MapCoordinate_IntegerPart i,
				       in MapCoordinate_FractionalPart f)
{
  return ((UINT16)(i) << MapCoordinate__subunitBitsCount | f);
}

/*--------------------*/

MapCoordinate_Type MapCoordinate_clearFractionalPart (in MapCoordinate_Type c)
{
  return (c & MapCoordinate__rasterMask);
}

/*--------------------*/

MapCoordinate_Type MapCoordinate_addOperation (in MapCoordinate_Type a,
					       in MapCoordinate_Type b,
					       in Boolean isSubtraction)
{
  MapCoordinate_Type result;
  MapCoordinate_IntegerPart ar, br;
  MapCoordinate_FractionalPart as, bs;

  ar = MapCoordinate_integerPart(a);
  br = MapCoordinate_integerPart(b);
  as = MapCoordinate_fractionalPart(a);
  bs = MapCoordinate_fractionalPart(b);

  if (isSubtraction) {
    if (as < bs) {
      as = as + MapCoordinate_subunitCount;
      ar--;
    }
    result = MapCoordinate_make(ar - br, as - bs);
  } else {
    MapCoordinate_IntegerPart r = ar + br;
    MapCoordinate_FractionalPart s = as + bs;

    if (s >= MapCoordinate_subunitCount) {
      s = s - MapCoordinate_subunitCount;
      r++;
    }
    result = MapCoordinate_make(r, s);
  }

  return result;
}

/*--------------------*/

MapCoordinate_Type MapCoordinate_shiftOperation (in MapCoordinate_Type a,
						 in INT8 offset)
{
  MapCoordinate_Type result;

  if (offset == 0) {
    result = a;
  } else {
    MapCoordinate_IntegerPart r = MapCoordinate_integerPart(a);
    MapCoordinate_FractionalPart s = MapCoordinate_fractionalPart(a);
    INT8 i;
    Boolean isRightShift = (offset < 0);

    if (isRightShift) {
      offset = -offset;
    }

    for (i = 0;  i != offset;  i++) {
      if (isRightShift) {
	if ((r & 1) != 0) {
	  s = s + MapCoordinate_subunitCount;
	}
 	s >>= 1;
	r >>= 1;
      } else {
	s <<= 1;
	r <<= 1;
	if (s >= MapCoordinate_subunitCount) {
	  s = s - MapCoordinate_subunitCount;
	  r++;
	}
      }
    }
    result = MapCoordinate_make(r, s);
  }

  return result;
}

/*--------------------*/

void MapCoordinate_round (inout MapCoordinate_Type *coordinate)
{
  *coordinate = MapCoordinate_addOperation(*coordinate,
					   MapCoordinate_subunitCount / 2,
					   false);
  *coordinate = MapCoordinate_clearFractionalPart(*coordinate);
}

/*--------------------*/

INT8 MapCoordinate_compare (in MapCoordinate_Type a, in MapCoordinate_Type b)
{
  if (a < b) {
    return -1;
  } else if (a > b) {
    return 1;
  } else {
    return 0;
  }
}

/*--------------------*/

void MapCoordinate_vectorAddOp (readonly MapCoordinate_Vector *a,
				readonly MapCoordinate_Vector *b,
				in Boolean isSubtraction,
				out MapCoordinate_Vector *result)
{
  result->x = MapCoordinate_addOperation(a->x, b->x, isSubtraction);
  result->y = MapCoordinate_addOperation(a->y, b->y, isSubtraction);
}

/*--------------------*/

void MapCoordinate_vectorShiftOp (readonly MapCoordinate_Vector *a,
				  in INT8 offset,
				  out MapCoordinate_Vector *result)
{
  result->x = MapCoordinate_shiftOperation(a->x, offset);
  result->y = MapCoordinate_shiftOperation(a->y, offset);
}

/*--------------------*/

Boolean MapCoordinate_vectorIsEqual (readonly MapCoordinate_Vector *a,
				     readonly MapCoordinate_Vector *b)
{
  return ((a->x == b->x) && (a->y == b->y));
}

/*--------------------*/

Boolean MapCoordinate_isEmptyRect (readonly MapCoordinate_Rectangle *r)
{
  return (r->diagonalVector.x == 0 || r->diagonalVector.y == 0);
}

/*--------------------*/

Boolean MapCoordinate_isInRectangle (
			     readonly MapCoordinate_Rectangle *rectangle,
			     readonly MapCoordinate_Vector *position)
{
  Boolean isOkay;
  MapCoordinate_Vector *upperLeftCorner;
  MapCoordinate_Vector lowerRightCorner;
  
  upperLeftCorner  = (MapCoordinate_Vector *) &(rectangle->upperLeftCorner);
  MapCoordinate_vectorAddOp(upperLeftCorner, &(rectangle->diagonalVector),
			    false, &lowerRightCorner);

  /* check x- and y-position */
  isOkay = (upperLeftCorner->x <= position->x
	    && position->x < lowerRightCorner.x
            && upperLeftCorner->y <= position->y
	    && position->y < lowerRightCorner.y);

  return isOkay;
}

/*--------------------*/

void MapCoordinate_clipRectangle (
 		       readonly MapCoordinate_Rectangle *rectangleA,
		       readonly MapCoordinate_Rectangle *rectangleB,
		       out MapCoordinate_Rectangle *rectangle)
{
  MapCoordinate_Vector *ulCornerA;
  MapCoordinate_Vector *ulCornerB;
  MapCoordinate_Vector *ulCorner;
  MapCoordinate_Vector *diagonalVector;
  MapCoordinate_Vector lrCornerA;
  MapCoordinate_Vector lrCornerB;
  MapCoordinate_Vector lrCorner;
  
  ulCornerA = (MapCoordinate_Vector *) &(rectangleA->upperLeftCorner);
  ulCornerB = (MapCoordinate_Vector *) &(rectangleB->upperLeftCorner);
  ulCorner  = &(rectangle->upperLeftCorner);
  ulCorner->x = MapCoordinate__maximum(ulCornerA->x, ulCornerB->x);
  ulCorner->y = MapCoordinate__maximum(ulCornerA->y, ulCornerB->y);

  MapCoordinate_vectorAddOp(ulCornerA, &(rectangleA->diagonalVector),
			    false, &lrCornerA);
  MapCoordinate_vectorAddOp(ulCornerB, &(rectangleB->diagonalVector),
			    false, &lrCornerB);
  
  lrCorner.x = MapCoordinate__minimum(lrCornerA.x, lrCornerB.x);
  lrCorner.y = MapCoordinate__minimum(lrCornerA.y, lrCornerB.y);

  diagonalVector = &(rectangle->diagonalVector);
  MapCoordinate_vectorAddOp(&lrCorner, ulCorner, true, diagonalVector);

  if (diagonalVector->x < 0) {
    diagonalVector->x = 0;
  }

  if (diagonalVector->y < 0) {
    diagonalVector->y = 0;
  }
}
