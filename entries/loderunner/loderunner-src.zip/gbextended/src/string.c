/** String module --
    Implementation of module providing all services for handling
    strings in a GameBoy game.

    Original version by Thomas Tensi, 2006-02
*/

#include <gbextended/string.h>

/*========================================*/

#include <gbextended/assertion.h>
#include <stdlib.h>
#include <gbextended/stdstring.h>
#include <gbextended/types.h>

/*========================================*/

void String_initialize (void)
{
}

/*--------------------*/

void String_finalize (void)
{
}

/*--------------------*/

void String_boundedCopy (out String_Type destination, in String_Type source,
			 in UINT16 maxSize)
{
  UINT16 length = String_length(source);
  Boolean destinationIsLongEnough = (length < maxSize);

  //Assertion_PRE(destinationIsLongEnough, "String_boundedCopy",
  //		"destination too short");

  if (destinationIsLongEnough) {
    String_memoryMove(destination, source, length + 1);
  } else {
    /* truncate at <maxSize> - 1 */
    UINT16 lastAllowedPosition = maxSize - 1;
    destination[lastAllowedPosition] = String_terminator;
    String_memoryMove(destination, source, lastAllowedPosition);
  }
}

/*--------------------*/

void String_concatenate (inout String_Type destination, 
			 in String_Type otherString,
			 in UINT16 maxSize)
{
  UINT16 destinationLength = String_length(destination);
  UINT16 otherLength = String_length(otherString);
  String_Type firstChar = &destination[destinationLength];

  Boolean destinationIsLongEnough = (destinationLength + otherLength < maxSize);

  Assertion_PRE(destinationIsLongEnough, "String_concatenate",
  		"destination too short");

  if (destinationIsLongEnough) {
    String_memoryMove(firstChar, otherString, otherLength + 1);
  } else {
    destination[maxSize - 1] = String_terminator;
    otherLength = maxSize - destinationLength - 1;
    String_memoryMove(firstChar, otherString, otherLength);
  }
}

/*--------------------*/

UINT16 String_findCharacter (in String_Type st,  in char ch)
{
  String_Type ptr = StdString_strchr(st, ch);
  UINT16 result;

  if (ptr == NULL) {
    result = String_notFound;
  } else {
    result = ptr - st;
  }

  return result;
}

/*--------------------*/

UINT16 String_findInList (in String_Type st, in String_List stringList)
{
  UINT16 i = 0;
  Boolean isSearching = true;

  do {
    String_Type currentString = stringList[i];

    if (currentString == NULL) {
      i = String_notFound;
      isSearching = false;
    } else if (currentString == st) {
      isSearching = false;
    } else {
      i++;
    }
  } while (isSearching);

  return i;
}

/*--------------------*/

void String_globalReplace (inout String_Type st, in String_Type pattern,
			   in String_Type replacement, in UINT16 maxSize)
{
  UINT16 replacementLength = String_length(replacement);

  for (;;) {
    /* find the first position of pattern */
    String_Type ptr = StdString_strstr(st, pattern);

    if (ptr == NULL) {
      break;
    } else {
      /* do an in-place character shift by shiftOffset */
      INT16 shiftOffset = replacementLength - String_length(pattern);

      if (shiftOffset != 0) {
	String_Type dPtr;
	String_Type sPtr;
	UINT8 shiftLength;

	if (shiftOffset < 0) {
	  dPtr = ptr;
	  sPtr = ptr - shiftOffset;
	} else {
	  dPtr = ptr + shiftOffset;
	  sPtr = ptr;
	}
	shiftLength = String_length(sPtr) + 1;
	String_memoryMove(dPtr, sPtr, shiftLength);
      }

      /* put replacement at ptr position */
      String_memoryMove(ptr, replacement, replacementLength);
    }
  }
}

/*--------------------*/

UINT16 String_length (in String_Type st)
{
  return StdString_strlen(st);
}

/*--------------------*/

void String_makeFromInteger (in INT16 value, out String_Type st, in UINT8 base)
{
  StdString_itoa(value, st, base);
}

/*--------------------*/

void String_memoryMove (inout String_Type destination,
			in String_Type source, in UINT16 size)
{
  StdString_memmove(destination, source, size);
}

/*--------------------*/

void *String_serialize (in void *destination, in void *source,
			in Boolean hasStringLeafs,
			in UINT16 leafSize,
			in UINT8 indirectionLevel,
			inout UINT16 *remainingSize)
{
  UINT16 dataSize;

  if (indirectionLevel == 0) {
    if (hasStringLeafs) {
      dataSize = String_length(source) + 1;
    } else {
      dataSize = leafSize;
    }
   
    if (dataSize > *remainingSize) {
      return NULL;
    } else {
      String_memoryMove(destination, source, dataSize);
      *remainingSize -= dataSize;
      return (String_Type)destination + dataSize;
    }
  } else {
    /* some kind of NULL-terminated list */
    void **sourceList = (void **) source;
    void *subList;

    /* find out whether there is enough space for the list pointers */
    dataSize = 0;

    do {
      subList = *sourceList++;
      dataSize += sizeof(void *);
    }  while (subList != NULL);

    if (dataSize > *remainingSize) {
      return NULL;
    } else {
      void **destinationList = (void **) destination;
      void *subListDataBuffer;
      Boolean isDefined[16];
      UINT8 i;

      /* reserve space for the pointers within the destination and store
	 the source pointers into the destination; then we can check for
	 duplicate source pointers later on and replace them by the same
	 pointers in the destination buffer */

      i = 0;
      sourceList = (void **) source;

      do {
	subList = *sourceList++;
	*destinationList++ = subList;
	isDefined[i++] = false;
      } while (subList != NULL);

      *remainingSize -= dataSize;
      subListDataBuffer = (void *) destinationList;
      sourceList = (void **) source;
      destinationList = (void **) destination;

      /* copy the sublists recursively */
      i = 0;
      do {
	subList = *sourceList++;

	if (subList != NULL && !isDefined[i]) {
	  UINT8 j;
	  void **otherDestination = (void **) destinationList + 1;

	  *destinationList = subListDataBuffer;

	  /* are there any other entries with the same reference? */
	  for (j = i + 1;  *otherDestination != NULL;  j++) {
	    if (!isDefined[j] && *otherDestination == subList) {
	      isDefined[j] = true;
	      *otherDestination = subListDataBuffer;
	    }
	    otherDestination++;
	  }

	  subListDataBuffer = String_serialize(subListDataBuffer, subList,
					       hasStringLeafs, leafSize,
					       indirectionLevel - 1,
					       remainingSize);

	  if (subListDataBuffer == NULL) {
	    /* not enough space for complete structure */
	    break;
	  }
	}

	destinationList++;
	i++;
      } while (subList != NULL);

      return subListDataBuffer;
    }
  }
}

/*--------------------*/

void String_setMemory (inout String_Type destination, in char value,
		       in UINT16 size)
{
  StdString_memset(destination, value, size);
}
