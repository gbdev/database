/** Map module --
    Implementation of module providing all services for handling the
    map of a GameBoy game. It provides a framework to be extended by a
    concrete map.

    Original version by Thomas Tensi, 2005-05
*/


#include <gbextended/map.h>

/*========================================*/

#include <gbextended/assertion.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/matrix.h>
#include <gbextended/stdstring.h>
#include <gbextended/types.h>

/*========================================*/

typedef struct {
  MapCoordinate_IntegerPart columnCount;
  MapCoordinate_IntegerPart rowCount;

  Boolean columnsAreCircular;
  Boolean rowsAreCircular;
  Map_ObjectKind *objectKindsInMap;
    /** list of object kinds allowed in the map */

  Map_Position maximumAllowedPosition;
    /** the maximum value a position may have on current map */

  Map_ObjectKind **data;
    /** two-dimensional array of data for this map in row major
	order */

  Map_ObserverProc observerProc;
    /** callback procedure which gets notified when static map at
        position (x,y) changes; x and y are given as parameters to
        this procedure */
  Map_ObjectKindMapProc objectKindAbstractionProc;
    /** procedure which maps one object kind into its abstract object
	kind */
} Map__Descriptor;

/*--------------------*/

typedef struct {
  MapCoordinate_IntegerPart column;
  MapCoordinate_IntegerPart row;
    /** the current position during an iteration over a specific
        object kind */
  Map_ObjectKind kind;
    /** the current object category during a position iteration */
} Map__Iterator;

/*--------------------*/

static Map__Descriptor Map__current;
static Map__Iterator Map__iterator;

MapCoordinate_Rectangle Map_boundingBox;
  /** the bounding box rectangle of map */

/*========================================*/
/*     PRIVATE ROUTINES                   */
/*========================================*/

static MapCoordinate_Type Map__adjustToInterval (in MapCoordinate_Type v,
				   in MapCoordinate_Type maxValue,
				   in Boolean dimensionIsCircular)
  /** adjusts <v> to lie within interval [0..<maxValue>] either by
      clipping for a non-circular dimension or by shifting by the
      interval length for a circular dimension */
{
  if (dimensionIsCircular) {
    while (v < 0) {
      v += maxValue;
    }
    while (v > maxValue) {
      v -= maxValue;
    }
  } else if (v > maxValue) {
    v = maxValue;
  } else if (v < 0) {
    v = 0;
  }

  return v;
}

/*--------------------*/

static Boolean Map__isInBoundary (in MapCoordinate_IntegerPart x,
				  in MapCoordinate_IntegerPart y)
  /** checks whether <x> and <y> are within map boundaries */
{
  return (0 <= x && 0 <= y
	  && x < Map__current.columnCount && y < Map__current.rowCount);
}

/*--------------------*/

static void Map__checkBoundsAssertion (in MapCoordinate_IntegerPart x,
				       in MapCoordinate_IntegerPart y,
				       in char *procName)
  /** checks whether <x> and <y> are within map boundaries; otherwise
      a preconditition assertion failure is raised for procedure with
      <procName> and <message> */
{
  Assertion_PRE(Map__isInBoundary(x, y), procName, "bad coordinate");
}

/*--------------------*/

static Map_ObjectKind Map__getEntryByCoordinates (
				       in MapCoordinate_IntegerPart x,
				       in MapCoordinate_IntegerPart y)
				       
  /** returns entry in map at position (<x>, <y>) */
{
  return Matrix_get(Map__current.data, y, x);
}


/*========================================*/
/*     PUBLIC ROUTINES AND DATA           */
/*========================================*/

void Map_initialize (void)
{
}

/*--------------------*/

void Map_finalize (void)
{
}

/*--------------------*/

void Map_define (in MapCoordinate_IntegerPart columnCount,
		 in MapCoordinate_IntegerPart rowCount,
		 in Boolean columnsAreCircular,
		 in Boolean rowsAreCircular,
		 in Map_ObjectKind *objectKindsInMap,
		 in Map_ObjectKind **data,
		 in Map_ObjectKindMapProc objectKindAbstractionProc)
{
  Map__Descriptor *m = &Map__current;
  MapCoordinate_Rectangle *boundingBox = &Map_boundingBox;

  m->columnCount               = columnCount;
  m->rowCount                  = rowCount;
  m->columnsAreCircular        = columnsAreCircular;
  m->rowsAreCircular           = rowsAreCircular;
  m->objectKindsInMap          = objectKindsInMap;
  m->data                      = data;
  m->observerProc              = NULL;
  m->objectKindAbstractionProc = objectKindAbstractionProc;

  /*** calculate all derived stuff ***/
  /* set maximum position on map */
  m->maximumAllowedPosition.x = MapCoordinate_make(m->columnCount - 1,
					     MapCoordinate_subunitCount - 1);
  m->maximumAllowedPosition.y = MapCoordinate_make(m->rowCount - 1,
					     MapCoordinate_subunitCount - 1);

  /* set bounding box of map */
  StdString_memset(boundingBox, 0, sizeof(MapCoordinate_Rectangle));
  boundingBox->diagonalVector.x = MapCoordinate_make(m->columnCount, 0);
  boundingBox->diagonalVector.y = MapCoordinate_make(m->rowCount, 0);
}

/*--------------------*/

void Map_getProperties (out MapCoordinate_IntegerPart *columnCount,
			out MapCoordinate_IntegerPart *rowCount,
			out Boolean *columnsAreCircular,
			out Boolean *rowsAreCircular,
			out Map_ObjectKind **objectKindsInMap)
{
  Map__Descriptor *m = &Map__current;

  *columnCount        = m->columnCount;
  *rowCount           = m->rowCount;
  *columnsAreCircular = m->columnsAreCircular;
  *rowsAreCircular    = m->rowsAreCircular;
  *objectKindsInMap   = m->objectKindsInMap;
}

/*--------------------*/

void Map_setObserver (in Map_ObserverProc observerProc)
{
  Map__current.observerProc = observerProc;
}

/*--------------------*/

Map_ObjectKind Map_getEntry (readonly Map_Position *position)
{
  MapCoordinate_IntegerPart y = MapCoordinate_integerPart(position->y);
  MapCoordinate_IntegerPart x = MapCoordinate_integerPart(position->x);
  Map_ObjectKind kind;

  if (!Map__isInBoundary(x, y)) {
    kind = '\0';
  } else {
    kind = Map__getEntryByCoordinates(x, y);

    /* abstract away the states of animated map cells */
    if (Map__current.objectKindAbstractionProc != NULL) {
      (*Map__current.objectKindAbstractionProc)(&kind);
    }
  }
  return kind;
}

/*--------------------*/

Map_ObjectKind Map_getEntryWithState (readonly Map_Position *position)
{
  MapCoordinate_IntegerPart y = MapCoordinate_integerPart(position->y);
  MapCoordinate_IntegerPart x = MapCoordinate_integerPart(position->x);

  { /* precondition checking */
    Map__checkBoundsAssertion(x, y, "Map_getEntryWithState");
  }

  { /* normal processing */
    return Map__getEntryByCoordinates(x, y);
  }
}

/*--------------------*/

void Map_setEntry (readonly Map_Position *position,
		   in Map_ObjectKind objectKind)
{
  MapCoordinate_IntegerPart y = MapCoordinate_integerPart(position->y);
  MapCoordinate_IntegerPart x = MapCoordinate_integerPart(position->x);

  { /* precondition checking */
    Map__checkBoundsAssertion(x, y, "Map_setEntry");
  }

  { /* normal processing */
    Map_Position normalizedPosition;

/*     Map_ObjectKind *ptr; */
/*     ptr = Map__current.data[y]; */
/*     ptr[x] = objectKind; */
    Matrix_set(Map__current.data, y, x, objectKind);
    /* update map view */
    normalizedPosition.x = MapCoordinate_make(x, 0);
    normalizedPosition.y = MapCoordinate_make(y, 0);
    if (Map__current.observerProc != NULL) {
      (*Map__current.observerProc)(&normalizedPosition);
    }
  }
}

/*--------------------*/

void Map_globalReplaceInMap (in Map_ObjectKind o,
			     in Map_ObjectKind replacement,
			     in Boolean observerIsUpdated)
  /** replaces all occurences of <object kind <o> by <replacement> in
      static map;  if <observerIsUpdated> then every change is reflected
      in the observer */
{
  UINT8 row;

  for (row = 0;  row != Map__current.rowCount;  row++) {
    UINT8 column;
    Map_ObjectKind *mapPtr;
    mapPtr = Map__current.data[row];

    for (column = 0;  column != Map__current.columnCount;  column++) {
      Map_ObjectKind kind;

      kind = *mapPtr;
      if (kind == o) {
	*mapPtr = replacement;
	if (observerIsUpdated && Map__current.observerProc != NULL) {
	  Map_Position position;
	  position.x = MapCoordinate_make(column, 0);
	  position.y = MapCoordinate_make(row, 0);
	  (*Map__current.observerProc)(&position);
	}
      }
      mapPtr++;
    }
  }
}

/*--------------------*/

void Map_adjustToCorrectPosition (inout Map_Position *position)
{
  MapCoordinate_Type maxX = Map__current.maximumAllowedPosition.x;
  MapCoordinate_Type maxY = Map__current.maximumAllowedPosition.y;

  position->x = Map__adjustToInterval (position->x, maxX,
				       Map__current.columnsAreCircular);
  position->y = Map__adjustToInterval (position->y, maxY,
				       Map__current.rowsAreCircular);
}

/*--------------------*/

void Map_resetPositionIterator (in Map_ObjectKind kind)
{
  Map__iterator.column = 0;
  Map__iterator.row    = 0;
  Map__iterator.kind   = kind;
}

/*--------------------*/

Boolean Map_getNextPosition (out Map_Position *position)
{
  Boolean isDone;
  Boolean found = false;
  Map_ObjectKind *st;
  UINT8 expectedKind = Map__iterator.kind;
  MapCoordinate_IntegerPart row = Map__iterator.row;
  MapCoordinate_IntegerPart column = Map__iterator.column;
  MapCoordinate_IntegerPart lastRow = Map__current.rowCount;
  MapCoordinate_IntegerPart lastColumn = Map__current.columnCount;

  st = Map__current.data[row];

  do {
    isDone = false;
    if (row == lastRow) {
      found = false;
      isDone = true;
    } else if (column == lastColumn) {
      row++;
      column = 0;
      st = Map__current.data[row];
    } else {
      Map_ObjectKind kind;
      kind = st[column];
      if (kind != expectedKind) {
	column++;
      } else {
	found = true;
	isDone = true;
      }
    }
  } while (!isDone);

  if (found) {
    position->x = MapCoordinate_make(column, 0);
    position->y = MapCoordinate_make(row, 0);
    column++;
    Map__iterator.row = row;
    Map__iterator.column = column;
  }

  return found;
}
