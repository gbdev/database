/** Sprite Animation module --
    Implementation of module providing services for handling the
    sprite animations of a GameBoy Color.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/spriteanimation.h>

/*========================================*/

#include <gbextended/sprite.h>
#include <gbextended/tile.h>

/*========================================*/

typedef struct {
  SpriteAnimation_Schedule *schedule;
  Boolean isPaused;  /** tells whether the animation is frozen */
  UINT8 timeToNextPhaseChange;
  UINT8 phaseIndex;
  SpriteAnimation_Phase *currentPhase;
} SpriteAnimation__Type;

static SpriteAnimation__Type SpriteAnimation__list[Sprite_maxCount];
  /** list of all animations associated with virtual sprites */

/*--------------------*/

void SpriteAnimation__advance (in Sprite_Type sprite)
  /** advance the animation of <sprite> by one frame */
{
  SpriteAnimation__Type *animation = &SpriteAnimation__list[sprite];

  if (!animation->isPaused) {
    SpriteAnimation_Schedule *schedule = animation->schedule;
    Boolean updateIsNecessary = false;

    if (animation->currentPhase == NULL) {
      animation->phaseIndex = 0;
      animation->currentPhase = &(schedule->phaseList[0]);
      updateIsNecessary = true;
    } else if (animation->timeToNextPhaseChange == 0) {
      updateIsNecessary = true;
      animation->phaseIndex++;
      if (animation->phaseIndex != schedule->phaseCount) {
	animation->currentPhase++;
      } else {
	animation->phaseIndex = 0;
	animation->currentPhase = &(schedule->phaseList[0]);
      }
    }

    if (updateIsNecessary) {
      SpriteAnimation_Phase *currentPhase = animation->currentPhase;

      animation->timeToNextPhaseChange = currentPhase->duration;
      /* update tiles, attributes and offsets of sprite */
      Sprite_setOffsets(sprite, currentPhase->offsetList);
      Sprite_setAttributes(sprite, currentPhase->attributeList);
      Sprite_setTiles(sprite, currentPhase->tileList);
    }

    animation->timeToNextPhaseChange--;
  }
}

/*--------------------*/
/* EXPORTED ROUTINES  */
/*--------------------*/

void SpriteAnimation_initialize (void)
{
  SpriteAnimation_stopAll();
}

/*--------------------*/

void SpriteAnimation_finalize (void)
{
}

/*--------------------*/

void SpriteAnimation_setSchedule ( in Sprite_Type sprite,
				   in SpriteAnimation_Schedule *schedule,
				   in Boolean scheduleIsRestarted)
{
  SpriteAnimation__Type *animation = &SpriteAnimation__list[sprite];

  if (scheduleIsRestarted || animation->schedule != schedule) {
    animation->schedule = schedule;
    animation->isPaused = false;
    animation->currentPhase = NULL;
    SpriteAnimation__advance(sprite);
  }
}

/*--------------------*/

void SpriteAnimation_setState (in Sprite_Type sprite,
			       in Boolean isPaused)
{
  SpriteAnimation__list[sprite].isPaused = isPaused;
}

/*--------------------*/

void SpriteAnimation_handleTickEvent (Sprite_Type sprite)
{
  SpriteAnimation__advance(sprite);
}

/*--------------------*/

void SpriteAnimation_stopAll (void)
{
  Sprite_Type sprite;

  for (sprite = 0;  sprite != Sprite_maxCount;  sprite++) {
    SpriteAnimation__list[sprite].isPaused = true;
  }
}
