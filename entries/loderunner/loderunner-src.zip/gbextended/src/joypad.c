/** Joypad module --
    Implementation of module providing services for querying the user
    input via the GameBoy joypad. This is done by mapping extended
    names into names from Jon Fuge's library.

    Original version by Thomas Tensi, 2004-09
*/

#include <gbextended/joypad.h>
#include <gbextended/set.h>
#include <gb/gb.h>

/*--------------------*/

void Joypad_initialize (void)
{
}

/*--------------------*/

void Joypad_finalize (void)
{
}

/*--------------------*/

Boolean Joypad_getKeyPressed (out Joypad_Key *key)
{
  Joypad_KeySet keysPressed = Joypad_getKeysPressed();
  Boolean someKeyIsPressed;

  someKeyIsPressed = !Set_isEmpty(keysPressed);
  if (someKeyIsPressed) {
    /* find out which one ... */
    *key = Set_firstElement(keysPressed);
  }
  return someKeyIsPressed;
}

/*--------------------*/

Joypad_KeySet Joypad_getKeysPressed (void)
{
  return (joypad());
}

/*--------------------*/

UINT8 Joypad_waitForAllKeys (in Joypad_KeySet keySet)
{
  return (waitpad(keySet));
}

/*--------------------*/

void Joypad_waitForNoKey (void)
{
  waitpadup();
}

/*--------------------*/

void Joypad_waitForSomeKey (out Joypad_Key *key)
{
  Joypad_waitForNoKey();

  while (!Joypad_getKeyPressed(key)) {
  }
}
