/** Hardware module --
    Implementation of module providing services for encapsulating the
    hardware layer of the GameBoy.

    by Thomas Tensi, 2005-10
*/

#include <gbextended/hardware.h>

/*========================================*/

#include <gbextended/types.h>

#include <gb/gb.h>
#include <gb/hardware.h>

/*========================================*/

typedef struct {
  UINT8 sweep;
  UINT8 soundLength;
  UINT8 envelope;
  UINT8 frequencyLow;
  UINT8 frequencyHigh;
} Hardware__SoundChannelSetup;


#define Hardware__lowestAllowedPitch 36

static const UINT8 Hardware__pitchToFrequency1[] = {
  0x2D, 0x9D, 0x07, 0x6B, 0xCA, 0x23, 0x77, 0xC7, 0x12, 0x59, 0x9C, 0xDB,
  0x17, 0x4F, 0x84, 0xB6, 0xE5, 0x12, 0x3C, 0x64, 0x89, 0xAD, 0xCE, 0xEE,
  0x0C, 0x28, 0x42, 0x5B, 0x73, 0x89, 0x9E, 0xB2, 0xC5, 0xD7, 0xE7, 0xF7,
  0x06, 0x14, 0x21, 0x2E, 0x3A, 0x45, 0x4F, 0x59, 0x63, 0x6C, 0x74, 0x7C,
  0x83, 0x8A, 0x91, 0x97, 0x9D, 0xA3, 0xA8, 0xAD, 0xB2, 0xB6, 0xBA, 0xBE,
  0xC2, 0xC5, 0xC9, 0xCC, 0xCF, 0xD2, 0xD4, 0xD7, 0xD9, 0xDB, 0xDD, 0xDF,
  0xE1, 0xE3, 0xE5, 0xE6, 0xE8, 0xE9, 0xEA, 0xEC, 0xED, 0xEE, 0xEF, 0xF0,
  0xF1, 0xF2, 0xF3, 0xF3, 0xF4, 0xF5, 0xF5, 0xF6
};

static const UINT8 Hardware__pitchToFrequency2[] = {
  0x00, 0x11, 0x21, 0x22, 0x33, 0x33,
  0x44, 0x44, 0x54, 0x55, 0x55, 0x55,
  0x66, 0x66, 0x66, 0x66, 0x66, 0x66,
  0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
  0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
  0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
  0x77, 0x77, 0x77, 0x77, 0x77, 0x77,
  0x77, 0x77, 0x77, 0x77
};

#define minDrumPitch 35
#define maxDrumPitch 64

typedef struct {
  UINT8 channel;
  UINT16 setup;  /* either frequency of tone or envelope and params */
  UINT8 length;  /* either length of tone or sweep length */
} Hardware__DrumInstrumentSetup;
  /* map entry for mapping a drum MIDI pitch to sound parameters for
     the GameBoy */

static const Hardware__DrumInstrumentSetup Hardware__drumInstrument[] = {
 { 2, 0x400, 0x60 }, /* 35 Acoustic Bass Drum */
 { 2, 0x400, 0x60 }, /* 36 Bass Drum 1 */
 { 3, 0x15F, 0x08 }, /* 37 Side Stick */
 { 2, 0x600, 0x60 }, /* 38 Acoustic Snare */
 { 0, 0x000, 0x10 }, /* 39 Hand Clap */
 { 2, 0x600, 0x30 }, /* 40 Electric Snare */
 { 2, 0x700, 0x40 }, /* 41 Low Floor Tom */
 { 3, 0x120, 0x10 }, /* 42 Closed Hi-Hat */
 { 2, 0x000, 0x40 }, /* 43 High Floor Tom */
 { 3, 0x120, 0x20 }, /* 44 Pedal Hi-Hat */
 { 2, 0x700, 0x40 }, /* 45 Low Tom */
 { 3, 0x120, 0x30 }, /* 46 Open Hi-Hat */
 { 2, 0x700, 0x40 }, /* 47 Low-Mid Tom */
 { 2, 0x700, 0x40 }, /* 48 Hi-Mid Tom */
 { 3, 0x224, 0x80 }, /* 49 Crash Cymbal 1 */
 { 2, 0x700, 0x40 }, /* 50 High Tom */
 { 3, 0x220, 0x40 }, /* 51 Ride Cymbal 1 */
 { 3, 0x222, 0x40 }, /* 52 Chinese Cymbal */
 { 2, 0x000, 0x20 }, /* 53 Ride Bell */
 { 0, 0x000, 0x00 }, /* 54 Tambourine */
 { 3, 0x223, 0x40 }, /* 55 Splash Cymbal */
 { 2, 0x000, 0x20 }, /* 56 Cowbell */
 { 3, 0x221, 0x40 }, /* 57 Crash Cymbal 2 */
 { 0, 0x000, 0x00 }, /* 58 Vibraslap */
 { 3, 0x220, 0x40 }, /* 59 Ride Cymbal 2 */
 { 2, 0x000, 0x40 }, /* 60 Hi Bongo */
 { 2, 0x000, 0x40 }, /* 61 Low Bongo */
 { 2, 0x000, 0x40 }, /* 62 Mute Hi Conga */
 { 2, 0x000, 0x40 }, /* 63 Open Hi Conga */
 { 2, 0x000, 0x40 }  /* 64 Low Conga */
/*  { 0, 0x000, 0x00 }, /\* 65 High Timbale *\/ */
/*  { 0, 0x000, 0x00 }, /\* 66 Low Timbale *\/ */
/*  { 0, 0x000, 0x00 }, /\* 67 High Agogo *\/ */
/*  { 0, 0x000, 0x00 }, /\* 68 Low Agogo *\/ */
/*  { 0, 0x000, 0x00 }, /\* 69 Cabasa *\/ */
/*  { 0, 0x000, 0x00 }, /\* 70 Maracas *\/ */
/*  { 0, 0x000, 0x00 }, /\* 71 Short Whistle *\/ */
/*  { 0, 0x000, 0x00 }, /\* 72 Long Whistle *\/ */
/*  { 0, 0x000, 0x00 }, /\* 73 Short Guiro *\/ */
/*  { 0, 0x000, 0x00 }, /\* 74 Long Guiro *\/ */
/*  { 0, 0x000, 0x00 }, /\* 75 Claves *\/ */
/*  { 0, 0x000, 0x00 }, /\* 76 Hi Wood Block *\/ */
/*  { 0, 0x000, 0x00 }, /\* 77 Low Wood Block *\/ */
/*  { 0, 0x000, 0x00 }, /\* 78 Mute Cuica *\/ */
/*  { 0, 0x000, 0x00 }, /\* 79 Open Cuica *\/ */
/*  { 0, 0x000, 0x00 }, /\* 80 Mute Triangle *\/ */
/*  { 0, 0x000, 0x00 }  /\* 81 Open Triangle *\/ */
};


#ifndef WINDOWS
static char at 0xA800 Hardware__tileBuffer[16];
static Hardware__SoundChannelSetup at 0xFF10 Hardware__soundChannelSetup[2];
#else
static char Hardware__tileBuffer[16];
static Hardware__SoundChannelSetup Hardware__soundChannelSetup[2];
#endif

static unsigned char* Hardware__vramMapPtr = (unsigned char *)0x9800;
static unsigned char* Hardware__waveRAMPtr = (unsigned char *)0xFF30;

static Boolean Hardware__dmaIsPossible;
  /** tells whether current machine supports HDMA */

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void Hardware__doHDMACopy (in void *destination, in void *source,
				  in UINT8 pageCount,
				  in Boolean isSynchronous)
  /** utilizes the high direct memory access (HDMA) mechanism of the
      GameBoy processor to copy from <source> to <destination>; the
      number of 16 byte pages is given in <pageCount> and
      <isSynchronous> tells that the caller waits for completion of
      the memory copy */
{
#ifndef WINDOWS
  UINT8 p;
  HDMA1_REG = (UINT8)((UINT16)source >> 8);
  HDMA2_REG = (UINT8)((UINT16)source & 0xFF);
  HDMA3_REG = (UINT8)((UINT16)destination >> 8);
  HDMA4_REG = (UINT8)((UINT16)destination & 0xFF);
  p = pageCount;
  if (!isSynchronous) {
    p |= 128;
    HDMA5_REG = p;
  } else {
    /* make sure that no intervening interrupts put synchronous DMA
       outside of VBLANK period */
    disable_interrupts();

    while (LY_REG != 0x90) {
    }

    HDMA5_REG = p;
    enable_interrupts();
  }
#endif
}

/*--------------------*/

static UINT16 Hardware__mapPitchToFrequency (in Hardware_MIDIPitch pitch)
  /* converts midi pitch to GameBoy frequency specification */
{
  UINT8 p = pitch & 0x7F;
  UINT16 frequency;

  if (p < Hardware__lowestAllowedPitch) {
    frequency = 0;
  } else {
    UINT8 fLow, fHigh;
    p = p - Hardware__lowestAllowedPitch;
    fLow = Hardware__pitchToFrequency1[p];
    fHigh = Hardware__pitchToFrequency2[p/2];

    if ((p & 1) == 1) {
      fHigh >>= 4;
    }

    fHigh &= 0x7;
    frequency = (fHigh << 8) | fLow;
  }
  return frequency;
}

/*--------------------*/

static void Hardware__playDrumSound (in Hardware_MIDIPitch pitch,
				     in UINT8 volume)
  /* play drum sound given by <pitch> with <volume> */
{
  if (minDrumPitch <= pitch && pitch <= maxDrumPitch) {
    Hardware__DrumInstrumentSetup *instrument
      = &Hardware__drumInstrument[pitch - minDrumPitch];
    if (instrument->channel == 0) {
      /* ignore */
    } else {
      UINT16 frequency = instrument->setup;
      UINT8 v = volume;
      if (instrument->channel == 2) {
	/* wave */
	NR30_REG = 0x80;
	NR31_REG = 0xFF - instrument->length;
	v >>= 2;
	if (v != 0) {
	  v = 1;
	}
	NR32_REG = (v << 5);
	NR33_REG = frequency & 0xFF;
	NR34_REG = 0xC0 | (( frequency >> 8 ) & 7);
      } else {
	/* noise */
	UINT8 envelope   = (instrument->setup >> 8) & 0xF;
	UINT8 noiseSetup = instrument->setup & 0xFF;
	//v >>= 1;
	NR41_REG = 64 - instrument->length;
	NR42_REG = (v << 4) | envelope;
	NR43_REG = noiseSetup;
	NR44_REG = 0xC0;
      }
    }
  }
}

/*========================================*/
/*             PUBLIC ROUTINES            */
/*========================================*/

void Hardware_initialize (void)
{
#ifdef WINDOWS
  Hardware__dmaIsPossible = false;
#else
  char *bankPtr = (char *)0x0000;
  const unsigned char magicCode = 'F';
  UINT8 i;

  /* enable external cartridge RAM */
  *bankPtr = 0x0a;

  /* checks whether HDMA works */
  wait_vbl_done();
  Hardware__tileBuffer[0] = magicCode;
  Hardware__doHDMACopy(Hardware__vramMapPtr, Hardware__tileBuffer,
		       0, true);
  Hardware__dmaIsPossible = (*Hardware__vramMapPtr == magicCode);

  for (i = 0;  i != 16;  i++) {
    UINT8 j = 15 - i;
    j = j << 4 | j;
    Hardware__waveRAMPtr[i] = j;
  }
#endif
}

/*--------------------*/

void Hardware_finalize (void)
{
}

/*--------------------*/

void Hardware_Bkg_show (void)
{
  LCDC_REG |= 0x01U;
}

/*--------------------*/

void Hardware_Bkg_hide (void)
{
  LCDC_REG &= 0xFEU;
}

/*--------------------*/

void Hardware_Bkg_move (in UINT8 deltaX, in UINT8 deltaY)
{
  move_bkg(deltaX, deltaY);
  update_sprites();
}

/*--------------------*/

void Hardware_Bkg_updateAttribs (in void *attributeBuffer)
{
  const UINT16 tileCount = 19 * Hardware_tilesPerBufferRow;

  if (!Hardware__dmaIsPossible) {
    VBK_REG = 1;
    //set_data(Hardware__vramMapPtr, attributeBuffer, tileCount);
  } else {
    /* copy the background tile attributes via DMA synchronously */
    const UINT8 dmaPageCount = (UINT16) tileCount / 16 - 1;

    VBK_REG = 1;
    Hardware__doHDMACopy(Hardware__vramMapPtr, attributeBuffer,
			 dmaPageCount, true);
  }
}

/*--------------------*/

void Hardware_Bkg_updateTiles (in void *tileBuffer)
{
  const UINT16 tileCount = 19 * Hardware_tilesPerBufferRow;

  VBK_REG = 0;

  if (!Hardware__dmaIsPossible) {
    set_data(Hardware__vramMapPtr, tileBuffer, tileCount);
  } else {
    /* copy the background tile data via DMA asynchronously in
       following HBLANKs */
    const UINT8 dmaPageCount = (UINT16) tileCount / 16 - 1;
    Hardware__doHDMACopy(Hardware__vramMapPtr, tileBuffer,
			 dmaPageCount, false);
  }
}

/*--------------------*/

void Hardware_Sound_play (in UINT8 channel, in Hardware_MIDIPitch pitch,
			  in UINT8 volume)
{
  UINT8 p = pitch + 12;
  UINT16 gameboyFrequency;
  gameboyFrequency = Hardware__mapPitchToFrequency(p);

  if (channel == 2) {
    /* this is a drum sound */
    Hardware__playDrumSound(p, volume);
  } else if (pitch >= Hardware__lowestAllowedPitch) {
    UINT8 envelope = 0;
    UINT8 wavePattern;
    Hardware__SoundChannelSetup *soundChannelSetup;

    soundChannelSetup = &Hardware__soundChannelSetup[channel & 1];
    soundChannelSetup->sweep         = 0x00; /* no sweep */
    if (channel == 0) {
      wavePattern = 0;
    } else {
      wavePattern = 2;
    }
    soundChannelSetup->soundLength   = wavePattern << 6;
    soundChannelSetup->envelope      = (volume << 4) | envelope;
    soundChannelSetup->frequencyLow  = gameboyFrequency & 0xFF;
    soundChannelSetup->frequencyHigh = 0x80 | ((gameboyFrequency >> 8) & 0x7);
  }
}

/*--------------------*/

void Hardware_Sound_enable (void)
{
#ifndef WINDOWS
    NR52_REG = 0x80; /* sound on */
    NR50_REG = 0x77; /* maximum master volume */
    NR51_REG = 0x69; /* put channel 1 to both outputs */
#endif
}

/*--------------------*/

void Hardware_Sound_disable (void)
{
#ifndef WINDOWS
  NR52_REG = 0x00; /* sound off */
#endif
}

/*--------------------*/

void Hardware_Interrupts_disable (void)
{
  disable_interrupts();
}

/*--------------------*/

void Hardware_Interrupts_enable (void)
{
  enable_interrupts();
}

/*--------------------*/

void Hardware_Timer_get (Hardware_TimeType *currentTime)
{
  Hardware_Interrupts_disable();
  *currentTime = sys_time;
  Hardware_Interrupts_enable();
}
