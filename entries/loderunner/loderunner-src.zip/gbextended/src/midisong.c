/** MidiSong module --
    Implementation of module providing all services for playing
    a MIDI song with multiple tracks in a GameBoy game.

    Original version by Thomas Tensi, 2006-03
*/

#include <gbextended/midisong.h>

/*========================================*/

#include <gbextended/types.h>
#include <gbextended/sound.h>

/*========================================*/

typedef struct {
  MidiSong_Track partList;
  Boolean isActive;
  UINT8 partIndex;
  UINT16 remainingPartEventCount;
  MidiSong_EventData *eventDataPtr;
  Sound_DeltaTime timeToNextEvent;
  Sound_Event nextEvent;
} MidiSong__TrackDescriptor;
  /** internal data type for storing the properties of a track
      and the current state during playback */

#define MidiSong__trackCount MidiSong_TrackKind_drums

static MidiSong__TrackDescriptor MidiSong__trackInfo[MidiSong__trackCount];

#define MidiSong__maxDeltaTime 0x7FFF

/*========================================*/
/*            PRIVATE ROUTINES            */
/*========================================*/

static void MidiSong__getTrackEvent (in UINT8 trackIndex,
				     out Sound_DeltaTime *deltaTime,
				     out Sound_Event *event,
				     out Boolean *isDone)
  /* returns next event for track given by <trackNumber> in <event>,
     the time offset to this event is returned in <deltaTime>;
     <isDone> tells that no further event */
{
  MidiSong__TrackDescriptor *track = &MidiSong__trackInfo[trackIndex];
  MidiSong_Part currentPart;

  currentPart = track->partList[track->partIndex];

  if (currentPart == NULL) {
    track->isActive = false;
  } else {
    MidiSong_EventData *eventDataPtr;
    MidiSong_EventData currentEventData;
    Sound_DeltaTime delta;

    if (track->remainingPartEventCount != 0) {
      eventDataPtr = track->eventDataPtr;
    } else {
      eventDataPtr = currentPart;
      track->remainingPartEventCount = eventDataPtr[0] + eventDataPtr[1] * 256;
      eventDataPtr += 2;
    }

    /* decode variable length note specification */
    delta = 0;
    currentEventData = *eventDataPtr++;

    while ((currentEventData & 128) != 0) {
      delta = (delta << 7) + (currentEventData & 0x7f) + 1;
      currentEventData = *eventDataPtr++;
    }

    event->channel = trackIndex;
    event->pitch = currentEventData;
    currentEventData = *eventDataPtr++;
    track->eventDataPtr = eventDataPtr;

    event->volume = (currentEventData >> 4) & 15;
    delta = (delta << 4) + (currentEventData & 15);

    *deltaTime = delta;
    *isDone = false;
    track->remainingPartEventCount--;

    if (track->remainingPartEventCount == 0) {
      track->partIndex++;
    }
  }
}

/*========================================*/
/*            PUBLIC ROUTINES             */
/*========================================*/

void MidiSong_initialize (void)
{
}

/*--------------------*/

void MidiSong_finalize (void)
{
}

/*--------------------*/

void MidiSong_reset (void)
{
  MidiSong_TrackKind i;

  for (i = 0;  i != MidiSong__trackCount;  i++) {
    MidiSong__TrackDescriptor *track = &MidiSong__trackInfo[i];
    Boolean trackIsDone;
    track->partIndex = 0;
    track->remainingPartEventCount = 0;
    MidiSong__getTrackEvent(i, &(track->timeToNextEvent), &(track->nextEvent),
			    &trackIsDone);
    track->isActive = !trackIsDone;
  }
}

/*--------------------*/

void MidiSong_setTrack (in MidiSong_TrackKind trackKind,
			in MidiSong_Track partList)
{
  MidiSong__trackInfo[trackKind - 1].partList = partList;
}

/*--------------------*/

void MidiSong_getNextEvent (out Sound_DeltaTime *deltaTime,
			    out Sound_Event *event,
			    out Boolean *isDone)
{
  UINT8 i;
  UINT8 indexOfNextTrack = 0;
  Sound_DeltaTime timeToNextEvent = MidiSong__maxDeltaTime;
  MidiSong__TrackDescriptor *track;
  MidiSong__TrackDescriptor *firstTrack = &MidiSong__trackInfo[0];
  Boolean allTracksAreDone;
  Boolean trackIsDone;

  do {
    /* find minimum of all delta times */
    track = firstTrack;

    for (i = 0;  i != MidiSong__trackCount;  i++) {
      if (track->isActive) {
        Sound_DeltaTime currentDeltaTime = track->timeToNextEvent;
        if (currentDeltaTime < timeToNextEvent) {
	  timeToNextEvent = currentDeltaTime;
  	  indexOfNextTrack = i;
        }
      }
      track++;
    }

    allTracksAreDone = (timeToNextEvent == MidiSong__maxDeltaTime);

    if (allTracksAreDone) {
      MidiSong_reset();
    }
  } while (allTracksAreDone);

  *isDone = false;

  /* reduce all delta times by <timeToNextEvent> */
  track = firstTrack;

  for (i = 0;  i != MidiSong__trackCount;  i++) {
    if (track->isActive) {
      track->timeToNextEvent -= timeToNextEvent;
    }
    track++;
  }

  track = &MidiSong__trackInfo[indexOfNextTrack];
  *deltaTime = timeToNextEvent;
  STRUCT_ASSIGN(*event, track->nextEvent);
  MidiSong__getTrackEvent(indexOfNextTrack, &(track->timeToNextEvent),
			  &(track->nextEvent), &trackIsDone);
}
