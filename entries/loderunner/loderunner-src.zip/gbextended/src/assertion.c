/** Assertion module --
    Implementation of module providing all services for handling pre- and
    postconditions of routines.

    Thomas Tensi, 2004-09
*/

#include <gbextended/assertion.h>

/*========================================*/

#include <gbextended/string.h>
#include <gbextended/window.h>

/*========================================*/

static void Assertion__message  (in Boolean condition, in char *procName,
				 in char *message, in char *prefix)
{
  char tempString[100];

  if (!condition) {
    /* make copies to variable because pointers may not survive bank
       switching */
    String_boundedCopy(tempString, prefix, sizeof(tempString));
    Window_writeString(tempString);
    Window_writeString(" violation in ");
    String_boundedCopy(tempString, procName, sizeof(tempString));
    Window_writeString(tempString);
    Window_writeString(": ");
    String_boundedCopy(tempString, message, sizeof(tempString));
    Window_writeString(message);
    Window_writeLine();
  }
}

/*--------------------*/

void Assertion_PRE (in Boolean condition, in char *procName,
		    in char *message)
{
  Assertion__message(condition, procName, message, "Precondition");
}

/*--------------------*/

void Assertion_POST (in Boolean condition, in char *procName,
		     in char *message)
{
  Assertion__message(condition, procName, message, "Postcondition");
}

/*--------------------*/

void Assertion_DEBUG (in Boolean condition, in char *procName,
		      in char *message)
{
  Assertion__message(condition, procName, message, "Assertion");
}
