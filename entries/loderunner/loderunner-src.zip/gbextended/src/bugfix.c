/** Bugfix module --
    Implementation of module with routine to break up allocation of
    the SDCC compiler which is buggy.

    Original version by Thomas Tensi, 2005-05
*/

#include <gbextended/bugfix.h>

void SDCCBUGFIX (in void *i)
  /** routine to circumvent a bug in SDCC */
{
}
