/** Tile module --
    This module provides all services for handling the tiles of a
    GameBoy.

    A tile is associated with a table entry of an 8x8 four colour
    bitmap with it and is used for moving objects (sprites) as well as
    background.

    There are different services for bitmap and sprite tiles, but they
    use a common tile bitmap table.  Note that bitmaps with indices
    128-255 in the sprite bitmap table overlap with bitmaps 128-255 of
    the background and window tile bitmap table.  Additionally on the
    GameBoy Color the register VBK_REG determines which bank of the
    background or sprite tile bitmaps are changed.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __TILE_H
#define __TILE_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

#define Tile_width 8
  /** each tile has 8 pixels width and height */

typedef UINT8 Tile_Type;
  /** index into tile bitmap table */

typedef UINT8 Tile_Bitmap[16];
  /** definition of a four coloured bitmap for a tile */ 

typedef UINT8 Tile_Attribute;
  /** attribute of a tile containing information about whether it is
      flipped vertically and/or horizontally, the tile bank and
      the assigned colour palette */

/*========================================*/

void Tile_initialize (void);
  /** initializes the tile data; must be called before any other
      routines in this module */

/*--------------------*/

void Tile_finalize (void);
  /** cleans up the internal tile data; should be called after any
      other routines in this module */

/*--------------------*/

void Tile_SpriteBitmaps_write (in Tile_Type firstTile,
			       in UINT8 count,
			       in Tile_Bitmap *bitmapList);
  /** sets the tile bitmaps in the sprite tile bitmap table starting
      with index <firstTile> for <count> tiles taking the values
      starting from <bitmapList> */

/*--------------------*/

void Tile_SpriteBitmaps_read (in Tile_Type firstTile, 
			      in UINT8 count,
			      out Tile_Bitmap *bitmapList);
  /** gets the tile bitmaps from the sprite tile bitmap table starting
      with index <firstTile> for <count> tiles copying the data into
      <bitmapList> */

/*--------------------*/

void Tile_BkgBitmaps_write (in Tile_Type firstTile, 
			    in UINT8 count,
			    in Tile_Bitmap *bitmapList);
  /** sets the tile bitmaps in the background tile bitmap table
      starting with index <firstTile> for <count> tiles taking the
      values starting from <bitmapList> */

/*--------------------*/

void Tile_WinBitmaps_write (in Tile_Type firstTile,
			    in UINT8 count,
			    in Tile_Bitmap *bitmapList);
  /** sets the tile bitmaps in the window tile bitmap table starting
      with index <firstTile> for <count> tiles taking the values
      starting from <bitmapList> */

#endif /* __TILE_H */

