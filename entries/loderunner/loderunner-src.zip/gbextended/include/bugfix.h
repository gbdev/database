/** Bugfix module --
    This module tries to break up allocation of the SDCC compiler
    which is buggy.

    Original version by Thomas Tensi, 2005-05
*/

#ifndef _BUGFIX_H
#define _BUGFIX_H

#include <gbextended/types.h>

void SDCCBUGFIX (in void *i);
  /* routine for circumventing allocation bug in SDCC compiler */

#endif /* _BUGFIX_H */
