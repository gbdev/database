/** MapView module --
    This module provides all services for presenting the map
    in a GameBoy game as the background.

    A map view is a viewport on the map which shows a rectangle of
    cells, where the position can be any position on the map.

    Each cell has a rectangle of tiles assigned for its
    representation.  The rectangle consists of an integer multiple of
    tiles, but the factors may be different in x- and y-dimension.
    The transformation from a cell to its representation tiles is done
    automatically in this module.

    When the map view has to be defined, one first must specify the
    number of tiles per cell vertically and horizontally (which is the
    same for all object kinds in a cell!), the data container for
    storing the tiles and where the relevant tiles are located in the
    tile map.  Additionally a mapping from map object kind to tile and
    from tile to tile attributes have to be given.

    The map view queries the map for some characteristics to know
    e.g.\ whether it is bounded or unbounded and how many tiles have
    to be used for the map.  Note that the given tile container must
    be large enough to contain all tiles for the complete map.

    The tile container is initially filled by <analyseLevel> and
    updated by the callback <updatePosition>.  This is only practical
    when the map does not change at a high rate.

    The viewport on the map may be changed via <setViewport> or
    <centreViewport> and queried by <getViewport>.
    
    Original version by Thomas Tensi, 2004-10
*/

#ifndef __MAPVIEW_H
#define __MAPVIEW_H

/*========================================*/

#include <gbextended/types.h>

#include <gbextended/map.h>
#include <gbextended/mapcoordinate.h>
#include <gbextended/tile.h>
#include <gbextended/screen.h>

/*========================================*/

void MapView_initialize (void);
  /** initializes the map view module; must be called before any other
      routines in this module */

/*--------------------*/

void MapView_finalize (void);
  /** cleans up the internal map view data; should be called after any
      other routines in this module */

/*--------------------*/

void MapView_define (in UINT8 tileColumnsPerCell,
		     in UINT8 tileRowsPerCell,
		     in INT8 tileIndexOffset,
		     in Tile_Type *tileMatrix,
		     in Tile_Type *kindToTile,
		     in Tile_Attribute *tileToAttribute);
  /** defines the characteristic parameters of a concrete map view:
      <tileColumnsPerCell> and <tileRowsPerCell> tell the width and
      height of a map cell in background tile units, <tileColumnCount>
      and <tileRowCount> give the overall count of tiles of the view
      per dimension; <tileIndexOffset> gives the index of tile 0 in
      the global tile table, <tileMatrix> is the two-dimensional
      matrix storing the tile values of the concrete map view,
      <kindToTile> maps an object kind and a relative position within
      a cell into a concrete tile and <tileToAttribute> maps a tile to
      a tile attribute used for it
    */

/*--------------------*/

void MapView_analyseLevel (void);
  /** extracts view data from current map level; should be called after
      the map is set up */

/*--------------------*/

void MapView_findCoordInView (readonly Map_Position *position,
			      out Screen_Coordinate *screenX,
			      out Screen_Coordinate *screenY);
  /** returns screen coordinates (<screenX>,<screenY>) for <position>
      in viewport */

/*--------------------*/

void MapView_setViewport (inout Map_Position *position);
  /** puts viewport onto map to absolute map position <position>;
      adjusts coordinates when out of bounds; note that the change in
      the viewport is not visible until the next frame because the
      update occurs in the frame gap */

/*--------------------*/

void MapView_centreViewport (readonly Map_Position *position);
  /** tries to set map view to have <position> in its centre; note
      that the change in the viewport is made visible in the next
      frame because the update occurs in the frame gap */

/*--------------------*/

void MapView_getViewport (out MapCoordinate_Rectangle *viewport);
  /** gets rectangle of viewport onto map (in map coordinates) */

/*--------------------*/

void MapView_showInScreen (void);
  /** waits for next frame gap and refreshes the screen with contents
      of current map view */

/*--------------------*/

void MapView_updatePosition (readonly Map_Position *position);
  /** callback used for getting notified about updates of specific
      positions in the map; the offsets in position are not important,
      since the update always changes the contents of a complete
      cell */

/*--------------------*/

Boolean MapView_isVisible (readonly MapCoordinate_Rectangle *rectangle);
  /** tells whether <rectangle> is (at least partially) visible in
      current map view viewport */

/*--------------------*/


#endif /* __MAPVIEW_H */
