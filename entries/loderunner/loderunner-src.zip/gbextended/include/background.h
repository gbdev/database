/** Background module --
    This module provides all services for handling the background of a
    GameBoy Color.  Note that backgrounds with dimensions bigger than
    the GameBoy hardware are supported; those are mapped in on demand.

    The first step is to define the properties of the background via
    <define>.  Properties are height and width (in tiles) and whether
    the background is a bounded plane, a cylinder or a torus.
    Additionally a callback routine must be given which tells how the
    tiles in the background are updated.

    Since the GameBoy hardware display has only a limited size of
    32x32 tiles, a viewport provides the limited view upon the
    background (like a sliding window).  Its coordinates can be set
    and queried by <setViewport> and <getViewport>.

    Finally the view on the background can be put into the real
    display memory by calling <showInScreen>.  After calling this
    routine the update is automatically done during the next frame
    gap and the following line gaps.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __BACKGROUND_H
#define __BACKGROUND_H

/*========================================*/

#include <gbextended/screen.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

typedef UINT8 Background_TileCoordinate;
  /** a tile coordinate is an eight-bit integer */


typedef struct {
  Background_TileCoordinate row;
  Background_TileCoordinate column;
} Background_TilePosition;
  /** the coordinates of a tile within the background */


typedef struct {
  UINT8 deltaX;
  UINT8 deltaY;
} Background_PixelOffset;
  /** the relative offsets in pixels within a tile; each offset is
      within [0,..,7] on the GameBoy */


typedef void (*Background_UpdateProc) (
		readonly Background_TilePosition *upperLeftCorner,
	        readonly Background_TilePosition *lowerRightCorner,
		readonly Background_TilePosition *upperLeftCornerInViewport,
		in Background_TileCoordinate tilesPerHWBufferRow,
		out Tile_Type *tileList,
		out Tile_Attribute *attributeList);
  /** callback function type used for selectively updating the
      background; it updates the viewport tiles <tileList> and
      attributes <attributeList> starting at
      <upperLeftCornerInViewport>; the background made visible in this
      viewport area goes from <upperLeftCorner> to and including
      <lowerRightCorner>; <tilesPerHWBufferRow> tells of how many
      tiles a row in the viewport tile list consists (this should
      match the real hardware display row size) */


extern UINT8 Background_tilesPerRow;
  /** number of tiles per row in background */

extern UINT8 Background_tilesPerColumn;
  /** number of tiles per column in background */


/*========================================*/

void Background_initialize (void);
  /** initializes the background module data; must be called before
      any other routines in this module */

/*--------------------*/

void Background_finalize (void);
  /** cleans up the internal module data; should be called after any
      other routines in this module */

/*--------------------*/

void Background_showLayer (void);
  /** turns on the background layer */

/*--------------------*/

void Background_hideLayer (void);
  /** turns off the background layer */

/*--------------------*/

void Background_define (readonly Background_TilePosition *lowerRightCorner,
			in Boolean columnsAreCircular,
			in Boolean rowsAreCircular,
			in Background_UpdateProc updateProc);
  /** defines the current background to consist of tiles indexed by
      (0,0)..<lowerRightCorner>; <rowsAreCircular> tells whether there
      is no boundary after the last row and the first row follows
      directly (and vice versa); <columnsAreCircular> is similar for
      columns; <updateProc> is called whenever some tiles have to be
      redrawn; it is handed over the top left corner and the bottom
      right corner as incoming parameters and expects a list of tile
      numbers and attributes as result parameters
  */

/*--------------------*/

void Background_getViewport (out Background_TilePosition *upperLeftCorner,
			     out Background_TilePosition *diagonalVector,
			     out Background_PixelOffset *pixelOffset);
  /** returns rectangle of all visible tiles in viewport; this is
      returned via <upperLeftCorner> and the tile offset
      <diagonalVector> (giving the dimensions of the viewport); the
      relative offset within the tiles is returned in <pixelOffset> */

/*--------------------*/

void Background_setViewport (
		     readonly Background_TilePosition *upperLeftCorner,
		     readonly Background_PixelOffset *pixelOffset);
  /** sets viewport such that upper left corner is showing tile with
      coordinate <upperLeftCorner> and uses offset <pixelOffset>
      within the tile */

/*--------------------*/

void Background_lastCorner (out Background_TilePosition *tilePosition);
  /** tells the bottommost and rightmost <tilePosition> to be used as
      the upper left coordinate for the viewport */

/*--------------------*/

void Background_showInScreen (void);
  /** waits for next frame gap and puts accumulated changes to current
      background into screen  */

#endif /* _BACKGROUND_H */
