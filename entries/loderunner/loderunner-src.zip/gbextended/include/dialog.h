/** Dialog module --
    This module provides all services for handling the user dialogs in
    a GameBoy game.

    A dialog makes the window layer completely cover the background to
    show some text information.  Each dialog usage is started by an
    explicit or implicit call to <open>, the some processing occurs
    and finally the dialog is dismissed by calling <close>.

    There are routines for simply showing text (<showMessage> and
    <closeMessage>), for showing a query to be answered by a joypad
    key (<showQuery>) and for showing choice lists possibly with
    subitems (<showChoice> and <showCascadedChoice>).

    Choice lists with subitems are handled by callback routines for
    joypad key handling.  Those routines change the displayed subitem
    and tell whether the subitem-specific handling is completed.

    Original version by Thomas Tensi, 2005-07
*/

#ifndef __DIALOG_H
#define __DIALOG_H

/*========================================*/

#include <gbextended/joypad.h>
#include <gbextended/string.h>
#include <gbextended/types.h>

/*========================================*/

#define Dialog_noSelection 128
  /** value returned when no selection was done in a choice list
      subitem */

typedef enum { Dialog_ItemResult_processing, Dialog_ItemResult_done,
	       Dialog_ItemResult_breakingOut } Dialog_ItemResult;
  /** result an item routine may have: the processing may still be
      going on, it may be done or the processing of the complete
      dialog can be terminated and the index of this item will be
      returned */

typedef Dialog_ItemResult (*Dialog_ItemRoutine)(in Joypad_Key key,
						inout String_Type *value);
  /** callback routine for subitem handling in a dialog; the <key>
      pressed on the joypad is provided and the routine returns string
      <value> as the current subitem setting and a choice result,
      whether item processing is ongoing, completed or breaking out of
      the dialog */

/*========================================*/

void Dialog_initialize (void);
  /** initializes the dialog manager data; must be called before any
      other routines in this module */

/*--------------------*/

void Dialog_finalize (void);
  /** cleans up the internal dialog manager data; should be called
      after any other routines in this module */

/*--------------------*/

void Dialog_open (void);
  /** sets up a dialog window; further information can be put out via
      calls to <Window> routines */

/*--------------------*/

void Dialog_close (void);
  /** dismisses a dialog window */

/*--------------------*/

void Dialog_showMessage (in String_Type message);
  /** shows dialog window containing <message>, but continues
      processing; does an implicit <open> */

/*--------------------*/

void Dialog_closeMessage (in String_Type continuationMessage,
			  in Joypad_KeySet continuationButtonSet);
  /** asks user to press one button from set <continuationButtonSet>
      via <continuationMessage> to discard currently open dialog; does
      an implicit <close> */

/*--------------------*/

Joypad_Key Dialog_showQuery (in String_Type message);
  /** shows <message> as query, waits for a joypad key press and
      returns the key pressed */

/*--------------------*/

UINT8 Dialog_showChoice (in String_Type message,
			 in String_List choiceList);
  /** asks the user to select one of the choices in <choiceList> via
      the A button; <choiceList> is a NULL-terminated string list;
      <message> is the title (which cannot be selected); the dialog
      can be discarded via the B button or via selecting the final
      "back" choice, which returns a <noSelection> result; does both
      an implicit <open> and <close> */

/*--------------------*/

UINT8 Dialog_showCascadedChoice (in String_Type message,
				 in String_List prefixList,
				 in Dialog_ItemRoutine routineList[],
				 inout String_List selectionList);
  /** shows dialog window to change parameter items (typically for
      setups); <message> gives the lead-in text (which cannot be
      selected), each parameter is introduced by a string in the
      <prefixList>; <routineList> is an array of routine pointers
      which handle any keypresses within a specific item;
      <selectionList> gives the initial and final values as a string
      pointer per item; if a specific element of <choiceRoutineList>
      is NULL, then no subitems can be selected for the given item:
      any selection terminate this routine and return the position of
      this item */


#endif /* __DIALOG_H */
