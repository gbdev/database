/** Sound module --
    This module provides all services for for playing
    melodies or noises in a GameBoy game.

    A melody is a sequence of sound events.  An event consists of some
    MIDI pitch (from 0 to 127), a volume (from 0 to 15) and a channel
    (from 0 to 2).  Channels 0 and 1 are melody channels, channel 2 is
    the drum channel.  Note that the drum channel uses the sample
    hardware channel for drum sounds and the noise hardware channel of
    the Gameboy for cymbals.

    Each event has some delta time relative to the previous event.
    This delta time is given as a multiple of the frame interval
    (1/60th of a second).  0 is an acceptable value which means that
    events with such a delta time are synchronous.

    As in MIDI a note is modelled by an on-event and some later
    off-event (with volume 0).

    All sound processing is done within the frame gap (by the routine
    <handleTickEvent>.  Here events which have been put into the event
    queue earlier (by the routine <putEventInQueue>) are put out to
    hardware.

    Since the event queue only stores a limited number of events, its
    capacity can be queried by the routine <slotsInEventQueue>.

    The playback of events can be started and stopped at any time via
    <startMusic> and <stopMusic>.

    Original version by Thomas Tensi, 2005-09
*/

#ifndef __SOUND_H
#define __SOUND_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

#define Sound_maxSlotsInEventQueue 63
  /** maximum number of free slots in sound event queue;
      is equal to $2^n - 1$ for some n */

typedef UINT8 Sound_Pitch;
  /** MIDI pitch from 0 to 127 */
typedef UINT8 Sound_Volume;
  /** the volume has a value from 0 (silent) to 15 (loud) */
typedef UINT8 Sound_Channel;
  /** value from 0 to 3 */

typedef struct {
  Sound_Channel channel;
  Sound_Volume volume;
  Sound_Pitch pitch;
} Sound_Event;
  /** an event consists of a channel, pitch and volume */

typedef UINT16 Sound_DeltaTime;
  /** the delta time is the time in frames divided by some time
      scaling factor; it is used for giving a time difference between
      events in a sequence */

/*========================================*/

void Sound_initialize (void);
  /** initializes the internal sound data; must be called before any other
      routines in this module */

/*--------------------*/

void Sound_finalize (void);
  /** cleans up the internal sound data; should be called after any
      other routines in this module */

/*--------------------*/

void Sound_setFlags (in Boolean musicIsOn, in Boolean soundsAreOn);
  /** enables or disables the music depending on <musicIsOn> and the
      game sounds depending on <soundsAreOn> */

/*--------------------*/

void Sound_startMusic (in UINT8 timeScale);
  /** starts or restarts processing of the sound event list which is
      filled by calls to <putEventInQueue>; <timeScale> tells how many
      frames are in one time unit used by the event sequence */

/*--------------------*/

void Sound_stopMusic (void);
  /** stops processing the current sound event list and stops any
      pending sounds */

/*--------------------*/

void Sound_handleTickEvent (void);
  /** does all sound-related actions when a new frame has occured */

/*--------------------*/

UINT8 Sound_slotsInEventQueue (void);
  /** returns number of currently free slots in event queue */

/*--------------------*/

void Sound_putEventInQueue (in Sound_DeltaTime deltaTime,
			    readonly Sound_Event *event);
  /** adds <event> which is due <deltaTime> ticks after the previous
      event */

#endif /* __SOUND_H */
