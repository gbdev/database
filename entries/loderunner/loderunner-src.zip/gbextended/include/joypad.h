/** Joypad module --
    This module provides all services for querying the user input
    via the GameBoy joypad.

    There are routines for getting a single or multiple keys pressed
    (<getKeyPressed>, <getKeysPressed>), waiting for a set of keys
    (<waitForAllKeys>), no key (<waitForNoKey>) and some specific key
    (<waitForSomeKey>).

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __JOYPAD_H
#define __JOYPAD_H

#include <gbextended/types.h>

/*========================================*/

typedef UINT8 Joypad_Key;
  /** a single key on the joypad */

#define	Joypad_Key_start      7
#define	Joypad_Key_select     6
#define	Joypad_Key_b          5
#define	Joypad_Key_a          4
#define	Joypad_Key_down       3
#define	Joypad_Key_up         2
#define	Joypad_Key_left       1
#define	Joypad_Key_right      0
  /** all keys of a GameBoy as constants */

typedef UINT8 Joypad_KeySet;
  /** a set of multiple joypad keys */

/*========================================*/

void Joypad_initialize (void);
  /** initializes the joypad and the internal representation of it;
      must be called before any other routines in this module */

/*--------------------*/

void Joypad_finalize (void);
  /** cleans up the internal representation of the joypad; should be
      called after any other routines in this module */

/*--------------------*/

Boolean Joypad_getKeyPressed (out Joypad_Key *key);
  /** reads and returns the lowest ranked pressed key of the joypad; if
      none is pressed, the routine returns false */

/*--------------------*/

Joypad_KeySet Joypad_getKeysPressed (void);
  /** reads and returns all keys pressed on the joypad (if any) */

/*--------------------*/

UINT8 Joypad_waitForAllKeys (in Joypad_KeySet keySet);
  /** waits until all the keys given in <keySet> are pressed; normally
      only used for checking one key, but it will support many, even
      <Key_left> at the same time as <Key_right> :) */

/*--------------------*/

void Joypad_waitForNoKey (void);
  /** waits for all buttons (including cursors) to be released */

/*--------------------*/

void Joypad_waitForSomeKey (out Joypad_Key *key);
  /** reads and returns the lowest ranked pressed key of the joypad;
      waits that all keys are released first and returns the first
      pressed */

#endif /* __JOYPAD_H */
