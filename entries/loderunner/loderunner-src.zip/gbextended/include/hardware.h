/** Hardware module --
    This module provides all services encapsulating the
    hardware layer of the GameBoy.

    It deals with the sound channels, the background, interrupt
    handling and the timer.  Typically those services are later
    abstracted by other modules.

    Original version by Thomas Tensi, 2005-10
*/

#ifndef __GBHARDWARE_H
#define __GBHARDWARE_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

#define Hardware_tilesPerBufferRow 32
  /** number of tiles per row in the hardware display buffer of the
      Gameboy */

typedef UINT8 Hardware_MIDIPitch;
  /** the frequency of a sound given as a MIDI integer */

typedef UINT32 Hardware_TimeType;
  /** absolute time [in frames] within the Gameboy; reset to 0 at the
      beginning of the program */

/*========================================*/

void Hardware_initialize (void);
  /** initializes the hardware layer data; must be called before any
      other routines in this module */

/*--------------------*/

void Hardware_finalize (void);
  /** cleans up the internal hardware layer data; should be called
      after any other routines in this module */

/*--------------------*/

void Hardware_Bkg_show (void);
  /** turns on the background layer*/

/*--------------------*/

void Hardware_Bkg_hide (void);
  /** turns off the background layer*/

/*--------------------*/

void Hardware_Bkg_move (in UINT8 deltaX, in UINT8 deltaY);
  /** sets offset over screen background tilebuffer to <deltaX> and
      <deltaY> pixels; also updates sprites buffered so far */

/*--------------------*/

void Hardware_Bkg_updateAttribs (in void *attributeBuffer);
  /** updates screen background attributes from <attributeBuffer> */

/*--------------------*/

void Hardware_Bkg_updateTiles (in void *tileBuffer);
  /** updates screen background tiles from <tileBuffer> */

/*--------------------*/

void Hardware_Interrupts_disable (void);
  /** disables any interrupts */

/*--------------------*/

void Hardware_Interrupts_enable (void);
  /** enables all interrupts */

/*--------------------*/

void Hardware_Sound_play (in UINT8 channel, in Hardware_MIDIPitch pitch,
			  in UINT8 volume);
  /** plays note with <volume> and <pitch> on <channel> */

/*--------------------*/

void Hardware_Sound_enable (void);
  /** activates sound output */

/*--------------------*/

void Hardware_Sound_disable (void);
  /** deactivates sound and stops any sound immediately */

/*--------------------*/

void Hardware_Timer_get (out Hardware_TimeType *currentTime);
  /** reads absolute time [in frames] into <currentTime> */

#endif /* __GBHARDWARE_H */
