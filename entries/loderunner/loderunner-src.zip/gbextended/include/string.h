/** String module --
    This module provides all services for handling strings in a
    GameBoy game.

    Apart from a renaming of standard string routines there is an
    additional service for replacing a pattern within a string and
    serializing a multilevel list structure.

    Original version by Thomas Tensi, 2006-02
*/

#ifndef __MYSTRING_H
#define __MYSTRING_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

#define String_terminator       '\0'

typedef char *String_Type;
  /** a character string, terminated with <terminator> */

typedef String_Type String_List[];
  /** a list of strings, NULL-terminated */

#define String_notFound (0xFFFF)

/*--------------------*/

void String_initialize (void);
  /** initializes the string module; must be called before any other
      routines in this module */

/*--------------------*/

void String_finalize (void);
  /** cleans up the internal string module data; should be called
      after any other routines in this module */

/*--------------------*/

void String_boundedCopy (out String_Type destination,
			 in String_Type source,
			 in UINT16 maxSize);
  /** copies contents of <source> into <destination> up to and
      including terminator, but at most <maxSize>-1 characters */

/*--------------------*/

void String_concatenate (inout String_Type destination,
			 in String_Type otherString,
			 in UINT16 maxSize);
  /** concatenates contents of <otherString> to <destination>; if
      capacity <maxSize> of <destination> is not enough, the
      concatenation is truncated */

/*--------------------*/

UINT16 String_findCharacter (in String_Type st, in char ch);
  /** locates <ch> in <st> and returns its position; when <ch> does
      not occur, <notFound> is returned */

/*--------------------*/

UINT16 String_findInList (in String_Type st, in String_List stringList);
  /** finds position of <st> in <stringList>; if <st> is not found,
      <notFound> is returned; note that the lookup is by reference,
      not by value! */

/*--------------------*/

void String_globalReplace (inout String_Type st, in String_Type pattern,
			   in String_Type replacement, in UINT16 maxSize);
  /** replaces all occurrences of <pattern> in <st> by <replacement>; if
      size exceeds <maxSize>, an error occurs */

/*--------------------*/

UINT16 String_length (in String_Type st);
  /** returns length of string <st> */

/*--------------------*/

void String_makeFromInteger (in INT16 value, out String_Type st,
			     in UINT8 base);
  /** puts representation of <value> in <base> into <st> */

/*--------------------*/

void String_memoryMove (inout String_Type destination,
			in String_Type source, in UINT16 size);
  /** copies <size> bytes from <source> to <destination> */

/*--------------------*/

void *String_serialize (in void *destination, in void *source,
			in Boolean hasStringLeafs,
			in UINT16 leafSize,
			in UINT8 indirectionLevel,
			inout UINT16 *remainingSize);
  /** copies contents of <source> into <destination>; <hasStringLeafs>
      tells whether the atomic information in this structure is
      NUL-terminated strings (as opposed to equally sized structures
      whose size is then given by <leafSize>); <indirectionLevel>
      tells what dimension the information has (when 0 both are
      atomic, for 1 both are lists of atoms etc.); the first
      unused position within destination is returned as the result of
      the routine; if <remainingSize> bytes is not enough to store all
      serialized information, NULL is returned as the serialization
      result */

/*--------------------*/

void String_setMemory (inout String_Type destination, in char value,
		       in UINT16 size);
  /** fills <size> bytes in memory starting at <destination> with
      <value> */

#endif /* __MYSTRING_H */
