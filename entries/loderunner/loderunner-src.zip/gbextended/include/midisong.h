/** MidiSong module --
    This module provides all services for playing
    a MIDI song with multiple tracks in a GameBoy game.

    As the name implies a MIDI song has properties similar to a MIDI
    sequencer song: it consists of parallel tracks containing musical
    events.

    A GameBoy MIDI song consists of at most three tracks: two melody
    tracks and one drum track.

    The melody tracks have to be monophonic and each one uses one
    sound channel of the GameBoy.  The drum track may have a white
    noise sound (like a cymbal) and a tonal sound (like a drum beat)
    in parallel, since it uses two output channels on the GameBoy.

    Each track is a list of parts, where each part may occur multiple
    times.  This is handy because normally a song has some repetitions
    in it.  The module allows the parts in different tracks to be
    different (e.g. when a bass repeats its main ostinato while the
    guitar plays a solo), but typically the start times of parts will
    be the same across different tracks.

    A part is a list of sound events.  As in MIDI files there are two
    events per note, a note-on event and a note-off event.  Since we
    also allow a volume of zero for a note, that kind of event is used
    as a note-off.

    Note that there is a companion program 'midiToGameBoy' which
    converts an appropriately structured midi-file into an
    include-file for use with this module.  More details can be
    found in the documentation of that program.

    Original version by Thomas Tensi, 2006-03
*/

#ifndef __MIDISONG_H
#define __MIDISONG_H

/*========================================*/

#include <gbextended/types.h>
#include <gbextended/sound.h>

/*========================================*/

typedef UINT8 MidiSong_EventData;
  /** events are represented as sequences of bytes */

typedef MidiSong_EventData *MidiSong_Part;
  /** a part is a list of bytes representing events */

typedef MidiSong_Part *MidiSong_Track;
  /** a track is a list of parts */

typedef UINT8 MidiSong_TrackKind;
  /** a type to distinguish the three kinds of Midi tracks for a
      GameBoy */

#define MidiSong_TrackKind_melody1 1
#define MidiSong_TrackKind_melody2 2
#define MidiSong_TrackKind_drums   3
  /** the different track kinds as constants */

/*========================================*/

void MidiSong_initialize (void);
  /** resets internal data for an empty song; must be called before
      any other routines in this module */

/*--------------------*/

void MidiSong_finalize (void);
  /** cleans up internal data; should be called after any other
      routines in this module */

/*--------------------*/

void MidiSong_reset (void);
  /** resets event pointer to start of song */

/*--------------------*/

void MidiSong_setTrack (in MidiSong_TrackKind trackKind,
			in MidiSong_Track partList);
  /** sets track specified by <trackKind> to contain the events in
      <partList>*/

/*--------------------*/

void MidiSong_getNextEvent (out Sound_DeltaTime *deltaTime,
			    out Sound_Event *event,
			    out Boolean *isDone);
  /** returns in <event> the next event of song for all active tracks
      (by merging all track event lists); the time offset to this
      event is returned in <deltaTime>; <isDone> tells that no further
      event occurs in song */


#endif /* __MIDISONG_H */
