/** Window module --
    This module provides all services for handling the window layer
    of a GameBoy Color.

    The window shown contains text and may have an automatic
    one-character border.  There are several services available: to
    clear the window (<clear>), to put text (<writeString>,
    <writeChar>) or numbers (<writeCard>, <writeInt>) into the window.
    <gotoXY> positions the cursor on (x,y).

    In general all write routines wrap around when the last cursor
    column is reached where the last column is dependent on whether
    the window has a border.

    Original version by Thomas Tensi, 2004-11
*/

#ifndef __WINDOW_H
#define __WINDOW_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

void Window_initialize (void);
  /** initializes the window data; must be called before any other
      routines in this module */

/*--------------------*/

void Window_finalize (void);
  /** cleans up the internal window data; should be called after any
      other routines in this module */

/*--------------------*/

void Window_showLayer (void);
  /** turns on the window layer*/

/*--------------------*/

void Window_hideLayer (void);
  /** turns off the window layer*/

/*--------------------*/

void Window_clear (in Boolean borderIsEnabled);
  /** clears contents of window and draws border when
      <borderIsEnabled>; sets cursor to left upper corner of window or
      the pane inside the border (if any) */

/*--------------------*/

void Window_clearLine (void);
  /** clears line starting from cursor position (except for the
      border, if any) */

/*--------------------*/

void Window_gotoRowColumn (in UINT8 row, in UINT8 column);
  /** sets cursor to given position of window (where (0,0) denotes the
      upper left corner); note that a border occupies the first and
      last columns and rows */

/*--------------------*/

void Window_writeLine (void);
  /** prints new line in window at the current cursor position */

/*--------------------*/

void Window_writeChar (in char ch);
  /** prints <ch> in window at the current cursor position */

/*--------------------*/

void Window_writeString (in char *st);
  /** prints string <st> in window at the current cursor position */

/*--------------------*/

void Window_writeCard (in UINT16 u);
  /** prints <u> in window at the current cursor position formatted
      with a minimum number of digits */

/*--------------------*/

void Window_writeInt (in INT16 i);
  /** prints <i> in window at the current cursor position formatted
      with a minimum number of digits */

#endif /* __WINDOW_H */
