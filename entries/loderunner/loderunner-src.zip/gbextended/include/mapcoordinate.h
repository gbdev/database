/** MapCoordinate module --
    This module provides all services for handling the user
    coordinates on a map of a GameBoy game.

    A coordinate is a word and consists of a fractional and integer
    part.  To make sure that coordinates can easily be divided by two
    and three without remainder not all bits for a fraction are used.
    This makes arithmetic for coordinates a bit more complicated.
    Hence the module offers routines to add and subtract coordinates
    and multiply them by a power of two.

    Coordinate pairs (typically used as point positions within the map
    plane) are supported with additional routines.  Also rectangles
    have routines in this module.

    Original version by Thomas Tensi, 2005-05
*/

#ifndef __MAPCOORDINATE_H
#define __MAPCOORDINATE_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

typedef INT16 MapCoordinate_Type;
  /** one dimension of the position of something on the map (a fixed
      point number with subunits) */

typedef INT16 MapCoordinate_IntegerPart;
  /** the integer part of a map coordinate */

typedef UINT8 MapCoordinate_FractionalPart;
  /** the fractional part of a map coordinate */

typedef struct {
  MapCoordinate_Type x;
  MapCoordinate_Type y;
} MapCoordinate_Vector;
  /** a position on a map (a pair of coordinates) */

typedef struct {
  MapCoordinate_Vector upperLeftCorner;
  MapCoordinate_Vector diagonalVector;
} MapCoordinate_Rectangle;
  /** a rectangle described by its upper left corner (which is
      contained in the rectangle unless it is empty) and the diagonal
      vector which gives the width and height in map dimensions; for a
      null diagonal vector the rectangle is empty */

typedef union {
  MapCoordinate_Vector vector;
  MapCoordinate_Type array[2];
} MapCoordinate_VectorArrayUnion;
  /** a converter type for map coordinates between cartesian
      representation with x and y fields and representation as an
      array of coordinates */

/*--------------------*/

extern MapCoordinate_Vector MapCoordinate_unitVectorX;
extern MapCoordinate_Vector MapCoordinate_unitVectorY;
extern MapCoordinate_Vector MapCoordinate_unitVector;
extern MapCoordinate_Vector MapCoordinate_halfCellVector;

#define MapCoordinate_unit 0x10
  /** the unit of map coordinates */

#define MapCoordinate_subunitCount (12U)
  /* the number of subunits a raster position has */

/*========================================*/

void MapCoordinate_initialize (void);
  /** initializes the internal data; must be called before any other
      routines in this module */

/*--------------------*/

void MapCoordinate_finalize (void);
  /** cleans up the internal data; should be called after any other
      routines in this module */

/*--------------------*/

MapCoordinate_IntegerPart MapCoordinate_integerPart (in MapCoordinate_Type c);
  /** extracts the integer part of a coordinate */

/*--------------------*/

MapCoordinate_FractionalPart MapCoordinate_fractionalPart (
					   in MapCoordinate_Type c);
  /** extracts the fractional part of a coordinate */

/*--------------------*/

MapCoordinate_Type MapCoordinate_make (in MapCoordinate_IntegerPart i,
				       in MapCoordinate_FractionalPart f);
  /** makes a coordinate from integer part <i> and fractional part <f> */

/*--------------------*/

MapCoordinate_Type MapCoordinate_clearFractionalPart (in MapCoordinate_Type c);
  /** returns a coordinate with fractional part set to 0 */

/*--------------------*/

MapCoordinate_Type MapCoordinate_addOperation (in MapCoordinate_Type a,
					       in MapCoordinate_Type b,
					       in Boolean isSubtraction);
  /** depending on <isSubtraction> returns either <a>-<b> or <a>+<b> */

/*--------------------*/

MapCoordinate_Type MapCoordinate_shiftOperation (in MapCoordinate_Type a,
						 in INT8 offset);
  /** calculates $<a> * 2 ^ <offset>$ and returns result */

/*--------------------*/

void MapCoordinate_round (inout MapCoordinate_Type *coordinate);
  /** rounds <coordinate> to cell raster */

/*--------------------*/

INT8 MapCoordinate_compare (in MapCoordinate_Type a, in MapCoordinate_Type b);
/** compares <a> with <b> and returns -1 for less, 0 for equal and +1
    for greater */

/*--------------------*/

void MapCoordinate_vectorAddOp (readonly MapCoordinate_Vector *a,
				readonly MapCoordinate_Vector *b,
				in Boolean isSubtraction,
				out MapCoordinate_Vector *result);
  /** depending on <isSubtraction> return either <a>-<b> or <a>+<b> in
       <result> */

/*--------------------*/

void MapCoordinate_vectorShiftOp (readonly MapCoordinate_Vector *a,
				  in INT8 offset,
				  out MapCoordinate_Vector *result);
  /** calculates $<a> * 2 ^ <offset>$ and returns result in <result> */

/*--------------------*/

Boolean MapCoordinate_vectorIsEqual (readonly MapCoordinate_Vector *a,
				     readonly MapCoordinate_Vector *b);
  /** tells whether two coordinate vectors <a> and <b> are equal */

/*--------------------*/

Boolean MapCoordinate_isEmptyRect (readonly MapCoordinate_Rectangle *r);
  /** tells whether <r> has size 0 */

/*--------------------*/

Boolean MapCoordinate_isInRectangle (
			     readonly MapCoordinate_Rectangle *rectangle,
			     readonly MapCoordinate_Vector *position);
  /** tells whether <position> is within <rectangle> */

/*--------------------*/

void MapCoordinate_clipRectangle (
 		       readonly MapCoordinate_Rectangle *rectangleA,
		       readonly MapCoordinate_Rectangle *rectangleB,
		       out MapCoordinate_Rectangle *rectangle);
  /** returns the intersection of <rectangleA> and <rectangleB> in
      <rectangle> */

#endif /* __MAPCOORDINATE_H */

