/** Sprite module --
    This module provides all services for handling the sprites of a
    GameBoy.

    Virtual sprites are supported where multiple hardware sprites are
    combined into a larger graphics object.

    A virtual sprite is defined by reserving a certain number of
    hardware sprites via the routine <make>.  The offsets (in pixels)
    are defined in a list and set via <setOffsets>, the associated
    tiles via <setTiles>, the palettes via <setPalettes>.  Those
    routines change the properties of all associated hardware sprites
    at once.

    It is also possible to change the attributes of a single hardware
    sprite by the routines <setSubTile> and <setSubAttribute>.

    There are additional routines for a complete virtual sprite: it
    may be hidden (via <hide>), moved to an absolute screen position
    (<moveAbsolute>) or relatively (<moveRelative>).  The effective
    size of a sprite in screen pixels is available via <getSize>.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __SPRITE_H
#define __SPRITE_H

/*========================================*/

#include <gbextended/palette.h>
#include <gbextended/screen.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

#define Sprite_maxCount 32
#define Sprite_maxIndex (Sprite_maxCount - 1) 

typedef UINT8 Sprite_Type;
  /** type representing a single virtual sprite (by an integer number)
      between 0 and <Sprite_maxIndex> */

typedef struct {
  UINT8 deltaX;
  UINT8 deltaY;
} Sprite_Offset;
  /** vector type representing the offset (in pixels) of some hardware
      sprite within a virtual sprite */

/*========================================*/

void Sprite_initialize (void);
  /** initializes the sprites data; must be called before any other
      routines in this module */

/*--------------------*/

void Sprite_finalize (void);
  /** cleans up the internal sprites data; should be called after any
      other routines in this module */

/*--------------------*/

void Sprite_showLayer (void);
  /** turns on the sprites layer */

/*--------------------*/

void Sprite_hideLayer (void);
  /** turns off the sprites layer */

/*--------------------*/

Boolean Sprite_canBeMade (in UINT8 tileCount);
  /** tells whether some virtual sprite can be made using <tileCount>
      tiles (and hardware sprites) */

/*--------------------*/

Sprite_Type Sprite_make (in UINT8 tileCount);
  /** makes a virtual sprite consisting of <tileCount> hardware
      sprites of 8x8 pixels */

/*--------------------*/

void Sprite_discard (in Sprite_Type sprite);
  /** discards a virtual sprite and frees its associated hardware
      sprites */

/*--------------------*/

void Sprite_setAttributes (in Sprite_Type sprite,
			   in Tile_Attribute *attributeList);
  /** sets virtual sprite <sprite> to use attributes in
      <attributeList> for its sprite hardware tiles; note that the
      attributes may be changed anytime in the lifetime of the
      sprite */

/*--------------------*/

void Sprite_setOffsets (in Sprite_Type sprite,
			in Sprite_Offset *offsetList);
  /** sets the offsets of the individual hardware sprite tiles as
      given in <offsetList>; note that the offsets may be changed
      anytime in the lifetime of the sprite */

/*--------------------*/

void Sprite_setPalettes (in Sprite_Type sprite,
			 in Palette_Type *paletteList);
  /** sets the palettes of the individual hardware sprite tiles as
      given in <paletteList>; note that the palettes may be changed
      anytime in the lifetime of the sprite */

/*--------------------*/

void Sprite_setTiles (in Sprite_Type sprite,
		      in Tile_Type *tileList);
  /** sets virtual sprite <sprite> to display tiles in <tileList> from
      the sprite tile data; note that the tiles may be changed anytime
      in the lifetime of the sprite */

/*--------------------*/

void Sprite_setSubTile (in Sprite_Type sprite,
			in UINT8 subspriteIndex,
		        in Tile_Type tile);
  /** sets subsprite given by <subspriteIndex> (in the range 0 to
      number of tiles - 1) of virtual sprite <sprite> to display
      <tile> from the sprite tile data */

/*--------------------*/

void Sprite_setSubAttribute (in Sprite_Type sprite,
			     in UINT8 subspriteIndex,
			     in Tile_Attribute attribute);
  /** sets subsprite given by <subspriteIndex> (in the range 0 to
      number of tiles - 1) of virtual sprite <sprite> to have
      <attribute> */

/*--------------------*/

void Sprite_hide (in Sprite_Type sprite);
  /** hides virtual sprite <sprite> by moving it off screen; the
      virtual sprite is shown again, when some move to the screen
      occurs */

/*--------------------*/

void Sprite_getSize (in Sprite_Type sprite, 
		     out Screen_Coordinate *width,
		     out Screen_Coordinate *height);
  /** tells the <width> and <height> of <sprite> in pixels (which of
      course depends on its offsets) */

/*--------------------*/

void Sprite_getMaxCoordinates (in Sprite_Type sprite, 
			       out Screen_Coordinate *maxX,
			       out Screen_Coordinate *maxY);
  /** tells the maximum screen coordinates in <maxX> and <maxY> for
      <sprite> which keeps it completely visible (which of course
      depends on its size) */

/*--------------------*/

void Sprite_moveAbsolute (in Sprite_Type sprite,
			  in Screen_Coordinate x,
			  in Screen_Coordinate y);
  /** moves <sprite> to the given position (<x>,<y>) on the screen
      with its top left corner */

/*--------------------*/

void Sprite_moveRelative (in Sprite_Type sprite,
			  in INT8 deltaX, in INT8 deltaY);
  /** moves <sprite> relative to its current position by
      (<deltaX>,<deltaY>) screen pixels */

#endif /* __SPRITE_H */
