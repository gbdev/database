/** MapAnimation module --
    This module provides all services for generically handling
    animations on the map of a GameBoy game.

    A map animation describes what kind of map objects are displayed
    at a specific map position.  More precisely it is a schedule of
    single phases, where each phase consists of a negative or zero
    start time (in frames) and a single map object to be displayed
    during this phase.

    Within a schedule the phase start times must be strictly
    increasing and the schedule ends with the phase with start time
    zero.  That associated object is displayed permanently at the map
    position after the animation schedule has been processed.

    Original version by Thomas Tensi, 2005-08
*/

#ifndef __MAPANIMATION_H
#define __MAPANIMATION_H

/*========================================*/

#include <gbextended/map.h>
#include <gbextended/types.h>

/*========================================*/

typedef struct {
  INT16 startTime;
  Map_ObjectKind kind;
} MapAnimation_Phase;
  /** tells at what <startTime> which <kind> of map object will be
      shown on some animated map position (where time is counted
      up towards zero) */

typedef MapAnimation_Phase *MapAnimation_Schedule;
  /** a list of phases with increasing start times and the last phase
      marked by a start time of zero */

/*========================================*/

void MapAnimation_initialize (void);
  /** initializes the map animation data; must be called before any
      other routines in this module */

/*--------------------*/

void MapAnimation_finalize (void);
  /** cleans up the internal map animation data; should be called
      after any other routines in this module */

/*--------------------*/

void MapAnimation_reset (void);
  /** resets all pending map animations (e.g. when a new level has
      been loaded) */

/*--------------------*/

void MapAnimation_handleTickEvent (void);
  /** animates map cells at a frame change */

/*--------------------*/

void MapAnimation_start (readonly Map_Position *position,
			 in MapAnimation_Schedule schedule);
  /** starts animation at <position> with animation schedule <schedule> */

#endif /* __MAPANIMATION_H */
