/** Matrix module --
    This module provides all services for handling matrices
    of elements in a GameBoy game.

    A matrix is a rectangular structure of elements with a specific
    row and column count.  Since multiplication is expensive on the
    GameBoy a matrix is represented technically as a list of pointers
    to all rows (terminated with a NULL-pointer) followed by the
    elements of each row column by column.

    Original version by Thomas Tensi, 2006-06
*/

#ifndef __MATRIX_H
#define __MATRIX_H


#define Matrix_size(rowCount, columnCount, ElementType) \
  ((rowCount + 1) * sizeof(ElementType *)\
    + (rowCount) * (columnCount) * sizeof(ElementType))
  /** calculates the size of a matrix in bytes based on <rowCount>,
      <columnCount> and <ElementType> */


#define Matrix_get(m, row, column)    (m[row][column])
  /** returns the element in matrix <m> at (<row>,<column>) */


#define Matrix_set(m, row, column, value)  \
  do { char *ptr = m[row];  ptr[column * sizeof(value)] = value; } while (0)
  /** sets the element in matrix <m> at (<row>,<column>) to <value> */


#endif /* __MATRIX_H */
