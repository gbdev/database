/** Assertion module --
    This module provides all services for handling pre- and
    postconditions of routines.

    The kind of reaction when an assertion fails is implementation
    dependent.  At least the message should be visible in some form.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __ASSERTION_H
#define __ASSERTION_H

#include <gbextended/types.h>

void Assertion_PRE (in Boolean condition, in char *procName,
		    in char *message);
  /** checks whether precondition <condition> in routine <procName> is
      violated;  if it is, <message> is put out */

void Assertion_POST (in Boolean condition, in char *procName,
		     in char *message);
  /** checks whether postcondition <condition> in routine <procName>
      is violated;  if it is, <message> is put out */

void Assertion_DEBUG (in Boolean condition, in char *procName,
		      in char *message);
  /** checks whether integrity condition <condition> in routine
      <procName> is violated;  if it is, <message> is put out */

#endif  /* __ASSERTION_H */
