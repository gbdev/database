/** SpriteAnimation module --
    This module provides services for handling the sprite
    animations of a GameBoy Color.

    A sprite animation is defined for a virtual sprite.  It consists
    of a schedule of simple animation phases. Each phase contains a
    list of tiles, tile attributes and offsets for each hardware
    sprites within the virtual sprite and the time in frames how long
    this will be shown within the schedule.

    A schedule is simply a list of those phases (with a leading count
    of phases).  Once all phases are done, the animation starts again
    at the first phase.

    The sprite animation is started by assigning a schedule to a
    virtual sprite to (via <setSchedule>), but the update upon each
    frame change must be explicitely requested by <handleTickEvent>.
    This routine is called per sprite, since it is normally quite
    expensive.

    When the animation has to be paused for some reason, this can be
    achieved by a call to <setState>.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __SPRITEANIMATION_H
#define __SPRITEANIMATION_H

/*========================================*/

#include <gbextended/sprite.h>
#include <gbextended/tile.h>
#include <gbextended/types.h>

/*========================================*/

typedef struct {
  UINT8 duration;
  Tile_Type *tileList;
  Tile_Attribute *attributeList;
  Sprite_Offset *offsetList;
} SpriteAnimation_Phase;


typedef struct {
  UINT8 phaseCount;
  SpriteAnimation_Phase *phaseList;
} SpriteAnimation_Schedule;


/*========================================*/

void SpriteAnimation_initialize (void);
  /** initializes the internal sprite animation data; must be called
      before any other routines in this module */

/*--------------------*/

void SpriteAnimation_finalize (void);
  /** cleans up the internal sprite animation data; should be called
      after any other routines in this module */

/*--------------------*/

void SpriteAnimation_setSchedule (in Sprite_Type sprite,
				  in SpriteAnimation_Schedule *schedule,
				  in Boolean scheduleIsRestarted);
  /** sets <schedule> for animation of <sprite>; if it is a new
      schedule or <scheduleIsRestarted> is true, it starts at the first
      frame */

/*--------------------*/

void SpriteAnimation_setState (in Sprite_Type sprite,
			       in Boolean isPaused);
  /** pauses or continues the animation for <sprite> */

/*--------------------*/

void SpriteAnimation_handleTickEvent (in Sprite_Type sprite);
  /** tells animation for <sprite> that another frame has occured */

/*--------------------*/

void SpriteAnimation_stopAll (void);
  /** stops all animations for sprites */

#endif /* __SPRITEANIMATION_H */

