/** Map module --
    This module provides all services for handling the map of a
    GameBoy game. It provides a generic map to be extended by a
    concrete map.

    A map is rectangular and consists of a certain number of columns
    and rows of equally sized cells.  Each cell contains some map
    object which is only characterized by an object kind (an
    enumeration type). It can also specified whether the map is a
    bounded plane, a cylinder or a torus.

    There are services to query and set the cells individually or to
    mass load a complete level to the map.  It is also possible to
    iterate over the map to find specific object kinds or to replace
    one object kind by another (e.g.~to get the initial coordinates of
    moving objects and replace them by empty cells).

    Original version by Thomas Tensi, 2005-08
*/

#ifndef __MAP_H
#define __MAP_H

/*========================================*/

#include <gbextended/types.h>
#include <gbextended/mapcoordinate.h>

/*========================================*/

typedef MapCoordinate_Vector Map_Position;
  /** a position on the map, described by a coordinate pair */

typedef UINT8 Map_ObjectKind;
  /** enumeration type for the kinds of objects on the map */

typedef void (*Map_ObserverProc) (readonly Map_Position *);
  /** type representing a callback procedure which gets notified when
      the static map at position (x,y) changes; the position is given
      as a parameter of the callback procedure */

typedef void (*Map_ObjectKindMapProc) (inout Map_ObjectKind *);
  /** type representing a callback procedure which maps one object kind
      to another (e.g. when an abstraction for the kind of
      object is needed which ignores some specific state) */

/*--------------------*/

extern MapCoordinate_Rectangle Map_boundingBox;

/*========================================*/

void Map_initialize (void);
  /** initializes the abstract map data; must be called before
      any other routines in this module */

/*--------------------*/

void Map_finalize (void);
  /** cleans up the internal abstract map data; should be called after
      any other routines in this module */

/*--------------------*/

void Map_define (in MapCoordinate_IntegerPart columnCount,
		 in MapCoordinate_IntegerPart rowCount,
		 in Boolean columnsAreCircular,
		 in Boolean rowsAreCircular,
		 in Map_ObjectKind *objectKindsInMap,
		 in Map_ObjectKind **data,
		 in Map_ObjectKindMapProc objectKindAbstractionProc);
  /** defines the map by its relevant information: the number of
      columns in <columnCount>, the number of rows in <rowCount>;
      <columnsAreCircular> and <rowsAreCircular> tell whether the map
      wraps around in horizontal or vertical direction; the list of
      allowed object kinds in the map is given as <objectKindsInMap>;
      the container for the map data is specified by <data> which
      contains the objects in row major order (with an initial
      NULL-terminated list of row pointers); the abstraction routine
      to map object kinds onto their canonical object kind is given as
      <objectKindAbstractionProc> (note that NULL is okay for an
      abstraction proc which means that the identity mapping is
      performed) */

/*--------------------*/

void Map_getProperties (out MapCoordinate_IntegerPart *columnCount,
			out MapCoordinate_IntegerPart *rowCount,
			out Boolean *columnsAreCircular,
			out Boolean *rowsAreCircular,
			out Map_ObjectKind **objectKindsInMap);
  /** returns the number of cell columns in <columnCount>, cell rows
      in <rowCount>, the fact whether the map is circular in x- or
      y-dimension in <columnsAreCircular> and <rowsAreCircular> and
      the list of object kinds in the map in <objectKindsInMap> */

/*--------------------*/

void Map_setObserver (in Map_ObserverProc observerProc);
  /** sets the routine to be called whenever some information is
      changed in static map to <observerProc>; there may currently be
      only one observer for the map */

/*--------------------*/

Map_ObjectKind Map_getEntry (readonly Map_Position *position);
  /** gets object kind of object at <position>, but maps the object
      kind at that position by the object abstration proc for the map;
      any fractional parts in position are ignored; positions outside
      of the map return the NUL character */

/*--------------------*/

Map_ObjectKind Map_getEntryWithState (readonly Map_Position *position);
  /** gets object kind of object at <position> and together with its
      state; any fractional parts in position are ignored */

/*--------------------*/

void Map_setEntry (readonly Map_Position *position,
		   in Map_ObjectKind objectKind);
  /** sets single entry at <position> to <objectKind>; this should
      only be used for nonmoving object kinds; any fractional parts in
      position are ignored */

/*--------------------*/

void Map_globalReplaceInMap (in Map_ObjectKind o,
			     in Map_ObjectKind replacement,
			     in Boolean observerIsUpdated);
  /** replaces all occurences of object kind <o> by <replacement> in
      static map; if <observerIsUpdated> is true, then every change is
      reflected in the observer */

/*--------------------*/

void Map_handleTickEvent (void);
  /** does all actions when a new frame has occured (e.g. the
      animations on map) */

/*--------------------*/

void Map_adjustToCorrectPosition (inout Map_Position *position);
  /** adjusts <position> such that it lies within map coordinate
      range; for circular dimensions the position is adjusted to the
      range [0..size[ */

/*--------------------*/

void Map_resetPositionIterator (in Map_ObjectKind kind);
  /** resets iterator to return only positions of objects of <kind> */

/*--------------------*/

Boolean Map_getNextPosition (out Map_Position *position);
  /** returns next position for kind defined by
      <resetPositionIterator>; returns false, when no such new
      position exists */

#endif /* __MAP_H */

