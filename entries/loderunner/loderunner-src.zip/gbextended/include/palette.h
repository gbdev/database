/** Palette module --
    This module provides all services for handling the colour palettes
    of a GameBoy Color.

    A palette is a number which is an index into a table of colour
    tuples.  Each bitmap has some palette assigned to it, which tells
    how the numeric pixel values are mapped into RGB colours.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __PALETTE_H
#define __PALETTE_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

typedef UINT8 Palette_Type;
  /** index into one of eight four colour palettes in the GameBoy */

typedef UINT16 Palette_Colour;
  /** an RGB colour */

typedef Palette_Colour Palette_Data[4];
  /** a tuple of four colours is the data for a palette on the GameBoy */

#define Palette_makeRGBColour(r, g, b) \
  ((((UINT16)(b) & 0x1f) << 10) | (((UINT16)(g) & 0x1f) << 5) | (((UINT16)(r) & 0x1f) << 0))
  /** constructor for RGB colours */

#define Palette_Colour_red        Palette_makeRGBColour(31,  0,  0)
#define Palette_Colour_darkRed    Palette_makeRGBColour(15,  0,  0)
#define Palette_Colour_green      Palette_makeRGBColour( 0, 31,  0)
#define Palette_Colour_darkGreen  Palette_makeRGBColour( 0, 15,  0)
#define Palette_Colour_blue       Palette_makeRGBColour( 0,  0, 31)
#define Palette_Colour_darkBlue   Palette_makeRGBColour( 0,  0, 15)
#define Palette_Colour_yellow     Palette_makeRGBColour(31, 31,  0)
#define Palette_Colour_darkYellow Palette_makeRGBColour(21, 21,  0)
#define Palette_Colour_cyan       Palette_makeRGBColour( 0, 31, 31)
#define Palette_Colour_aqua       Palette_makeRGBColour(28,  5, 22)
#define Palette_Colour_pink       Palette_makeRGBColour(11,  0, 31)
#define Palette_Colour_purple     Palette_makeRGBColour(21,  0, 21)
#define Palette_Colour_magenta    Palette_makeRGBColour(31,  0, 31)
#define Palette_Colour_black      Palette_makeRGBColour( 0,  0,  0)
#define Palette_Colour_darkGrey   Palette_makeRGBColour(10, 10, 10)
#define Palette_Colour_lightGrey  Palette_makeRGBColour(21, 21, 21)
#define Palette_Colour_white      Palette_makeRGBColour(31, 31, 31)
#define Palette_Colour_lightFlesh Palette_makeRGBColour(30, 20, 15)
#define Palette_Colour_brown      Palette_makeRGBColour(10, 10,  0)
#define Palette_Colour_orange     Palette_makeRGBColour(30, 20,  0)
#define Palette_Colour_teal       Palette_makeRGBColour(15, 15,  0)
  /** constants for common colors */

/*========================================*/

void Palette_initialize (void);
  /** initializes the palette data; must be called before any other
      routines in this module */

/*--------------------*/

void Palette_finalize (void);
  /** cleans up the internal palettes data; should be called after any
      other routines in this module */

/*--------------------*/

void Palette_setBkgPalettes (in Palette_Type firstPalette,
			     in UINT8 count,
			     in Palette_Data *paletteDataList);
  /** sets background palette(s) starting with palette <firstPalette>
      and updating <count> palettes altogether with colour data from
      <paletteDataList> */

/*--------------------*/

void Palette_setSpritePalettes (in Palette_Type firstPalette,
				in UINT8 count,
				in Palette_Data *paletteDataList);
  /** sets sprite palette(s) starting with palette <firstPalette>
      and updating <count> palettes altogether with colour data from
      <paletteDataList> */

/*--------------------*/

void Palette_setBkgPaletteEntry (in Palette_Type palette,
				 in UINT8 entry,
				 in Palette_Colour colour);
  /** sets a specific background palette entry indexed by <entry> of
      <palette> to <colour> */

/*--------------------*/

void Palette_setSprPaletteEntry (in Palette_Type palette,
				 in UINT8 entry,
				 in Palette_Colour colour);
  /** sets a specific sprite palette entry indexed by <entry> of
      <palette> to <colour> */


#endif /* __PALETTE_H */
