/** Font module --
    This module provides support for multiple fonts for the GameBoy.

    A font is characterized by a font descriptor which specifies
    properties of the font (like family, slant etc.).  Currently it is
    only possible to give a font name (which is ignored by now ;-)
    Note that currently a font may only contain 128 printable
    characters.

    The desired font can be selected via <setCurrent> and then some
    tiles in the tile memory contain the character glyphs.  The
    mapping of some string into the tile numbers is done by
    <convertToTiles>, the reverse mapping by <convertFromTiles>.

    Original by Michael Hope, 1999 (michaelh@earthling.net)

    Adapted to modular naming conventions and self-documenting
      function names by Thomas Tensi, 2004-09
*/

#ifndef __FONTEXT_H
#define __FONTEXT_H

#include <gbextended/types.h>
#include <gbextended/tile.h>

typedef char *Font_Descriptor;
  /** characterizes the font to be manipulated; currently just the
      name of font to load */

/*========================================*/

void Font_initialize (void);
  /** initializes the font system and loads default font; must be
      called before any other routines in this module */

/*--------------------*/

void Font_finalize (void);
  /** cleans up the font system; should be called after any other
      routines in this module */

/*--------------------*/

void Font_setCurrent (in Font_Descriptor descriptor);
  /** loads and activates the font given by <descriptor> */

/*--------------------*/

void Font_convertFromTiles (in Tile_Type *tileList, in UINT8 length,
			    out char *st);
  /** converts <length> tiles in <tileList> of current font into
      <st> */

/*--------------------*/

void Font_convertToTiles (in char *st, out Tile_Type *tileList);
  /** converts <st> into <tileList> of current font */


#endif /* __FONTEXT_H */
