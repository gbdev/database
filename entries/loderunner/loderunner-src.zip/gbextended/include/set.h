/** Set module --
    This module provides all services for handling sets represented
    as long integers (bitsets).

    The standard routines are available to make a set empty (<clear>),
    to check whether it is empty (<isEmpty>), to find some element in
    the set (<firstElement>), to make a singleton set from one element
    (<makeSet>), to find the complement set (<complement>), to test
    set membership (<isElement>) and to in-/exclude an element
    (<include>, <exclude>).

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __SET_H
#define __SET_H

/*========================================*/

#include <gbextended/types.h>

/*========================================*/

typedef UINT32 Set_Type;
  /** a set may contain the elements 0..31 */

typedef UINT8 Set_Element;
  /** the generic base type of a set */

/*========================================*/

void Set_initialize (void);
  /** initializes the set data; must be called before any other
      routines in this module */

/*--------------------*/

void Set_finalize (void);
  /** cleans up the internal set data; should be called after any
      other routines in this module */

/*--------------------*/

void Set_clear (out Set_Type *set);
  /** makes <set> empty */

/*--------------------*/

Boolean Set_isEmpty (in Set_Type set);
  /** finds out whether <set> is empty */

/*--------------------*/

Set_Element Set_firstElement (in Set_Type set);
  /** finds out first element in <set> when not empty */

/*--------------------*/

Set_Type Set_makeSet (in Set_Element element);
  /** makes a singleton set from <element> */

/*--------------------*/

Set_Type Set_complement (in Set_Type set);
  /** returns the complement set of <set> */

/*--------------------*/

Boolean Set_isElement (in Set_Type set, in Set_Element element);
  /** tells whether <element> occurs in <set> or not */

/*--------------------*/

void Set_include (inout Set_Type *set, in Set_Element element);
  /** adds <element> to <set> */

/*--------------------*/

void Set_exclude (inout Set_Type *set, in Set_Element element);
  /** removes <element> from <set> */

#endif /* __SET_H */
