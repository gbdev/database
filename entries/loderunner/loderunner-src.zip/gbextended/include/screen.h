/** Screen module --
    This module provides basic services for handling the screen of a
    GameBoy.

    The main services are one to control the visibility of the screen
    (like <turnOff> and <turnOn> and one to find whether the display
    updater is in the frame gap, where the screen data can be safely
    updated.

    Specialties like drawing, sprites, windows and background
    are in other modules, but rely on the services here.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef __SCREEN_H
#define __SCREEN_H

#include <gbextended/types.h>

/*========================================*/

typedef UINT8 Screen_Coordinate;
  /** a coordinate on the screen */

#define Screen_graphicsWidth 160
  /** width of the screen in pixels */

#define Screen_graphicsHeight 144
  /** height of the screen in pixels */

/*========================================*/

void Screen_initialize (void);
  /** initializes the screen and the internal representation of it;
      must be called before any other routines in this module */

/*--------------------*/

void Screen_finalize (void);
  /** cleans up the internal representation of the screen; should be
      called after any other routines in this module */

/*--------------------*/

void Screen_waitForFrameGap (void);
  /** waits for the vertical blank interrupt (VBL) to finish; this can
      be used to sync map and sprite animation with the screen
      re-draw; if VBL interrupt is disabled, this function will never
      return, if the screen is off this function returns immediately
  */

/*--------------------*/

Boolean Screen_isInFrameGap (void);
  /** tells whether the screen can be safely updated because the
      system is in the frame gap period */

/*--------------------*/

void Screen_turnOffInFrameGap (void);
  /** turns the display off, but waits for until the frame gap */

/*--------------------*/

#define Screen_turnOff   Screen_turnOffInFrameGap
  /** turns the display off immediately */

/*--------------------*/

void Screen_turnOn (void);
  /** turns the display back on */

#endif /* __SCREEN_H */

