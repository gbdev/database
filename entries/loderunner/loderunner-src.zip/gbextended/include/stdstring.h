/** StdString module --
    Wrapper around standard C string module redefining some routines

    by Thomas Tensi, 2005-10
*/

#ifndef __STDSTRING_H
#define __STDSTRING_H

extern void _itoa (int n, char *s, unsigned char base);
extern void *memmove (void *, void *, unsigned int);
extern void *memset (void *, unsigned char, unsigned int );
extern char *strchr (char *, char);
extern int strlen (char *);
extern char *strstr (char *, char *);

#define StdString_itoa     _itoa
#define StdString_memmove  memmove
#define StdString_memset   memset
#define StdString_strchr   strchr
#define StdString_strlen   strlen
#define StdString_strstr   strstr

#endif
