/** Profiler module --
    This module provides all services for handling the entry and exit
    interrupts when profiling a program for a GameBoy Color.

    Profiling is activated by a compiler flag which generates prologue
    and epilogue code in the profiled routines.  For each such entry
    and exit the profiler generates three calls to the routine
    <_DEBUG_write> which typically writes information to some file for
    later analysis. The information written is: "<IN> total nmber of
    clocks used", <banked address> and "<OUT> total number of clocks
    used"

    Hence the profiling time is split up into two values to minimize
    the imprecision by the profiling code itself.  A later analysis
    will use the IN-time for a routine entry, the OUT-time for a
    routine exit and the time period from IN to OUT should be assigned
    to the profiler measurement itself.

    Note that there is a companion program 'analyzeProfile' which
    takes the measurement data and writes a report about the cycles
    used per routine.  More details can be found in the documentation
    of that program.

    Original version by Thomas Tensi, 2005-08
*/

#ifndef __PROFILER_H
#define __PROFILER_H

/*========================================*/

void Profiler_initialize (void);
  /** initializes the profiler and activates the profiling
      interrupt */

/*--------------------*/

void Profiler_finalize (void);
  /** cleans up the internal profiler data and deactivates the profiling
      interrupt */


#endif /* __PROFILER_H */
