/** Types Module --
    This module provides the basic types necessary when programming a
    GameBoy Color.

    Original version by Thomas Tensi, 2004-09
*/

#ifndef _GBX_TYPES_H
#define _GBX_TYPES_H

#include <gb/asmtypes.h>
extern void *memcpy (void *, void *, unsigned int);

/** Good 'ol NULL.
 */
#undef NULL
#ifndef NULL
#  define  NULL     (0)
#endif

/** Boolean type with true and false */
typedef UINT8 Boolean;
#define false		0
#define true		1


#define STRUCT_ASSIGN(dest,source) memcpy(&(dest),&(source), sizeof(dest))
  /** assignment macro for structures, since SDCC does not support
      it */

#ifdef WINDOWS
#define switchROMBank(x)
#define nonbanked
#else
#define switchROMBank(x) SWITCH_ROM_MBC1(x)
#endif

/*-------------------------------------------------------*/
/* parameter qualifiers for routine signatures           */
/*-------------------------------------------------------*/

#define readonly
  /** parameter tag to tell that some pointer parameter is pointing to
      a constant which should be passed by value as IN parameter */

#define in
  /** parameter tag to tell that parameter is not changed by routine */

#define out
  /** parameter tag to tell that parameter is set by routine */

#define inout
  /** parameter tag to tell that parameter is changed by routine */

#endif
