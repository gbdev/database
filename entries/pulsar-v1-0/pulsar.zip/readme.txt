   /   \  /  /  / / /    /  __/ / \     /   \ v  for GB/C
  /  _ / /  /  / / /__  \  \   /   \   /  _ / 1. (c) 2001
 / /    /     / /    / /    / /     \ /   \   0  by  ph0x
~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~`~

ABOUT/
 This is my contribution to the GameBoy programming competition Freedom 2001.
 The game should run on all Gameboys available up to date!
 It was written from scratch in only 3 days. 
 Unfinished version! Watch out for the final version.

 !!IMPORTANT!! the 'Nintendo' logo has been omited due to copyright/trademark
 concerns, thus the game won't run on real Gameboys

CREDITS/
 code:...........ph0x/amuQ
 tune:...........pHx/blowfish
 music engine:...Aleksi/CNCD
 gfx:............internet :)

GAMEPLAY/
 Watch out and don't hit the walls. Duh (:

LEGAL STUFF/
 Gameboy and Gameboy Color are registered trademarks of Nintendo.
 The game is freeware. You may spread it freely as long as you
 don't charge any money for it.

GREETS/
 pHx, Ravity, ile, lazyone, vulc, alotir, Nokturn, Paul, Aleksi, Kojote, 
 Todi, makkmarci, Ego, Wayne, dox, groepaz, Chip, #gameboy, #gbadev, Channel42

CONTACT/
 I can be contacted at:
 e-mail: ph0x@freemail.hu
 url: http://people.inf.elte.hu/~ph0x
 icq: 10657470
 #pascal, #amuq @ IRCnet
 #gameboy, #gbadev @ EFnet

/signed,
 ph0x

 09.25.2001