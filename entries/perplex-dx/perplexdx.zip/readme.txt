PERPLEX DELUXE   (c)2001 Smacks-Designs
-Short-Game-Instruction-


What's my Mission ?:
 
 You have to connect the red stones with the grey stones
 to colourize them also to red. If you get all the stones red in 
 the level, then you will enter the next one.


But how to do that? :

 You have a corsor in the screen, which you can move in 4 directions.
 You have to move the cursor on the red stones and hold the 'A' buttom,
 then you can press the direction keys to move that stone to the wished
 way if possible. Note, that you have to hold the 'A' buttom, if you
 want to move something.
 If you connect one red stone to a grey one, so press the 'B' buttom, to
 colorize it to red. But be carefull with your moves. You can just move
 the stones on a limited times on each level. Also there's a time running.
 On the first 30 levels everything is quite easy, but it gets harder and
 harder ;-)
 

What can I move ?:

 Just red stones and the blue circled stones
 The blue circled stones have no effect, they just try to make your ways 
 not easy.


How many levels are included ?:

 You have to pass 64 levels. Every level is tested and has 100% a solution.
 Don't be boried, if you don't manage a level. You have a password function,
 to try it later again ;-)


The moves are not enough !

 Don't believe your eyes, there's surely a way, try it again :-)
 

The time is not enough !

 I think, you must be abit quicker than ;-). The first 30 levels are quite 
 easy, it must train you abit. So I think, you will get it ;-)
 

I need a paused !:

 Press the 'START' buttom, to take a break.


Damn, I have no moves left and there are 30 seconds over, how can I retry
without waiting?
 
 Just press the 'START' buttom for the menu and select the retry option, or
 directly the retry on 'SELECT' buttom.
 

How can I finish the game to return to the intro ?

 Press 'START' buttom for the menu, and than select 'Game Over'.


Enjoy!
 