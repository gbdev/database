---------------------------------------------------
                   -=ToyToy=-

                  GameBoy Color
---------------------------------------------------
                PDROMS compo entry
---------------------------------------------------


  Bad Knorfi has stolen the toys of little Jack.
       As Jack can't live without his toys,
it's your quest to bring toys back before morning

---------------------------------------------------

Tools used :
 RGBAsm 1.11
 Tilebuddy 4.1
 ProPack 2.29
 Carillon Editor 1.2
 Custom *magic* tools

---------------------------------------------------

Pure asm code by
 Tomasz Slanina

Pixelized by
 Adam Karol

Music tracked by
 Krzysztof Wierzynkiewicz


 ***

Carillon Player
 Aleksi Eeben

Propack
 Rob Northen

--------------------------------------------------

http://www.9wires.com
