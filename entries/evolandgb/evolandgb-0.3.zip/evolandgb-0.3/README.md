# Evoland GB

Evoland.gb is a fan-made port of the Evoland game, on the Nintendo GameBoy console. This project is still in a work-in-progress state, but it is in a sufficiently advanced state to be shown.

For those who do not know Evoland, It is the first game of Shiro Games studio. It takes the form of an action RPB that relates the history of the video game through its technological evolutions and its gameplay. I will not tell you more about it, but if the concept interests you, you will find many let's plays on Youtube.


## Links

* Project's website: https://evogb.flozz.org/
* Github repository: https://github.com/flozz/evoland.gb
* An article about this project on my blog (French): https://blog.flozz.fr/2019/04/21/evoland-sur-gameboy/


## Changelog

* **0.3.0** First public release
