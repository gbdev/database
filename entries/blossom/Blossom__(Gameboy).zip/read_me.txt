﻿*** blossom rom ***
*** a homebrew gameboy game ***

\\\\ by Colorful Courier ////

its the season for blossom ❁ use any button to bloom ❀

ט"ו בשבט הגיע ❁ השתמשי בכל כפתור כדי לפרוח לצלילי שיר האילן

[---------------------------------------------------]

beside me is a gameboy rom file (๑˃̵ᴗ˂̵) (gesusa_hilfe.gb) in order to play it you need a gameboy / gameboy emulator.
i recommend BGB (http://bgb.bircd.org/) (for windows or linux wine)
# no installation required, just double click and drag in the rom. (+ F11 to set up your keyboard / joypad)

[---------------------------------------------------]
	visit us >>> http://o--0oo0--o.com/
[---------------------------------------------------]

♥ thanks ♥
    # Saba Vidyo for coding support
    # BGB emulator/debugger

[---------------------------------------------------]	
	
© colorful courier (aharon manor) 2018

[---------------------------------------------------]	

このゲームはROMファイルです(๑˃̵ᴗ˂̵) プレイするにはゲームボーイ、パソコンでの場合はゲームボーイのエミュレーターが必要です。
推薦するエミュレーター： BGB （ windows、linux wine対応）ダウンロードした後インストールは不要、ROMファイルをダブルクリックしてアプリケーションにドラッグします。プレイでの操作は+ F11を押してキーボードのコントロールボタン設定または手持ちのコントローラーをパソコンに接続する事が可能です。

