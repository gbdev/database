Jet Pak DX (aka GB JetPac)

Version History

0.05s - After some great feedback I got via email and IRC, I've changed a few things
        around in version 0.05, most importantly I've slowed the game down, as it
		seems alot of you think it's too fast. I don't but maybe that's because I
		play test it so much as I'm coding it. Also I've added a pause function, and
		the controls at the beginning on the splash screen.
0.05  - Big day today, added COLOUR!. Also redrew all the sprites, and rewrote all
        the source code. Hopefully things are a lot more neater now, but still
	    not as great as I would like them to be.
	    Added lives, so you can now die. HiScore, a core ingredient of the old ways.
	    I put the three Spaceship parts in, and I know you can't do anything with
	    them yet, but they're there just to see how things will come together.
	    After seeing the response FoulOne got with his GB Lander Homepage, I've
	    knocked one up with all the previous betas available with screenshots. And
	    even the 'not so great' source code for the first Beta.
	    http://datapotato.simplenet.com/gbdev/
	   
0.04  - Added very scruffy code for baddies, baddies detection, killing baddies,
        baddies killing man. I really gotta clean it up later.
	    Simple animation for popped man, and dusted baddie.
	    Added a quick 'Press Start' splash screen.
	   
0.03  - Rearranged code, started modularistion, and changed gravity routine
        Fixed walking of ledges and still walking while falling bug
        Added laser fire, with collision detection between lasers and platforms

0.02  - Redid all the graphics, making them smaller, so the play area is larger
        Put the tree platforms in and a floor, and did simple collision detection
	    for man and platforms

0.01  - Ripped the graphics directly from the Spectrum version for the little space
        man. Had him floating about
	   	   

comments and stuff to : quang@mindless.com

	   