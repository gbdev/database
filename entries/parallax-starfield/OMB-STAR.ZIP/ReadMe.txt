
Hi...

Thanks for taking the time to download this little demo.

It's a very simple piece of code that illustrates how to perform a parallax
scrolling starfield.

This was one of the first things I did on the GameBoy, and the code shows it.
The code has been untouched for nearly a year, so please keep that in mind
when looking through it. It has been collecting (virtual) dust on my hard
drive since then and I won't ever go back to it, so I'm releasing it to the
public for all to laugh at. :)

The code works with no$ (with _all_ exceptions on, I might add ;) and has a
slight problem when running on a real GameBoy Color. I leave fixing that as
an exercise for the reader.

-- Bob
bob@onemanband.com

Other examples and references can be downloaded at http://www.onemanband.com
