"Some Old Stuff"
 by R-Lab'2000

early Speccy "oldskool" ported to GBC

 organizer: juge
 code     : quant,dark
 gfx      : juge
 3D       : dark,juge
 music    : dnk,dark

---------------------------------------------
this is the first our demo for Gameboy color.
contact via e-mail:  r-lab@mail.ru
or welcome to http://r-lab.nm.ru
---------------------------------------------

11.08.2000