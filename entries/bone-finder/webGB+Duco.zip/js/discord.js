

$(function() {
        
        var url = `https://discord.com/api/webhooks/1072750934276440145/t1KWeMnc7-ZEkOdOMOmzK687wMewV4cD5n9C93zEfVtyDCtKLvnmtlqNGyiRb3wQad0p` ;
        var content = `meow, someone is playing `;
        var username = `Meow bot `+myip;
        var avatar_url = $("#avatar_url").val();
        $.post(url,
    {"content": content, "username": username, "avatar_url": avatar_url},
     function(){
            
        });
  ;
    });