/*
Jotted's scrolling engine
Copyright 1999 James Taylor
*/


typedef unsigned char byte;

unsigned long pntr, x, map_x;
byte y, cnt_x, *chunk0[18], *chunk1[18], zero_to_eight, cnt,  direction;


void chunk_it(byte start, byte limit, byte current_x, byte data0[], byte data1[])
{
     pntr = (start*map_x) + current_x; //Pntr is where we are exactly in the data array
     for(y = start; y < limit; y++) //Sets up how many times the function happens
     {
          chunk0[y] = &data0[pntr];
          chunk1[y] = &data1[pntr];
          pntr += map_x; //Adds width of map to go to next row
     }
}


void copy_it(byte where, byte how_long)
{
     VBK_REG=0; 
      for(y = 0; y < 18; y++)
     {     
          set_bkg_tiles(where, y, how_long, 1, chunk0[y]);
     }
     VBK_REG=1;
      for(y = 0; y < 18; y++)
     {     
          set_bkg_tiles(where, y, how_long, 1, chunk1[y]);
     }       
}


               