/*
 * checkers - cwan really (a lame joke) for gameboy color
 * Copyright (C) 1999  Chuck Mason
 *
 * This program is free software; you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation; either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program; if not, write to the Free Software
 * Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
 *
 * Chuck Mason <chuckjr@sinclair.net>
 */
                   
#include <gb.h>
#include <cgb.h>
#include <colors.h>

#include "defs.h"
#include "tiles.h"
#include "sprites.h"
#include "bg/CWAN.MAP"
#include "bg/CWAN.DAT"


UWORD backgroundpalette[] = {
	darkred, darkred, black, red,
	white, red, black, white,
	darkgreen, black, black, black,
	red, black, lightgray, red,
	black, white, white, black
};

unsigned char bgmap[] = {	/* References to a row tiles */
	0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0
};

unsigned char checkermap[] = {	/* References to palette */
        2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2,
	2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
	2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
	2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
        2, 2, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 0, 0, 1, 1, 2, 2,
	2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2, 2
};

/* These are just palette references, I just love manipulating the palette like this :) */
unsigned char checker_red[4] = {
	4, 5, 6, 7
};

unsigned char checker_black[4] = {
	8, 9, 10, 11
};

unsigned char checker_red_king[4] = {
	12, 13, 14, 15
};

unsigned char checker_black_king[4] = {
	16, 17, 18, 19
};

unsigned char tile_inverted[4] = {
	4, 4,
	4, 4
};

unsigned char tile_regular[4] = {
	1, 1,
	1, 1
};

/* Sprites */
UWORD sprite_palette[] = {
	black, darkgray, lightgray, white,
	blue, white, darkblue, cyan
};

typedef struct _spritedat {
	unsigned int x, y;
	int tile;
	/* Expansion to animated sprites soon */
	int palette;
} spritedat;

typedef struct _checkerdat {
	unsigned int x, y;
	unsigned int king;
} checkerdat;

spritedat arrow;
checkerdat allcheckers[3 * 4 * 2];

char checker[8][8];
int jumpx, jumpy;

WHOPLAYS currentplayer;

void not_gameboy_color();
void game_loop();
void update_array(int, int, int, int);
int is_king(int, int);
void set_king(int, int);

void logo()
{
	DISPLAY_ON;
	printf("CWAN 4 GAMEBOY\n");
	printf("Interested in CWAN\n");
	printf("for PC? Check web @ emu.simplenet.com\n");
	printf("\nThis game is\nUNFINISHED.\n");
	printf("\nHowever, you're welcome to finish it if you want to.\n");
	printf("Send bugs/flames/suggestions/etc. to /dev/null.\n");
	printf("Otherwise, email me,Chuck Mason <chuckjr@sinclair.net>\n");
	waitpad(0xFF);
	waitpadup();
	
	cls();
	
	printf("Unfortunatly I could");
	printf("not implement\neverything");
	printf(" I had\nplanned before ");
	printf("goingon vacation.\n");
	printf("I'll be in New\nSmyrna\n");
	printf("hah hah.. hah..\n");
	printf("But if anyone wants to\n");
	printf("Add link port or the is_win\n");
	printf("stuff, feel free to.\n");
	waitpad(0xFF);
	waitpadup();
				
	disable_interrupts();
	DISPLAY_OFF;

	VBK_REG = 0;
	set_bkg_palette(0, 1, CwanPal);
	set_bkg_data(0, 124, CwanData);
	set_bkg_tiles(0, 0, 20, 18, CwanMap);
	
	DISPLAY_ON;
	SHOW_BKG;
	enable_interrupts();	
	waitpad(0xFF);
	waitpadup();
}

void vblank()
{
}

	
void put_checker(int x, int y, int c)
{
	int ox, oy;
	
	ox = x;
	oy = y;
	
	if(checker[y][x] == 0)
		checker[y][x] = c;
	else
		return;
	
	x = 2 + (x * 2);
	y = 1 + (y * 2);
	
	switch(c) {
		case 1: /* Black */
			if(is_king(ox, oy)) 
				set_bkg_tiles(x, y, 2, 2, checker_black_king);
			else
				set_bkg_tiles(x, y, 2, 2, checker_black);
			break;
		case 2: /* Red */
			if(is_king(ox, oy)) 
				set_bkg_tiles(x, y, 2, 2, checker_red_king); 
			else
				set_bkg_tiles(x, y, 2, 2, checker_red);
			break;
		default:
			return;
	}
}

void clear_checker(int x, int y)
{
	if(checker[y][x] == 0)
		return;
	
	checker[y][x] = 0;
	
	x = 2 + (x * 2);
	y = 1 + (y * 2);
	
	set_bkg_tiles(x, y, 2, 2, bgmap);
}

/* This was static inside the function, but it didn't work? */
/*unsigned int inverted_x = 0, inverted_y = 0;
unsigned int have_old_inverted = 0;*/

void invert_tile(int x, int y, int s)
{
	/* Inverting means changing a tile from palette 1 to palette 4 */
	unsigned int bx, by;
	
	if(s == 1) {
		/* Must invert it, eh */
		bx = 2 + (x * 2);
		by = 1 + (y * 2);
		set_bkg_tiles(bx, by, 2, 2, tile_inverted);
	} else if(s == 0) {
		bx = 2 + (x * 2);
		by = 1 + (y * 2);
		set_bkg_tiles(bx, by, 2, 2, tile_regular);
	}
}

int is_legal_for_king(int oldx, int oldy, int newx, int newy)
{
	if(abs(newy - oldy) == 1) {
		if(abs(newx - oldx) == 1) /* Must be legal heh */
			return 1;
	} else if(abs(newy - oldy) == 2) {
		if(abs(newx - oldx) == 2) {
			int tempx, tempy;
			
			if(newy < oldy) {
				tempy = newy + 1;
			} else {
				tempy = newy - 1;
			}
			
			if(newx < oldx) {
				tempx = newx + 1;
			} else {
				tempx = newx - 1;
			}
			
			if(currentplayer == BLACK) {
				if(checker[tempy][tempx] == RED) {
					jumpx = tempx;
					jumpy = tempy;
					return 2;
				}
			} else if(currentplayer == RED) {
				if(checker[tempy][tempx] == BLACK) {
					jumpx = tempx;
					jumpy = tempy;
					return 2;
				}
			}
		}
	}
	
	return 0;
}
	
/* returns 2 on legal jump, 1 on legal move, 0 on illegal anything */
int is_legal(int oldx, int oldy, int newx, int newy)
{
	if(checker[newy][newx] != 0)
		return 0;
		
	if(is_king(oldx, oldy))
		return is_legal_for_king(oldx, oldy, newx, newy);
				
	switch(currentplayer) {
		case RED:
			if(newy == (oldy - 2))	/* Trying to jump? */ {
				int tempx, tempy;
				
				if(newx > oldx) { 
					if((newx - oldx) != 2) /* no? */
						return 0;
				} else {
					if((oldx - newx) != 2) /* no? */
						return 0;
				}
				/* Must be trying to jump.. */
				tempy = newy + 1;	/* Y is easy */
				if(newx > oldx) 
					tempx = newx - 1;
				else
					tempx = newx + 1;
			
				if(checker[tempy][tempx] == BLACK) {
					jumpx = tempx;
					jumpy = tempy;
					return 2; /* It's GOOD! */
				}
				return 0; /* Failure! */
			}
			/* Can only go up (for now) */
			if(newy != (oldy - 1))
				return 0;
			/* Can only go left or right 1 square */
			if(newx > oldx) {
				if((newx - oldx) != 1)
					return 0;
			} else {
				if((oldx - newx) != 1)
					return 0;
			}
			return 1;
		case BLACK:
			if(newy == (oldy + 2))	/* Trying to jump? */ {
				int tempx, tempy;
				
				if(newx > oldx) { 
					if((newx - oldx) != 2) /* no? */
						return 0;
				} else {
					if((oldx - newx) != 2) /* no? */
						return 0;
				}
				/* Must be trying to jump.. */
				tempy = newy - 1;	/* Y is easy */
				if(newx > oldx) 
					tempx = newx - 1;
				else
					tempx = newx + 1;
			
				if(checker[tempy][tempx] == RED) {
					jumpx = tempx;
					jumpy = tempy;
					return 2; /* It's GOOD! */
				}
				return 0; /* Failure! */
			}
		
			/* Can only go down (for now) */
			if(newy != (oldy + 1))
				return 0;
			if(newx > oldx) {
				if((newx - oldx) != 1)
					return 0;
			} else {
				if((oldx - newx) != 1)
					return 0;
			}
			return 1;
	}
	return 0;
}

int is_king(int x, int y)
{
	int i;

	for(i = 0; i < 3 * 4 * 2; i++) {
		if(allcheckers[i].x == x && allcheckers[i].y == y)
			return (allcheckers[i].king == 1) ? 1 : 0;
	}
	return 0;
}

void set_king(int x, int y)
{
	int i;
	
	for(i = 0; i < 3 * 4 * 2; i++) {
		if(allcheckers[i].x == x && allcheckers[i].y == y)
			allcheckers[i].king = 1;
	}
}

void update_array(int ox, int oy, int nx, int ny)
{
	int i;
	
	for(i = 0; i < 3 * 4 * 2; i++) {
		if(allcheckers[i].x == ox && allcheckers[i].y == oy) {
			allcheckers[i].x = nx;
			allcheckers[i].y = ny;
		}
	}
}
			
void do_sprite(int nb, spritedat *sp)
{
	set_sprite_tile(nb, sp->tile);
	if(currentplayer == BLACK)
		set_sprite_prop(nb, sp->palette | S_FLIPY);
	else
		set_sprite_prop(nb, sp->palette);
		
	move_sprite(nb, sp->x, sp->y);
}

void setup_sprites()
{
	SPRITES_8x16;
	set_sprite_palette(0, 2, sprite_palette);
	set_sprite_data(0, 2, sprite_tiles);
	
	arrow.x = 28;
	arrow.y = 32;
	arrow.tile = 0;	/* And 1, its a 8x16 sprite.. */
	arrow.palette = 1;
	
	do_sprite(0, &arrow);
	
	SHOW_SPRITES;
}

void main(void)
{
	int i;
	checkerdat allcheckercopy[3 * 4 * 2] = {
		{ 0, 0, 0 }, { 2, 0, 0 }, { 4, 0, 0 }, { 6, 0, 0 },
		{ 1, 1, 0 }, { 3, 1, 0 }, { 5, 1, 0 }, { 7, 1, 0 },
		{ 0, 2, 0 }, { 2, 2, 0 }, { 4, 2, 0 }, { 6, 2, 0 },
		
		{ 1, 5, 0 }, { 3, 5, 0 }, { 5, 5, 0 }, { 7, 5, 0 },
		{ 0, 6, 0 }, { 2, 6, 0 }, { 4, 6, 0 }, { 6, 6, 0 },
		{ 1, 7, 0 }, { 3, 7, 0 }, { 5, 7, 0 }, { 7, 7, 0 }
	};
	
	if(_cpu != CGB_TYPE) {
		not_gameboy_color();
		return;
	} 
	
	logo();
		
	disable_interrupts();
	DISPLAY_OFF;
	
	add_VBL(vblank);
	set_interrupts(VBL_IFLAG);
	
	set_bkg_palette(0, 5, &backgroundpalette[0]);
	set_bkg_data(0, 20, checker_tiles);
	VBK_REG = 1;

	set_bkg_tiles(0, 0, 20, 18, checkermap);
	
	VBK_REG = 0;	/* So we can update tiles instead of palettes */

	for(i = 0; i < 18; i++)
		set_bkg_tiles(0, i, 20, 1, bgmap);
	/* Create the checkers on the board */
	for(i = 0; i < 3 * 4 * 2; i++) 
		allcheckers[i] = allcheckercopy[i];
	for(i = 0; i < 3 * 4; i++)
		put_checker(allcheckers[i].x, allcheckers[i].y, BLACK);
	for(i = 3 * 4; i < 3 * 4 * 2; i++)
		put_checker(allcheckers[i].x, allcheckers[i].y, RED);
		
	setup_sprites();	
	SHOW_BKG;
	DISPLAY_ON;
	enable_interrupts();

	game_loop();	/* Should never return? */
				
	return;
}

/* Bah, bah */
void not_gameboy_color()
{
	unsigned char *mem = 0;

	cls();
	font_init();
	puts("Sorry, cwan was madeto run only on a\ngameboy color!");
	printf("\n\nDBG:LCDC REG = 0x%x\n", *(mem+0xff40));

	while(1);
}

/****************************************************************************/
/* Game Loop */
void game_loop()
{
	UBYTE keypad;
	int done = 0;
	unsigned int i;
	
	unsigned int bx, by;	/* Old selected box */
	unsigned int got_old = 0;

	currentplayer = RED;			
	while(!done) {
		keypad = waitpad(J_UP | J_DOWN | J_LEFT | J_RIGHT | J_A);

		if(keypad & J_UP) {
			arrow.y -= 16;
			if(currentplayer == RED) {
				if(arrow.y < 32)
					arrow.y = 32;
			} else {
				if(arrow.y < 16)
					arrow.y = 16;
			}
		}
		if(keypad & J_DOWN) {
			arrow.y += 16;
			if(currentplayer == RED) {
				if(arrow.y > 144)
					arrow.y = 144;
			} else {
				if(arrow.y > 128)
					arrow.y = 128;
			}
		}
		if(keypad & J_LEFT) {
			arrow.x -= 16;
			if(arrow.x < 28)
				arrow.x = 28;
		}
		if(keypad & J_RIGHT) {
			arrow.x += 16;
			if(arrow.x > 140)
				arrow.x = 140;
		}

		if(keypad & J_A) {
			unsigned int nx, ny;
			
			disable_interrupts();
			VBK_REG = 1;
			
			if(currentplayer == RED) {
				nx = (arrow.x - 28) / 16;
				ny = (arrow.y - 32) / 16;
			} else {
				nx = (arrow.x - 28) / 16;
				ny = (arrow.y - 16) / 16;
			}
			
			if(got_old) {
				int move;
				invert_tile(bx, by, 0);
				if((move = is_legal(bx, by, nx, ny)) > 0) {
					VBK_REG = 0;
					
					clear_checker(bx, by);

					put_checker(nx, ny, currentplayer);

					update_array(bx, by, nx, ny);

					if(ny == 0 && currentplayer == RED)
						set_king(nx, ny);
					else if(ny == 7 && currentplayer == BLACK)
						set_king(nx, ny);
					
					/* I Wish there was a better way than calling put_checker 
					 * twice, but the way my code is set up (which is really horrible)
					 * this is the best I can do. 
					 * (Oh yea, The following lines are just in case the checker
					 * was set to kinged)
					 */
					if(is_king(nx, ny)) {
						clear_checker(nx, ny);
						put_checker(nx, ny, currentplayer);
					}
					
					
					VBK_REG = 1;
					if(currentplayer == RED) {
						currentplayer = BLACK;
						arrow.y -= 16;
					} else {
						currentplayer = RED;
						arrow.y += 16;
					}
					if(move == 2) /* Jump */ {
						VBK_REG = 0;
						clear_checker(jumpx, jumpy);
						update_array(jumpx, jumpy, 99, 99);
					}
						
				}
				got_old = 0;
			} else {
			
				bx = nx;
				by = ny;
			
				if(checker[by][bx] == currentplayer) {
					invert_tile(bx, by, 1);
					got_old = 1;
				}
			}
			
			VBK_REG = 0;
			enable_interrupts();
		}
		do_sprite(0, &arrow);
/*		waitpadup(); */
		DELAY;
	};
}
