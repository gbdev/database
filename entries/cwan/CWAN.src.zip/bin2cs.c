#include <stdio.h>

int main(int argc,char **argv)
{
    FILE *bin,*src;
    unsigned char lif;
    unsigned int leno;
    int vif;
    if(argc < 4)
    {
        printf("syntax: %s [infile] [outfile] [global name]\n",argv[0]);
        exit(1);
    }
    printf("bin2c coded by Pharos (c) 1998-99\n");
    if(( bin = fopen(argv[1],"rb")) == NULL)
    {
        printf("File Not found\n");
        exit(1);
    }
    if(( src = fopen(argv[2],"wb")) == NULL)
    {
        printf("Unable to create output file\n");
        exit(1);
    }
    lif=0;
    fprintf(src,"unsigned char %s[] =\n{",argv[3]);
    printf("converting\n[");
    leno=0;
    while( (vif = getc(bin)) != EOF)
    {
    	if(leno != 0)
    		fprintf(src, ",");
   	if((leno % 8) == 0)
   		fprintf(src, "\n");
        leno++;
        if(lif>60)
        {
           lif=0;
           putchar('.');
        }
        switch(vif)
        {
           case '\0':
           {
              lif+= fprintf(src," 0x00");
              break;
           }
           case '\n':
           {
              lif+= fprintf(src," '\\n'");
              break;
           }
           case '\\':
           {
              lif+= fprintf(src," '\\\\'");
              break;
           }
           case '\r':
           {
              lif+= fprintf(src," '\\r'");
              break;
           }
           default:
           {           
              if( (vif < 48) || ( vif > 90) )
                 lif+= fprintf(src," 0x%02X",vif);
              else
                 lif+= fprintf(src," '%c'",vif);
           }
        }
    }
    fprintf(src,"\n};\n");
    printf("]\nDone.%i byte(s)\n",leno);
    fclose(src);
    fclose(bin);
}
    
    
                                                            