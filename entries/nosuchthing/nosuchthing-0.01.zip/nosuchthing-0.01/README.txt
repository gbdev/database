No Such Thing
=============

In 1990, Nintendo placed print ads clarifying how to refer to
its products by their trademarks.  For example, it's not accurate
to call the Nintendo Entertainment System (NES) a "Nintendo".
The ad's headline was "There's no such thing as a Nintendo."

Fast-forward to the late 2010s, when the Internet meme community
rediscovered this ad and made parodies titled "There's no such
thing as Nintendo."  These were meant to jokingly imply that
Nintendo and its products never existed in the first place, and
anyone who believes otherwise must be a victim of mass delusion.

This 1K tech demo for Game Boy displays "There's no such thing as
Nintendo" with Mario drawn as a shadow.  Should Nintendo's legal
department start to attack fan-made content even more intensely
than it did in the 2010s, the demo can represent a farewell to the
homebrew scene.  It has a second purpose that I plan to explain later.

Copyright 2020 Damian Yerrick  
Distributed under the zlib License

