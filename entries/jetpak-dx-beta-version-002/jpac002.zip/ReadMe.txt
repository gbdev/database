GB-JetPac

Version History

0.02 - Redid all the graphics, making them smaller, so the play area is larger
       Put the tree platforms in and a floor, and did simple collision detection
	   for man and platforms

0.01 - Ripped the graphics directly from the Spectrum version for the little space
       man. Had him floating about
	   	   

comments and stuff to : quang@mindless.com

	   