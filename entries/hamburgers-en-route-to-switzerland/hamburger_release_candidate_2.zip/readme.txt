hamburgers en route to switzerland.
start - begin game, pause/unpause
d pad - control burger
a - shoot.

shoot the milkshakes shooting various food projectiles, each with a certain pattern of moving. Chicken nuggets are extra lives, so pick them up and don't shoot them.