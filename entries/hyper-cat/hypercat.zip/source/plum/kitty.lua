do kitty = {}
    local Self = kitty

    function Self.init()
        Self.frame = 0
        Self.frame2 = 0

        Self.x = 40
        Self.y = 60
        Self.reverse = 0
        Self.step = 0
        Self.moving = true
        Self.cursor = 0

        Self.love = {
            timer = random.next() * 2 + 1024;
            value = math.floor(random.next() / 64) + 1;
            animation = 0;
            hugs = math.floor(random.next() / 64) + 2;
            hugging = false;
        }

        Self.food = {
            timer = random.next() * 2 + 1024;
            value = math.floor(random.next() / 64) + 1;
            feeeding = false;
            x = 78;
            y = 0;
        }

        Self.poop = {
            timer = random.next() * 2 + 1024;
            x = 0;
        }

        Self.nap = {
            timer = random.next() * 4 + 4096;
            sleeping = false;
            dark = false;
        }
    end

    function Self.drawHUD()
        for i = 1, Self.love.value do
            fakeboy.addSprite(Self.nap.dark and 0x52 or 0x42, (i + 5) * 8, 8, false)
        end
        for i = 1, Self.food.value do
            fakeboy.addSprite(Self.nap.dark and 0x52 or 0x42, (i + 5) * 8, 16, false)
        end
        fakeboy.addSprite(Self.nap.dark and 0x53 or 0x43, 8, (Self.cursor + 13) * 8, false)
    end

    function Self.updateMenu()
        if fakeboy.key.Tilde.pressed then
            plum.timer.speed = plum.speed.Fast
        else
            plum.timer.speed = plum.speed.Normal
        end

        if fakeboy.key.Q.pressed then
            fakeboy.key.Q.pressed = false
            Self.food.value = math.max(Self.food.value - 1, 0)
        elseif fakeboy.key.W.pressed then
            fakeboy.key.W.pressed = false
            Self.food.value = math.min(Self.food.value + 1, 4)
        end
        if fakeboy.key.E.pressed then
            fakeboy.key.E.pressed = false
            Self.love.value = math.max(Self.love.value - 1, 0)
        elseif fakeboy.key.R.pressed then
            fakeboy.key.R.pressed = false
            Self.love.value = math.min(Self.love.value + 1, 4)
        end

        if fakeboy.key.Up.pressed then
            fakeboy.key.Up.pressed = false
            if Self.cursor > 0 then
                Self.cursor = Self.cursor - 1
            end
        elseif fakeboy.key.Down.pressed then
            fakeboy.key.Down.pressed = false
            if Self.cursor < 3 then
                Self.cursor = Self.cursor + 1
            end
        end

        if fakeboy.key.A.pressed then
            fakeboy.key.A.pressed = false
            if Self.cursor == 0 then
                if Self.poop.timer > 0 and not Self.love.hugging and not Self.nap.sleeping then
                    Self.love.hugging = true
                    Self.love.animation = 64
                end
            elseif Self.cursor == 1 then
                if Self.poop.timer > 0 and not Self.food.feeding then
                    Self.food.feeding = true
                    Self.food.y = 0
                end
            elseif Self.cursor == 2 then
                if Self.poop.timer == 0 then
                    Self.poop.timer = random.next() * 2 + 1024
                end
            else
                Self.nap.dark = not Self.nap.dark
                if Self.nap.dark and not Self.nap.sleeping then
                    Self.love.timer = random.next() + 127
                end
                fakeboy.tileset.image.canvas:replaceColor(plum.color.Black, plum.color.Red)
                fakeboy.tileset.image.canvas:replaceColor(plum.color.White, plum.color.Black)
                fakeboy.tileset.image.canvas:replaceColor(plum.color.Red, plum.color.White)
            end
        end
    end


    function Self.update()
        if Self.frame >= 255 then
            Self.frame2 = (Self.frame2 + 1) % 256
        end
        Self.frame = (Self.frame + 1) % 256

        if Self.nap.dark or Self.nap.sleeping then
            Self.moving = false
            Self.step = 10
        end

        if Self.love.animation > 0 then
            Self.love.animation = Self.love.animation - 1
            Self.moving = false
            Self.step = 80
            if Self.love.animation == 0 then
                Self.love.hugging = false
                Self.love.hugs = Self.love.hugs - 1
                Self.love.timer = Self.love.timer + 127
                if Self.love.hugs == 0 then
                    Self.love.hugs = math.floor(random.next() / 64) + 2
                    Self.love.value = math.min(Self.love.value + 1, 4)
                    if not Self.nap.sleeping then
                        Self.nap.timer = Self.nap.timer - 1024
                        if Self.nap.timer < 1 then
                            Self.nap.timer = 1
                        end
                    end
                end
            end
        end


        Self.nap.timer = Self.nap.timer - 1
        if Self.nap.timer == 0 then
            Self.nap.sleeping = not Self.nap.sleeping
            if Self.nap.sleeping then
                Self.nap.timer = random.next() * 2 + 1024
                Self.food.timer = random.next() + 512
            else
                Self.love.timer = random.next() + 240
                if not Self.nap.dark then
                    Self.love.value = math.max(Self.love.value - 1, 0)
                else
                    Self.love.value = math.min(Self.love.value + 1, 4)
                end
                Self.nap.timer = random.next() * 4 + 4096
            end
        end

        if not Self.nap.sleeping then
            Self.love.timer = Self.love.timer - 1
            if Self.love.timer == 0 then
                if Self.nap.dark then
                    Self.love.timer = random.next() + 127
                elseif Self.poop.timer == 0 then
                    Self.love.timer = random.next() + 512
                else
                    Self.love.timer = random.next() * 2 + 1024
                end

                Self.love.value = math.max(Self.love.value - 1, 0)
            end
        end

        Self.food.timer = Self.food.timer - 1
        if Self.food.timer == 0 then
            if sleeping then
                Self.food.timer = random.next() + 512
            else
                Self.food.timer = random.next() * 2 + 1024
            end
            Self.food.value = math.max(Self.food.value - 1, 0)
        end

        if not Self.food.feeding and not Self.nap.dark and not Self.nap.sleeping then
            if Self.poop.timer > 0 then
                Self.poop.timer = Self.poop.timer - 1
                Self.poop.x = Self.x
                if Self.poop.timer == 0 then
                    Self.love.timer = random.next() + 512
                    Self.moving = false
                    Self.step = 80
                end
            end
        end

        if Self.food.feeding then
            if Self.food.y < Self.y then
                Self.food.y = Self.food.y + 1
            else
                if Self.x < Self.food.x + 16 and Self.x + 16 > Self.food.x then
                    Self.food.feeding = false
                    if Self.food.value + 1 > 4 then
                        Self.love.value = math.max(Self.love.value - 1, 0)
                    end
                    Self.food.value = math.min(Self.food.value + 1, 4)
                    Self.poop.timer = Self.poop.timer - 128
                    if Self.poop.timer < 1 then
                        Self.poop.timer = 1
                    end
                end
            end
        end

        if Self.step == 0 then
            Self.moving = true
            if Self.reverse then
                if Self.poop.timer == 0 then
                    Self.x = Self.x - 2
                else
                    Self.x = Self.x - 1
                end
                if Self.x + 24 < 40 then
                    Self.reverse = false
                end
            else
                if Self.poop.timer == 0 then
                    Self.x = Self.x + 2
                else
                    Self.x = Self.x + 1
                end
                if Self.x > 160 - 40 then
                    Self.reverse = true
                end
            end
            if Self.poop.timer == 0 then
                Self.step = 1
            else
                Self.step = 4
            end
        else
            Self.step = Self.step - 1
        end

        if Self.food.feeding then
            fakeboy.addSprite(0x3F, Self.food.x + 0x10, Self.food.y + 0x10, false)
            fakeboy.addSprite(0x3E, Self.food.x + 0x08, Self.food.y + 0x10, false)
            fakeboy.addSprite(0x2F, Self.food.x + 0x10, Self.food.y + 0x08, false)
            fakeboy.addSprite(0x2E, Self.food.x + 0x08, Self.food.y + 0x08, false)
        end

        local bubble = 0x00
        local head = 0x00
        
        if Self.nap.sleeping then
            head = 0x24
            if Self.frame >= 128 then
                bubble = 0x28
            end
        elseif Self.nap.dark then
            head = 0x46
            if Self.frame >= 128 then
                bubble = 0x4C
            end
        else
            if Self.love.value < 2 then
                head = 0x04
                if Self.frame >= 128 then
                    bubble = 0x0C
                end
            else
                head = 0x02
                if Self.food.value >= 2 then
                    head = 0x06
                end
                if Self.frame >= 128 then
                    if Self.frame2 % 2 == 0 and Self.poop.timer > 0 then
                        bubble = 0x0A
                    end
                end
            end
        end
            
        if Self.frame < 128 then
            bubble = 0x00
            if Self.nap.sleeping then
                head = 0x26
            elseif Self.nap.dark then
                head = 0x46
            else
                if Self.food.value < 2 then
                    bubble = 0x2C
                    if Self.love.value < 2 then
                        head = 0x26
                    else
                        head = 0x46
                    end
                elseif Self.love.value >= 2 then
                    head = 0x02
                end
            end
        end

        if Self.love.hugging then
            bubble = 0x00
            if Self.love.animation > 48 then
                head = 0x26
            elseif Self.love.animation > 24 then
                bubble = 0x08
                head = 0x02
            else
                bubble = 0x08
                head = 0x06
            end
        end

        local leg = 0
        local bob = 0
        if not Self.moving or Self.frame % 32 < 16 then
            leg = 0x20
            bob = 0
        else
            leg = 0x30
            bob = 1
        end

        local tail = 0x40
        if Self.poop.timer == 0 then
            fakeboy.addSprite(0x1F, Self.poop.x + 0x10, Self.y + 0x10, false)
            fakeboy.addSprite(0x1E, Self.poop.x + 0x08, Self.y + 0x10, false)
            fakeboy.addSprite(0x0F, Self.poop.x + 0x10, Self.y + 0x08, false)
            fakeboy.addSprite(0x0E, Self.poop.x + 0x08, Self.y + 0x08, false)
        end

        if Self.reverse then
            fakeboy.addSprite(leg + 0x02, Self.x + 0x10, Self.y + 0x10, false)
            fakeboy.addSprite(leg + 0x01, Self.x + 0x08, Self.y + 0x10, false)
            fakeboy.addSprite(leg + 0x00, Self.x + 0x00, Self.y + 0x10, false)
            fakeboy.addSprite(tail + 0x10, Self.x + 0x10, Self.y + 0x08, false)
            fakeboy.addSprite(head + 0x11, Self.x + 0x08, Self.y + bob + 0x08, false)
            fakeboy.addSprite(head + 0x10, Self.x + 0x00, Self.y + bob + 0x08, false)
            fakeboy.addSprite(tail + 0x00, Self.x + 0x10, Self.y + 0x00, false)
            fakeboy.addSprite(head + 0x01, Self.x + 0x08, Self.y + bob + 0x00, false)
            fakeboy.addSprite(head + 0x00, Self.x + 0x00, Self.y + bob + 0x00, false)
        else
            fakeboy.addSprite(leg + 0x02, Self.x + 0x10 - 0x10, Self.y + 0x10, true)
            fakeboy.addSprite(leg + 0x01, Self.x + 0x10 - 0x08, Self.y + 0x10, true)
            fakeboy.addSprite(leg + 0x00, Self.x + 0x10 - 0x00, Self.y + 0x10, true)
            fakeboy.addSprite(tail + 0x10, Self.x + 0x10 - 0x10, Self.y + 0x08, true)
            fakeboy.addSprite(head + 0x11, Self.x + 0x10 - 0x08, Self.y + bob + 0x08, true)
            fakeboy.addSprite(head + 0x10, Self.x + 0x10 - 0x00, Self.y + bob + 0x08, true)
            fakeboy.addSprite(tail + 0x00, Self.x + 0x10 - 0x10, Self.y + 0x00, true)
            fakeboy.addSprite(head + 0x01, Self.x + 0x10 - 0x08, Self.y + bob + 0x00, true)
            fakeboy.addSprite(head + 0x00, Self.x + 0x10 - 0x00, Self.y + bob + 0x00, true)
        end
        fakeboy.addSprite(bubble + 0x11, Self.x + 0x08, Self.y + bob + 0x08 - 0x10, false)
        fakeboy.addSprite(bubble + 0x10, Self.x + 0x00, Self.y + bob + 0x08 - 0x10, false)
        fakeboy.addSprite(bubble + 0x01, Self.x + 0x08, Self.y + bob + 0x00 - 0x10, false)
        fakeboy.addSprite(bubble + 0x00, Self.x + 0x00, Self.y + bob + 0x00 - 0x10, false)
    end
end