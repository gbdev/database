do fakeboy = {}
    local Self = fakeboy

    Self.screen = plum.Screen(160, 144, 3)
    Self.key = Self.screen.key

    Self.map = plum.Tilemap(32, 32)
    Self.tileset = {
        image = nil;
        sheet = nil;
    }
    Self.spriteset = {
        image = nil;
        sheet = nil;
    }

    Self.transform = plum.Transform()
    Self.sprites = {}
    for i = 1, 40 do
        table.insert(Self.sprites, {x = -8, y = -16, tile = 0, mirror = false})
    end
    Self.spriteCount = 0

    Self.clearSprites = function()
        for i, sprite in ipairs(Self.sprites) do
            sprite.x = -8
            sprite.y = -16
            sprite.tile = 0
            sprite.mirror = false
        end
        Self.spriteCount = 0
    end

    Self.addSprite = function(tile, x, y, mirror)
        Self.spriteCount = Self.spriteCount + 1
        Self.sprites[Self.spriteCount].x = x
        Self.sprites[Self.spriteCount].y = y
        Self.sprites[Self.spriteCount].tile = tile
        Self.sprites[Self.spriteCount].mirror = mirror
    end

    Self.loop = function(update)
        while true do
            for i = 1, plum.timer.gap do
                Self.clearSprites()
                if update() then
                    return
                end
            end

            Self.screen:clear(0, 0, Self.screen.width, Self.screen.height, plum.color.White)
            if Self.tileset.image and Self.tileset.sheet then
                Self.map:draw(Self.tileset.image, Self.tileset.sheet, 0, 0, Self.screen)
            end
            if Self.spriteset.image and Self.spriteset.sheet then
                local mirror = false
                Self.transform.mirror = mirror

                for i, sprite in ipairs(Self.sprites) do
                    if sprite.mirror ~= mirror then
                        mirror = sprite.mirror
                        Self.transform.mirror = mirror
                    end
                    Self.spriteset.image:drawFrame(Self.spriteset.sheet, sprite.tile, sprite.x, sprite.y, Self.transform, Self.screen)
                end
            end
            plum.refresh()
        end
    end
end