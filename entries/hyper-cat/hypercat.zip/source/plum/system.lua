require 'fakeboy'
require 'text'
require 'random'
require 'kitty'

fakeboy.screen.title = 'hypercat'
fakeboy.tileset.image = plum.Image('bwcrapfont.png')
fakeboy.tileset.sheet = plum.Sheet(8, 8, fakeboy.tileset.image)
fakeboy.spriteset.image = plum.Image('gbcat.png')
fakeboy.spriteset.sheet = plum.Sheet(8, 8, fakeboy.spriteset.image)

fakeboy.map:clear(26)
text.print(1, 3, text.string.Title, fakeboy.map)
text.print(4, 6, text.string.PressStart, fakeboy.map)
text.print(1, 15, text.string.AndrewGCrowell, fakeboy.map)

random.init()
kitty.init()
fakeboy.loop(function()
    random.next()
    return fakeboy.key.A.pressed
end)

fakeboy.key.A.pressed = false

fakeboy.map:clear(26)
text.print(1, 1, text.string.Love, fakeboy.map)
text.print(1, 2, text.string.Food, fakeboy.map)
text.print(3, 13, text.string.Hug, fakeboy.map)
text.print(3, 14, text.string.Feed, fakeboy.map)
text.print(3, 15, text.string.Clean, fakeboy.map)
text.print(3, 16, text.string.Lights, fakeboy.map)

kitty.init()
fakeboy.loop(function()
    random.next()

    kitty.drawHUD()
    kitty.updateMenu()
    kitty.update()
end)