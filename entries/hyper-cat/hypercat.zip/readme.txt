H Y P E R   C A T

by Andrew G. Crowell (@Bananattack)


Hypercat is a virtual pet simulator game! Take care of HYPERCAT and keep it well-fed and happy!

This is an entry for GBJAM 2, and is an actual Game Boy game written in GBZ80 assembly. Written in Wiz, a high-level assembly language. Run with run.bat to use the included bgb emulator on windows, or use an emulator of your choice.

Controls
--------
Up/Down = move cursor
A = confirm

(note: the X key on your keyboard is = A in BGB)

Display
-------

LOVE - the current relationship between you and HYPERCAT, measuring how much it likes you on a scale of 0-4.
FOOD - how hungry HYPERCAT is at the moment. Wait too long, and HYPERCAT will be hungry.

Actions
-------

Hug - lavish your attention on HYPERCAT. Do this enough and HYPERCAT will learn to love you.
Feed - feed HYPERCAT some food. HYPERCAT has very specialized dietary needs, and will only eat pepperoni pizza. Make sure you don't overfeed!
Clean - when HYPERCAT poops, it leaves an undesirable stench. You should clean this up or HYPERCAT will be out of control!
Lights - when HYPERCAT sleeps, you need to turn out the lights to make sure it rests adequately. Just don't do it when HYPERCAT is awake.

About Source
------------

Copyright (c) 2013 Andrew G. Crowell (Bananattack)
All rights reserved.

Redistribution and use in source and binary forms, with or without
modification, are permitted provided that the following conditions are met:

1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.
2. Redistributions in binary form must reproduce the above copyright
   notice, this list of conditions and the following disclaimer in the
   documentation and/or other materials provided with the distribution.
3. Neither the name of HYPERCAT nor the names of its contributors may be
   used to endorse or promote products derived from this software without
   specific prior written permission.

THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS" AND
ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE ARE
DISCLAIMED. IN NO EVENT SHALL HYPERCAT CONTRIBUTORS BE LIABLE FOR ANY
DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND
ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT
(INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.


About Wiz
---------

Wiz is a work-in-progress high-level assembly language compiler, which has not been released yet.

The source code repo is https://github.com/Bananattack/wiz

It supports GBZ80 assembly targets, as well as 6502 targets (NES/C64/Atari etc).

I want to release it some day, and could use help if there is actually an audience for it.
It needs (a lot of) documentation, better/more examples, more helpful libraries, some bugfixes, a port for Mac.
The code is written in D, so if you wanna help me compile it for other platforms or add to the source, feel free to help!



