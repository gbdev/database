DMG*P-01 by Genesies*Project

Code: Shadow
Graphics: Illm
Music: Z-nexx
Platform: Gameboy classic
Release date: 2013-02-09
Release party: Datastorm 2013

Note that the while the demo should run on all Gameboys (even newer
ones like Gameboy color) the 10-color gradient effect used in many
parts of the demo looks best on old, slow LCD models like the 
original DMG-01!