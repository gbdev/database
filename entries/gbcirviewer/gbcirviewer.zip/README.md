# IR signal viewer for Gameboy color
IrViewer has been realized by GBC own feature. 

# License
Copyright (c) Osamu OHASHI  
Distributed under the MIT License either version 1.0 or any later version. 
