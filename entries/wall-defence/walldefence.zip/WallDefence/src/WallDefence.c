/* Wall Defence by Ventzislav Tzvetkov http://drhirudo.hit.bg

Coded from scratch for the PDROMs coding competition 2.5

Works on Classic and Color Gameboys.

compile with:
lcc -Wl-yp0x143=0x80 WallDefence.c -o WallDefence.gbc

Also available for Amiga, Oric and Sinclair.

*/

char Scroll[]="                     Hello and welcome to Wall Defence - an entry for PD ROMs coding competition 2.5, about creating LCD type game. To play the game press -START- and use the D-Pad to move and use A button to get a stone or B button to throw a stone. GOOD LUCK!!! ................ No the scroll didn't restart... This game is also available for Amiga (best version so far), Oric Atmos (placed 35th out of 62 in the Minigame Compo 2002), and Sinclair Spectrum - done recently and main base for this remake. More info is available from my website, which is written somewhere in the text document or in case you didn't want to read it - here it is: http://drhirudo.hit.bg . Currently the access is kinda slow, but I hope I will move it somewhere else soon, as soon as I find a reliable host. So you read it so far and you are still here. Ok here is my greeting list: All the people coding and enjoying the old (called nowadays retro) platforms - including Sega Master System, GameBoy Classic, Commodore 64, Amiga 500 and Amiga 1200, Amstrad CPC, Oric Atmos, Sinclair ZX Spectrum, Apple 2, Nintendo Entertainment System, Super Famicom, Vic-20, Dragon 32, TRS-80 and many more, too many to mention all them alone here. Before I forget - watch out for my first SNES release coming soon. Got to go finishing this game now. Bye. Scroll Restarts for Real Now, Yes..............";

#include <gb.h>
#include <drawing.h>
#include <rand.h>
#include <cgb.h>

#include "WallDefenceTiles.h"

// #define CONSOLEFEVER  // Remove for the non compo version.

unsigned int GameBoyMode;

int direction,count;

unsigned int Orc;

UWORD background_palette[] =
{ RGB(0x1f, 0x1f, 0x1f), RGB(0x13, 0x06, 0x00), RGB(0x14, 0x12, 0x12), RGB(0, 0, 0),
  RGB(0x1f, 0x1f, 0x1f), RGB(0x1f, 0x1f, 0x1f), RGB(0x1f, 0x1f, 0x1f), RGB(0x1f, 0x1f, 0x1f),

};

void fadein(){
if (GameBoyMode==CGB_TYPE) set_bkg_palette(0,1,&background_palette[0]);
 else
{BGP_REG = 0x40U;delay(59); BGP_REG = 0x90U;delay(59); BGP_REG = 0xE4U;}}

void fadeout() {
     if(GameBoyMode==CGB_TYPE) set_bkg_palette( 0, 1, &background_palette[4] ); else 
{    BGP_REG = OBP0_REG = OBP1_REG = 0x90U;
     delay(59); BGP_REG = OBP0_REG = OBP1_REG = 0x40U;
     delay(59); NR52_REG = BGP_REG = OBP0_REG = OBP1_REG = 0x00U;}HIDE_SPRITES;}

unsigned long Score,TmpScore,HighScore,K=100,Lives,CO,F;

char Scores[6],Level,X,SX,KX,Throw,hold,B[20],C,E;

void sound1()
{

NR52_REG = 128; /* make sure sound is enabled */
NR51_REG = 0x22; /* send sound to left and rignt */


NR10_REG = 0x00;
NR11_REG = 0x81;
NR12_REG = 0x43;
NR13_REG = 0x73;
NR14_REG = 0x06;
NR21_REG = 0x80;
NR22_REG = 0x31;
NR23_REG = 0x30;
NR24_REG = 0x07;
NR30_REG = 0x80;
NR31_REG = 0x00;
NR32_REG = 0x20;
NR33_REG = 0xd6;
NR34_REG = 0x06;
NR41_REG = 0x3b;
NR42_REG = 0xa1;
NR43_REG = 0x00;
NR44_REG = 0x40;
NR50_REG = 0x77;
}

void sound2()
{

NR52_REG = 128; /* make sure sound is enabled */
NR51_REG = 0x22; /* send sound to left and rignt */

NR10_REG = 127;

NR22_REG = 34;
NR23_REG = 180;
NR24_REG = 135;
}

void sound3()
{

NR52_REG = 128; /* make sure sound is enabled */
NR51_REG = 255; /* send sound to left and rignt */

NR10_REG = 127;

NR11_REG = 0;
NR12_REG = 242;
NR13_REG = 180;
NR14_REG = 135;

}


void CalculateScore() /* Converts the Score to String. Score stays untouched */
{TmpScore=Score;
Scores[0]=(TmpScore/10000)+0x10U; TmpScore=TmpScore%10000;
Scores[1]=(TmpScore/1000)+0x10U;   TmpScore=TmpScore%1000;
Scores[2]=(TmpScore/100)+0x10U;     TmpScore=TmpScore%100;
Scores[3]=(TmpScore/10)+0x10U;       TmpScore=TmpScore%10;
Scores[4]=TmpScore+0x10U;
}

void CalculateScoreT() /* Converts the Score to String. Score stays untouched */
{TmpScore=Score;
ScoresTiles[0]=(TmpScore/10000); TmpScore=TmpScore%10000;
ScoresTiles[1]=(TmpScore/1000);   TmpScore=TmpScore%1000;
ScoresTiles[2]=(TmpScore/100);     TmpScore=TmpScore%100;
ScoresTiles[3]=(TmpScore/10);       TmpScore=TmpScore%10;
ScoresTiles[4]=TmpScore;
if (Score%5000==0) Lives++;
}

void main() {

BGP_REG = OBP0_REG = OBP1_REG = GameBoyMode = 0x00U;
if(_cpu==CGB_TYPE) {    // Color GameBoy detected
    /* Transfer color palette */
    set_bkg_palette( 0, 1, &background_palette[4] );
    GameBoyMode=CGB_TYPE;}
SPRITES_8x8;HIDE_BKG;DISPLAY_ON;HIDE_WIN;HIDE_SPRITES;mode (M_NO_SCROLL);
disable_interrupts();move_bkg(0,0);
color( BLACK, WHITE, SOLID);
#ifdef CONSOLEFEVER
gotogxy(0,8);gprint("www.consolefever.com");
#else
gotogxy(0,8);gprint("  drhirudo.hit.bg   ");
#endif

SHOW_BKG;fadein();sound2();delay(1800);

fadeout();

// Game Main cycle

gotogxy (0,0);color( BLACK, WHITE, SOLID);
gprint ("� HighScore  ----- �");gotogxy (0,1);
gprint ("��������������������");gotogxy (0,2);
gprint ("��������������������");gotogxy (0,3);
gprint ("�                  �");gotogxy (0,4);
gprint ("�  WALL   DEFENCE  �");gotogxy (0,5);
gprint ("�                  �");gotogxy (0,6);
gprint ("��������������������");gotogxy (0,7);
gprint ("��������������������");gotogxy (0,8);
gprint ("��������������������");gotogxy (4,11);
gprint ("by drHirudo");
Score=HighScore;CalculateScore();
gotogxy(13,0);gprint(Scores);
fadein();

for (;;) {count++;
wait_vbl_done();

for (direction=0;direction!=20;direction++)
{gotogxy(0+direction,15);wrtchr (Scroll[TmpScore+direction]);}
if (++TmpScore==1350) TmpScore=0;
wait_vbl_done();wait_vbl_done();
if (!(TmpScore%450)) {
gotogxy (4,11);gprint ("by drHirudo");
gotogxy (4,13);gprint ("           ");}

if (!(TmpScore%900)) {
gotogxy (4,11);gprint ("           ");
color( WHITE, BLACK, SOLID);
gotogxy (4,12);gprint ("by drHirudo");

color( BLACK, WHITE, SOLID);

}

if (!(TmpScore%1350)) {
gotogxy (4,12);gprint ("           ");
gotogxy (4,13);gprint ("by drHirudo");}

wait_vbl_done();
if (joypad() & J_START) break;
wait_vbl_done();
}

initrand(count);

fadeout();disable_interrupts();display_off();move_bkg(0,0);
set_bkg_data(0,0x33,image_data);Level=1;E=10;
set_bkg_tiles(0,0,20,4,screen_tiles);
for (count=4;count!=18;count++)
set_bkg_tiles(0,count,20,1,bricks_tiles);

DISPLAY_ON;fadein();
for (;;)
 {

Score=0;CalculateScoreT();
set_bkg_tiles(6,0,5,1,ScoresTiles);
LevelNumber_tile[0]=Level+1;set_bkg_tiles(19,0,1,1,LevelNumber_tile);

X=9;Lives=3;CO=37;
for(;;)
 {SX=0;F=hold=Throw=0;
 set_bkg_tiles(6,0,5,1,ScoresTiles);
 LevelNumber_tile[0]=Level;set_bkg_tiles(19,0,1,1,LevelNumber_tile);
 delay(50);for(count=0;count!=3;count++){
 set_bkg_tiles(7,1,6,1,ReadyText_tiles);
 delay(600);
 set_bkg_tiles(7,1,6,1,EmptyText_tiles);delay(200);}

/* Game */
 for (;;)
  {
  delay(20-Level);
  if (Throw) {set_bkg_tiles(SX,Throw++,1,1,Brick_tile);
              set_bkg_tiles(SX,Throw,1,1,FallingStone_tile);
  if (Orc==Throw) {sound2();CalculateScoreT();}
}

  delay(20-Level);
  if (Throw) {set_bkg_tiles(SX,Throw++,1,1,Brick_tile);
              if (Orc==Throw) {sound2();CalculateScoreT();}
  if (Throw==18) {Throw=hold=0;set_bkg_tiles(KX,2,1,1,PlacedStone_tile);KX=0;
  if (CO==37 && Orc) {Level+=(Level<9);K+=15;Orc=0;break;}
  Orc=0;
   }
  else {set_bkg_tiles(SX,Throw,1,1,FallingStone_tile);}
  }
 set_bkg_tiles(6,0,5,1,ScoresTiles);
 delay(10-Level);
 direction=joypad();
  if (direction==J_A && !hold)
   {
   	   if ((X==1 || /* X==9 || X==10 ||*/ X==18) && KX!=X && !Throw)
   	   {
   	   	hold=1;set_bkg_tiles(X,3,1,1,ManStone_tile);KX=X;
                set_bkg_tiles(X,2,1,1,RemovedStone_tile);
   	   }
   }
                          
   if (direction&J_LEFT && X>1) {set_bkg_tiles(X,3,1,1,Empty_tile);X--;
                                 if (hold)
                                  set_bkg_tiles(X,3,1,1,ManStone_tile);
                                 else
                                  set_bkg_tiles(X,3,1,1,Man_tile);
                                 } // LControl
   if (direction&J_RIGHT && X<18) {set_bkg_tiles(X,3,1,1,Empty_tile);X++;
                                 if (hold)
                                  set_bkg_tiles(X,3,1,1,ManStone_tile);
                                 else
                                  set_bkg_tiles(X,3,1,1,Man_tile);
                                 }

if (direction&J_B && hold) {hold=0;Throw=4;SX=X;
 if (B[SX]) {CO++;F+=B[SX]; Orc=18-B[SX]; Score+=B[SX];B[SX]=0;}
 set_bkg_tiles(X,3,1,1,Man_tile);
 }

if (direction&J_START) {NR42_REG=0;set_bkg_tiles(7,2,6,1,PausedText_tiles);
sound2();delay(350);while(!(joypad()&J_START));
sound2();delay(350);set_bkg_tiles(7,2,6,1,EmptyText_tiles);}

if (--E==Level) {E=12;C=rand()%18+1;if (B[C]==0 && F>K) continue;
   sound1();CO-=(B[C]==0);
   if (B[C]==14) {
   set_bkg_tiles(C,18-B[C],1,1,Ladder_tile);
   set_bkg_tiles(C,3,1,1,OrcUp_tile);
   delay(18-Level);delay(18-Level);delay(18-Level);
   if (X<C) SX=-1;else SX=1;B[C]=0;CO++;
   while (C!=X)
    {delay(18-Level);
      set_bkg_tiles(C,3,1,1,Empty_tile);
      C+=SX;
      set_bkg_tiles(C,3,1,1,OrcUp_tile);
      delay(30);   
    }
   sound3();
   for (count=4;count!=17;count++)
   { delay(18-Level);
  if (Throw) {set_bkg_tiles(SX,Throw++,1,1,Brick_tile);
  color( BLACK,WHITE,SOLID);
  if (Orc==Throw) {sound2();}
  if (Throw==18) {Throw=hold=0;set_bkg_tiles(KX,2,1,1,PlacedStone_tile);KX=0;
  Orc=0;
   }
  else {set_bkg_tiles(SX,Throw,1,1,FallingStone_tile);}
  }

      set_bkg_tiles(X,count,1,1,Brick_tile);
      set_bkg_tiles(X,count+1,1,1,FallingMan_tile);
     delay(30);
   }
if (B[X]) {CO++;F+=B[X]; Score+=B[X];B[X]=0;CalculateScoreT();}
set_bkg_tiles(X,3,1,1,Empty_tile);Lives--;X=9;
       if (Lives) {set_bkg_tiles(X,3,1,1,Man_tile);hold=0;
        set_bkg_tiles(KX,2,1,1,PlacedStone_tile);KX=0;}
if (CO==37) {Level+=(Level<9);K+=15;}break;}
    else B[C]++;
   if (B[C]==1) {set_bkg_tiles(C,18-B[C],1,1,Orc_tile);}
               else
                {set_bkg_tiles(C,18-B[C],1,1,Orc_tile);
                 set_bkg_tiles(C,19-B[C],1,1,Ladder_tile);
                }
   }
  }
 if (Lives==0) break;
 }
set_bkg_tiles(6,0,5,1,ScoresTiles);
if (HighScore<Score) for (count=0;count!=8;count++) {
HighScore=Score;
if ((joypad() & J_START) || (joypad() & J_A) || (joypad() & J_B)) break;
set_bkg_tiles(6,0,5,1,ScoresTiles);sound2();delay(700);
if ((joypad() & J_START) || (joypad() & J_A) || (joypad() & J_B)) break;
set_bkg_tiles(6,0,5,1,EmptyText_tiles);delay(350);sound2();
if ((joypad() & J_START) || (joypad() & J_A) || (joypad() & J_B)) break;
} else delay(1000);
 for (count=1;count!=19;count++) B[count]=0;Level=1;
set_bkg_tiles(0,0,20,4,screen_tiles);
for (count=4;count!=18;count++)
set_bkg_tiles(0,count,20,1,bricks_tiles);
Score=HighScore;CalculateScoreT();set_bkg_tiles(6,0,5,1,ScoresTiles);
set_bkg_tiles(7,1,6,1,EmptyText_tiles);
while(!(joypad()&J_START || joypad()&J_A||joypad()&J_B));

  }
}

