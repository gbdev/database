Back to Earth 3D

First person 3d shooter for GBC.
Actually you can't shoot anything because you haven't
a weapon and will not find any target.
You just can wander in the tunnels of the simple test level.

It will work on real hardware or No$GMB.
No one other emulator can run it properly (at this time).

We just doesn't have a reason to continue the development,
so bugs are still exist and sprites isn't implemented
completely.

Now we focused on AGB development.

If you are interested in quality GameBoy Advance
production, contact us.

We would like to cooperate.

web : http://r-lab.8m.com [or http://r-lab.nm.ru]
mail: r-lab@mail.ru