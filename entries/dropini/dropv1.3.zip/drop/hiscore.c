#include <gb.h>
#include "tiles\highscore_table.c"

const UBYTE cOFFSET = 128;

static const unsigned char cHIGHSCORE[] = 
"     High Scores    ";

void wait_for_start (void)
{
  UBYTE jpad,last,delay;
  unsigned char cursor;

  jpad = 0;
  last = 0;
  cursor = 28+cOFFSET;
  delay = 0;

  set_bkg_tiles(18,16,1,1,&cursor);

  jpad = joypad();

  while ((jpad & J_SELECT) || (jpad & J_START) || 
         (jpad & J_B) || (jpad & J_A))
  {
    jpad = joypad();
    wait_vbl_done();

    delay ++;
    if (delay==20)
    {
      delay=0;
      cursor++;
      if (cursor == 32+cOFFSET)
        cursor=28+cOFFSET;
      set_bkg_tiles(18,16,1,1,&cursor);
    }
  }

  wait_vbl_done();

  while (((jpad & J_SELECT) == 0) && ((jpad & J_START) == 0)
         && ((jpad & J_B) == 0) && ((jpad & J_A) == 0) )
  {
    jpad = joypad();
    wait_vbl_done();

    delay ++;
    if (delay==20)
    {
      delay=0;
      cursor++;
      if (cursor == 32+cOFFSET)
        cursor=28+cOFFSET;
      set_bkg_tiles(18,16,1,1,&cursor);
    }
  }

  wait_vbl_done();

  while ((jpad & J_SELECT) || (jpad & J_START) 
         || (jpad & J_B) || (jpad & J_A) )
  {
    jpad = joypad();
    wait_vbl_done();

    delay ++;
    if (delay==20)
    {
      delay=0;
      cursor++;
      if (cursor == 32+cOFFSET)
        cursor=28+cOFFSET;
      set_bkg_tiles(18,16,1,1,&cursor);
    }
  }
}

static void put_number (UBYTE posx, UBYTE posy, unsigned long int s)
{
  UBYTE x;
  unsigned char t;

  x = (s / 10000) % 10;
  t = (unsigned char) x+48+cOFFSET;
  if (s >9999)
    set_bkg_tiles (posx,posy,1,1,&t);   

  x = (s / 1000) % 10;
  t = (unsigned char) x+48+cOFFSET;
  if (s > 999)
    set_bkg_tiles (posx+1,posy,1,1,&t);   

  x = (s / 100) % 10;
  t = (unsigned char) x+48+cOFFSET;
  if (s > 99)
    set_bkg_tiles (posx+2,posy,1,1,&t);   

  x = (s / 10) % 10;
  t = (unsigned char) x+48+cOFFSET;
  if (s > 9) 
    set_bkg_tiles (posx+3,posy,1,1,&t);   

  x = s % 10;
  t = (unsigned char) x+48+cOFFSET;
  set_bkg_tiles (posx+4,posy,1,1,&t);   

}

static void put_score (UBYTE pos)
{
  unsigned long int s;
  UBYTE x;
  unsigned char t;
  extern unsigned long int scores[5];
 
  x = (pos+1);
  t = (unsigned char) x+48+cOFFSET;
  set_bkg_tiles (0,pos+pos+4,1,1,&t);   
  
  s = scores[pos];
  put_number (2,pos+4+pos,s);
}

void show_scores (UBYTE row)
{
  UBYTE e,x;
  unsigned char c;

  extern UBYTE word[5][12];
  
  DISPLAY_OFF;
  HIDE_BKG;

  empty_screen ();
  
  if( _cpu==CGB_TYPE )
  {
    /* background palette */
    set_bkg_palette_entry(0,0,RGB(0,0,0));
    set_bkg_palette_entry(0,1,RGB(31,0,31));
    set_bkg_palette_entry(0,2,RGB(31,0,0));
    set_bkg_palette_entry(0,3,RGB(31,31,31));

    set_bkg_palette_entry(1,0,RGB(31,0,0));
    set_bkg_palette_entry(1,1,RGB(31,0,31));
    set_bkg_palette_entry(1,2,RGB(31,0,0));
    set_bkg_palette_entry(1,3,RGB(0,0,0));
  }

  if (row > 0) // put a heart to show the users score
  {
    c = 124 + cOFFSET;
    set_bkg_tiles(1,row+row+2,1,1,&c);
  }
  
  // put in the highscores titlebar
  for (x=0;x<20;x++)
  {
    c = cHIGHSCORE[x];
    c = c+cOFFSET;
    set_bkg_tiles(x,1,1,1,&c);   
  }  


  for (e = 0;e<5;e++)
  {
    for (x = 0;x<12;x++)
    {
      c = word[e][x];
      if (c==0)
        c = 32+cOFFSET;
      //else
      //  c = c+cOFFSET;
      set_bkg_tiles(8+x,4+e+e,1,1,&c);   
    }
    put_score(e);
  }

  SHOW_BKG;
  DISPLAY_ON;

  wait_for_start();

}

static void set_pointers (UBYTE x,UBYTE y)
{
  unsigned char left;
  unsigned char right;
 
  left = 62+cOFFSET;
  right = 60+cOFFSET;

  if (y==6)
  {
    if (x==0)
    {
      set_bkg_tiles(5,5+y+y,1,1,&left);
      set_bkg_tiles(10,5+y+y,1,1,&right);
    }
    if (x==1)
    {
      set_bkg_tiles(10,5+y+y,1,1,&left);
      set_bkg_tiles(14,5+y+y,1,1,&right);
    }
    if (x==2)
    {
      set_bkg_tiles(14,5+y+y,1,1,&left);
      set_bkg_tiles(18,5+y+y,1,1,&right);
    }
  }
  else
  {  
    set_bkg_tiles(0+x+x,5+y+y,1,1,&left);
    set_bkg_tiles(2+x+x,5+y+y,1,1,&right);
  }
}

static void del_pointers (UBYTE x,UBYTE y)
{
  unsigned char left;
  unsigned char right;
 
  left = 32+cOFFSET;
  right = 32+cOFFSET;
  if (y==6)
  {
    if (x==0)
    {
      set_bkg_tiles(5,5+y+y,1,1,&left);
      set_bkg_tiles(10,5+y+y,1,1,&right);
    }
    if (x==1)
    {
      set_bkg_tiles(10,5+y+y,1,1,&left);
      set_bkg_tiles(14,5+y+y,1,1,&right);
    }
    if (x==2)
    {
      set_bkg_tiles(14,5+y+y,1,1,&left);
      set_bkg_tiles(18,5+y+y,1,1,&right);
    }
  }
  else
  {  
    set_bkg_tiles(0+x+x,5+y+y,1,1,&left);
    set_bkg_tiles(2+x+x,5+y+y,1,1,&right);
  }
}
  
static UBYTE set_letter (UBYTE l,UBYTE x, UBYTE y, UBYTE upper_lower)
{
  unsigned char c;
  c = highscore_table_map[x+x+41+(20*y)] + cOFFSET;
  if ((upper_lower == 1) && (y < 3))
  {
    c = c + 32;
    if ((x == 8) && (y == 2)) 
      c = c-32;
  }
  set_bkg_tiles(3+l,3,1,1,&c);
  return (UBYTE) c;
}

/* put up the name getting screen */
void hs_letter (UBYTE cs)
{
  UBYTE e,x,l;

  for (e = 2 ; e < 5 ; e++)  
  for (x = 1 ; x < 19 ; x = x + 2)
  {
    l = highscore_table_map[(20*e)+x] +cOFFSET;
    if (cs == 1) // lowercase
    {
      if (!((x==17) && (e==4)))
        l=l+32;
    }
    set_bkg_tiles(x,1+e+e,1,1,(unsigned char *) &l);
  }
}

void get_word (UBYTE *str)
{
  UBYTE e;
  UBYTE x,y;
  UBYTE jpad,last;
  UBYTE l,cs;
  UBYTE end;
  UBYTE delay;
  UBYTE pos;
  unsigned char cursor;

  for (x=0;x<12;x++)
    str[x]=0;

  delay = 0;
  end=0;
  last=0,jpad=0;
  cursor = 28 + cOFFSET;

  DISPLAY_OFF;
  HIDE_BKG;

  empty_screen ();
  
  if( _cpu==CGB_TYPE )
  {
    /* background palette */
    set_bkg_palette_entry(0,0,RGB(0,0,0));
    set_bkg_palette_entry(0,1,RGB(31,0,31));
    set_bkg_palette_entry(0,2,RGB(31,0,0));
    set_bkg_palette_entry(0,3,RGB(31,31,31));
  }
  
  for (e=0;e<9;e++)  
  for (x=0;x<20;x++)
  {
    l = highscore_table_map [(20*e)+x]+cOFFSET ;
    set_bkg_tiles(x,1+e+e,1,1,(unsigned char *) &l);
  }
 
  cs = 0;
  x = y = 0; 
  l=1;
  set_pointers(x,y);
  
  SHOW_BKG;
  DISPLAY_ON;
  
  set_bkg_tiles(3+l,3,1,1,&cursor);
  
  while (end ==0 )
  {
    last=jpad;
    wait_vbl_done();
    jpad=joypad();
    if ((jpad & J_UP) && !(last & J_UP))
    {
      
      del_pointers(x,y);  
      if (y==6)
      {
        if (x == 0)
          x=3;
        else if (x == 1)
          x=5;
        else
          x=7;
      }
      y=(y+6) % 7;    
      if (y==6)
      {
        if (x <5)
          x=0;
        else if (x < 7)
          x=1;
        else
          x=2;
      }
      set_pointers(x,y);
    }
    if ((jpad & J_DOWN) && !(last & J_DOWN))
    {
      del_pointers(x,y);  
      if (y==6)
      {
        if (x == 0)
          x=3;
        else if (x == 1)
          x=5;
        else
          x=7;
      }
      y=(y+8) % 7;    
      if (y==6)
      {
        if (x <5)
          x=0;
        else if (x < 7)
          x=1;
        else
          x=2;
      }
      set_pointers(x,y);
    }
    if ((jpad & J_LEFT) && !(last & J_LEFT))
    {
      del_pointers(x,y);  
      if (y==6)
      {
        x = (x + 2) % 3;
      }
      else
      {
        x=(x+8) % 9;    
      }
      set_pointers(x,y);
    }
    if ((jpad & J_RIGHT) && !(last & J_RIGHT))
    {
      del_pointers(x,y);  
      if (y==6)
      {
        x = (x + 4) % 3;
      }
      else
      {
        x = (x + 10) % 9;    
      }
      set_pointers(x,y);
    }
    if ((jpad & J_A) && !(last & J_A))
    {
      if ((l<13) && (y != 6))
      {
        e = set_letter(l,x,y,cs);
        str[l-1] = e;
        if (e == 160) //space
        {
          cs = 0;
          hs_letter (cs);
        }
        else if (cs==0) // after the first letter, goto lower case
        {
          cs = 1;
          hs_letter (cs);
        }
        l++;
      }
      if (y==6)
      {
        if (x == 0) // swap upper / lower case
        {
          cs = 1 - cs;
          hs_letter (cs);
        }

        if (x == 1) // del
        {
          jpad = J_B;
        }
        if (x == 2) // end
        {
          end=1;
        }
      }
      if (l<13)
        set_bkg_tiles(3+l,3,1,1,&cursor);
    }
    if ((jpad & J_B) && !(last & J_B))  
    {
      if (l>1)
      {
        unsigned char c;
 
        c = 0;
        set_bkg_tiles(2+l,3,1,1,&c);
        str[l-1]=0;
        str[l-2] = 0;
        l--;
        if (l==1)
        {
          cs = 0;
          hs_letter (cs);
        }
        if (l<12)
          set_bkg_tiles(4+l,3,1,1,&c);
        if (l<13)
          set_bkg_tiles(3+l,3,1,1,&cursor);
      }
    }
    if ((jpad & J_SELECT) && !(last & J_SELECT))  
    {
      cs = 1 - cs;
      hs_letter (cs);
    }

    delay ++;
    if (delay==20)
    {
      delay=0;
      cursor++;
      if (cursor == 160)
        cursor = 156;
      if (l<13)
        set_bkg_tiles(3+l,3,1,1,&cursor);
    }
  }
}

/* returns 0 if no score added, pos if new score added */
UBYTE add_new_score (unsigned long int new_score)
{
  extern UBYTE word[5][12];
  UBYTE temp[12];  
  extern unsigned long int scores[5];
  UBYTE e;
  BYTE x,y;

  if (new_score < scores[4])
    return 0;

  /* find where the score will go */
  for (x=4;x>-1;x--)  
  {
    if (new_score >= scores[x])
      e = x;
  }

  /* copy old names + scores down 1 pos */
  if (e<4)
  {
    for (x=3;x+1>e;x--)
    {
      for (y=0;y<12;y++)
        word[x+1][y]=word[x][y];
      scores[x+1]=scores[x];
    }
  }

  get_word ((UBYTE *)&word[e][0]);
  scores[e] = new_score;

  return e+1;
}

void save_hiscore(UBYTE num)
{
  extern long sc_score;
  extern unsigned long int scores[5];
  extern UBYTE word[5][12];

  long * savescores;
  UBYTE* savenames;
  UBYTE e,x;

  ENABLE_RAM_MBC1;
  savescores = (long *)0xa000;
  savenames = (UBYTE *)0xa000;

  savescores[num*150] = 5124;
  for (e=0;e<5;e++)  
  {
    for (x=0;x<12;x++)
    {
      savenames[(num*300)+100+(e*12)+x] = word[e][x];
    }
    savescores[(num*150)+10+e] = scores[e]; 
  }
  savescores[(num*150)+21] = sc_score;

  DISABLE_RAM_MBC1;
}

void load_hiscore(UBYTE num)
{
  extern long sc_score;
  extern unsigned long int scores[5];
  extern UBYTE word[5][12];

  long * savescores;
  UBYTE* savenames;
  UBYTE e,x;

  ENABLE_RAM_MBC1;

  savescores = (long *)0xa000;
  savenames = (UBYTE *)0xa000;

  if (savescores[num*150] == 5124) 
  {
    for (e=0;e<5;e++)  
    {
      for (x=0;x<12;x++)
      {
        word[e][x] = savenames[(num*300)+100+(e*12)+x];
      }
      scores[e] = savescores[(num*150)+e+10]; 
    }
  }
  else
  {
    for (e=0;e<5;e++)
    {
      for (x=0;x<12;x++)
      {
        word[e][x] = 0;
      }
      scores[e] = 0;
    }
  }

  DISABLE_RAM_MBC1;
}


