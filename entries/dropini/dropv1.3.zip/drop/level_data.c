#include "tiles\level_data1.c"

char level_name [20][20] = {
"   The Thin Line    ",
"    Mt. Everest     ",
"    Bomb Bunker     ",
"     The Vault      ",
"      The Tomb      ",
"    3 of a kind     ",
"     3 in a row     ",
"    Ampitheater     ",
"     Tuts Tomb      ",
" Flies on the Salad ",
"     Overhang       ",
"      Girder        ",
"  Silver Soup Spoon ",
" Monkey Bites Dragon",
"    Blast Radius 7  ",
"     The Armoury    ",
"   A Tight Squeese  ",
"    Swiss Cheese    ",
"     Pure Hell      ",
"    Maelstorm       "
};


