#include <gb.h>
#include "drop.h"
#include "hiscore.h"

#include "font.c"

extern char level_name [20][20];

char CGB_ONLY1[] = "   Kitty Quest      ";
char CGB_ONLY2[] = "     Press Start    ";
char CGB_ONLY3[] = " Gameboy Color only ";

void check_cgb (void)
{
  unsigned char tmp1, tmp2;

  if( _cpu!=CGB_TYPE )
  {
    HIDE_SPRITES;
    HIDE_BKG;
    HIDE_WIN;

    move_bkg(0,0);
    putln (CGB_ONLY1,7,0);
    putln (CGB_ONLY3,7,0);
  
    SHOW_BKG;
    SHOW_SPRITES;
  
    while (1==1);
  }
}

void add_time (void)
{
  extern UBYTE t_partsec, t_second, t_minute, t_hour, t_day;
  extern UBYTE t2_partsec, t2_second, t2_minute, t2_hour, t2_day;
  
  t2_partsec += t_partsec;
  while (t2_partsec > 59)
  {
    t2_partsec -= 60;
    t2_second ++;
  }
  
  t2_second += t_second;
  while (t2_second > 59)
  {
    t2_second -= 60;
    t2_minute ++;
  }
  
  t2_minute += t_minute;
  while (t2_minute > 59)
  {
    t2_minute -= 60;
    t2_hour ++;
  }
  
  t2_hour += t_hour;
  while (t2_hour > 23)
  {
    t2_hour -= 24;
    t2_day ++;
  }

  // put the result in both sets
  t_second = t2_second;
  t_minute = t2_minute;
  t_hour = t2_hour;
  t_day = t2_day;

}

void show_time (UBYTE y)
{
  extern UBYTE temp1;
  extern UBYTE t_partsec, t_second, t_minute, t_hour, t_day;
  long x;
  long n;
  UBYTE posx = 4;

  VBK_REG = 0;
  
  n = t_day;
  if (n > 0)
  {
    if (n >99) 
    {
      x = (n / 100) % 10;
      temp1 = (unsigned char) x;
      temp1 = temp1+176;
    }
    else 
      temp1 = 160;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;
  
    if (n > 9)
    {
      x = (n / 10) % 10;
      temp1 = (unsigned char) x;
      temp1 = temp1+176;
    }
    else
      temp1 = 160;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;
  
    x = (t_day ) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;
    posx++;
  }
  else 
  {
    posx +=4;
  }

  if ((t_day == 0) && (t_hour == 0))
  {
    posx +=3;
  }
  else
  {
    if ((t_hour > 9) || (t_day > 1))
    {
      x = (t_hour / 10) % 10;
      temp1 = (unsigned char) x;
      temp1 = temp1+176;
    }
    else
      temp1 = 160;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;
  
    x = (t_hour ) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;

    // put a : in
    temp1 = 58+128;
    set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
    posx++;
  }

  x = (t_minute / 10) % 10;
  temp1 = (unsigned char) x;
  temp1 = temp1+176;
  set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
  posx++;

  x = (t_minute ) % 10;
  temp1 = (unsigned char) x;
  temp1 = temp1+176;
  set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
  posx++;

  // put a : in
  temp1 = 58+128;
  set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
  posx++;

  x = (t_second / 10) % 10;
  temp1 = (unsigned char) x;
  temp1 = temp1+176;
  set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
  posx++;

  x = (t_second ) % 10;
  temp1 = (unsigned char) x;
  temp1 = temp1+176;
  set_bkg_tiles (posx,y,1,1,(unsigned char *)&temp1);
  posx++;
  posx++;

}

char GO1[] = "     Game Over      ";
char GO2[] = "     Score:         ";
char GO3[] = "     Lines:         ";
char GO4[] = "     Game Time      ";
char GO5[] = "     Total Time     ";

void gameover (void)
{
  extern UBYTE temp1,temp2;
  extern long sc_score, sc_lines, display_number;
  
  empty_screen();

  if( _cpu==CGB_TYPE )
  {
    /* set the title palettes */
    /* background palette */
    set_bkg_palette_entry(0,0,RGB(0,0,0));
    set_bkg_palette_entry(0,1,RGB(31,0,31));
    set_bkg_palette_entry(0,2,RGB(31,0,0));
    set_bkg_palette_entry(0,3,RGB(31,31,31));

    set_bkg_palette_entry(1,0,RGB(31,0,0));
    set_bkg_palette_entry(1,1,RGB(31,0,31));
    set_bkg_palette_entry(1,2,RGB(31,0,0));
    set_bkg_palette_entry(1,3,RGB(0,0,0));
  }
 
  for (temp1 = 0; temp1<20; temp1++)
  {
    temp2 = GO1[temp1] + 128;
    set_bkg_tiles (temp1,1,1,1,(unsigned char *)&temp2);
    temp2 = GO2[temp1] + 128;
    set_bkg_tiles (temp1,6,1,1,(unsigned char*)&temp2);
    temp2 = GO3[temp1] + 128;
    set_bkg_tiles (temp1,8,1,1,(unsigned char*)&temp2);
    temp2 = GO4[temp1] + 128;
    set_bkg_tiles (temp1,10,1,1,(unsigned char*)&temp2);
    temp2 = GO5[temp1] + 128;
    set_bkg_tiles (temp1,13,1,1,(unsigned char*)&temp2);
  }
  
  display_number = sc_score;
  displaynumber(6);

  display_number = sc_lines;
  displaynumber(8);

  
  show_time (11); 
  add_time ();
  show_time (14);

  delay(600);

  VBK_REG = 0;
  wait_for_start ();

}


// empties the gameboard and displays "GAME OVER" or "YOU WIN"

unsigned char EB1 [] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
unsigned char EB5 [] = {1,1,1,1,1,1,1,1,1,1,1,1,1};
unsigned char EB4 [] = {7,7,7,7,7,7,7,7,7,7,7,7,7};
char EB2 [] = " Good Going  ";
char EB3 [] = "  Try Again  ";

void empty_board (void)
{
  extern UBYTE show_score_t, show_score_x, show_score_y, joy;
  extern unsigned char gametiles [], sc_doiwin;
  extern UBYTE temp1,temp2;
  extern UBYTE sc_combo, show_combo_y;
  UBYTE t1,t2;

  t1 = 2;
  t2 = 0;

  while (t2 < 63)
  {
    t2++;
    wait_vbl_done();

    if (t2 % 3 == 0)
    {
      VBK_REG = 0;
      set_bkg_tiles (1,t1-1,13,1,EB1);
      set_bkg_tiles (1,t1,13,1,EB5);
      VBK_REG = 1;
      set_bkg_tiles (1,t1,13,1,EB5);
      t1 ++;
    }

    // if a score is being shown then count that down
    if (show_score_t > 0)
    {
      show_score_t --;

      if (show_score_t == 0)
      {
        show_score_y = 0;
        show_score();
      }

      if (show_score_t % 10 == 0)
      {
        joy = joypad();

        if (joy & J_LEFT)
          show_score_x --;
        if (joy & J_RIGHT)
          show_score_x ++;

        show_score_y--;
        show_score();
      }
    }

    update_sides();
  }

  VBK_REG = 1;
  set_bkg_tiles (1,8,13,1,EB4);

  if (sc_doiwin == YES)
  {
    VBK_REG = 0;
    for (temp1 = 0; temp1<13; temp1++)
    {
      temp2 = EB2[temp1] + 128;
      set_bkg_tiles (temp1+1,8,1,1,(unsigned char *)&temp2);
    }
    VBK_REG = 1;
  }
  else
  {
    VBK_REG = 0;
    for (temp1 = 0; temp1<13; temp1++)
    {
      temp2 = EB3[temp1] + 128;
      set_bkg_tiles (temp1+1,8,1,1,(unsigned char *)&temp2);
    }
    VBK_REG = 1;
  }    

  wait_for_button();

}


// menu to get difficulty and mode

char MENU1[] = "       Start        ";
char MENU2[] = "       Easy         ";
char MENU3[] = "      Medium        ";
char MENU4[] = "       Hard         ";
char MENU8[] = "       Evil         ";
char MENU5[] = "       Quest        ";
char MENU6[] = "     Practice       ";
char MENU7[] = "     Level          ";

void menu_draw_choice (UBYTE pos, UBYTE val)
{
  UBYTE t;

  if (pos == 1)
  {
    if (val == EASY)
      putln (MENU2,7,0);
    if (val == MEDIUM)
      putln (MENU3,7,0);
    if (val == HARD)
      putln (MENU4,7,0);
    if (val == EVIL)
      putln (MENU8,7,0);
  }
  if (pos == 2)
  {
    if (val == FAST)
    {
      putln (MENU6,11,0);
    }
    else
    {
      putln (MENU5,11,0);
    } 
  }
  if (pos == 3)
  {
    putln (MENU7,14,0);
    putln (level_name[val],15,0);
    val ++;
    if (val > 19)
    {
      t = 178;
      set_bkg_tiles (11,14,1,1,(unsigned char *)&t);
      val = val - 20;
    }
    if (val > 9)
    { 
      t = 177;
      set_bkg_tiles (11,14,1,1,(unsigned char *)&t);
      val = val - 10;
    }
    t = 176+val;
    set_bkg_tiles (12,14,1,1,(unsigned char *)&t);

  }
}

void menu (void)
{
  extern UBYTE sc_difficulty, sc_gametype, start_level;
  extern UBYTE temp1, max_level;

  UBYTE pos = 0;
  UBYTE joy, last;
  UBYTE start = 0;
  UBYTE cnt = 156;
  empty_screen();

  /* background palette */
  set_bkg_palette_entry(0,0,RGB(0,0,0));
  set_bkg_palette_entry(0,1,RGB(31,0,31));
  set_bkg_palette_entry(0,2,RGB(31,0,0));
  set_bkg_palette_entry(0,3,RGB(31,31,31));

  putln (MENU1,3,0);

  menu_draw_choice (1,sc_difficulty);
  menu_draw_choice (2,sc_gametype);
  menu_draw_choice (3,start_level);

  last = joypad ();

  while (start == 0)
  {
    joy = joypad();
    
    if ((joy & J_DOWN ) && !(last & J_DOWN))
    {
      pos = (pos + 1) % 4;
      cnt++;
      if (cnt == 160)
        cnt = 156;
    }
    if ((joy & J_UP) && !(last & J_UP))
    {
      pos = (pos + 3) % 4;
      cnt++;
      if (cnt == 160)
        cnt = 156;
    }

    if ((joy & J_B) && !(last & J_B)) 
    {
      cnt++;
      if (cnt == 160)
        cnt = 156;
      if (pos == 0)
      {
        start = 1;
      }
      if (pos == 1)
      {
        sc_difficulty = (sc_difficulty + 3) % 4; 
        menu_draw_choice (1,sc_difficulty);
      }
      if (pos == 2)
      {
        sc_gametype = (sc_gametype + 1) % 2;
        menu_draw_choice (2,sc_gametype);
      }
      if (pos == 3)
      {
        start_level = (start_level+(max_level-1)) % max_level;
        menu_draw_choice (3,start_level);
      }
    }
 


    if ((joy & J_A) && !(last & J_A)) 
    {
      cnt++;
      if (cnt == 160)
        cnt = 156;

      if (pos == 0)
      {
        start = 1;
      }
      if (pos == 1)
      {
        sc_difficulty = (sc_difficulty + 1) % 4; 
        menu_draw_choice (1,sc_difficulty);
      }
      if (pos == 2)
      {
        sc_gametype = (sc_gametype + 1) % 2;
        menu_draw_choice (2,sc_gametype);
      }
      if (pos == 3)
      {
        start_level = (start_level+1) % max_level;
        menu_draw_choice (3,start_level);
      }
    }
 
    if (pos == 0)
    {
      temp1 = cnt;   
      set_bkg_tiles (0,3,1,1,(unsigned char *) &temp1);
      set_bkg_tiles (19,3,1,1,(unsigned char *)&temp1);
    }
    else
    {
      temp1 = 0;   
      set_bkg_tiles (0,3,1,1,(unsigned char *)&temp1);
      set_bkg_tiles (19,3,1,1,(unsigned char *)&temp1);
    }
    if (pos == 1)
    {
      temp1 = cnt;   
      set_bkg_tiles (0,7,1,1,(unsigned char *) &temp1);
      set_bkg_tiles (19,7,1,1,(unsigned char *)&temp1);
    }
    else
    {
      temp1 = 0;   
      set_bkg_tiles (0,7,1,1,(unsigned char *)&temp1);
      set_bkg_tiles (19,7,1,1,(unsigned char *)&temp1);
    }
    if (pos == 2)
    {
      temp1 = cnt;   
      set_bkg_tiles (0,11,1,1,(unsigned char *) &temp1);
      set_bkg_tiles (19,11,1,1,(unsigned char *)&temp1);
    }
    else
    {
      temp1 = 0;   
      set_bkg_tiles (0,11,1,1,(unsigned char *)&temp1);
      set_bkg_tiles (19,11,1,1,(unsigned char *)&temp1);
    }
    if (pos == 3)
    {
      temp1 = cnt;   
      set_bkg_tiles (0,15,1,1,(unsigned char *) &temp1);
      set_bkg_tiles (19,15,1,1,(unsigned char *)&temp1);
    }
    else
    {
      temp1 = 0;   
      set_bkg_tiles (0,15,1,1,(unsigned char *)&temp1);
      set_bkg_tiles (19,15,1,1,(unsigned char *)&temp1);
    }
    last = joy;
  }

}

