#include <dos.h>
#include <stdlib.h>
#include <stdio.h>
#include <conio.h>
#include <string.h>
#include <time.h>

#include "joystick.h"
#include "drop.h"
#include "modex.h"
#include "rego.h"
#include "hiscore.h"
#include "keys.h"

#define UP 200
#define DOWN 208
#define LEFT 203
#define RIGHT 205

int get_input (void)
{
	unsigned int j;
	static int jlast = 0;
	int jinst = is_joystick_installed();
	int k;

	while (1==1)
	{
		if (kbhit())
		{
			k= getch();
			if (k ==0)
				return getch()+128;
			else
			return k;
		}
		if (jinst)
		{
			ReadJoystick (&j, NULL);

			if ((j & JOY_AF) && !(jlast & JOY_AF))
			{
				jlast = j;
				return 13;
			}
			if ((j & JOY_BF) && !(jlast & JOY_BF))
			{
				jlast = j;
				return 13;
			}

			if ((j & JOY_DN) && !(jlast & JOY_DN))
			{
				jlast = j;
				return DOWN;
			}

			if ((j & JOY_UP) && !(jlast & JOY_UP))
			{
				jlast = j;
				return UP;
			}
			jlast = j;
		}
	}
}

void set_option_fairy (int num,int draw);

void register_menu(void);

void title (void)
{
	// LoadPal();

	set_active_page(0);
	set_display_page(1);

	LoadPCX ("fairy2.pcx");

	set_display_page(0);

	get_input();
}


void reg_menu(options *gameops, score_t score)
{
	int choice=0;
	int finished =NO;
	unsigned char f;
	char cheat[10];
	int cheatlet=0;

	set_active_page(1);
	clear_vga_screen(0);
	set_active_page(0);
	set_display_page(1);

	LoadPCX ("menu.pcx");
	set_active_page(1);
	set_display_page(0);
	LoadPCX("sm_fairy.pcx");
	set_active_page(0);

	while (finished ==NO)
	{

		if (choice !=0)
		{
			set_fairy(44,2,0,NO);
		}

		if (choice !=1)
		{
			set_fairy(4,44,0,NO);
		}

		if (choice !=2)
		{
			set_fairy(24,85,0,NO);
		}

		if (choice !=3)
		{
			set_fairy(40,126,0,NO);
		}

		if (choice==0) //Play
		{
			copy_bitmap(1,0,0,68,55,0,44,2);

		}

		if (choice==1) // High Scores
		{
			copy_bitmap(1,0,0,68,55,0,4,44);
		}

		if (choice ==2) // Options
		{
			copy_bitmap(1,0,0,68,55,0,24,85);
		}

		if (choice ==3) // Quit
		{
			copy_bitmap(1,0,0,68,55,0,40,126);
		}

		f = get_input();


		if (f==DOWN)
			choice=(choice+1) %4;
		if (f==UP)
			choice=(choice+7) %4;
		if (f>='a' && f<='z')
		{
			if (cheatlet <9)
			{
				cheat[cheatlet] = f;
				cheatlet ++;
			}
		}

		if (f==' ' || (f==13 && cheatlet==0))
		{
			if (choice==0) // PLAY Option
			{
				gameops->wantstoplay = YES;
				finished = playmenu(gameops);
				if (finished==NO)
				{
					set_display_page(0);
					set_active_page(0);
				}
			}
			if (choice==2) // Options
			{
				options_menu(gameops);
				set_display_page(0);
				set_active_page(0);
			}
			if (choice==3) // QUIT Option
			{
				gameops->wantstoplay = NO;
				finished = YES;
			}
			if (choice==1) // HISCORE Option
			{
				hiscore(score,NO);
			}
		}

		if (f==13 && cheatlet>0)
		{
			cheat[cheatlet] = '\0';
			if (strcmp(cheat,"freedyna") == 0)
			{
				gameops->cheating |= DYNAMITE;
				print_str("Free dynamite cheat activated  ",32,10,190,4,15);
			}
			if (strcmp(cheat,"nocheat")==0)
			{
				gameops->cheating =0;
				gameops->resetspeed=8;
				gameops->maxspeed=2;
				print_str("All cheats removed             ",32,10,190,4,15);
			}
			if (strcmp(cheat,"slowdown")==0)
			{
				gameops->maxspeed=4;
				gameops->cheating |= SLOWDOWN;
				print_str("Slow down speed cheat activated",32,10,190,4,15);
			}
			if (strcmp(cheat,"random")==0)
			{
				gameops->cheating |= BOARD;
				print_str("Random board cheat activated   ",32,10,190,4,15);
			}
			if (strcmp(cheat,"showloop")==0)
			{
				gameops->cheating |= SHOWLOOP;
				print_str("Show loop cheat activated       ",32,10,190,4,15);
			}
			cheatlet=0;
		}
	}
}

void unreg_menu (options *g,score_t score)
{
	int fairy_pos[5][2] = {{52,0},{12,33},{12,65},{28,98},{32,132}};
	int selection = 0;
	int finished = NO;
	unsigned char key;

	set_active_page(2);
	clear_vga_screen(0);
	set_display_page(2);

	set_active_page(0);
	LoadPCX ("unrmenu.pcx");
	set_active_page(1);
	LoadPCX("sm_fairy.pcx");
	set_active_page(0);
	set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],0,YES);
	set_display_page(0);


	while (!finished)
	{

		key= get_input();

		if (key=='q'|| key=='Q' || key ==27)
		{
			finished = YES;
		}

		if (key==' ' || key==13)
		{
			if (selection == 0)
			{
				g->wantstoplay = YES;
				finished = playmenu(g);
				if (finished==NO)
				{
					set_display_page(0);
					set_active_page(0);
				}
			}
			if (selection == 1)
			{
				hiscore(score,NO);
			}
			if (selection == 2)
			{
				options_menu(g);
				set_display_page(0);
				set_active_page(0);
			}
			if (selection ==3)
			{
				register_menu();
				set_active_page(0);
				set_display_page(0);

				if (is_registered() == YES)
					finished = YES;

			}
			if (selection ==4)
			{
				finished = YES;
				g->wantstoplay=NO;
			}
		}
		if (key == UP)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],0,NO);
			selection = (selection +9) % 5;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],0,YES);
		}
		if (key == DOWN)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],0,NO);
			selection = (selection +1) % 5;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],0,YES);

		}
	}
}

void menu (options *g, score_t score)
{
	if (is_registered() == YES)
	{
		reg_menu(g,score);
	}
	else
	{
		unreg_menu(g,score);
		if (is_registered()==YES)
			reg_menu(g,score);
	}

}

void play_fairy(int pos, int draw)
{
	if (pos == 0)
	{
		set_fairy (46,0,3,draw);
		return;
	}
	if (pos ==1)
	{
		set_fairy (46,38,3,draw);
		return;
	}
	if (pos == 2)
	{
		set_fairy (46,90,3,draw);
		return;
	}
	if (pos ==3)
	{
		set_fairy (46,127,3,draw);
	}
}

int playmenu(options * gameops)
{
	int pos = 0;
	unsigned char f;

	set_active_page(3);
	LoadPCX("play.pcx");
	set_display_page(3);

	play_fairy (pos,YES);

	while (1 == 1){
		if (pos == 1) // NORMAL option
		{
			(*gameops).startlines=0;
			(*gameops).linesperlevel=10;
			(*gameops).gametype = NORMAL;
			set_players(1);
		}
		else if (pos == 0) // FAST Option
		{
			(*gameops).startlines= 14;
			(*gameops).linesperlevel=5;
			(*gameops).gametype=FAST;
			set_players(1);
		}
		else if (pos ==3)
		{
			(*gameops).startlines=0;
			(*gameops).linesperlevel=10;
			(*gameops).gametype = NORMAL;
			set_players(2);
		}
		else if (pos == 2)
		{
			(*gameops).startlines= 14;
			(*gameops).linesperlevel=5;
			(*gameops).gametype=FAST;
			set_players(2);
		}


		f = get_input();

		if (f==27||f=='q'|| f=='Q')
		{
			return NO;
		}

		if (f==DOWN)
		{
			play_fairy(pos,NO);
			pos=(pos+1)%4;
			play_fairy(pos,YES);
		}
		if (f==UP)
		{
			play_fairy(pos,NO);
			pos=(pos+7)%4;
			play_fairy(pos,YES);
		}

		if (f==' ' || f == 13)
		{
			return YES;
		}
	}
}

void set_fairy(int x,int y,int screen,int draw)
{

	x = x - (x%4);
	if (draw)
	{
		copy_bitmap(1,0,0,68,55,screen,x,y);
	}
	else
	{
		copy_bitmap(1,316-68,199-55,316,199,screen,x,y);
	}
}

void set_tick_button(int ison,int p,int x, int y)
{
	if (ison)
	{
		copy_bitmap(1,36,70,70,100,p,x,y);
	}
	else
	{
		copy_bitmap(1,0,70,30,100,p,x,y);
	}
}

void set_option_fairy (int num,int draw)
{
	if (num ==0)
	{
		set_fairy(20,14,3,draw);
		return;
	}
	if (num ==1)
	{
		set_fairy(20,47,3,draw);
		return;
	}
	if (num==2)
	{
		set_fairy(20,81,3,draw);
		return;
	}
	if (num==3)
	{
		set_fairy(20,115,3,draw);
		return;
	}
}

void set_option_num(int num,int screen, int x, int y)
{
	x = x- (x%4);

	if (num == 1)
	{
		copy_bitmap(1,0,108,20,136,screen,x,y);
		return;
	}
	if (num == 2)
	{
		copy_bitmap(1,40,108,60,136,screen,x,y);
		return;
	}
	if (num == 3)
	{
		copy_bitmap(1,80,108,100,136,screen,x,y);
		return;
	}
	if(num == 4)
	{
		copy_bitmap(1,0,140,20,168,screen,x,y);
		return;
	}
	if (num==5)
	{
		copy_bitmap(1,40,140,60,168,screen,x,y);
		return;
	}
	if (num==6)
	{
		copy_bitmap(1,80,140,100,168,screen,x,y);
		return;
	}
	if (num==7)
	{
		copy_bitmap(1,0,172,20,196,screen,x,y);
		return;
	}
	if (num==8)
	{
		copy_bitmap(1,40,172,60,196,screen,x,y);
		return;
	}
	if (num==9)
	{
		copy_bitmap(1,80,172,100,196,screen,x,y);
		return;
	}
}

void sound_menu (options *g);
void key_menu (options *g);

void options_menu(options *g)
{
	int finished = NO;
	int selection = 0;
	unsigned char key;

	set_active_page(3);
	LoadPCX("options.pcx");
	set_tick_button(g->shownext,3,256,35);
	set_option_fairy(selection,YES);

	set_display_page(3);
	while (!finished)
	{
		key= get_input();

		if ((key==' ' || key==13) && selection == 1)
		{
			sound_menu(g);
			set_active_page(3);
			LoadPCX("options.pcx");
			set_tick_button(g->shownext,3,256,35);
			set_option_fairy(selection,YES);
			set_display_page(3);

		}
		if ((key==' ' || key == 13) && selection == 2)
		{
			key_menu(g);

			set_active_page(3);
			LoadPCX("options.pcx");
			set_tick_button(g->shownext,3,256,35);
			set_option_fairy(selection,YES);
			set_display_page(3);
		}
		if ((key ==' ' || key==13) && selection == 0)
		{
			g->shownext = !g->shownext;
			set_tick_button(g->shownext,3,256,35);
		}

		if ((key==' ' || key==13) && selection ==3)
		{
			finished =YES;
		}

		if (key=='q'|| key=='Q' || key ==27)
		{
			finished = YES;
		}

		if (key == UP)
		{
			set_option_fairy(selection,NO);
			selection = (selection +7) % 4;
			set_option_fairy(selection,YES);
		}
		if (key == DOWN)
		{
			set_option_fairy(selection,NO);
			selection = (selection +1) % 4;
			set_option_fairy(selection,YES);
		}

	}

	save_options(g);
}

void input_type( int t)
{
	if (t == KEYBOARD)
	{
		print_str("KEYBOARD",8,220,25,3,15);
	}
	else
	{
		print_str("JOYSTICK",8,220,25,3,15);
	}
}

void joystick_menu (void);

void p1_key_menu( void);
void p2_key_menu(void);

void key_menu(options *g)
{
	int fairy_pos[5][2] = {{0,0},{0,31},{0,60},{0,94},{0,124}};
	int selection = 0;
	int finished = NO;
	unsigned char key;

	set_active_page(2);
	LoadPCX("keymenu.pcx");

	set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
	input_type (g->p1key);

	set_display_page(2);

	while (!finished)
	{

		key= get_input();

		if (key=='q'|| key=='Q' || key ==27)
		{
			finished = YES;
		}

		if (key==' ' || key==13)
		{
			if (selection == 0)
			{
				if (g->p1key == KEYBOARD)
					g->p1key = JOYSTICK;
				else
					g->p1key = KEYBOARD;
				input_type(g->p1key);
			}

			if (selection == 1)
			{
				p1_key_menu();
				set_display_page(2);
			}

			if (selection == 2)
			{
				p2_key_menu();
				set_display_page(2);
			}

			if (selection == 3)
			{
				joystick_menu();
				set_active_page(2);
				LoadPCX("keymenu.pcx");
				set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
				input_type (g->p1key);
				set_display_page(2);

			}
			if (selection ==4)
			{
				finished = YES;
			}
		}

		if (key == UP)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +9) % 5;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
		if (key == DOWN)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +1) % 5;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
	}
}


void sound_menu (options *g)
{
	int fairy_pos[4][2] = {{12,32},{12,66},{12,100}};
	int selection = 0;
	int finished = NO;
	unsigned char key;

	set_active_page(2);
	LoadPCX("smenu.pcx");

	set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
	set_tick_button(g->ismusicon,2,256,55);
	set_tick_button(g->issoundon,2,256,88);

	set_display_page(2);

	while (!finished)
	{
		key= get_input();

		if (key=='q'|| key=='Q' || key ==27)
		{
			finished = YES;
		}

		if (key==' ' || key==13)
		{
			if (selection == 0)
			{
				g->ismusicon = !g->ismusicon;
				set_tick_button(g->ismusicon,2,256,55);
			}
			if (selection == 1)
			{
				g->issoundon = !g->issoundon;
				set_tick_button(g->issoundon,2,256,88);
			}
			if (selection ==2)
			{
				finished = YES;
			}
		}

		if (key == UP)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +7) % 4;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
		if (key == DOWN)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +1) % 4;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
	}
}

void order_info(void)
{
	set_active_page(3);
	LoadPCX("register.pcx");
	set_fairy(200,20,3,YES);
	set_display_page(3);




	while(kbhit())
		getch();

	get_input();

	set_active_page(2);
	set_display_page(2);


}

void get_rego(void)
{
	char name[40], code [15],*ans;
	set_active_page(3);
	clear_vga_screen(15);
	print_str("Please enter your name (30 chars max):",44,10,50,3,15);
	set_display_page(3);

	strcpy ( name, &"                  ");
	get_string (name,20,70,30,15);
	print_str("Pleace enter the registration code:",40,10,100,3,15);
	get_string (code,100,120,9,15);


	ans = regcode(name);
	if (strcmp(code,ans)==0)
	{
		print_str("Congratulations, you are now registered",44,5,150,3,15);
		they_registered(name,code);
	}
	else
	{
		print_str("I'm sorry that is not the correct code",44,10,150,3,15);
		print_str(ans,44,10,160,3,15);
		print_str(name,44,10,170,3,15);
	}
	free (ans);

	while (kbhit())
		getch();

	while (!kbhit());

	getch();

	set_active_page(2);
	set_display_page(2);

}

void register_menu ()
{
	int fairy_pos[3][2] = {{20,31},{20,66},{20,100}};
	int selection = 0;
	int finished = NO;
	unsigned char key;

	set_active_page(2);
	LoadPCX("rscreen.pcx");

	set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);

	set_display_page(2);

	while (!finished)
	{

		key= get_input();

		if (key=='q'|| key=='Q' || key ==27)
		{
			finished = YES;
		}

		if (key==' ' || key==13)
		{
			if (selection == 0)
			{
				get_rego();
				if (is_registered()==YES)
					finished = YES;
			}
			if (selection == 1)
			{
				order_info();
			}
			if (selection ==2)
			{
				finished = YES;
			}
		}

		if (key == UP)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +5) % 3;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
		if (key == DOWN)
		{
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,NO);
			selection = (selection +1) % 3;
			set_fairy(fairy_pos[selection][0],fairy_pos[selection][1],2,YES);
		}
	}
}

void joystick_menu (void)
{
	install_joystick();
}

void show_key(int k, int y)
{
	if (k == 32)
	{
		print_str("Space",5,255,y,3,15);
		return;
	}
	if (k==13)
	{
		print_str("Enter",5,255,y,3,15);
		return;
	}
	if (k==DOWN)
	{
		gprintc(25,255,y,3,15);
		return;
	}
	if (k==UP)
	{
		gprintc(24,255,y,3,15);
		return;
	}
	if (k==LEFT)
	{
		gprintc(27,255,y,3,15);
		return;
	}
	if (k==RIGHT)
	{
		gprintc(26,255,y,3,15);
		return;
	}
	if (k<128)
		gprintc(k,255,y,3,15);
	if (k>127)
		gprintc(k%128,255,y,3,15);

}

void p1_key_menu (void)
{

	keys_t keys;
	int k;
	set_active_page(3);
	clear_vga_screen(15);
	copy_bitmap (2,70,50,300,75,3,70,0);
	set_display_page(3);

	print_str ("Press the new key for left",27,10,50,3,15);

	k = get_input();
	show_key(k,50);
	keys.left = k;

	print_str ("Press the new key for right",27,10,70,3,15);

	k = get_input();
	show_key(k,70);
	keys.right = k;

	print_str ("Press the new key for rotate",28,10,90,3,15);

	k = get_input();
	show_key(k,90);
	keys.rotate = k;

	print_str ("Press the new key for drop",27,10,110,3,15);

	k = get_input();
	show_key(k,110);
	keys.drop = k;

	print_str ("Press the new key for dynamite",30,10,130,3,15);

	k = get_input();
	show_key(k,130);
	keys.dynamite = k;

	change_keys(1,keys);
	save_keys();
	print_str ("Press a key to finish",27,40,150,3,15);
	get_input();
}

void p2_key_menu (void)
{

	keys_t keys;
	int k;
	set_active_page(3);
	clear_vga_screen(15);
	copy_bitmap (2,70,80,300,105,3,70,0);
	set_display_page(3);

	print_str ("Press the new key for left",27,10,50,3,15);

	k = get_input();
	show_key(k,50);
	keys.left = k;

	print_str ("Press the new key for right",27,10,70,3,15);

	k = get_input();
	show_key(k,70);
	keys.right = k;

	print_str ("Press the new key for rotate",28,10,90,3,15);

	k = get_input();
	show_key(k,90);
	keys.rotate = k;

	print_str ("Press the new key for drop",27,10,110,3,15);

	k = get_input();
	show_key(k,110);
	keys.drop = k;

	print_str ("Press the new key for dynamite",30,10,130,3,15);

	k = get_input();
	show_key(k,130);
	keys.dynamite = k;

	change_keys(2,keys);
	save_keys();
	print_str ("Press a key to finish",27,40,150,3,15);
	get_input();
}

void drop_curtain( score_t s)
{
	clock_t clok;

	extern players;
	int y = 1;

	clok = clock();

	while (y<181)
	{
		if (clok != clock())
		{
			clok = clock();
			copy_bitmap (1,1,122,130,132,0,1,y);

			if (players == 2)
			{
				copy_bitmap(1,1,122,130,132,0,181,y);
			}

			if (y == 101)
			{
				if (players == 1)
				{
					if (s.doiwin ==YES)
					{
						print_str("You Win",8,35,90,12,15);
					}
					else
					{
						print_str("You Lose",10,34,90,12,15);
					}
				}
				if (players == 2)
				{
					if (s.doiwin == YES)
					{
						print_str("You Win",8,35,90,12,15);
						print_str("You Lose",10,34+180,90,12,15);
					}
					else
					{
						print_str("You Lose",10,34,90,12,15);
						print_str("You Win",10,34+180,90,12,15);
					}
				}
			}

			if (y == 176)
			{
				y += 4;
			}
			else
				y += 5;
		}

	}

	while (kbhit())
		getch();

	get_input();
}





void gameover (score_t score, options gameops)
{
	extern players;

	drop_curtain(score);

	if (players == 2)
	{
		set_active_page(1);
		clear_vga_screen(0);
		set_display_page(1);
		set_active_page(0);

		if (score.doiwin == YES)
		{
			LoadPCX("p1.pcx");
		}
		else
		{
			LoadPCX("p2.pcx");
		}
	}

	else if (gameops.gametype == FAST)
	{

		set_active_page(1);
		clear_vga_screen(0);
		set_display_page(1);
		set_active_page(0);

		if (score.doiwin==NO)
			if (score.score <20)
				LoadPCX("chicken.pcx");
			else if (score.lines >=40)
				LoadPCX("sad.pcx");
			else
				LoadPCX("try.pcx");
		else if (score.score<800)
			LoadPCX("win.pcx");
		else if (score.score <1000)
			LoadPCX("800.pcx");
		else if (score.score <1100)
			LoadPCX("1000.pcx");
		else
			LoadPCX("happy.pcx");
	}
	else if (gameops.gametype == NORMAL)
	{
		set_active_page(1);
		clear_vga_screen(0);
		set_display_page(1);
		set_active_page(0);

		if (score.score <100)
			LoadPCX("flagnz.pcx");
		else if (score.score <2000)
			LoadPCX("octo1.pcx");
		else if (score.score <4000)
			LoadPCX("octo2.pcx");
		else if (score.score <6000)
			LoadPCX("octo3.pcx");
		else
			LoadPCX("pirate.pcx");
	}


	set_display_page(0);

	get_input();
	clear_vga_screen(0);

	if (is_registered() == NO)
	{
			annoy_screen();
	}
}

void annoy_screen( void )
{
	int c;
	set_active_page(1);
	clear_vga_screen(15);
	set_display_page(1);
	set_active_page(0);
	LoadPCX("register.pcx");
	set_display_page(0);
	set_active_page(1);
	LoadPCX("sm_fairy.pcx");
	set_fairy(200,20,0,YES);
	set_active_page(0);
	for (c=9;c>0;c--)
	{
		set_option_num(c,0,260+ ((c%2)*25),35+((10-c)*15));
		delay (1200);
	}

	clear_vga_screen(0);
}
