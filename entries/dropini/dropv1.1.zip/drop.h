#define NUM_COLORS 5
#define NUM_FACES 6

#define YES 1
#define NO  0

#define BOARD_MAX_X 15
#define BOARD_MAX_Y 22

/* Game Types */
#define NORMAL 1
#define FAST 2
#define QUEST 3

/* Cheat bits */
#define DYNAMITE (1<<0)
#define SLOWDOWN (1<<1)
#define BOARD (1<<2)
#define SHOWLOOP (1<<3)

void piecefall (void);
void displaysquare(UBYTE posx, UBYTE posy);
void displaypiece (UBYTE posx, UBYTE posy);
void displaynextpiece (void);
void erasepiece (UBYTE posx, UBYTE posy);
void erasesquare (UBYTE posx, UBYTE posy);
void show_score (void);
void displaynumber (UBYTE y);
void displayspeed (void);
void init_graphics (void);
void play_sound (UBYTE);
void sound_click (void);
void sound_pop (void);
UBYTE wait_for_button (void);

void gameover (void);

