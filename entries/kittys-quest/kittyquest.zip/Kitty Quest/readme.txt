                                  Kitty Quest
                                    by
                     Shen Mansell (shenmansell@hotmail.com)

    --------
    ABOUT ME
    --------

    The PC version of this game was primarily written in the period of 
    time between finishing university and getting a job. 
  
    The gameboy version was started on 19 Jan 2000.

    I have been working as a business application programmer for the past 3 years
    I work with C, Sybase and Powerbuilder. 

    I am interested in working in handheld game development professionally, and
    will take any legitimate offers of work seriously. You can contact me at
    shenmansell@hotmail.com

    ------------
    INTRODUCTION
    ------------
    
    Kitty Quest is an exciting puzzle game for the gameboy. A variant of 
    the ever popular Tetris, Dropini will provide you with several hours of
    addictive gameplay a day. 

    ---------                              
    THE STORY
    ---------

    You are a happy kitty who wants to become a rabbit. You wear a rabbit suit and
    have heard that collecting a set of magic stars will transform you into a real
    bunny. You set out on the quest of a lifetime...

    -----------                           
    HOW TO PLAY
    -----------

    Colored tiles will drop in sets of two. These balls can be rotated using
    the A button, and forced to drop faster using the down key. 

    The object of the game catch all the stars on every level. The stars are caught
    by joining them with tiles of the same color. When you join the tiles into groups
    of four or more tiles of the same color the will disappear. The star tiles will 
    join with any other tiles

    When a group disappears you will get a score based on how many tiles 
    were in the group. the first tile in the group will score 1 point, the
    second tile in the group will score 2 points, the third 3 and so on. Star
    tiles score an additional 40 points

    If you are able to make 2 group disappear with 1 set of falling tiles 
    then the score you receive will be the score of both individual groups 
    added together then multiplied by 4.

    For example:
      a group of 4 tiles will give you:
         1 + 2 + 3 + 4 = 10 points
      a group of 5 tiles:
         1 + 2 + 3 + 4 + 5 = 15 points
      a group of 4 tiles and a group of 5 tiles:
         ( 15 + 10 ) * 8 = 120 points

    If you make 2 lines one after another then you will score a 2X bonus for the
    second line. If you then make a third line you will get a 3X bonus, and so on
    for a 4X bonus

    As you make more groups of tiles disappear, the tiles will begin to 
    fall at a faster pace. Eventually the tiles will slow down. If this happens
    in hard mode , the minimum number of tiles needed to make a group 
    disappear will increase by one. So the first time the speed slows down
    you will need to start making groups of at least 5 tiles.

    If you are playing a practice game then the game will end when you complete
    50 lines, or the tiles reach the top of the playing field. In a quest 
    game play will continue until the tiles reach the top of the playing 
    field, or you succeed in collecting all the stars

    
    -----------------
    ABOUT Bunny Quest
    -----------------
    
    Bunny Quest was written on a 386sx-20 using Turbo C++ version 3.0 from
    Borland International, Inc. The amazing graphics for the game were 
    draw by hand and scanned into the computer using a black and white 
    hand held scanner, then colored in using the paint program included 
    with Windows 95.

    The Gameboy Port uses:
    GBDK v 2-1-0 by all the GBDK Team	
    GBTD and GBMB by Harry Mulder
    Hi-Colour gameboy picture convertor by Glen Cook
    The shoulders of the many giants in the GB Dev scene.
       
    ----------
    DISCLAIMER
    ----------

    The author makes no warranty, express or implied, with respect to 
    this software, its quality, performance, merchantability or fitness 
    for a particular purpose. The author shall have no liability for 
    special, incidental, or consequential damages arising out of or 
    resulting from the use of modification of this software. 



