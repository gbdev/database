-= DMG vs. Super Game Boy =- (source code)

The first (and only?) "Super Game Boy exclusive" game!
	by Dr. Ludos (2025-08-30)

Made for the GB COMPO 25 (https://itch.io/jam/gbcompo25) 
and the SNES DEV 25 (https://itch.io/jam/snesdev-2025) game jams.

Get all my other games:
		http://drludos.itch.io/
Support my work and get access to betas and prototypes:
		http://www.patreon.com/drludos


-= ABOUT =-

I could never have been able to make this game without the wonderful tools and templates
created and shared by Game Boy and SNES homebrew communities. 

So here's my little to contribution to the wonderful retro gamedev communities, in the form of the fully commented source of this game.
It's quite simple, but it may be useful to someone who want to toy with all the features of the Super Game Boy.

In particular, this game rely on an "hidden" feature of the Super Game Boy, allowing a GB game to display and control SNES sprites in addition to everything rendering on the GB screen.
This command is a bit convoluted to use (you'll have to write Sprite OAM data to the GB VRAM tiles data so the SNES can read it and transfer them to the SNES OAM VRAM), so I heavily recommend to read the documentation about this:
https://gbdev.io/pandocs/SGB_Command_Border.html#sgb-command-18--obj_trn

You'll also notice that the music, playing from the Game Boy, is a using a wonderful audio driver named GBT Player.
The GBT player version included here was patched to be able to be compiled with GBDK-2020 versions after 4.0.6, as described here:
https://github.com/AntonioND/gbt-player/pull/21


-= HOW TO BUILD =-

The game is written in C. To compile it, you'll have to use the GBDK 2020 toolchain available here:
http://gbdk.org/

I used GBDK2020 v.4.4.0 to create this project.

When you have the toolchain all set up, you can compile this game using the following commands:

# First, use GBDK2020 to compile the game ROM
lcc -Wa-l -Wl-m -Wl-j -c -o DMGvsSGB.o DMGvsSGB.c -Wf--max-allocs-per-node50000 -Wf--opt-code-speed

# Then, use GBDK2020 to compile the GBT Player output (music data - C code from mod file)
lcc -Wa-l -Wl-m -Wl-j -c -o music.o music.c

# And also use GBDK2020 to compile the GBT Player engine (ASM code)
lcc -Wa-l -Wl-m -Wl-j -c -o gbt_player.o gbt_player.s
lcc -Wa-l -Wl-m -Wl-j -c -o gbt_player_bank1.o gbt_player_bank1.s

# And finally, assemble the ROM using GBDK2020 (set it as SGB compatible (-ys))
lcc -Wl-yt0x00 -Wl-yo2 -Wl-ya0 -Wm-yn"DMG-vs-SGB" -Wm-ys -o DMGvsSGB.gb DMGvsSGB.o music.o gbt_player.o gbt_player_bank1.o


-= LICENSING =-

The source code is released under the MIT license, 

The assets (graphics and audio) under a Creative Commons CC-BY license. 

N.B.: The assets running on the SNES (SGB minions and sounds played by the SNES chip) are NOT part of this project as they are standard assets provided by the Super Game Boy device.
They are thus NOT covered by this license as they were NOT created by myself.


-= FINAL WORDS =-

If you actually happen to read this source code and have any question about it, 
feel free to get in touch: drludos@ludoscience.com

I hope you'll enjoy the game!