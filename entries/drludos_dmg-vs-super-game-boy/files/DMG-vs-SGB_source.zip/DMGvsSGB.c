/*
	
		-= DMG vs Super Game Boy =-

	The first (and only?) "Super Game Boy exclusive" game!
						by Dr. Ludos (2025)

	Get all my other games:
			http://drludos.itch.io/
	Support my work and get access to betas and prototypes:
			http://www.patreon.com/drludos

*/
	
// INCLUDE GBDK FUNCTION LIBRARY
#include <gbdk/platform.h> // includes gb.h, sgb.h, cgb.h
// INCLUDE HANDY HARDWARE REFERENCES
#include <gb/hardware.h>
// INCLUDE RANDOM FUNCTIONS
#include <rand.h>
//INCLUDE FONT (+CUSTOM COLOR) AND TEXT DISPLAY FUNCTIONS
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <gbdk/font.h>
#include <gb/drawing.h>
#include <gbdk/console.h>


//INCLUDE GRAPHICS
#include "assets.h"

//INCLUDE MUSIC PLAYER (GBT Player by AntonioND)
#include "gbt_player.h"
extern const unsigned char * song_Data[];
extern const unsigned char * song_boss_Data[];


//==========================================
//==========  VARIABLES & HEADERS ============
//==========================================


//VARIABLE DECLARATIONS - STORED IN RAM

//Looping variables
UINT8 i, j, k, l;

//Game State : ( 0 : Intro / 1 : game / 2 : game over / 3 : title / 4 : how to play)
UINT8 state;

//Hold keypressed for the current frame
UINT8 pad;
//Variable to check whether we already pressed key or not (to force player to release button before pressing it again)
UINT8 keyPressed, aPressed, bPressed, startPressed, selectPressed; 

//SCORE

//Value to add to the score (so we update the score only once per frame, even if we earn several points by hitting several enemies)
UINT8 scoreAdd; 


//PLAYER

//Player position
UINT8 playerX, playerY;
//Player velocity
INT8 speedX, speedY;
//Player direction (to land punches / face left or right)
INT8 dirX, dirY;

//Player life
UINT8 life;
//Player stun time
UINT8 stun;
//Player invincible time
UINT8 invincible;
//Player Animation Frame and Counter
UINT8 animStep;


//HANDS

//Hand structure
typedef struct {
	UINT8 x; //X position
	UINT8 y; //Y position
	INT8 speedX; //X speed
	INT8 speedY; //Y speed
	UINT8 state; //State of the hand : ready for shoot / shot / idle on ground / moving back / 
	UINT8 target; //Index of the foe we are currently holding in hand (255: empty)
	UINT8 anim; //used to do animation
} Hand;

//Hands variables (A button (Right) / B button (Left) )
Hand handLeft;
Hand handRight;

//FOES

//Foe structure
typedef struct {
	UINT8 active; //0: inactive / 1: active
	UINT8 x; //X position
	UINT8 y; //Y position
	INT8 speedX; //X speed
	INT8 speedY; //Y speed
	UINT8 type; //type of the foe
	UINT8 life; //life of the foe (if == 0 then death anim!)
	UINT8 anim; //used to do animation
	UINT8 stun; //time we are "stun" when we are hit
	UINT8 slow; //counter timer for how long we are using a "slow" movement (once every two frame) : 0=>normal speed / 255=> permanent slow movement
	UINT8 think; //countdown timer before the next "think" cycle (e.g. change direction towards the player)
	UINT8 hop; //counter to check whether we'll need to "hop" or not while walking (move sprite Y position 1 pixel offset from real position)
	UINT8 palette; //current SGB palette displayed by the SGB sprite (not used for GB sprites)
	
} Foe;

//Foe container (Array of Foe)
Foe foes[12];

//Foe pointer (used to update them in gameplay loop)
Foe* foe;


//ROOMS / LEVEL 
//Current level number
UINT8 room; 
//Current number of foes present on screen at the same time for the current room
UINT8 foesActive; 
//Maximum number of foes present on screen at the same time for the current room
UINT8 foesMax;
//Total Number of remaining foes to be spawned
UINT8 foesLeft; 
//Number of Boss foes to be spawned in the current room
UINT8 foesBoss; 
//Countdown before the next foe spawn
UINT8 foesSpawn; 






//BACKEND

//Ticks counter (frame counter + modulo computed each frame to trigger 3 "every X frame" counter, so we can move at speed slower than 60 pixel / seconds - 60fps game baby !)
//Frame counter (resetted every 240 frames (4 seconds), so it can be used for countdown too)
UINT8 ticks;
//Fast speed : triggered every 2 frames
UINT8 ticks_fast;
//Mid speed : triggered every 4 frames
UINT8 ticks_mid;
//Slow speed : triggered every 8 frames
UINT8 ticks_slow;
//Slower speed : triggered every 16 frames
//UINT8 ticks_slower; //Disabled to save ROM space as it's not used in the game currently
//Slowest speed : triggered every 32 frames
UINT8 ticks_slowest;

//Variable for the game pause state (0: off / 1: on)
UINT8 paused;

//Variable for the fadeout/fadein countdown
UINT8 fadeout, fadein;
//Define the duration of a fadeout / fadein cycle once for all the game
const UINT8 FADEON=16;

//Variable for the music played (0: no music / 1: level song / 2: boss song)
UINT8 musicPlaying;


//SUPER GAME BOY

//Ram Buffer to prepare commands sent to the SGB
UINT8 sgb_packet[16]; 
//Ram Buffer used to prepare the OBJ_TRN data before they are copied to VRAM
UINT8 font_OBJMODE[112]; 
//TileMap Data to map the tiles used to send OBJ_TRN commands to the GB screen (the 7 leftmost tiles on the last row of the screen)
const UINT8 font_OBJINIT[7]={0xF9,0xFA,0xFB,0xFC,0xFD,0xFE,0xFF};
//TileMap Data to map back the border background tiles when we quit OBJ TRN mode and need to restore the original background instead of the previous tiles used to control SGB OAM sprites
const UINT8 font_OBJQUIT[7]={0x69,0x65,0x65,0x65,0x65,0x65,0x65};
//Variable to specify the ID of the SGB Sound Effect to play (sound A)
UINT8 sgb_sfx; 
//Variable to specify the volume of the SGB Sound Effect to play (sound A)
UINT8 sgb_volume;
//Variable to specify the pitch of the SGB Sound Effect to play (sound A)
UINT8 sgb_pitch;



//TILEMAPS (Const & Dynamic ones)

//Blank tile used on any screen (first tile in VRAM)
const UINT8 bg_blank[1]={0x00};

//Background tiles (const => stored in rom)
const UINT8 bg_wallL[1]={0x62};
const UINT8 bg_wallR[1]={0x63};
const UINT8 bg_wallU[1]={0x64};
const UINT8 bg_wallD[1]={0x65};
const UINT8 bg_wallLU[1]={0x66};
const UINT8 bg_wallRU[1]={0x67};
const UINT8 bg_wallRD[1]={0x68};
const UINT8 bg_wallLD[1]={0x69};

//Life counter (GUI)
const UINT8 bg_lifeOK[1]={0x6A};
const UINT8 bg_lifeNO[1]={0x6B};

//Counter used to display the score (6 slots, so maximum displayed score is 999999)
UINT8 font_score[6];
//Counter used to display the best score (6 slots, so maximum displayed score is 999999)
UINT8 font_highscore[6];



//FUNCTION DECLARATIONS

//Game init
void initGame(void);		
//Foe update
void updateFoeMovement(void);
void updateFoeLeftHand(void);
void updateFoeRightHand(void);
//Player update
void updatePlayerMovement(void);
void updatePlayerLeftHand(void);
void updatePlayerRightHand(void);
void updatePlayerAnimation(void);
//Foes spawning
UINT8 spawnFoe(UINT8, UINT8, UINT8);
//SGB features
void sgb_OBJenable(void);
void sgb_OBJdisable(void);
void sgb_setPalette(void);
void sgb_playSFX(void);
//Menu screens update
void updateGameOver(void);
void updateTitle(void);
void updateIntro(void);
void updateInstructions(void);






//========================================
//======= GAME INIT / RESET FUNCTION ========
//========================================
void initGame(void){
	
	//VARIABLES
	
	//Seed the randomizer
	initrand(DIV_REG);														

	//Reset vars
	ticks=1;
	state=1;
	paused=0;
	aPressed=1; //Set to 1 in case the player did release the button after title screen
	bPressed=1; //Set to 1 in case the player did release the button after title screen
	startPressed=0;
	selectPressed=0;
	scoreAdd=0;
	musicPlaying=0;
	
	//PLAYER
	
	//Set the player initial position
	life = 4;
	playerX = 80;
	playerY = 86;
	speedX = 0;
	speedY = 0;
	dirX = 1;
	dirY = 0;
	stun = 0;
	invincible = 0;
	animStep = 0;
	
	//Init HANDS too
	handLeft.state=0;
	handLeft.anim=0;
	handLeft.target=255;
	handRight.state=0;
	handRight.anim=0;
	handRight.target=255;
		
	
	
	//FOES
	//Using Sprites 20-32
	
	//Reset each foe individually
	for(i = 0 ; i < 12 ; i++ ){
		
		//Get a pointer to the current foe
		foe=&foes[i];
		
		//Disable the foe
		foe->active = 0;
		
		//And put its sprite offscreen
		move_sprite(20+i, 0, 0);
	}
	
	//BACKGROUND
	
	//Load the Background tile data into VRAM
	set_bkg_data(97, 22, gfx_bg);
	
	//Load the Game Over message tile data in VRAM too
	set_bkg_data(119, 105, msg_gameover_tiles);
	
	//Background sprites : fill the screen with white tiles for floor and walls around the screen (paint the whole 32x32 bg map white in case of screenshake!)
	for (j=0 ; j != 32 ; j++){
		for (i=0 ; i != 32 ; i++){
			//Left-Up Corner
			if( i == 0 && j == 0 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallLU);
			}
			//Left-Down Corner
			else if( i == 0 && j == 17 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallLD);
			}
			//Right-Up Corner
			else if( i == 19 && j == 0 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallRU);
			}
			//Right-Down Corner
			else if( i == 19 && j == 17 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallRD);
			}
			//Left wall border
			else if( i == 0 && j < 18 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallL);
			}
			//Right wall border
			else if( i == 19 && j < 18 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallR);
			}
			//Up wall border
			else if( j == 0 && i < 20 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallU);
			}
			//Down wall border
			else if( j == 17 && i < 20 ){
				set_bkg_tiles(i, j, 1, 1, bg_wallD);
			}
			//Else display floor tiles (blank tiles for better readibility)
			else {
				set_bkg_tiles(i, j, 1, 1, bg_blank);
			}
		}
	}
	
	//Background sprites : life counter
	//Set as many "life counter" tile as needed
	for (j=0 ; j != life ; j++){
		set_bkg_tiles(1+j, 0, 1, 1, bg_lifeOK);
	}
	
	//Set the all the score displayer tiles to the "0" tile to reset the score back to 0
	font_score[0]=0x6C;
	font_score[1]=0x6C;
	font_score[2]=0x6C;
	font_score[3]=0x6C;
	font_score[4]=0x6C;
	font_score[5]=0x6C;
	//Update the score displayed on the BG by sending it to VRAM
	set_bkg_tiles(13, 0, 6, 1, font_score);
	
	//Reset the scrolling at Startup
	move_bkg(0,0);
	
	
	//ROOM GENERATION (levels are called "rooms" here, each room will spawn a certain number of foes, when they are all killed, you'll fight next "room" with a new a set of foes with improved stats)
	
	//Start at level 0
	room=0; 
	
	//Define the maximum number of foes on screen at the same time for this room (1-12)
	foesMax=1;
	//Set the number of foes left to generate before the next room
	foesLeft=1;
	//Set the number of foes left to generate before the next room
	foesBoss=0;
	//Start the countdown to generate a new foe
	foesSpawn=10;
	//Reset the current number of foes active on screen too in the dedicated counter
	foesActive=0;
	
	
	
	
	//LOAD GAME TILES AND SPRITES INTO MEMORY NOW 
	
	//Load the player sprites into Sprite VRAM (start: 0)
	set_sprite_data(0, 52, gfx_sprites);
	
	
	//Define player Sprites (after room generation, so the player is placed where it belongs!)
	//Hands
	set_sprite_tile(10, handLeft.anim);
	move_sprite(10, playerX, playerY);
	set_sprite_tile(11, handRight.anim);
	move_sprite(11, playerX+24, playerY);
	//Body
	set_sprite_tile(12, 10);
	move_sprite(12, playerX+8, playerY);
	set_sprite_tile(13, 12);
	move_sprite(13, playerX+16, playerY);
	
	//Left hand is mirrored from right hand tile  (allows to reset all other props too)
	set_sprite_prop(10, S_FLIPX);
	//While right hand is normal (allows to reset all other props too)
	set_sprite_prop(11, !S_FLIPX);
	
	
	//SGB OBJ mode
	
	//Reset the buffer holding the SGB OBJ OAM data (that will be sent to VRAM everyframe during gameplay)
	for( i=0 ; i < 112 ; ++i ){
		font_OBJMODE[i]=0;
	}
	
	//Set some parameters that won't be changed during gameplay once and for all here
	//MSB (two bits per objects: bit0 : X coordinate Upper bit (sign) / bit1: size of sprite (0=> 8x8 / 1=>16x16)
	font_OBJMODE[96]=0b10101010;
	font_OBJMODE[97]=0b10101010;
	font_OBJMODE[98]=0b10101010;
	font_OBJMODE[99]=0b10101010;
	font_OBJMODE[100]=0b10101010;
	font_OBJMODE[101]=0b10101010;
	
	//Reset SGB SFX variables
	sgb_sfx=0; 
	sgb_volume=0;
	sgb_pitch=0;
	
	//Set the color palette for the current "room"
	sgb_setPalette();
	
	
	//COLOR in Blocks (ATTR_BLK)
	// Used to specify color attributes for the inside or outside of one or more rectangular screen regions.
	//Byte  Content
	//0     Command*8+Length (length=1..7)
	// 1     Number of Data Sets ($01..$12)
	// 2-7   Data Set #1
	//	 Byte 0 - Control Code (0-7)
	//	   Bit 0 - Change Colors inside of surrounded area     (1=Yes)
	//	   Bit 1 - Change Colors of surrounding character line (1=Yes)
	//	   Bit 2 - Change Colors outside of surrounded area    (1=Yes)
	//	   Bit 3-7 - Not used (zero)
	//	   Exception: When changing only the Inside or Outside, then the
	//	   Surrounding line becomes automatically changed to same color.
	//	 Byte 1 - Color Palette Designation
	//	   Bit 0-1 - Palette Number for inside of surrounded area
	//	   Bit 2-3 - Palette Number for surrounding character line
	//	   Bit 4-5 - Palette Number for outside of surrounded area
	//	   Bit 6-7 - Not used (zero)
	//	 Data Set Byte 2 - Coordinate X1 (left)
	//	 Data Set Byte 3 - Coordinate Y1 (upper)
	//	 Data Set Byte 4 - Coordinate X2 (right)
	//	 Data Set Byte 5 - Coordinate Y2 (lower)
	//	   Specifies the coordinates of the surrounding rectangle.
	//8-D   Data Set #2 (if any)
	// E-F   Data Set #3 (continued at 0-3 in next packet) (if any)
	//Header
	sgb_packet[0]=0x04*8+1;
	sgb_packet[1]=0x01;
	//Data set 1
	sgb_packet[2]=0b00000111;
	sgb_packet[3]=0b00010000;
	sgb_packet[4]=1;
	sgb_packet[5]=1;
	sgb_packet[6]=18;
	sgb_packet[7]=16;
	//Data set 2
	// TODO : define another zone for the life counter with different colors?
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	//Data set 3
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	//Send the SGB command packet
	sgb_transfer(sgb_packet);
	
	
	//Custom Palette Priority (PAL_PRI)
	//Enable SGB custom palette switching over player chosen palette
	//Whenever we set a new palette, we want to show it to the player (he can disable it later by pressing X if he wants)
	//Header
	//sgb_packet[0]=0x19*8+1;
	sgb_packet[0]=0xC9;
	//Command: palette switching disabled (1) or enabled (0 - default)
	sgb_packet[1]=0x01;
	//Unused
	sgb_packet[2]=0x00;
	sgb_packet[3]=0x00;
	sgb_packet[4]=0x00;
	sgb_packet[5]=0x00;
	sgb_packet[6]=0x00;
	sgb_packet[7]=0x00;
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	//Send the SGB command packet
	sgb_transfer(sgb_packet);
	
	
	//Attract mode disable (ATRC_EN)
	//Disable attract mode. Attract mode, enabled by default, is the fact that some screen border (all but the GB and plain black one) will show an animation after 7 minutes of player inactivity.
	//Using the (hidden) feature OBJ_TRN to display SNES sprites over the GB screen like we do on this game doesn't work with this feature:
	//	- First, it seems that the "inactivity timer" is running even when player use the controller, so the "inactivity" animation will show while playing, and will never go away
	//	- Second, depending on the screen border, the animation will be corrupt (garbage on some or all tiles), it's likely due to interference from the OBJ_TRN
	//So it's safer to disable "attract mode" when using SGB sprite like this game does
	//Header
	sgb_packet[0]=0x0C*8+1;
	//Command: attract mode disabled (1) or enabled (0 - default)
	sgb_packet[1]=0x01;
	//Unused
	sgb_packet[2]=0x00;
	sgb_packet[3]=0x00;
	sgb_packet[4]=0x00;
	sgb_packet[5]=0x00;
	sgb_packet[6]=0x00;
	sgb_packet[7]=0x00;
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	//Send the SGB command packet
	sgb_transfer(sgb_packet);
	
	
	//Play Level Music
	gbt_play(song_Data, 1, 3);
	musicPlaying=1;

	//Active the fade in at startup
	fadein=FADEON;
}



//========================================
//=============== MAIN LOOP ===============
//========================================
void main(void){
	
	//Set the display Off (forced blanking!)
	DISPLAY_OFF;
	
	//SGB initialisation
	// Wait 4 frames - For PAL SNES this delay is required on startup so the border has the time to finish loading up and the SGB is fully ready to listen to our commands
	for ( i = 4; i != 0; i--){ vsync(); }
	
	// TURN SOUND ON
	//NR52_REG = 0x8F;
	NR52_REG = 0x80;
	// ENABLE SOUND CHANNELS (1: 0x11 / 2: 0x22 / 3: 0x44 / 4: 0x88 / All : 0xFF)
	NR51_REG = 0xFF;
	// VOLUME MAX = 0x77, MIN = 0x00	
	NR50_REG = 0x77;
	
	//Init the GBT music player
	gbt_loop(0);
	set_interrupts(VBL_IFLAG);
	enable_interrupts();
	
	
	//Set sprites to 8x16
	SPRITES_8x16;
		
	//Load one of the GBDK default font (the tiles will be located on the BG VRAM between index 1-96 (0x01-0x60)
	font_init();
	font_load(font_spect);
	
	//Fadein at start (set BGP to white to automatically trigger a white fadein)
	fadeout = 0;
	fadein = 0;
	BGP_REG = 0x00U;
	
	//Define the Intro Screen state to start the program
	state = 0;
	
	//Set the color palette as "DMG Peasoup screen" to start (like room 0-1 in the game)
	room=0;
	sgb_setPalette();


	//Set the display ON
	DISPLAY_ON;
	
	
	//One time init of some vars
	
	//Set the highscore to 0 (0x10 is the "0" tile in our text font tileset, and we handle score and highscore directly in text font values for display simplicity)
	font_highscore[0] = 0x10;
	font_highscore[1] = 0x10;
	font_highscore[2] = 0x10;
	font_highscore[3] = 0x10;
	font_highscore[4] = 0x10;
	font_highscore[5] = 0x10;
	
	
	// GAME LOOP START
	while(1){
		
		//Read player inputs
		pad=joypad();
		
		//IF WE HAVE TO MAKE A FADEOUT / FADEIN, it takes priority over game states
		if( fadeout != 0 ){
			
			//Change palettes to make a fadeout to white at specific countdown ticks 
			//On comments, the palette are in binary as they are easier to read than their hexademical translation used in C code
			//10-01-00-00
			if( fadeout == 16 ){
				BGP_REG = 0x90U;
				OBP0_REG = 0x90U;
			}
			//01-00-00-00
			else if( fadeout == 11 ){
				BGP_REG = 0x40U;
				OBP0_REG = 0x40U;
			}
			//00-00-00-00
			else if( fadeout == 6 ){
				BGP_REG = 0x00U;
				OBP0_REG = 0x00U;
			}
			//Final action (if needed)
			else if( fadeout == 1 ){
				
				//Special case : if we're on gameover (2) or entering gameplay (1 + ticks == 255) state, trigger the "(re)start game function" after the fadeout has ended
				if ( state == 2 || (state == 1 && ticks == 255) ){
					initGame();
				}
			}
			
			//Decrease countdown
			fadeout--;
		}
		else if( fadein != 0 ){
		
			//01-00-00-00
			if( fadein == 16 ){
				BGP_REG = 0x40U;
				OBP0_REG = 0x40U;
			}
			//10-01-00-00
			else if( fadein == 11 ){
				BGP_REG = 0x90U;
				OBP0_REG = 0x90U;
			}
			//11-10-01-00
			else if( fadein == 6 ){
				BGP_REG = 0xE4U;
				OBP0_REG = 0xE4U;
			}
			//Final action (if needed)
			else if( fadein == 1 ){
				
				//Special case : if we're entering gameplay state, enable the SGB OBJ as we're starting a new game and have just finished fading in (can't do fading when using OBJ_TRN, it'll mess everything)
				if ( state == 1 ){
					//Enable the SGB OBJ mode
					sgb_OBJenable();
					
					//Set the tiles to the BKG map that will be used to transfer SGB OBJ OAM data (the 7 leftmost tiles of the last screen row)
					set_bkg_tiles(0,17,7,1, font_OBJINIT);
				}
			}
			
			//Decrease countdown
			fadein--;
		}
		//ELSE, REGULAR GAMEPLAY
		else {
			
			//If we are totally faded out (BGP Palette is full white), then automatically trigger a fadein for the next tick
			//That way, it's old state => fade out => new state (for one tick) => fade in => resume new state
			if( BGP_REG == 0x00U ){
				
				//Activate the fadein transition
				fadein = FADEON;
			}
			
			//========================================
			//============ GAMEPLAY STATE ============
			//========================================
			if( state == 1 ){
				
				//If the game is not paused (pause / unpause code at the end of this block)
				if( paused == 0 ){
					

					//=== Frame & ticks counter ====
					
					//Increase the frame counter
					++ticks;
					
					//Reset it to zero every 4 seconds (UINT8 > 255 max, so 240 ticks => 4 seconds is ok)
					if (ticks == 241){
						ticks= 1;
					}
					
					//Update the "animation trigger" for everyone
					ticks_fast=!(ticks & 0x1);
					ticks_mid=!(ticks & 0x3);
					ticks_slow=!(ticks & 0x7);
					//ticks_slower=!(ticks & 0xF); //Disabled to save ROM space as it's not used in the game currently
					ticks_slowest=!(ticks & 0x1F);
			
					
					//======= FOES GENERATION =========
					
					//Are we ready to spawn a new Foe?
					if( foesSpawn == 0 ){
					
						//Do we need to generate a "boss" foe? (the last few foes of a room)
						if( foesLeft == foesBoss ){
							
							//Boss type depend on room number (room 0 doesn't have a boss, so it starts with room 1)
							j=(room&3); //Modulo 4, as we have 4 differents boss types
							
							//Then, Spawn a new Boss Foe
							//Second boss: the weakling spawner
							if( j == 2 ){
								//Tries to spawn the boss
								k=spawnFoe(98, 0, 0 );
							}
							//Third boss: the bullet shooter
							else if( j == 3 ){
								//Tries to spawn the boss
								k=spawnFoe(139, 0, 0 );
							}
							//Fourth boss: the fast chaser spawning loads of basic foes
							else if( j == 0 ){
								//Tries to spawn the boss
								k=spawnFoe(161, 0, 0 );
							}
							//Else, First and default boss: the fast grunt mine dropper
							else {
								//Tries to spawn the boss
								k=spawnFoe(111, 0, 0 );
							}
							
							//if the creation of the Boss was succesful (function returned anything but 0)
							if( k != 0 ){
								
								//Set a new countdown timer before new foe Spawning (that will be the first foe of the next room)
								foesSpawn=240;

								//Increase the total number of active foes
								++foesActive;
								
								//Decrease the "foes left to spawn" countdown (but prevent it from looping over 0 in case we spawn more foes than the number required to clear the room)
								if( foesLeft > 0 ){
									--foesLeft;
								}
								
								//Also decrease the number of "Bosses left to spawn"
								if( foesBoss > 0 ){
									--foesBoss;
								}
								
								//If the boss music isn't playing yet
								if( musicPlaying != 2 ){
									//Play Boss Music
									gbt_play(song_boss_Data, 1, 2);
									musicPlaying=2;
								}
							}
							
						}
						//Else, spawn a standard foe
						else {
							
							//Spawn a new foe that will randomly appear outside of the screen and enter the room
							//if the creation of the Foe was successful (function returned anything but 0)
							if( spawnFoe(0, 0, 0 ) != 0 ){

								//Set a new countdown timer before new foe Spawning
								foesSpawn=60 - (room << 2);
								
								//Prevent the countdown timer to be too low if the player goes far in the game and clear a high number of rooms
								if( foesSpawn < 10 ){ foesSpawn = 10; }
								
								//Increase the total number of active foes
								++foesActive;
								
								//Decrease the "foes left to spawn" countdown (but prevent it from looping over 0 in case we spawn more foes than the number required to clear the room)
								if( foesLeft > 0 ){
									--foesLeft;
								}
								
								//If the next time we will generate a boss (or a series of boss), we increase the time to wait for the next spawn
								if( foesLeft == foesBoss ){ 
									foesSpawn = 240;
								}
								
								//If no music is playing (it's stopped when we kill the last enemy of a room)
								if( musicPlaying == 0 ){
									
									//Play normal music
									gbt_play(song_Data, 1, 3);
									musicPlaying=1;
								}
							}
						}
					}
					//Else, keep the countdown running if we still have foes left to spawn and we haven't reached the max number of foes for the room
					else if( foesLeft > 0 && foesActive < foesMax ){
						
						//Decrease the foe spawn countdown timer
						--foesSpawn;
					}
					
					
					
					
					
					//======= FOES UPDATE =========
					
					//Update each foe individually
					for(i = 0 ; i < 12 ; i++ ){
						
						//Get a pointer to the current foe
						foe=&foes[i];
						
						//If the foe is active
						if( foe->active == 1 ){
							
							//If foe is not dead
							if( foe->life > 0 ){

								//-= FOE MOVEMENT =-
								updateFoeMovement();

							}
							//Else, the foe is DEAD => Death animation before removal
							else {
								//Did we finish the death animation sequence ? (tiles 38-52)
								if( foe->anim > 52 ){
									
									//Remove the foe so it can be recycled
									foe->active=0;
									foe->x=0;
									foe->y=230;
									
									//Move the sprite offscreen so it doesn't count in the 10 sprites limit per scanline
									move_sprite(20+i, foe->x, foe->y);
									
									//if the foe is an actual foe (and not an explosion, a bullet or a bonus)
									if( foe->type >= 10 ){
										
										//Decrease the total number of active foes (prevent it from going under 0)
										if( foesActive > 0 ){
											--foesActive;
										}
									}
								}
								//Else, do the death animation !
								else {
									
									//Do some initialisation on the first frame only
									if( foe->anim == 38){
										
										//Hide the SGB sprite now that we won't need it
										//Modify Y position of the SGB OAM sprite
										font_OBJMODE[(i<<2)+1]=230;
										
										//Cap the GB sprite Y position on the bottom edge to never overlap the screen border (else, it could mess with the SGB sprites OAM transfer of OBJ_TRN mode in the bottom-left corner)
										if( foe->y > 136 ){ foe->y = 136; }
										
										//And move the GB sprite back onscreen so we can have an explosion!
										move_sprite(20+i, foe->x, foe->y);
										
										//Play SFX : explosion
										//If it's an "explosion" foe, use a longer sound (as it's mainly used for player)
										if( foe->type == 5 ){
											NR41_REG = 0x3F;
											NR42_REG = 0xF4;
											NR43_REG = 0x7C;
											NR44_REG = 0x00;
											NR44_REG = 0x80;
										}
										//Else, regular foe explosion sound (softer and shorter than player's, to be easier on your ears!)
										else {
											NR41_REG = 0x37;
											NR42_REG = 0xF3;
											NR43_REG = 0x65;
											NR44_REG = 0x00;
											NR44_REG = 0x80;
										}
									}
									
									//Go to the next animation
									if( ticks_mid ){
									
										//Go to the next animation (2 per 2 as we are in 8x16 sprites)
										foe->anim += 2; 

										//And displays it!
										set_sprite_tile(20+i, foe->anim);
									}
								}
							}
						}
						
					}
					
					//SGB Sprites OAM update (data content are modified when needed in the updateFoesXXX() functions)
					//Send Data to the GB VRAM so it can be read by the SGB (ie, update the tile data from the 7 first BG tiles displayed at bottom, they have been mapped so when the SGB OBJ mode was enabled)
					set_bkg_data(249, 7, font_OBJMODE);
					

					
						
					
					//======= PLAYER =========
					

					//-= MOVING BODY =-
					updatePlayerMovement();
					
					//-= MOVING HAND LEFT =-
					updatePlayerLeftHand();
					
					//-= MOVING HAND RIGHT =-
					updatePlayerRightHand();
					
					//-= ANIMATIONS =-
					updatePlayerAnimation();
					
					
					//======= BACKEND =========
					
					
					//-= UPDATE SCORE =-
					
					//If we have earned points during this frame
					if( scoreAdd > 0 ){
					
						//Add all the earned points to the single digit counter (even if we earned more than 10 points this frame, we'll pass them to the other digits below)
						font_score[5] += scoreAdd;
						
						//Check whether we have to increase other counters (10's, 100's, etc.)
						//Tile 0 is 0x6C, so tile 9 is 0x6C+9 = 0x75
						//10's => this one is a while, as we may have earned more than 10 points on a single frame :)
						while( font_score[5] > 0x75 ){ 
							++font_score[4];
							font_score[5] -= 10;
						}
						//100's
						if( font_score[4] > 0x75 ){ 
							++font_score[3];
							font_score[4] -= 10;
						}
						//1000's
						if( font_score[3] > 0x75 ){ 
							++font_score[2];
							font_score[3] -= 10;
						}
						//10000's
						if( font_score[2] > 0x75 ){ 
							++font_score[1];
							font_score[2] -= 10;
						}
						//100000's
						if( font_score[1] > 0x75 ){ 
							++font_score[0];
							font_score[1] -= 10;
						}
						
						//Update the score displayed on the BG by sending it to VRAM
						set_bkg_tiles(13, 0, 6, 1, font_score);
						
						//And reset the earned points variable
						scoreAdd=0;
					}

					
					
					
					//-= ROOM MANAGEMENT =-
					
					
					
					//If we have cleared the room from all the enemies (they've all been spawned and killed)
					if( foesLeft == 0 && foesActive == 0 ){
						
						//Generate life bonus, except if its the first room
						if( room > 0 ){
							//Create a new life bonus foe
							spawnFoe( 200, 88, 40);
							
							//Stop the Music (so we have a short pause for the player to breathe, then music will start again when the first foe of the next room is spawned)
							gbt_stop();
							musicPlaying=0;
							
							//Play a SGB SFX to congratulate the player
							sgb_sfx=0x05;
							sgb_volume=0;
							sgb_pitch=3;
							sgb_playSFX();
							
							//Earn increasing score points for completing levels (room*100)
							//Increase the 100's digit directly on the score
							font_score[3] += room;
							//Increase the 1000's if the 100's has overflown (over 10) in the process, several times if needed
							while( font_score[3] > 0x75 ){ 
								++font_score[2];
								font_score[3] -= 10;
							}
							//And add a point to the scoreAdd variable so the score graphics is updated on next frame
							++scoreAdd;
						}
						//Else it's the first room, so no life bonus, but very short foeSpawn countdown instead
						else {
							foesSpawn=10;
							//And don't stop the music :)
						}
						
						//Increase the level number (it's used to compute the foes lives, so it'll make them stronger)
						++room;
						
						//Define the maximum number of foes on screen at the same time for this room (1-12)
						if( foesMax < 8 ){
							++foesMax;
						}
						
						//Set the number of foes left to generate before the next room (that will make the foeSpawn countdown run again!)
						if( room < 5 ){
							foesLeft=6+(room << 2);
						} else if( room < 9 ){
							foesLeft=6+(room << 1);
						} else {
							foesLeft=6+room;
						}
						
						//Set the number of Boss for the current level (Increase every 4 rooms, as we have 4 different bosses, but discard the first room that doesn't have a boss (only a single "tutorial foe"))
						foesBoss=1+((room-1) >> 2);
					}

				
				} //END of "if not paused" block
				
				
				//START BUTTON PRESSED => pause / unpause game
				if ( pad & J_START ){
					
					//Do it only once per keyPress
					if( !startPressed ){
						
						//Toggle the pause
						if( paused == 0 ){
							paused = 1;
							//Pause music (modify the volume register directly, as the gbt_pause function is bugged and can't unpause the sound)
							NR50_REG = 0x00;
							//gbt_pause(1);
						} else {
							paused = 0;
							//Unpause music (modify the volume register directly, as the gbt_pause function is bugged and can't unpause the sound)
							NR50_REG = 0x77;
							//gbt_pause(0);
						}
						
						
						//Done!
						startPressed=1;
					}
				}
				//If key isn't pressed, record that player released the key
				else if( startPressed ){
					startPressed = 0;
				}

			}
			
			//========================================
			//========= GAME OVER SCREEN =============
			//========================================
			else if ( state == 2 ){
				
				//Call the dedicated function
				updateGameOver();	
			}
			
			//========================================
			//============= TITLE SCREEN ==============
			//========================================
			else if ( state == 3 ){
				
				//Call the dedicated function
				updateTitle();
			}
			
			//========================================
			//========== INTRO SCREEN ===========
			//========================================
			else if ( state == 0 ){
				
				//Call the dedicated function
				updateIntro();
			}
			
			//========================================
			//========== INSTRUCTION SCREEN ===========
			//========================================
			else if ( state == 4 ){
				
				//Call the dedicated function
				updateInstructions();
			}
		}

		//=============== COMMON CORE LOOP  ================
		
		//Play the music
		gbt_update(); //This will change to ROM bank 1 (but we are not using banking here: 32kb only - welcome to 1989!).
		
		//Update Display
		HIDE_WIN;
		SHOW_SPRITES;
		SHOW_BKG;
		
		// WAIT FOR VBLANK TO FINISH - ENSURES 60 FRAMES PER SECOND MAXIMUM
		vsync();														
	}
	// GAME LOOP END
}










//=================================
//==========  FUNCTIONS ============
//=================================


//============ FOE =============

//This functions handle the Foe movement
//Params ()
void updateFoeMovement(void){
	
	//-= UPDATE FOE MOVEMENT =-
	
	//If the foe is "stun" => wait for recovery
	if( foe->stun != 0 ){
		//Decrease the stun counter
		--foe->stun;
		//Go back to normal animation frame instead of "hit" after a certain thresold
		if( foe->stun == 20 ){
			//Go back 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
			if( foe->palette > 0 ){ --foe->palette; }
			
			//Update the SGB OAM with the new palette value
			//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
			j=(i << 2)+3;
			//Set the current palette value to the attributes (bits 3-1)
			font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foe->palette << 1) & 0b00001110);
		}
		//If stun period is over
		if( foe->stun == 0 ){
			//Force a "think" cycle to move towards the player who attacked us!
			foe->think = 0;
		}
	}
	
	//If the foe is not held by a hand
	if( handLeft.target != i  && handRight.target != i ){

		//If the foe is not "stun"
		if( foe->stun == 0 ){
			
			//If slow motion movement is disabled or if it's enabled but once every two frames
			if( foe->slow == 0 || ticks_fast ){
				
				//Move the foe according to its speed variables
				foe->x += foe->speedX;
				foe->y += foe->speedY;

				//Bounce if going out of bounds
				//LEFT
				if( foe->x < 17 && foe->speedX <= 0 ){
					
					//Reverse speed
					foe->speedX=-foe->speedX;
					
					//Unmirror the sprite in X
					set_sprite_prop( 20+i, get_sprite_prop(20+i) & ~S_FLIPX);
					
					//Special case: bullet stopped when hitting wall
					if( foe->type == 8 ){
						foe->speedX=0;
						foe->speedY=0;
						//if it's an "instakill" bullet, destroy it immediatedly
						if( foe->anim == 4 ){
							foe->life=1; //the life = 0 and removal code is located after that, alongside all the "special foes" code
						}
					}
					//Else it's not a bullet but a normal foe and if our speed is 0, it means we are stuck in a wall
					else if( foe->speedX == 0 ){
						//So we force a "think" cycle to movetowards the player
						foe->think = 0;
					}
				}
				//RIGHT
				else if ( foe->x > 152 && foe->speedX >= 0 ){
					
					//Reverse speed
					foe->speedX=-foe->speedX;
					
					//Mirror the sprite in X
					set_sprite_prop( 20+i, get_sprite_prop(20+i) | S_FLIPX);
					
					//Special case: bullet stopped when hitting wall
					if( foe->type == 8 ){
						foe->speedX=0;
						foe->speedY=0;
						//if it's an "instakill" bullet, destroy it immediatedly
						if( foe->anim == 4 ){
							foe->life=1; //the life = 0 and removal code is located after that, alongside all the "special foes" code
						}
					}
					//Else it's not a bullet but a normal foe and if our speed is 0, it means we are stuck in a wall
					else if( foe->speedX == 0 ){
						//So we force a "think" cycle to movetowards the player
						foe->think = 0;
					}
				}
				//TOP
				if( foe->y < 25 && foe->speedY <= 0 ){
					
					//Reverse speed
					foe->speedY=-foe->speedY;
					
					//Special case: bullet stopped when hitting wall
					if( foe->type == 8 ){
						foe->speedX=0;
						foe->speedY=0;
						//if it's an "instakill" bullet, destroy it immediatedly
						if( foe->anim == 4 ){
							foe->life=1; //the life = 0 and removal code is located after that, alongside all the "special foes" code
						}
					}
					//Else it's not a bullet but a normal foe and if our speed is 0, it means we are stuck in a wall
					else if( foe->speedY == 0 ){
						//So we force a "think" cycle to movetowards the player
						foe->think = 0;
					}
				}
				//BOTTOM
				else if ( foe->y > 136 && foe->speedY >= 0 ){
					
					//Reverse speed
					foe->speedY=-foe->speedY;
					
					//Special case: bullet stopped when hitting wall
					if( foe->type == 8 ){
						foe->speedX=0;
						foe->speedY=0;
						//if it's an "instakill" bullet, destroy it immediatedly
						if( foe->anim == 4 ){
							foe->life=1; //the life = 0 and removal code is located after that, alongside all the "special foes" code
						}
					}
					//Else it's not a bullet but a normal foe and if our speed is 0, it means we are stuck in a wall
					else if( foe->speedY == 0 ){
						//So we force a "think" cycle to movetowards the player
						foe->think = 0;
					}
				}
				
				//Walking animation (hop 1 pixel high) - except for bullets and bosses
				if( foe->type != 8 && foe->type != 111 && foe->type != 98 && foe->type != 139 && foe->type != 161 ){
					++foe->hop;
					if( foe->hop == 13 ){ foe->hop = 0; }
				}
				
				//Decrease slowdown unless it's a permanent state
				if( foe->slow != 0 && foe->slow != 255 ){
					--foe->slow;
				}
				
				//Think! (i.e. follow the player / change direction if needed)
				if( foe->think == 0 ){
					
					//Modify direction according to current player position
					//If we need to go left
					if( playerX+8 < foe->x-8 ){														
						foe->speedX=-1;
						//Mirror the sprite in X
						set_sprite_prop( 20+i, get_sprite_prop(20+i) | S_FLIPX);
					}
					//Else If we need to go right
					else if( playerX+8 > foe->x+24 ){	
						foe->speedX=1;
						//Unmirror the sprite in X
						set_sprite_prop( 20+i, get_sprite_prop(20+i) & ~S_FLIPX);
					}
					//Else, if we are near the player in X
					else {
						foe->speedX=0;
					}
					
					//If we need to go up
					if( playerY < foe->y-8 ){
						foe->speedY=-1;
					}
					//Else If we need to go down
					else if( playerY > foe->y+24 ){	
						foe->speedY=1;
					}
					//Else, if we are near the player in Y
					else {
						foe->speedY=0;
					}
					
					//If we are static after thinking, force a default movement towards the player (because it means we are very close to him)
					if( foe->speedX == 0 && foe->speedY == 0 ){
						//Move towards the player in X
						if( foe->x < playerX+8 ){ foe->speedX = 1; }
						else { foe->speedX = -1; }
						//Move towards the player in Y
						if( foe->y < playerY ){ foe->speedY = 1; }
						else { foe->speedY = -1; }
					}
					
					//If we are a bullet, we go faster than that!
					if( foe->type == 8 ){
						foe->speedX = foe->speedX << 1;
						foe->speedY = foe->speedY << 1;
					}
					
					//Wait again before next thinking cycle
					if( foe->slow == 255){
						foe->think = 25;
					} else {	
						foe->think = 45;
					}
				} 
				//Else, wait for the next "think" cyle
				else {
					//If we are a "smart" robot (chaser, etc.)
					if( (foe->type >= 50 && foe->type < 90) || (foe->type >= 130 && foe->type < 170) ){
						//decrease the waiting count before the next "let's do something smart" cycle
						--foe->think;
					}
				}
				
				
				//SPECIAL FOES
				//Bullets exploding after X ticks
				if( foe->type == 8 ){
					
					//When not catched, we lose life every turn (countdown before explosion)
					--foe->life;
					
					//If dead, kill it !
					if( foe->life == 0 ){
						//Launch the death anim
						foe->anim=38;
						set_sprite_tile(20+i, foe->anim);
						//unstun because we are dead "now!"
						foe->stun=0;
					}
				}
				//First boss : fast grunt dropping mines (static bullets)
				else if( foe->type == 111 ){
					
					//Animate the foe
					if( ticks_mid ){
						
						//Go to the next animation frame
						foe->anim += 2;
						
						//Loop back if needed
						if( foe->anim > 58 ){
							foe->anim=48;
						}
						
						//Update tile animation in the SGB OAM
						font_OBJMODE[(i<<2)+2]=foe->anim;
					}
					
					//Shoot a bullet from time to time
					if( ticks == 80 || ticks == 160 || ticks == 240 ){
						
						//Avoid generating too much foes on screen, else it lags and became too hard
						if( foesActive < 8 ){
					
							//Shoot a new "bullet" foe on the current foe Position
							k=spawnFoe( 8, foe->x, foe->y);
							//Check if the foe was actually created or if it was silently dismissed because we already have the maximal number of foes
							if( k != 0 ){
								//Modify the life of the bullet so it last 4 seconds => done by spawnFoe
								//foes[k-1].life=240;
								
								//Modify the think value of the bullet so it doesn't aim at the player (it will never countdown, as it's not a smart enemy)
								foes[k-1].think=255;
								
								//And set the speed value so it stands still, like a mine
								foes[k-1].speedX=0;
								foes[k-1].speedY=0;
								
								//Sound : foes shoots
								NR10_REG = 0x21;
								NR11_REG = 0xA3;
								NR12_REG = 0xF1;
								NR13_REG = 0x0A;
								NR14_REG = 0x00;
								NR14_REG = 0x80;
							}
						}
					}
				}
				//Second Boss : Spinning Head that spawn weakling
				else if( foe->type == 98 ){
					
					//Animate the foe
					if( ticks_mid ){
						
						//Go to the next animation frame
						foe->anim += 2;
						
						//Loop back if needed
						if( foe->anim > 58 ){
							foe->anim=48;
						}
						
						//Update tile animation in the SGB OAM
						font_OBJMODE[(i<<2)+2]=foe->anim;
					}
					
					//Spawn a weakling from time to time
					if( ticks == 200 ){
						
						//Avoid generating too much foes on screen, else it lags and became too hard
						if( foesActive < 8 ){
					
							//Shoot a new "tamagotchi" foe on the current foe Position
							k=spawnFoe( 77, foe->x, foe->y);
							//Check if the foe was actually created or if it was silently dismissed because we already have the maximal number of foes
							if( k != 0 ){
								//Increase the foesActive variable as it means we now have a new foe to kill!
								++foesActive;
								//And modify the life of the spawned foe to 1, as it's just a "weakling" that we have to use to kill the boss!
								foes[k-1].life=1;
								
								//Sound : Boss spawn egg!
								NR10_REG = 0x26;
								NR11_REG = 0x85;
								NR12_REG = 0xF3;
								NR13_REG = 0x84;
								NR14_REG = 0x00;
								NR14_REG = 0x83;
							}
						}
					}
					
				}
				//Third Boss : Spinning Head that shoots bullets
				else if( foe->type == 139 ){
					
					//Animate the foe
					if( ticks_mid ){
						
						//Go to the next animation frame
						foe->anim += 2;
						
						//Loop back if needed
						if( foe->anim > 58 ){
							foe->anim=48;
						}
						
						//Update tile animation in the SGB OAM
						font_OBJMODE[(i<<2)+2]=foe->anim;
					}
					
					//Shoot a bullet from time to time
					if( ticks == 60 || ticks == 180 ){
						
						//Avoid generating too much foes on screen, else it lags and became too hard
						if( foesActive < 8 ){
					
							//Shoot a new "bullet" foe on the current foe Position
							k=spawnFoe( 8, foe->x, foe->y);
							//Check if the foe was actually created or if it was silently dismissed because we already have the maximal number of foes
							if( k != 0 ){
								//Modify the life of the bullet so it last 4 seconds => done by spawnFoe
								//foes[k-1].life=240;
								
								//Sound : foes shoots
								NR10_REG = 0x21;
								NR11_REG = 0xA3;
								NR12_REG = 0xF1;
								NR13_REG = 0x0A;
								NR14_REG = 0x00;
								NR14_REG = 0x80;
							}
						}
					}
					
				}
				//Fourth boss : fast chaser spawning loads of foes
				else if( foe->type == 161 ){
					
					//Animate the foe
					if( ticks_mid ){
						
						//Go to the next animation frame
						foe->anim += 2;
						
						//Loop back if needed
						if( foe->anim > 58 ){
							foe->anim=48;
						}
						
						//Update tile animation in the SGB OAM
						font_OBJMODE[(i<<2)+2]=foe->anim;
					}
					
					//Spawn a foe from time to time
					if( ticks == 80 || ticks == 160 || ticks == 240 ){
						//Avoid generating too much foes on screen, else it lags and became too hard
						if( foesActive < 7 ){
						
							//Shoot a new "palette" foe on a random position (spawnLeft)
							k=spawnFoe( 11, 0, 0);
							//Check if the foe was actually created or if it was silently dismissed because we already have the maximal number of foes
							if( k != 0 ){
								//Increase the foesActive variable as it means we now have a new foe to kill!
								++foesActive;
								//And modify the life of the spawned foe to 1, as it's just a "weakling" that we have to use to kill the boss!
								foes[k-1].life=1;
							}
						}
					}
				}
			}
		}
	
	
		//-= FOE LEFT HAND COLLISION =-
		updateFoeLeftHand();
	
		
		//-= FOE PLAYER COLLISION =-
		
		//Collision with player body (unless player is stun or invincible)
		if( stun == 0 && (playerX+4) < foe->x && (playerX+20) > foe->x && playerY < (foe->y+12) && (playerY+12) > foe->y ){
		
			//If it's not a life bonus (and player is not invincible)
			if( foe->type != 200 && invincible == 0 ){
			
				//Decrease player life
				--life;
				
				//Stun the player
				stun = 30;
				
				//special case for bullet (they move too fast to use their vars directly and will explode even they have life left)
				if( foe->type == 8 ){
					
					//Move the player back, but slower than when hitting a foe
					speedX = foe->speedX;
					speedY = foe->speedY;
					
					//Kill the foe bullet as it has reached its target!
					foe->life = 0;
					//Launch the death anim
					foe->anim=38;
					set_sprite_tile(20+i, foe->anim);
					//unstun because we are dead "now!"
					foe->stun=0;										
				}
				//Else, normal case for all the other foes
				else {
					//Moves the player back! (using player Speed variables)
					speedX = foe->speedX << 2;
					speedY = foe->speedY << 2;
					
					//Bounce the foe back
					foe->speedX = -foe->speedX;
					foe->speedY = -foe->speedY;
					//Mirror the foe sprite in X if needed
					if( foe->speedX < 0 ){ 
						set_sprite_prop( 20+i, get_sprite_prop(20+i) | S_FLIPX);
					} else {
						set_sprite_prop( 20+i, get_sprite_prop(20+i) & ~S_FLIPX);
					}
				}

				//Update the "life counter" display to remove a life unit
				set_bkg_tiles(1+life, 0, 1, 1, bg_lifeNO);
			}
			//Else if it's a life bonus
			else if( foe->type == 200 ){
				
				//Increase player life if it's not already maxed out
				if( life < 4 ){
					//Restore player life
					life=4;
					//Update the "life counter" display 4 life unit
					fill_bkg_rect(1, 0, 4, 1, bg_lifeOK[0]);
				}
				
				//Remove the foe so it can be recycled (no explosion needed here)
				foe->active=0;
				foe->x=0;
				foe->y=205;
				
				//the SGB sprite will be updated right below, so need to do it now, it'll go offscren a few lines below with the new foe->y position (205+25 =230)
				//Modify Y position of the SGB OAM sprite
				//font_OBJMODE[(i<<2)+1]=230;
				
				//Change the SGB palette to match the current level
				sgb_setPalette();
				
				//If no music is playing (it's stopped when we kill the last enemy of a room)
				if( musicPlaying == 0 ){					
					//Play normal music
					gbt_play(song_Data, 1, 3);
					musicPlaying=1;
				}
				
				//Sound : Bonus collected!
				NR10_REG = 0x27;
				NR11_REG = 0xD4;
				NR12_REG = 0xF2;
				NR13_REG = 0x40;
				NR14_REG = 0x00;
				NR14_REG = 0x86;
			}
		}
		
		//Update the SGB sprite with the new position
		
		//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index)
		j=(i << 2);
				
		//If walking, make it "hop" 1 pixel high to animate it
		if( foe->hop < 6 ){
			//Position in SGB OAM buffer
			font_OBJMODE[j]=foe->x+36;
			++j;
			font_OBJMODE[j]=foe->y+24;
		} else  {	
			//Position in SGB OAM buffer
			font_OBJMODE[j]=foe->x+36;
			++j;
			font_OBJMODE[j]=foe->y+25;
		}
		
		//DIRTY (but efficient) BUGFIX: sometimes with many foes (room == 7 and after) the SGB sprite gets corrupted and display wrong tiles.
		//I didn't find the source of the bug yet, but refreshing the displayed tile at least fixes the issue, until I manage to prevent it from happening in the first place
		//My guess is that it's tied to the fact that palette will be set over 7 and overflow, thus messing the font_OBJMODE as only 3 bits are allocated to the palette
		//That may explain why you need to be on room 7, as foes must be hit 8 times in this room (so more than the palette number max number)
		//Not only the tiles, but the palette is also displayed wrong
		//The bug is likely due to the "stun" animation management, through palettes, when the foes are hit too quickly / by both hands at the same time.
		//Update tile animation in the SGB OAM
		++j;
		font_OBJMODE[j]=foe->anim;
		//Set the current palette value to the attributes (bits 3-1)
		++j;
		font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foe->palette << 1) & 0b00001110);
	}
}


//This functions handle the Foe - Left Hand collisions
//Params ()
void updateFoeLeftHand(void){
	
	//-= FOE LEFT HAND COLLISION =-
	
	//Collision with Left Hand while shot (except for life bonus foe type)
	if( handLeft.state == 1 && foe->type != 200 && handLeft.x < (foe->x+8) && (handLeft.x+8) > foe->x && handLeft.y < (foe->y+14) && (handLeft.y+14) > foe->y ){
		
		//If hand is empty, catch the current foe
		if( handLeft.target == 255 ){
			
			//If the foe is not "uncatchable" (see foes types in the spawnFoe() function)
			if( foe->type < 90 || foe->type > 200 ){
				//Catch the foe! (we'll move it later)
				handLeft.target = i;
				foe->speedX=0;
				foe->speedY=0;
			}
			//Else, the hand can't catch the foe, so it'll bounce back and make a sad sound
			else {
				//Make the hand move back with swapped axises to show it's been repelled
				handLeft.x -= handLeft.speedY << 1;
				handLeft.y -= handLeft.speedX << 1;
			}
			
			//Special case: catched bullet only have one life point
			if( foe->type == 8 ){
				foe->life = 1;
			}
			
			//Send the hand back to the player
			handLeft.state=2;
			handLeft.speedX=0;
			handLeft.speedY=0;
		}
		//Else if we are hit while the hand is holding a foe different from us, the two foes are damaged altogether
		else if( handLeft.target != i ){
			
			//Current foe
			//Special case for a bullet (it will explode instantly, and it doesn't have a "blink" animation)
			if( foe->type == 8 ){
				foe->life=0;
			}
			//Else, normal foe
			else {
				//Remove one life!
				foe->life -= 1;
				//Change our animation, unless we were previously "stunned" already
				if( foe->stun < 21 ){
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foe->palette < 7 ){ ++foe->palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(i << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foe->palette << 1) & 0b00001110);
				}
				//Stun us
				foe->stun = 32;
				
				//Player earn score points
				++scoreAdd;
			}
			
			//If dead, kill it !
			if( foe->life == 0 ){
				//Launch the death anim
				foe->anim=38;
				set_sprite_tile(20+i, foe->anim);
				//unstun because we are dead "now!"
				foe->stun=0;
				
				//Player earn score points
				scoreAdd += 9;
			}
			//Else, make us move back a little as we've been hit by a hand
			else {
				foe->x += handLeft.speedX << 1;
				foe->y += handLeft.speedY << 1;
				
				//Play SFX : wall hitting sound
				NR41_REG = 0x3F;
				NR42_REG = 0xF2;
				NR43_REG = 0x7D;
				NR44_REG = 0x00;
				NR44_REG = 0x80;
			}
			
			
			//Handheld foe
			//Do the same for the foe currently holded by the hand
			foes[handLeft.target].life -= 1;
			//And change its animation too, unless it was previously stunned already
			if( foes[handLeft.target].stun < 21 ){
				
				//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
				if( foes[handLeft.target].palette < 7 ){ ++foes[handLeft.target].palette; }
				
				//Update the SGB OAM with the new palette value
				//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
				j=(handLeft.target << 2)+3;
				//Set the current palette value to the attributes (bits 3-1)
				font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handLeft.target].palette << 1) & 0b00001110);
			}
			//Stun it
			foes[handLeft.target].stun = 32;
			
			//Player earn score points
			++scoreAdd;
			
			//If dead, kill it !
			if( foes[handLeft.target].life == 0 ){
				
				//Launch the death anim
				foes[handLeft.target].anim=38;
				set_sprite_tile(20+handLeft.target, 38);
				//unstun because we are dead "now!"
				foes[handLeft.target].stun=0;
				
				//Teleport the foe to the current "hand release" position
				foes[handLeft.target].x=handLeft.x;
				foes[handLeft.target].y=handLeft.y;
				
				//Free the hand
				handLeft.target=255;
				
				//Player earn score points
				scoreAdd += 9;
			}
			
			//Send the hand back to the player
			handLeft.state=2;
			handLeft.speedX=0;
			handLeft.speedY=0;
		}
	}
	//Collision with Right Hand while shot (except for life bonus foe type)
	else if( handRight.state == 1 && foe->type != 200 && handRight.x < (foe->x+8) && (handRight.x+8) > foe->x && handRight.y < (foe->y+14) && (handRight.y+14) > foe->y ){

		//-= FOE RIGHT HAND COLLISION =-
		updateFoeRightHand();
	}
	
}


//This functions handle the Foes - Right Hand collisions
//Params ()
void updateFoeRightHand(void){
	
	//-= FOE RIGHT HAND COLLISION =-
	
	//If hand is empty, catch the current foe
	if( handRight.target == 255 ){
		
		//If the foe is not "uncatchable" (see foes types in the spawnFoe() function)
		if( foe->type < 90 || foe->type > 200 ){
			//Catch the foe! (we'll move it later)
			handRight.target = i;
			foe->speedX=0;
			foe->speedY=0;
		}
		//Else, the hand can't catch the foe, so it'll bounce back and make a sad sound
		else {
			//Make the hand move back with swapped axises to show it's been repelled
			handRight.x -= handLeft.speedY << 1;
			handRight.y -= handLeft.speedX << 1;
		}
		
		//Special case: catched bullet only have one life point
		if( foe->type == 8 ){
			foe->life = 1;
		}
		
		//Send the hand back to the player
		handRight.state=2;
		handRight.speedX=0;
		handRight.speedY=0;
	}
	//Else if we are hit while the hand is holding a foe different from us, the two foes are damaged altogether
	else if( handRight.target != i ){
		
		//Current foe
		//Special case for a bullet (it will explode instantly, and it doesn't have a "blink" animation)
		if( foe->type == 8 ){
			foe->life=0;
		}
		//Else, normal foe
		else {
			//Remove one life!
			foe->life -= 1;
			//Change our animation, unless we were previously "stunned" already
			if( foe->stun < 21 ){
				
				//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
				if( foe->palette < 7 ){ ++foe->palette; }
				
				//Update the SGB OAM with the new palette value
				//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
				j=(i << 2)+3;
				//Set the current palette value to the attributes (bits 3-1)
				font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foe->palette << 1) & 0b00001110);
			}
			//Stun us
			foe->stun = 32;
			
			//Player earn score points
			++scoreAdd;
		}
		
		//If dead, kill it !
		if( foe->life == 0 ){
			//Launch the death anim
			foe->anim=38;
			set_sprite_tile(20+i, foe->anim);
			//unstun because we are dead "now!"
			foe->stun=0;
			
			//Player earn score points
			scoreAdd += 9;
		}
		//Else, make us move back a little as we've been hit by a hand
		else {
			foe->x += handRight.speedX << 1;
			foe->y += handRight.speedY << 1;
			
			//Play SFX : wall hitting sound
			NR41_REG = 0x3F;
			NR42_REG = 0xF2;
			NR43_REG = 0x7D;
			NR44_REG = 0x00;
			NR44_REG = 0x80;
		}
		
		
		//Handheld foe
		//Do the same for the foe currently holded by the hand
		foes[handRight.target].life -= 1;
		//And change its animation too, unless it was previously stunned already
		if( foes[handRight.target].stun < 21 ){
			
			//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
			if( foes[handRight.target].palette < 7 ){ ++foes[handRight.target].palette; }
			
			//Update the SGB OAM with the new palette value
			//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
			j=(handRight.target << 2)+3;
			//Set the current palette value to the attributes (bits 3-1)
			font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handRight.target].palette << 1) & 0b00001110);
		}
		//Stun it
		foes[handRight.target].stun = 32;
		
		//Player earn score points
		++scoreAdd;
		
		//If dead, kill it !
		if( foes[handRight.target].life == 0 ){
			
			//Launch the death anim
			foes[handRight.target].anim=38;
			set_sprite_tile(20+handRight.target, 38);
			//unstun because we are dead "now!"
			foes[handRight.target].stun=0;
			
			//Teleport the foe to the current "hand release" position
			foes[handRight.target].x=handRight.x;
			foes[handRight.target].y=handRight.y;
			
			//Free the hand
			handRight.target=255;
			
			//Player earn score points
			scoreAdd += 9;
		}
		
		//Send the hand back to the player
		handRight.state=2;
		handRight.speedX=0;
		handRight.speedY=0;
	}	
}





//============ PLAYER =============

//This functions handle the Player movement
//Params ()
void updatePlayerMovement(void){

	//-= MOVING BODY =-
	
	//If player is not stun
	if( stun == 0 ){
	
		//UP
		if (pad & J_UP){
			speedY = -1;
			dirY = -1;
			//Force Y shoot direction only (if diagonal, we'll set X below)
			dirX = 0;
		}
		//DOWN
		else if (pad & J_DOWN){
			speedY = 1;
			dirY = 1;
			//Force Y shoot direction only (if diagonal, we'll set X below)
			dirX = 0;
		}
		//Don't move if no keypress
		else {
			speedY = 0;
		}
		
		//LEFT
		if (pad & J_LEFT){
			speedX = -1;
			dirX = -1;
			//Force X shoot direction if not moving in Y
			if( speedY == 0 ){
				dirY=0;
			}
		}
		//RIGHT
		else if (pad & J_RIGHT){
			speedX = 1;
			dirX = 1;
			//Force X shoot direction if not moving in Y
			if( speedY == 0 ){
				dirY=0;
			}
		}
		//Don't move if no keypress
		else {
			speedX = 0;
		}
	}

	//Update player position according to its speed
	playerX += speedX;	
	playerY += speedY;
	
	//Bounce if going out of bounds
	if( playerX < 7 && speedX < 0 ){
		playerX=7;
		speedX=0;
	} else if ( playerX > 137 && speedX > 0 ){
		playerX=137;
		speedX=0;
	}
	if( playerY < 24 && speedY < 0 ){
		playerY=24;
		speedY=0;
	} else if ( playerY > 135 && playerY > 0 ){
		playerY=135;
		speedY=0;
	}
}


//This functions handle the Player Left Hand movement
//Params ()
void updatePlayerLeftHand(void){
	
	//-= MOVING HAND LEFT =-
	
	//B button pressed
	if ( (pad & J_B) ){
		
		//Do only once per keypres
		if( bPressed == 0 ){
			
			//If player is not stun and hand is ready to shoot, shot it 
			if( stun == 0 && handLeft.state == 0 ){
				
				//Set the bullet as "fired"
				handLeft.state=1;
				
				//Set the bullet speed according to the current player speed * 2 for more speed!
				handLeft.speedX = dirX * 3;
				handLeft.speedY = dirY * 3;
				
				//Move the bullet to the player position (+ 1 step of the shooting movement)
				handLeft.x = playerX+handLeft.speedX;
				handLeft.y = playerY+handLeft.speedY;
				
				//Change hand animation
				handLeft.anim=2;
				set_sprite_tile(10, handLeft.anim);
				
				//Mirror the sprite if needed (enabled for left+up+down / disabled for right)
				if( dirX > 0 ){
					set_sprite_prop(10, !S_FLIPX);
				} else {
					set_sprite_prop(10, S_FLIPX);
				}
			}
			
			//Do Only once per keypress
			bPressed = 1;
		}
	}
	//Release key when not pressed
	else {
		bPressed = 0;
	}
	
	// UPDATE HAND
	
	//If the Left hand isn't flying but stuck to the player
	if( handLeft.state == 0 ){
		
		//Move it near the player
		handLeft.x=playerX;
		handLeft.y=playerY;
	}
	//Else if it's being "shot"
	else if( handLeft.state == 1 ){
		
		//Move the Hand according to it's internal speeds
		handLeft.x += handLeft.speedX;
		handLeft.y += handLeft.speedY;
		
		//Don't go out in X
		if( handLeft.x < 17 ){
			
			//Set state as repelled
			handLeft.state=2;
			
			//and bounce back from wall
			handLeft.x = 14;
			handLeft.speedX=0;
			
			//If we hold a foe, we damage it!
			if( handLeft.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handLeft.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handLeft.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handLeft.target].palette < 7 ){ ++foes[handLeft.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handLeft.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handLeft.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handLeft.target].stun = 32;
				
				//Player earn score points
				++scoreAdd;
				
				//If dead, kill it !
				if( foes[handLeft.target].life == 0 ){
					
					//Launch the death anim
					foes[handLeft.target].anim=38;
					set_sprite_tile(20+handLeft.target, 38);
					//unstun because we are dead "now!"
					foes[handLeft.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handLeft.target].x=handLeft.x;
					foes[handLeft.target].y=handLeft.y;
					
					//Free the hand
					handLeft.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}
		else if( handLeft.x > 152 ){
			
			//Set state as repelled
			handLeft.state=2;
			//and bounce back from wall
			handLeft.x = 155;
			handLeft.speedX=0;
			
			//If we hold a foe, we damage it!
			if( handLeft.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handLeft.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handLeft.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handLeft.target].palette < 7 ){ ++foes[handLeft.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handLeft.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handLeft.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handLeft.target].stun = 32;

				//Player earn score points
				++scoreAdd;				
				
				//If dead, kill it !
				if( foes[handLeft.target].life == 0 ){
					
					//Launch the death anim
					foes[handLeft.target].anim=38;
					set_sprite_tile(20+handLeft.target, 38);
					//unstun because we are dead "now!"
					foes[handLeft.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handLeft.target].x=handLeft.x;
					foes[handLeft.target].y=handLeft.y;
					
					//Free the hand
					handLeft.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}									
			}
		}
		
		//Don't go out in Y
		if( handLeft.y < 18 ){
			
			//Set state as repelled
			handLeft.state= 2;
			//and bounce back from wall
			handLeft.y = 15;
			handLeft.speedY=0;
			
			//If we hold a foe, we damage it!
			if( handLeft.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handLeft.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handLeft.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handLeft.target].palette < 7 ){ ++foes[handLeft.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handLeft.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handLeft.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handLeft.target].stun = 32;

				//Player earn score points
				++scoreAdd;				
				
				//If dead, kill it !
				if( foes[handLeft.target].life == 0 ){
					
					//Launch the death anim
					foes[handLeft.target].anim=38;
					set_sprite_tile(20+handLeft.target, 38);
					//unstun because we are dead "now!"
					foes[handLeft.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handLeft.target].x=handLeft.x;
					foes[handLeft.target].y=handLeft.y;
					
					//Free the hand
					handLeft.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}									
			}
		}
		else if( handLeft.y > 135 ){
			
			//Set state as repelled
			handLeft.state=2;
			//and bounce back from wall
			handLeft.y = 138;
			handLeft.speedY=0;
			
			//If we hold a foe, we damage it!
			if( handLeft.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handLeft.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handLeft.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handLeft.target].palette < 7 ){ ++foes[handLeft.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handLeft.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handLeft.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handLeft.target].stun = 32;

				//Player earn score points
				++scoreAdd;				
				
				//If dead, kill it !
				if( foes[handLeft.target].life == 0 ){
					
					//Launch the death anim
					foes[handLeft.target].anim=38;
					set_sprite_tile(20+handLeft.target, 38);
					//unstun because we are dead "now!"
					foes[handLeft.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handLeft.target].x=handLeft.x;
					foes[handLeft.target].y=handLeft.y;
					
					//Free the hand
					handLeft.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}

	}
	//Else if it's being recalled
	else if( handLeft.state == 2 ){
		
		//Move the Hand according to it's internal speeds
		handLeft.x += handLeft.speedX;
		handLeft.y += handLeft.speedY;
		
		//If we touch the hand, we retrieve it
		if( playerX < (handLeft.x+8) && (playerX+8) > handLeft.x && playerY < (handLeft.y+8) && (playerY+8) > handLeft.y ){
			
			//Change state back to normal
			handLeft.state = 0;
			
			//Move back to player body
			handLeft.x=playerX;
			handLeft.y=playerY;
			
			//And cancels movement speed
			handLeft.speedX=0;
			handLeft.speedY=0;
			
			//Reset back mirroring (enabled for left hand / disabled for right hand)
			set_sprite_prop(10, S_FLIPX);
			
			//Reset anim too, unless we hold a foe
			if( handLeft.target == 255 ){
				handLeft.anim=0;
				set_sprite_tile(10, handLeft.anim);
			}
		}
		
		//Always moves toward the player
		//in X
		if( handLeft.x < playerX-1 ){
			handLeft.speedX=2;
		} else if( handLeft.x > playerX+1 ){
			handLeft.speedX=-2;
		} else {
			handLeft.speedX=0;
		}
		
		//in Y
		if( handLeft.y < playerY-1 ){
			handLeft.speedY=2;
		} else if( handLeft.y > playerY+1 ){
			handLeft.speedY=-2;
		} else {
			handLeft.speedY=0;
		}
	}
	
}


//This functions handle the Player Right Hand movement
//Params ()
void updatePlayerRightHand(void){
	
	//-= MOVING HAND RIGHT =-	
	
	//A button pressed
	if ( (pad & J_A) ){
		
		//Do only once per keypres
		if( aPressed == 0 ){
			
			//If player is not stun hand is ready to shoot, shot it
			if( stun == 0 && handRight.state == 0 ){
				
				//Set the hand as "fired"
				handRight.state=1;
				
				//Set the bullet speed according to the current player speed * 2 for more speed!
				handRight.speedX = dirX*3;
				handRight.speedY = dirY*3;
				
				//Move the bullet to the player position (+ 1 step of the shooting movement)
				handRight.x = playerX+24+handRight.speedX ;
				handRight.y = playerY+handRight.speedY;
				
				//Change hand animation
				handRight.anim=2;
				set_sprite_tile(11, handRight.anim);
				
				//Mirror the sprite if needed (enabled for left / disabled for right+up+down)
				if( dirX < 0 ){
					set_sprite_prop(11, S_FLIPX);
				} else {
					set_sprite_prop(11, !S_FLIPX);
				}
			}
			
			//Do Only once per keypress
			aPressed = 1;
		}
	}
	//Release key when not pressed
	else {
		aPressed = 0;
	}
	
	// UPDATE HAND
	
	//If the Right hand isn't flying but stuck to the player
	if( handRight.state == 0 ){
		
		//Move it near the player
		handRight.x=playerX+24;
		handRight.y=playerY;
	}
	//Else if it's being "shot"
	else if( handRight.state == 1 ){
		
		//Move the Hand according to it's internal speeds
		handRight.x += handRight.speedX;
		handRight.y += handRight.speedY;
		
		//Don't go out in X
		if( handRight.x < 17 ){
			
			//Set state as repelled
			handRight.state=2;
			
			//and bounce back from wall
			handRight.x = 14;
			handRight.speedX=0;
			
			//If we hold a foe, we damage it!
			if( handRight.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handRight.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handRight.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handRight.target].palette < 7 ){ ++foes[handRight.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handRight.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handRight.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handRight.target].stun = 32;
				
				//Player earn score points
				++scoreAdd;
				
				//If dead, kill it !
				if( foes[handRight.target].life == 0 ){
					
					//Launch the death anim
					foes[handRight.target].anim=38;
					set_sprite_tile(20+handRight.target, 38);
					//unstun because we are dead "now!"
					foes[handRight.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handRight.target].x=handRight.x;
					foes[handRight.target].y=handRight.y;
					
					//Free the hand
					handRight.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}	
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}
		else if( handRight.x > 152 ){
			
			//Set state as repelled
			handRight.state=2;
			//and bounce back from wall
			handRight.x = 155;
			handRight.speedX=0;
			
			//If we hold a foe, we damage it!
			if( handRight.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handRight.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handRight.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handRight.target].palette < 7 ){ ++foes[handRight.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handRight.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handRight.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handRight.target].stun = 32;	

				//Player earn score points
				++scoreAdd;				
				
				//If dead, kill it !
				if( foes[handRight.target].life == 0 ){
					
					//Launch the death anim
					foes[handRight.target].anim=38;
					set_sprite_tile(20+handRight.target, 38);
					//unstun because we are dead "now!"
					foes[handRight.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handRight.target].x=handRight.x;
					foes[handRight.target].y=handRight.y;
					
					//Free the hand
					handRight.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}	
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}
		
		//Don't go out in Y
		if( handRight.y < 18 ){
			
			//Set state as repelled
			handRight.state= 2;
			//and bounce back from wall
			handRight.y = 15;
			handRight.speedY=0;
			
			//If we hold a foe, we damage it!
			if( handRight.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handRight.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handRight.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handRight.target].palette < 7 ){ ++foes[handRight.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handRight.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handRight.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handRight.target].stun = 32;

				//Player earn score points
				++scoreAdd;				
				
				//If dead, kill it !
				if( foes[handRight.target].life == 0 ){
					
					//Launch the death anim
					foes[handRight.target].anim=38;
					set_sprite_tile(20+handRight.target, 38);
					//unstun because we are dead "now!"
					foes[handRight.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handRight.target].x=handRight.x;
					foes[handRight.target].y=handRight.y;
					
					//Free the hand
					handRight.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}
		else if( handRight.y > 135 ){
			
			//Set state as repelled
			handRight.state=2;
			//and bounce back from wall
			handRight.y = 138;
			handRight.speedY=0;
			
			//If we hold a foe, we damage it!
			if( handRight.target != 255 ){
			
				//Do the same for the foe currently holded by the hand
				foes[handRight.target].life -= 1;
				//And change its animation too, unless it was previously stunned already
				if( foes[handRight.target].stun < 21 ){
					
					//Go forward 1 palette (each "foe" has two "stun animation frames" set through palettes, one "normal" and one "hit" located 1 index after the normal one)
					if( foes[handRight.target].palette < 7 ){ ++foes[handRight.target].palette; }
					
					//Update the SGB OAM with the new palette value
					//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index), and add the offset to modify the attributes (byte #3, so +3)
					j=(handRight.target << 2)+3;
					//Set the current palette value to the attributes (bits 3-1)
					font_OBJMODE[j]=(font_OBJMODE[j] & ~0b00001110) | ((foes[handRight.target].palette << 1) & 0b00001110);
				}
				//Stun it
				foes[handRight.target].stun = 32;
				
				//Player earn score points
				++scoreAdd;
				
				//If dead, kill it !
				if( foes[handRight.target].life == 0 ){
					
					//Launch the death anim
					foes[handRight.target].anim=38;
					set_sprite_tile(20+handRight.target, 38);
					//unstun because we are dead "now!"
					foes[handRight.target].stun=0;
					
					//Teleport the foe to the current "hand release" position
					foes[handRight.target].x=handRight.x;
					foes[handRight.target].y=handRight.y;
					
					//Free the hand
					handRight.target=255;
					
					//Player earn score points
					scoreAdd += 9;
				}
				//Else play a wall-hitting sound
				else {									
					//Play SFX
					NR41_REG = 0x3F;
					NR42_REG = 0xF2;
					NR43_REG = 0x7D;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
		}

	}
	//Else if it's being recalled
	else if( handRight.state == 2 ){
		
		//Move the Hand according to it's internal speeds
		handRight.x += handRight.speedX;
		handRight.y += handRight.speedY;
		
		//If we touch the hand, we retrieve it
		if( (playerX+16) < handRight.x && (playerX+32) > handRight.x && playerY < (handRight.y+8) && (playerY+8) > handRight.y ){
			
			//Change state back to normal
			handRight.state = 0;
			
			//Move back to player body
			handRight.x=playerX+24;
			handRight.y=playerY;
			
			//And cancels movement speed
			handRight.speedX=0;
			handRight.speedY=0;
			
			//Reset back mirroring (enabled for left hand / disabled for right hand)
			set_sprite_prop(11, !S_FLIPX);
			
			//Reset anim too, unless we hold a foe
			if( handRight.target == 255 ){
				handRight.anim=0;
				set_sprite_tile(11, handRight.anim);
			}
		}
		
		//Always moves toward the player
		//in X
		if( handRight.x < playerX+23 ){
			handRight.speedX=2;
		} else if( handRight.x > playerX+25 ){
			handRight.speedX=-2;
		} else {
			handRight.speedX=0;
		}
		
		//in Y
		if( handRight.y < playerY-1 ){
			handRight.speedY=2;
		} else if( handRight.y > playerY+1 ){
			handRight.speedY=-2;
		} else {
			handRight.speedY=0;
		}
	}
	
}


//This functions handle the Player animations
//Params ()
void updatePlayerAnimation(void){
	
	//-= ANIMATIONS =-
	
	//Update PLAYER sprites positions on screen
	//hands
	move_sprite(10, handLeft.x, handLeft.y);
	move_sprite(11, handRight.x, handRight.y);
	//body
	move_sprite(12, playerX+8, playerY);
	move_sprite(13, playerX+16, playerY);
	
	//STUN (disable player control)
	if( stun != 0 ){
		
		//Animate body
		//Start of a stun (i.e. number we set at the start of a player stun);
		if( stun == 30 ){ 
			//Set animation "hit" 1
			set_sprite_tile(12, 34);
			set_sprite_tile(13, 36);
		}
		else if ( stun == 20 ){
			//Set body  animation "hit" 2
			set_sprite_tile(12, 30);
			set_sprite_tile(13, 32);
			
			//Decrease speed
			speedX = speedX >> 1;
			speedY = speedY >> 1;
		}
		else if ( stun == 10 ){
			//Set body animation normal
			set_sprite_tile(12, 10);
			set_sprite_tile(13, 12);
		
			//Stop all movement
			speedX = 0;
			speedY = 0;
		}
		//Last stun step
		else if ( stun == 1 ){
			
			//Is the player dead ?
			if( life == 0 ){

				//Stop the music
				gbt_stop();
				
				//And put the game in game over state
				state = 2;

				//Reset ticks for the game over screen
				ticks=0;
				
				//Restore the original background tiles to the BKG map instead of the ones used to transfer SGB OBJ OAM data (the 7 leftmost tiles of the last screen row)
				set_bkg_tiles(0,17,7,1, font_OBJQUIT);
				
				//Disable the SGB OBJ mode so we can do fading out in the Game Over state
				sgb_OBJdisable();
			}
			//Else the player is still alive!
			else {
				//Give the player a short invicible time after a stun!
				invincible = 180;
			}
		}
		
		//Generate explosions!
		if( ticks_fast && stun > 20 ){
			spawnFoe(5, playerX+12, playerY);
		}
		
		//Decrease stun counter
		--stun;
	} 
	
	//Else, player control is active!
	else {
	
		//STANDING STILL
		if( speedX == 0 && speedY == 0 ){		
			
			//Animation (2 steps )
			if( ticks_slowest) {
				++animStep;
			}
			if( animStep > 1){ animStep = 0; }
			
			//Display current animation
			if( animStep == 1 ){
				//Hands one pixel up
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y-1); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y-1); }
			} else {
				//Hands normal
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y); }
			}
		}
		//WALKING
		else {
			//Animation (4 steps )
			if( ticks_slow) {
				++animStep;
			}
			if( animStep > 3){ animStep = 0; }
			
			//Display current animation
			if( animStep == 3 ){
				//Hands
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y-1); }
				//Move Body
				move_sprite(12, playerX+8, playerY+1);
				move_sprite(13, playerX+16, playerY+1);
			} 
			else if( animStep == 2 ){
				//Hands
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y-1); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y-1); }
			} 
			else if( animStep == 1 ){
				//Hands
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y-1); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y); }
				//Move Body
				move_sprite(12, playerX+8, playerY+1);
				move_sprite(13, playerX+16, playerY+1);
			} 
			else {
				//Hands
				if( handLeft.state == 0 ){ move_sprite(10, handLeft.x, handLeft.y-1); }
				if( handRight.state == 0 ){ move_sprite(11, handRight.x, handRight.y-1); }
			}
			
			//BODY
			//Face Left
			if( dirX == -1 ){
				set_sprite_tile(12, 18);
				set_sprite_tile(13, 20);
			} 
			//Face Right
			else if( dirX == 1 ){
				set_sprite_tile(12, 14);
				set_sprite_tile(13, 16);
			}
			//Face Up
			else if( dirY == -1 ){
				set_sprite_tile(12, 22);
				set_sprite_tile(13, 24);
			}
			//Face Down
			else if( dirY == 1 ){
				set_sprite_tile(12, 26);
				set_sprite_tile(13, 28);
			}
		}
	}
	
	//If the hands hold a target, we move it with them now
	if( handLeft.target != 255 ){
		
		//Update the Foe position variables
		foes[handLeft.target].x=handLeft.x;
		foes[handLeft.target].y=handLeft.y-4;
		
		//Move SGB the sprite onscreen too
		
		//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index)
		j=(handLeft.target << 2);

		//Position in SGB OAM buffer
		font_OBJMODE[j]=handLeft.x+36;
		++j;
		font_OBJMODE[j]=handLeft.y+20;
		
	}
	if( handRight.target != 255 ){

		//Update the Foe position variables
		foes[handRight.target].x=handRight.x;
		foes[handRight.target].y=handRight.y-4;
		
		//Move SGB the sprite onscreen too
		
		//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index)
		j=(handRight.target << 2);

		//Position in SGB OAM buffer
		font_OBJMODE[j]=handRight.x+36;
		++j;
		font_OBJMODE[j]=handRight.y+20;
	}
	
	//Player Invicibilty
	if( invincible != 0 ){
		
		//Every X frames, set the body sprites off screen to make it "blink"
		if( ticks % 6 < 3 ){
			move_sprite(12, 0, 0); 
			move_sprite(13, 0, 0); 
		}
		
		//Decrease invicibility counter
		--invincible;
	}
	
}



//============ GAMEPLAY =============




//This function spawn a new "foe" and add it to the general foe array
//Return 0 if the foe creation have failed (i.e. if we already had the maximal number of foes onscreen), or the foesIndex+1 otherwise
//Params (type, X position, Y Position) => if X and Y == 0, then they will be spawned offscreen on a random position
//Foe Types:
// 5: Explosion!
// 8: Bullet (catchable, self-destruct after a while, doesn't mess with the number of foes to kill to clear a room)
// 10-29: base grunt : slow and random movement
// 30-49: faster grunt : fast and random movement
// 50-69: slow chaser : slowly follow player
// 70-89: quick chaser : fast follow player
// 90-109: Uncatchable base grunt : slow and random movement
// 110-129: Uncatchable faster grunt : fast and random movement
// 130-149: Uncatchable slow chaser : slowly follow player
// 150-169: Uncatchable quick chaser : fast follow player
// 170-199: Uncatchable others foes (boss parts...)
// 200: Uncatchable life bonus
UINT8 spawnFoe( UINT8 type, UINT8 posX, UINT8 posY ){
	
	//Find an empty spot in the array of pointer to avoid wasting them!
	UINT8 index=255;
	UINT8 iterator = 0;
	for( iterator = 0 ; iterator < 12 ; ++iterator ){
		
		//If the foe is inactive, break the loop to use this index (don't use break statement here for reasons I don't remember now, but simply don't erase the "index" if one was found already (255=no index found, else we already have found a slot)
		if( foes[iterator].active == 0 ){ 
			if( index == 255 ){ index=iterator; }
		}
		//Else the loop will test the next index, until it reaches the limit :)
	}
	
	//Only if we could find a free spot in the foe array (else we silently "skip" generating a foe)
	if( index < 12 ){
	
		//Generate a new foe in the current slot
		foes[index].active=1;
		
		//Foes don't need to think at first (they will during their active life if needed / able)
		//Generate a slightly randomized start value to avoid that foes generated at the same time all "think" at the same time too!
		foes[index].think=30+((UINT8)rand() % 30);
		
		//Reset all other foes variables (some foes don't set them all, so it can lead to strange bugs 
		foes[index].speedX=0;
		foes[index].speedY=0;
		foes[index].life=0;
		foes[index].anim=0;
		foes[index].stun=0;
		foes[index].slow=0;
		foes[index].hop=0;
		foes[index].palette=0;
		
		//POSITION
		//If we have a specified position, use it directly
		if( posX != 0 || posY != 0 ){
			
			//Use the specified position directly, so the foe can appear inside the room
			foes[index].x=posX;
			foes[index].y=posY;
			
			//Except for "special foes" (life bonus, explosion)
			if( type != 5 && type != 200 ){
			
				//Set Initial speed
				foes[index].speedX=1 - ((UINT8)rand() & 1);
				foes[index].speedY=1 - ((UINT8)rand() & 1);
				//Set a default speed if random has failed,
				if( foes[index].speedX == 0 && foes[index].speedY == 0 ){
					foes[index].speedX=1;
					foes[index].speedY=1;
				}
			}
		}
		//Else generate new random position in one of the four borders
		else {
			
			//Use local i to store random value
			//Cast rand() as UINT because the function return a INT (-X / +X) number by default!
			iterator = (UINT8)rand() & 3;
			//Left
			if( iterator == 0 ){
				foes[index].x=0;
				foes[index].y=25+((UINT8)rand() % 108);
				//Set Initial speed
				foes[index].speedX=1;
				foes[index].speedY=1 - ((UINT8)rand() & 1);
			}
			//Right
			else if( iterator == 1 ){
				foes[index].x=168;
				foes[index].y=25+((UINT8)rand() % 108);
				//Set Initial speed
				foes[index].speedX=-1;
				foes[index].speedY=1 - ((UINT8)rand() & 1);
			}
			//Top
			else if( iterator == 2 ){
				foes[index].x=17+((UINT8)rand() % 130);
				foes[index].y=0;
				//Set Initial speed
				foes[index].speedX=1 - ((UINT8)rand() & 1);
				foes[index].speedY=1;
			}
			//Bottom
			else if( iterator == 3 ){
				foes[index].x=17+((UINT8)rand() % 130);
				foes[index].y=160;
				//Set Initial speed
				foes[index].speedX=1 - ((UINT8)rand() & 1);
				foes[index].speedY=-1;
			}
		}
		
		//TYPE (include life, slow/fast speed, movement type, etc.)
		//if we got one, use it
		if( type != 0 ){
			foes[index].type = type;
			
			//If it's an explosion
			if( type == 5 ){
				//No life needed here, we'll just explode!
				foes[index].life=0;
				
				//Select the corresponding animation
				foes[index].anim=38;
			}
			//If it's a bullet (that will explode after X time if it misses targer and is not catched by player)
			else if( type == 8 ){
				//Our life expectency is 4 seconds (it'll decrease automatically at every frame)
				foes[index].life=240;
				
				//Select the corresponding animation
				foes[index].anim=60;

				//Define the palette
				foes[index].palette = 1;
				
				//We will do a "think" at start to target the player (only once, we're not an aiming missile :p)
				//Our movement speed is also defined in the "think" section in the main foe loop code
				foes[index].think=0;
			}
			//Else if it's an life up bonus
			else if( type == 200 ){
				//No life needed here, we'll just explode!
				foes[index].life=1;
				
				//Select the corresponding animation
				foes[index].anim=112;
				
				//Makes it forever "slow" so it "hops" slower
				foes[index].slow=255;
			}
			//else it's a standard enemy
			else {
				//Generate the life according to the "room" we are in
				foes[index].life=1+room;
				
				//Adjust movement speed and thinking according to the type
				if( (foes[index].type >= 10 && foes[index].type < 29) || (foes[index].type >= 50 && foes[index].type < 69) || (foes[index].type >= 90 && foes[index].type < 109) || (foes[index].type >= 130 && foes[index].type < 149) ){
					foes[index].slow=255;
				}
				//Else, fast movement
				else {
					//Set a minimal amount of slow movement at room start / foe spawn
					foes[index].slow=15;
				}
				
				//Define the corresponding animation based on the type
				//Boss : Spinning Head
				if( foes[index].type == 111 || foes[index].type == 98 || foes[index].type == 139 || foes[index].type == 161 ){
					
					//Define the first animation frame, the foe will then be animated in its "foeMovement" function
					foes[index].anim = 48;
					
					//Set the boss life too, as it's higher than common enemies too
					foes[index].life=3+(room >> 2);
				}
				//Boss spawn : second boss chaser weaklings
				if( foes[index].type == 77 ){
					
					//Define the animation frame
					foes[index].anim = 62;
					//Define the palette
					foes[index].palette = 1;
				}
				//Boss spawn : fourth boss dumb weaklings
				if( foes[index].type == 11 ){
					
					//Define the animation frame
					foes[index].anim = 62;
					//Define the palette
					foes[index].palette = 1;
				}
			}
		}
		//Else, generate one randomly among the "basic" foes
		else {
			
			//Generate the life according to the "room" we are in 
			if( room < 4 ){
				//Gain one life point every room at start
				foes[index].life=1+room;
			} else {
				//Then gain one life point every 2 room after that
				foes[index].life=1+(room >> 1);
			}
			
			
			//Use local i to store random value
			//Cast rand() as UINT because the function return a INT (-X / +X) number by default!
			i = (UINT8)rand() % 19;
			
			//Basic Grunt slow
			if( i < 9 ){
				//Select the right foe type
				foes[index].type = 10;
				
				//Makes it forever slow
				foes[index].slow=255;
				
				//Select the corresponding animation
				foes[index].anim=114;
				
				//If we are on SGB2, only the first 2 palettes are defined (+6 fully black), while 8 palette ares defined on SGB1 (although only 2 or 3 looks great, and the others are okay)
				if( _cpu == MGB_TYPE ){
					//And pick a palette at random (0-1 looks good for this one)
					foes[index].palette=((UINT8)rand() & 1);
				}
				//Else SGB1 with 4 palettes to pick from
				else {
					//And pick a palette at random (0-3 looks good for this one)
					foes[index].palette=((UINT8)rand() & 3);
				}
			}
			//Basic Grunt fast
			else if ( i >= 9 && i < 14 ){
				//Select the right foe type
				foes[index].type = 30;
				
				//Makes it slow at start only
				foes[index].slow=30;
				
				//Select the corresponding animation
				foes[index].anim=116;
				
				//If we are on SGB2, only the first 2 palettes are defined (+6 fully black), while 8 palette ares defined on SGB1 (although only 2 or 3 looks great, and the others are okay)
				if( _cpu == MGB_TYPE ){
					//And pick a palette at random (0-1 looks good for this one)
					foes[index].palette=((UINT8)rand() & 1);
				}
				//Else SGB1 with 4 palettes to pick from
				else {
					//And pick a palette at random (0-3 looks good for this one)
					foes[index].palette=((UINT8)rand() & 3);
				}
			}
			//Slow chaser
			else if ( i == 14 ){
				//Select the right foe type
				foes[index].type = 54;
				
				//Makes it forever slow
				foes[index].slow=255;
				
				//Select the corresponding animation
				foes[index].anim=1;
			}
			//Slow chaser
			else if ( i == 15 ){
				//Select the right foe type
				foes[index].type = 55;
				
				//Makes it forever slow
				foes[index].slow=255;
				
				//Select the corresponding animation
				foes[index].anim=4;
			}
			//Fast Chaser
			else if ( i == 16 ){
				//Select the right foe type
				foes[index].type = 56;
				
				//Makes it slow at start only
				foes[index].slow=30;
				
				//Select the corresponding animation
				foes[index].anim=7;
			}
			//Fast Chaser
			else if (  i == 17 ){
				//Select the right foe type
				foes[index].type = 57;
				
				//Makes it slow at start only
				foes[index].slow=30;
				
				//Select the corresponding animation
				foes[index].anim=9;
			}
			//Fast Chaser
			else if (  i == 18 ){
				//Select the right foe type
				foes[index].type = 58;
				
				//Makes it slow at start only
				foes[index].slow=30;
				
				//Select the corresponding animation
				foes[index].anim=13;
			}
		}
		
		//SPRITE
		
		//First, compute the current foe index to SGB OAM index offset (foe index * 4 = SGB index)
		iterator=(index << 2);

		//If the foe is an explosion, display it using the regular GB sprites
		if( foe->type == 5 ){
		
			//Initialise the corresponding sprite
			set_sprite_tile( 20+index, foes[index].anim );
			
			//Mirror the sprite in X if needed (enabled for left / disabled for right)
			if( foes[index].speedX < 0 ){
				set_sprite_prop( 20+index, get_sprite_prop(20+index) | S_FLIPX);
			} else {
				set_sprite_prop( 20+index, get_sprite_prop(20+index) & ~S_FLIPX);
			}
		
			//Move the sprite to the game area!
			move_sprite( 20+index, foes[index].x, foes[index].y );
			
			//Hide the SGB sprite by putting it offscreen
			
			//Position
			font_OBJMODE[iterator]=0;
			++iterator;
			font_OBJMODE[iterator]=230;
			
		}
		//Else, we use a SGB sprite to display it, so we hide the GB sprite, and set the corresponding SGB OAM entry
		else {
			
			//Hide the GB sprite as we won't use it

			//Put it offscreen
			move_sprite( 20+index, 0, 200 );
			
			//And attribute it to a "blank" tile data
			set_sprite_tile( 20+index, 114 );
			
			//Set up the SGB SPRITE (SNES OAM format)

			//Position
			font_OBJMODE[iterator]=foes[index].x+36;
			++iterator;
			font_OBJMODE[iterator]=foes[index].y+24;
			
			//Tile number (00-FF)
			++iterator;
			font_OBJMODE[iterator]=foes[index].anim;
			
			//Attributes : Y-Flip (0=Normal, 1=Mirror Vertically)+X-Flip (0=Normal, 1=Mirror Horizontally)+Priority relative to BG (use only 3 on SGB)+Palette Number (0-7)+Tile Page (use only 0 on SGB)
			++iterator;
			font_OBJMODE[iterator]=0b00110000;
			//Set the current palette value to the attributes (bits 3-1)
			font_OBJMODE[iterator]=(font_OBJMODE[iterator] & ~0b00001110) | ((foes[index].palette << 1) & 0b00001110);
		}
		
		//Return the foe index + 1 (so we send a value > 0) to notice that we DID create a new foe
		return (1+index);
	}
	//Else, the foe creation was silently dismissed
	else {
		//Return 0 to notice that the foe wasn't created
		return 0;
	}
	
}



//============ SUPER GAME BOY =============

//This functions enable the OBJ_TRN mode
//Params ()
void sgb_OBJenable(void){
	
	//Hacking method, courtesy of Nenson Dubois (thanks A LOT for sharing this discovery, this game won't have been possible without your work!)
	//
	//DATA_SND Game Boy Command Set: 
	//To toggle this in any game, at any time set the following DATA_SND commands in GB/GBC ROM: 
	//79 06 0F 00 7E 01 00000000000000000000 - Enable OBJ_TRN mode 
	//79 06 0F 00 7E 00 00000000000000000000 - Disable OBJ_TRN mode 
	//
	//Read more details: https://www.romhacking.net/hacks/5709/
		
	//Activate object transfer mode using the DATA_SND to forcefully toggle the OBJ_TRN function (you can't enable it the regular way, the SGB BIOS prevents it)
	
	//Prepare the command packet data
	sgb_packet[0]=0x79; //0x0F*8+1;
	sgb_packet[1]=0x06;
	sgb_packet[2]=0x0F;
	sgb_packet[3]=0x00;
	sgb_packet[4]=0x7E;
	sgb_packet[5]=0x01; //0x01 : enable / 0x00 : disable
	sgb_packet[6]=0x00;
	sgb_packet[7]=0x00;
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	
	//Send the packet to the SGB
	sgb_transfer(sgb_packet);
}


//This functions disable the OBJ_TRN mode
//Params ()
void sgb_OBJdisable(void){
	
	//Disable object transfer mode using the DATA_SND to forcefully toggle the OBJ_TRN function (you can't enable it the regular way, the SGB BIOS prevents it)
	
	//Prepare the command packet data
	sgb_packet[0]=0x79; //0x0F*8+1;
	sgb_packet[1]=0x06;
	sgb_packet[2]=0x0F;
	sgb_packet[3]=0x00;
	sgb_packet[4]=0x7E;
	sgb_packet[5]=0x00; //0x01 : enable / 0x00 : disable
	sgb_packet[6]=0x00;
	sgb_packet[7]=0x00;
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	
	//Send the packet to the SGB
	sgb_transfer(sgb_packet);
}


//This functions set the SGB palettes 0 & 1 depending on the current room / level value (each room has it's own color scheme)
//Params ()
void sgb_setPalette(void){

	//ROOM 0-1 : Monochrome DMG palette ("PeaSoup")
	if ( room == 0 || room == 1 ){

		//Modify default SGB Palette 0 & 1 for GB colorization
		//Color Data for 7 colors of 2 bytes (16bit) each:
		// Bit 0-4 - Red Intensity   (0-31)
		// Bit 5-9 - Green Intensity (0-31)
		// Bit 10-14 - Blue Intensity  (0-31)
		// Bit 15 - Not used (zero)
		//Header
		sgb_packet[0]=0x01; //0x00*8+1;
		//Color 0
		sgb_packet[1]=0xFF;
		sgb_packet[2]=0x67;
		//Color 1 - Pal 0
		sgb_packet[3]=0x17;
		sgb_packet[4]=0x2F;
		//Color 2 - Pal 0
		sgb_packet[5]=0x30;
		sgb_packet[6]=0x22;
		//Color 3 - Pal 0
		sgb_packet[7]=0x48;
		sgb_packet[8]=0x15;
		//Color 1 - Pal 1
		sgb_packet[9]=0x17;
		sgb_packet[10]=0x2F;
		//Color 2 - Pal 1
		sgb_packet[11]=0x30;
		sgb_packet[12]=0x22;
		//Color 3 - Pal 1
		sgb_packet[13]=0x48;
		sgb_packet[14]=0x15;
		//Unused
		sgb_packet[15]=0x00;
		//Send the SGB command packet
		sgb_transfer(sgb_packet);
	}
	//ROOM 2 and above : Red colored walls + Original or Play It loud DMG
	else {
		//We are cycling 8 color palettes for the DMG body (Original DMG color + 7 colors from the Play It Loud series)
		l=room&7; //equals a modulo 8 
	
		//Modify default SGB Palette 0 & 1 for GB colorization
		//Color Data for 7 colors of 2 bytes (16bit) each:
		// Bit 0-4 - Red Intensity   (0-31)
		// Bit 5-9 - Green Intensity (0-31)
		// Bit 10-14 - Blue Intensity  (0-31)
		// Bit 15 - Not used (zero)
		//Header
		sgb_packet[0]=0x01; //0x00*8+1;
		//Color 0
		sgb_packet[1]=0xFF;
		sgb_packet[2]=0xFF;
		//Color 1 - Pal 0 (DMG body color, change with the room number)
		//Play It Loud: Traditional White
		if ( l == 0 ){
			sgb_packet[3]=0xFF;
			sgb_packet[4]=0xFF;
		}
		//Play It Loud: Deep Black
		else if ( l == 1 ){
			sgb_packet[3]=0xC6;
			sgb_packet[4]=0x20;
		}
		//Original 1989 DMG color: Off-White (3rd position as we only get "color" starting with 3rd level, so room == 2)
		else if ( l == 2 ){
			sgb_packet[3]=0xD8;
			sgb_packet[4]=0x62;
		}
		//Play It Loud: Vibrant Yellow
		else if ( l == 3 ){
			sgb_packet[3]=0xDE;
			sgb_packet[4]=0x16;
		}
		//Play It Loud: Gorgeous Green
		else if ( l == 4 ){
			sgb_packet[3]=0x65;
			sgb_packet[4]=0x36;
		}
		//Play It Loud: Radiant Red
		else if ( l == 5 ){
			sgb_packet[3]=0xDD;
			sgb_packet[4]=0x10;
		}
		//Play It Loud: Cool Blue
		else if ( l == 6 ){
			sgb_packet[3]=0x86;
			sgb_packet[4]=0x4D;
		}
		//Limited Edition: Hot Pink (special edition with Kirby logo, 1994 UK exclusive, so before the Play It Loud series in 1995)
		else if ( l == 7 ){
			sgb_packet[3]=0xBF;
			sgb_packet[4]=0x6E;
		}
		//Color 2 - Pal 0 (DMG Screen border and buttons color)
		//Original 1989 DMG & Play It Loud: Deep Black have a light grey color for screen border and buttons unlike the other variant with a very dark grey, almost black, color
		if ( l == 2 || l == 1 ){
			sgb_packet[5]=0xEF;
			sgb_packet[6]=0x3D;
		}
		//Else, all other colors have a "dark gray" color for screen border and buttons
		else {
			sgb_packet[5]=0xC6;
			sgb_packet[6]=0x20;
		}
		//Color 3 - Pal 0
		sgb_packet[7]=0x00;
		sgb_packet[8]=0x00;
		//Color 1 - Pal 1
		sgb_packet[9]=0x9F;
		sgb_packet[10]=0x00;
		//Color 2 - Pal 1
		sgb_packet[11]=0x13;
		sgb_packet[12]=0x20;
		//Color 3 - Pal 1
		sgb_packet[13]=0x23;
		sgb_packet[14]=0x40;
		//Unused
		sgb_packet[15]=0x00;
		//Send the SGB command packet
		sgb_transfer(sgb_packet);
	}	
}


//This functions play a SGB Sound Effects
//Params () but uses variables sgb_sfx (sound id) and sgb_pitch (sound pitch), for voice A
void sgb_playSFX(void){
	
	//Play a Sound Effect using the parameters from global variables
	
	//Prepare the command packet data
	sgb_packet[0]=0x41; //0x08*8+1;
	//Sound A id (0x80 = silent)
	sgb_packet[1]=sgb_sfx;
	//Sound B id (0x80 = silent)
	sgb_packet[2]=0x80;
	//Sound A & B attributes: 
	//	Bit 0-1 - Sound Effect A Pitch  (0..3=Low..High)
	//	Bit 2-3 - Sound Effect A Volume (0..2=High..Low, 3=Mute on)
	//	Bit 4-5 - Sound Effect B Pitch  (0..3=Low..High)
        //	Bit 6-7 - Sound Effect B Volume (0..2=High..Low, 3=Not used)
	sgb_packet[3]=0+sgb_pitch+(sgb_volume << 2);
	//Music Score (0 if not used)
	sgb_packet[4]=0x00;
	sgb_packet[5]=0x00;
	sgb_packet[6]=0x00;
	sgb_packet[7]=0x00;
	sgb_packet[8]=0x00;
	sgb_packet[9]=0x00;
	sgb_packet[10]=0x00;
	sgb_packet[11]=0x00;
	sgb_packet[12]=0x00;
	sgb_packet[13]=0x00;
	sgb_packet[14]=0x00;
	sgb_packet[15]=0x00;
	
	//Send the packet to the SGB
	sgb_transfer(sgb_packet);
}





//============ MENU STATES =============



//This functions handle the Game Over Screen
//Params ()
void updateGameOver(void){
	
	//Is the Game Over animation over ?
	if (ticks == 190){
		//Finish the BG fade in
		BGP_REG = 0xE4U;
	}
	//Else, keep playing the game over animation
	else {
		//increase the frame counter
		++ticks;
		
		//Do the game over animation !
		
		//Keep on making explosions with the all the foes that are already in the "explosion" animation process
		//We use the last 6 foes to make the death explosions !
		//Init on first frame
		if( ticks == 1 ){
			
			//Init the first explosion foe
			foes[6].anim=38;
			foes[6].x=playerX;
			foes[6].y=playerY;
			set_sprite_tile(20+6, 38);
			
			//Init the other explosions foe
			for(i = 7 ; i < 12 ; i++ ){
				foes[i].anim=38-((i+1)*4);
				foes[i].x=0;
				foes[i].y=0;
				set_sprite_tile(20+i, 38);
				move_sprite(20+i, 0, 0);
			}
			
			//Re-enable the sound
			NR52_REG = 0x80;
			// ENABLE SOUND CHANNELS (1: 0x11 / 2: 0x22 / 3: 0x44 / 4: 0x88 / All : 0xFF)
			NR51_REG = 0xFF;
			// VOLUME MAX = 0x77, MIN = 0x00	
			NR50_REG = 0x77;
			
			//Sound : Long power down sound
			NR10_REG = 0x4E; //or 1E or 1D for louder sound / 2E / 3E / 4E... for more "vibe"
			NR11_REG = 0x96;
			NR12_REG = 0xF7; //B7, C7, D7...F7 for longer sound
			NR13_REG = 0xBB;
			NR14_REG = 0x00;
			NR14_REG = 0x85;
		}
		
		//Update each foe individually
		for(i = 0 ; i < 12 ; i++ ){
				
			//Get a pointer to the current foe
			foe=&foes[i];
		
			//Do some initialisation on the first frame only
			if( foe->anim == 38){

				//Position the explosion randomly near the player
				foe->x=playerX+26-((UINT8)rand() % 20);
				foe->y=playerY+10-((UINT8)rand() % 20);
				
				//Position the sprite
				move_sprite( 20+i, foe->x, foe->y);
				set_sprite_tile(20+i, foe->anim);
				
				//Play SFX
				if( ticks < 130 ){
					NR41_REG = 0x3F;
					NR42_REG = 0xF4;
					NR43_REG = 0x7C;
					NR44_REG = 0x00;
					NR44_REG = 0x80;
				}
			}
			//Animation end
			else if( foe->anim > 52){
				
				//Unless the explosion sequence has ended, and only for the 6 last foes (to avoid having too much explosions sprites!) 
				if( ticks < 120 && i > 5 ){
					//Reset the explosion
					foe->anim=38-((i-5)*4);
					//And move offscreen as it will start again in a new position on the next frame
					move_sprite( 20+i, 0, 0);
				}
			}
			
			//Go to the next animation, only if we are exploding (the lower limits is set to 10 (DMG tiles) to avoid the bullet tiles while still having some room before the actual explosions animations to delay them)
			if( !(ticks & 0x3) && foe->anim >= 10 && foe->anim <= 52 ){
			
				//Go to the next animation (2 per 2 as we are in 8x16 sprites)
				foe->anim += 2; 

				//And displays it!
				set_sprite_tile(20+i, foe->anim);
			}
		}
		
		//Make the player "blink" using its "hit" animation
		if( ticks <= 120 ){
			
			k=ticks % 30;
			if( k == 0 ){ 
				//Set body animation normal
				set_sprite_tile(12, 10);
				set_sprite_tile(13, 12);
			}
			else if( k == 10 ){ 
				//Set animation "hit" 1
				set_sprite_tile(12, 34);
				set_sprite_tile(13, 36);
			}
			else if ( k == 20 ){
				//Set body  animation "hit" 2
				set_sprite_tile(12, 30);
				set_sprite_tile(13, 32);
			}
		}

		//Fade the background first
		if (ticks == 60){
			BGP_REG = 0x90;
		}
		//Fade the background first
		else if (ticks == 70){
			BGP_REG = 0x40;
		}
		//Fade the background first
		else if (ticks == 80){
			//The palette isn't pure white, but light gray is still on, as if we go to palette 0x00 for BG it'll automatically trigger a fadein again
			//However, we "modify" the BG in real time to remove all tiles containing a "light gray" color (the game over message uses dark gray)
			BGP_REG = 0x04;
			
			//Background tiles : fill the screen white
			for (j=0 ; j != 18 ; j++){
				for (i=0 ; i != 22 ; i++){		
					set_bkg_tiles(i, j, 1, 1, bg_blank);
				}
			}	
			
			//Display a Game Over message (the text font uses black color, although it's current set to white in the palette as it's "faded out")
			//gotoxy(5,8);
			//printf("GAME OVER");
			set_bkg_based_tiles(2, 2, 15, 9, msg_gameover_map, 119);
			
			//Print the score
			gotoxy(3,14);
			printf("Score:");
			
			//Convert the all the score GUI display tiles to the "0" tile of our text font tileset to display them using the text font (until now, they were using the special font with the BKG baked in to be displayed during gameplay on the GUI)
			//The "0" tile in the GUI font is 0x6C, while it's 0x10 in our regular text font. So we substract 0x6C - 0x10 = 0x5C to each digit to convert them and be able to display them with our text font
			font_score[0] -= 0x5C;
			font_score[1] -= 0x5C;
			font_score[2] -= 0x5C;
			font_score[3] -= 0x5C;
			font_score[4] -= 0x5C;
			font_score[5] -= 0x5C;
			//Display the converted score by sending it to VRAM on the BKG tilemap
			set_bkg_tiles(10, 14, 6, 1, font_score);
			
			//Temp variable used to compare if we made an highscore or not
			j=0;
			//Compare each of the 6 digits of score and highscore variables one by one, starting with the highest digit to check which number is the highest
			//100000's : score is higher than highscore
			if( font_score[0] > font_highscore[0] ){ j=1; }
			//100000's : score is equal to highscore
			else if( font_score[0] == font_highscore[0] ){ 
				//10000's : score is higher than highscore
				if( font_score[1] > font_highscore[1] ){ j=1; }
				//10000's : score is equal to highscore
				else if( font_score[1] == font_highscore[1] ){ 
					//1000's : score is higher than highscore
					if( font_score[2] > font_highscore[2] ){ j=1; }
					//1000's : score is equal to highscore
					else if( font_score[2] == font_highscore[2] ){ 
						//100's : score is higher than highscore
						if( font_score[3] > font_highscore[3] ){ j=1; }
						//100's : score is equal to highscore
						else if( font_score[3] == font_highscore[3] ){ 
							//10's : score is higher than highscore
							if( font_score[4] > font_highscore[4] ){ j=1; }
							//10's : score is equal to highscore
							else if( font_score[4] == font_highscore[4] ){ 
								//1's : score is higher than highscore
								if( font_score[5] > font_highscore[5] ){ j=1; }
								//Else, if score is still equal to highscore, as it's the last digit, it means both numbers are equal.
							}
						}
					}
				}
			}
			//Else, if j remains == 0 after checking all the digits, it means that score is lower than highscore
			
			//Did we make an highscore ?
			if( j == 1 ){
				//Save the new highscore
				font_highscore[0]=font_score[0];
				font_highscore[1]=font_score[1];
				font_highscore[2]=font_score[2];
				font_highscore[3]=font_score[3];
				font_highscore[4]=font_score[4];
				font_highscore[5]=font_score[5];
				
				//Display congratulations message
				gotoxy(4,16);
				printf("NEW RECORD!!!");
			}
			//Else, no highscore
			else {
				//Print the best score!
				gotoxy(4,16);
				printf("Best:");
				//Display highscore by sending it to VRAM on the BKG tilemap
				set_bkg_tiles(10, 16, 6, 1, font_highscore);
			}
		}
		//Then fade the player
		else if (ticks == 120){
			OBP0_REG = 0x90;
		}
		//Then fade the player
		else if (ticks == 130){
			OBP0_REG = 0x40;
			
			//Play SFX : big explosion sound (the player is dead !)
			NR41_REG = 0x3F;
			NR42_REG = 0xF7;
			NR43_REG = 0x62;
			NR44_REG = 0x00;
			NR44_REG = 0x80;
		}
		//Then fade the player
		else if (ticks == 140){
			OBP0_REG = 0x00;
		}
		//Display the game over info on the background
		else if (ticks == 150){
			
			//Move all the sprites away so we don't see them over the background
			move_sprite(10, 0,0);
			move_sprite(11, 0,0);
			move_sprite(12, 0,0);
			move_sprite(13, 0,0);
			move_sprite(20, 0,0);
			move_sprite(21, 0,0);
			move_sprite(22, 0,0);
			move_sprite(23, 0,0);
			move_sprite(24, 0,0);
			move_sprite(25, 0,0);
			move_sprite(26, 0,0);
			move_sprite(27, 0,0);
			move_sprite(28, 0,0);
			move_sprite(29, 0,0);
			move_sprite(30, 0,0);
			move_sprite(31, 0,0);
			move_sprite(32, 0,0);
		}
		//Then fade in the BG to display it
		else if (ticks == 170){		
			//Finish the BG fade in
			BGP_REG = 0x40U;
		}
		//Then fade in the BG to display it
		else if (ticks == 180){
			//Finish the BG fade in
			BGP_REG = 0x90U;
		}
		//At last, play a victory sound if we made an highscore, right before the last animation step
		else if (ticks == 189){
			//Did we made an highscore? (j hold the results computed a few frames before)
			if( j == 1 ){
				//Play a SGB SFX to congratulate the player
				sgb_sfx=0x1D;
				sgb_volume=0;
				sgb_pitch=2;
				sgb_playSFX();
			}
		}
	}
	
	
	
	//BUTTON PRESSED
	if ( pad & J_B  || pad & J_A ){
		
		//Only once per keyPress (including from previous screen), and after a tiny countdown to avoid non-desired restart because we were "hitting keys like crazy" inside the game
		if( !keyPressed  ){
			
			//Only if we game over animation is over
			if( ticks == 190 ){
		
				//Activate a fadeout transition
				fadeout=FADEON;
				
				//Restart Game => disabled, will be triggered automatically at the end of the fadeout transition
				//initGame();
			}
		}
		
		//Record the keypress
		keyPressed = 1;
	}
	//If key isn't pressed, record that player released the key
	else if( keyPressed ){
		keyPressed = 0;
	}
}


//This functions handle the Title Screen
//Params ()
void updateTitle(void){

	//Init the game once, and drawn the title screen 
	//(use the i var to track that we'll do this only once, as the var will be be reseted at game startup)
	if( i != 1 ){
		
		// TITLE SCREEN
		
		//Reset screen scrolling
		move_bkg(0,0);
		
		//Load the DMG logo title message tile data in VRAM
		set_bkg_data(119, 53, msg_title_tiles);
		
		//Background sprites : fill the screen white for starter (tile 0x09 in the title screen image)
		for (j=0 ; j != 18 ; j++){
			for (i=0 ; i != 20 ; i++){		
				set_bkg_tiles(i, j, 1, 1, bg_blank);
			}
		}
		
		//Use Texts to display the Title Screen
		gotoxy(9,0);
		printf("by Dr.LUDOS");
		gotoxy(7,16);
		printf("VERSUS");
		
		//Display the DMG logo too
		set_bkg_based_tiles(3, 11, 14, 4, msg_title_map, 119);
		
		//Reset ticks, that will be used for blinking animation
		ticks=0;
		
		//Do only once!
		i = 1;
	}
	
	//BLINKING ANIMATION
	
	//Increase the frame counter
	++ticks;

	//Reset it to zero every half a second
	if (ticks == 32){
		ticks= 0;
	}
	
	//Print message if it's time to do it
	if( ticks == 15 ){
		gotoxy(4, 5);
		printf("press button"); 
	}
	//Else clear if it's time
	else if( ticks == 0 ){
		gotoxy(4, 5);
		printf("            "); 
	}
	
	
	//BUTTON PRESSED
	if ( pad & J_B  || pad & J_A ){
		
		//Only once per keyPress (including from previous screen
		if( !keyPressed ){
		
			//Reset the screen init variable
			i = 0;
			
			//Define the state as instruction screen
			state = 4;
			
			//Activate a fadeout transition
			fadeout= FADEON;
			
			//Play a SGB SFX
			sgb_sfx=0x04;
			sgb_volume=0;
			sgb_pitch=3;
			sgb_playSFX();
		}
	}
	//If key isn't pressed, record that player released the key
	else if( keyPressed ){
		keyPressed = 0;
	}
}


//This functions handle the Intro Screen
//Params ()
void updateIntro(void){

	//Init the game once, and drawn the title screen 
	//(use the i var to track that we'll do this only once, as the var will be be reseted at game startup)
	if( i != 1 ){
		
		//===== DISPLAY INTRO SCREEN =========
		
		//Background sprites : fill the screen white for starter
		for (j=0 ; j != 18 ; j++){
			for (i=0 ; i != 20 ; i++){		
				set_bkg_tiles(i, j, 1, 1, bg_blank);
			}
		}
		
		
		//Display the intro text (using printf)
		gotoxy(0,0);
		printf("!!!!!! WARNING !!!!!");					
		gotoxy(0,2);
		printf("This game requires aSuper Game Boy 1/2.\n\nFor the game to workPLEASE DO THIS NOW:\n\n 1)PRESS L+R to open   the SGB menu.\n\n 2)PRESS L+R again\n   to close it.\n\n 3)Setup is done!\n\n Then press A or B\n to start the game.");
		
		//Do only once!
		i = 1;
	}

	//BUTTON PRESSED
	if ( pad & J_B  || pad & J_A ){
		
		//Only once per keyPress (including from previous screen
		if( !keyPressed ){
			
			//Reset the screen init variable
			i = 0;
		
			//Define the state as title
			state = 3;
			
			//Activate a fadeout transition
			fadeout= FADEON;
			
			//Play a SGB SFX
			sgb_sfx=0x01;
			sgb_volume=0;
			sgb_pitch=3;
			sgb_playSFX();
		}
	}
	//If key isn't pressed, record that player released the key
	else if( keyPressed ){
		keyPressed = 0;
	}
}


//This functions handle the Instructions Screen
//Params ()
void updateInstructions(void){

	//Init the game once, and drawn the title screen 
	//(use the i var to track that we'll do this only once, as the var will be be reseted at game startup)
	if( i != 1 ){
		
		//===== DISPLAY INSTRUCTION SCREEN =========
		
		//Background sprites : fill the screen white for starter
		for (j=0 ; j != 18 ; j++){
			for (i=0 ; i != 20 ; i++){		
				set_bkg_tiles(i, j, 1, 1, bg_blank);
			}
		}
		
		
		//Display the instructions (using printf)
		gotoxy(1,2);
		printf("-= HOW TO PLAY =-");					
		gotoxy(0,5);
		printf("Press A / B to catchenemies and to smash them on the walls.\n\n You can also smash\n   them together!");
		gotoxy(0,13);
		printf("  How long can you\nfight the SGB icons?");
		
		//Do only once!
		i = 1;
	}

	//BUTTON PRESSED
	if ( pad & J_B  || pad & J_A ){
		
		//Only once per keyPress (including from previous screen
		if( !keyPressed ){
		
			//Define the state as game
			state = 1;
			//Don't do the "initGame", it'll be made automatically after the fadeout transition if we set ticks to 255
			ticks=255;
			
			//Activate a fadeout transition
			fadeout= FADEON;
			
			//Play a SGB SFX to emphasize the game starting!
			sgb_sfx=0x05;
			sgb_volume=0;
			sgb_pitch=3;
			sgb_playSFX();
		}
	}
	//If key isn't pressed, record that player released the key
	else if( keyPressed ){
		keyPressed = 0;
	}
}