/*
*        --------------------------------------------------------------
*        ---                                                        ---
*        ---                                                        ---
*        ---                       GBT PLAYER  v2.1.1               ---
*        ---                                                        ---
*        ---                                                        ---
*        ---              Copyright (C) 2009-2015 Antonio Ni�o D�az ---
*        ---                      All rights reserved.              ---
*        --------------------------------------------------------------
*
*                                          antonio_nd@outlook.com
*/

#ifndef _GBT_PLAYER_
#define _GBT_PLAYER_

#include <gb/gb.h>

// Fix to be able to use GBT Player with GBDL2020 versions after 4.0.6, read more at https://github.com/AntonioND/gbt-player/pull/21
#ifndef OLDCALL
  #if __SDCC_REVISION >= 12608
    #define OLDCALL __sdcccall(0)
  #else
    #define OLDCALL
  #endif
#endif

//plays the song pointed by data (pointer array to patterns) in given bank at initial given speed
void gbt_play(void * data, UINT8 bank, UINT8 speed) OLDCALL;

//pauses/unpauses music.
void gbt_pause(UINT8 pause) OLDCALL;

//stops music and turns off sound system. Called automatically when ends last pattern and loop
//isn't activated.
void gbt_stop(void) OLDCALL;

//enables/disables looping
void gbt_loop(UINT8 loop) OLDCALL;

//updates player. should be called every frame.
//THIS WILL CHANGE TO BANK 1!!!
void gbt_update(void) OLDCALL;

#define GBT_CHAN_1 (1<<0)
#define GBT_CHAN_2 (1<<1)
#define GBT_CHAN_3 (1<<2)
#define GBT_CHAN_4 (1<<3)
//Set enabled channels to prevent the player from using that channel. If you re-enable a 
//channel, it could need some time to sound OK (until pan and volume are modified in the song).
//You should only disable unused channels or channels that don't change pan or volume.
void gbt_enable_channels(UINT8 channel_flags) OLDCALL;

#endif //_GBT_PLAYER_

