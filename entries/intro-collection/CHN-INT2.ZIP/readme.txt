This is the source code of the GBC Intro Collection written in 2001 by
chn. Install rgbasm95, xlink95, rgbfix95 and any version of make, open a
DOS box, cd to the Intro Collection source directory and type 'make'.
For those who don't want or can't assemble the whole thing, I've
included the binaries.

There you go.

chn <chnowak@web.de>, 09-May-2002

