(function webpackUniversalModuleDefinition(root, factory) {
	if(typeof exports === 'object' && typeof module === 'object')
		module.exports = factory();
	else if(typeof define === 'function' && define.amd)
		define([], factory);
	else if(typeof exports === 'object')
		exports["Virtjs"] = factory();
	else
		root["Virtjs"] = factory();
})(this, function() {
return /******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};

/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {

/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId])
/******/ 			return installedModules[moduleId].exports;

/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			exports: {},
/******/ 			id: moduleId,
/******/ 			loaded: false
/******/ 		};

/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);

/******/ 		// Flag the module as loaded
/******/ 		module.loaded = true;

/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}


/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;

/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;

/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";

/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(0);
/******/ })
/************************************************************************/
/******/ ([
/* 0 */
/***/ function(module, exports, __webpack_require__) {

	module.exports = __webpack_require__(1);


/***/ },
/* 1 */
/***/ function(module, exports, __webpack_require__) {

	"use strict";

	var req = __webpack_require__(2);

	var _iteratorNormalCompletion = true;
	var _didIteratorError = false;
	var _iteratorError = undefined;

	try {
	    for (var _iterator = req.keys()[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	        var name = _step.value;


	        var filtered = name.replace(/^.\/|\.js$/g, "");

	        if (filtered === "index") continue;

	        var _module = req(name);
	        var parts = filtered.split("/");

	        var target = exports;

	        for (var t = 0; t < parts.length - 1; ++t) {
	            target = target[parts[t]] = target[parts[t]] || {};
	        }var main = _module[parts[parts.length - 1]] || {};
	        target[parts[parts.length - 1]] = main;

	        var _iteratorNormalCompletion2 = true;
	        var _didIteratorError2 = false;
	        var _iteratorError2 = undefined;

	        try {
	            for (var _iterator2 = Reflect.ownKeys(_module)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	                var symbol = _step2.value;

	                if (symbol !== parts[parts.length - 1]) {
	                    main[symbol] = _module[symbol];
	                }
	            }
	        } catch (err) {
	            _didIteratorError2 = true;
	            _iteratorError2 = err;
	        } finally {
	            try {
	                if (!_iteratorNormalCompletion2 && _iterator2.return) {
	                    _iterator2.return();
	                }
	            } finally {
	                if (_didIteratorError2) {
	                    throw _iteratorError2;
	                }
	            }
	        }
	    }
	} catch (err) {
	    _didIteratorError = true;
	    _iteratorError = err;
	} finally {
	    try {
	        if (!_iteratorNormalCompletion && _iterator.return) {
	            _iterator.return();
	        }
	    } finally {
	        if (_didIteratorError) {
	            throw _iteratorError;
	        }
	    }
	}

/***/ },
/* 2 */
/***/ function(module, exports, __webpack_require__) {

	var map = {
		"./devices/audio/Audio.js": 3,
		"./devices/audio/NullAudio.js": 4,
		"./devices/inputs/AggregateInput.js": 5,
		"./devices/inputs/Input.js": 6,
		"./devices/inputs/KeyboardInput.js": 7,
		"./devices/inputs/ManualInput.js": 8,
		"./devices/inputs/NullInput.js": 9,
		"./devices/screens/NullScreen.js": 10,
		"./devices/screens/Screen.js": 11,
		"./devices/screens/WebGLScreen.js": 12,
		"./devices/timers/AnimationFrameTimer.js": 13,
		"./devices/timers/AsyncTimer.js": 14,
		"./devices/timers/ImmediateTimer.js": 17,
		"./devices/timers/NullTimer.js": 20,
		"./devices/timers/SerialTimer.js": 15,
		"./devices/timers/Timer.js": 21,
		"./devices/timers/utils.js": 16,
		"./index.js": 1,
		"./mixins/EmitterMixin.js": 22,
		"./utils/DataUtils.js": 23,
		"./utils/FormatUtils.js": 29,
		"./utils/MemoryUtils.js": 30,
		"./utils/ObjectUtils.js": 31,
		"./utils/TypeUtils.js": 32
	};
	function webpackContext(req) {
		return __webpack_require__(webpackContextResolve(req));
	};
	function webpackContextResolve(req) {
		return map[req] || (function() { throw new Error("Cannot find module '" + req + "'.") }());
	};
	webpackContext.keys = function webpackContextKeys() {
		return Object.keys(map);
	};
	webpackContext.resolve = webpackContextResolve;
	module.exports = webpackContext;
	webpackContext.id = 2;


/***/ },
/* 3 */
/***/ function(module, exports) {

	/**
	 * @name Audio
	 * @interface
	 */

	/**
	 * An engine will call this function to check if the device supports the specified input format.
	 *
	 * Return true if the audio device supports the specified input format.
	 *
	 * @method
	 * @name Audio#validateInputFormat
	 *
	 * @param {AudioInputFormat} format - The input format to validate.
	 */

	/**
	 * An engine will call this function to inform the device of the new input format.
	 *
	 * Throw an exception if the audio device doesn't support the new input format.
	 *
	 * @method
	 * @name Audio#setInputFormat
	 *
	 * @param {AudioInputFormat} format - The new input format.
	 */

	/**
	 * An engine will call this function to send samples that the audio device will queue to be played.
	 *
	 * Regardless of the input format, the samples are expected to be interlaced (for example, a mono stream will have [left, left, left], whereas a stereo stream will have [left, right, left, right, left, right]).
	 *
	 * @param {number[]} samples - The samples to queue.
	 */
	"use strict";

/***/ },
/* 4 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var NullAudio = exports.NullAudio = function () {

	    /**
	     * A NullAudio is an audio device that won't play anything.
	     *
	     * @constructor
	     * @implements {Audio}
	     */

	    function NullAudio() {// eslint-disable-line no-useless-constructor

	        // nothing

	        _classCallCheck(this, NullAudio);
	    }

	    _createClass(NullAudio, [{
	        key: "validateInputFormat",
	        value: function validateInputFormat(format) {

	            return true;
	        }
	    }, {
	        key: "setInputFormat",
	        value: function setInputFormat(format) {

	            // nothing

	        }
	    }, {
	        key: "pushSampleBatch",
	        value: function pushSampleBatch(samples) {

	            // nothing

	        }
	    }]);

	    return NullAudio;
	}();

/***/ },
/* 5 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var AggregateInput = exports.AggregateInput = function () {

	    /**
	     * An AggregateInput is an input device that combines multiple other inputs together.
	     *
	     * @constructor
	     * @implements {Input}
	     *
	     * @param {Input[]} [sources] - The initial sources used for the aggregate.
	     */

	    function AggregateInput() {
	        var sources = arguments.length <= 0 || arguments[0] === undefined ? [] : arguments[0];

	        _classCallCheck(this, AggregateInput);

	        this.inputs = [];

	        var _iteratorNormalCompletion = true;
	        var _didIteratorError = false;
	        var _iteratorError = undefined;

	        try {
	            for (var _iterator = sources[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	                var source = _step.value;

	                this.addSource(source);
	            }
	        } catch (err) {
	            _didIteratorError = true;
	            _iteratorError = err;
	        } finally {
	            try {
	                if (!_iteratorNormalCompletion && _iterator.return) {
	                    _iterator.return();
	                }
	            } finally {
	                if (_didIteratorError) {
	                    throw _iteratorError;
	                }
	            }
	        }
	    }

	    /**
	     * Add a new input source inside the aggregate.
	     *
	     * @param {Input} input - The input to aggregate.
	     */

	    _createClass(AggregateInput, [{
	        key: "addSource",
	        value: function addSource(input) {

	            if (this.inputs.includes(input)) return;

	            this.inputs.push(input);
	        }

	        /**
	         * Remove an input source from the aggregate.
	         *
	         * @param {Input} input - The input to remove.
	         */

	    }, {
	        key: "removeSource",
	        value: function removeSource(input) {

	            var index = this.inputs.indexOf(input);
	            this.inputs.splice(index, 1);
	        }

	        /**
	         * Simultaneously poll each aggregated input.
	         */

	    }, {
	        key: "pollInputs",
	        value: function pollInputs() {
	            var _iteratorNormalCompletion2 = true;
	            var _didIteratorError2 = false;
	            var _iteratorError2 = undefined;

	            try {

	                for (var _iterator2 = this.inputs[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	                    var input = _step2.value;

	                    input.pollInputs();
	                }
	            } catch (err) {
	                _didIteratorError2 = true;
	                _iteratorError2 = err;
	            } finally {
	                try {
	                    if (!_iteratorNormalCompletion2 && _iterator2.return) {
	                        _iterator2.return();
	                    }
	                } finally {
	                    if (_didIteratorError2) {
	                        throw _iteratorError2;
	                    }
	                }
	            }
	        }

	        /**
	         * Returns true if any of the aggregated input should return true.
	         *
	         * @param {number} port - The input slot controller.
	         * @param {number} code - The input slot code.
	         */

	    }, {
	        key: "getState",
	        value: function getState(port, code) {
	            var _iteratorNormalCompletion3 = true;
	            var _didIteratorError3 = false;
	            var _iteratorError3 = undefined;

	            try {

	                for (var _iterator3 = this.inputs[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
	                    var input = _step3.value;

	                    if (input.getState(port, code)) return true;
	                }
	            } catch (err) {
	                _didIteratorError3 = true;
	                _iteratorError3 = err;
	            } finally {
	                try {
	                    if (!_iteratorNormalCompletion3 && _iterator3.return) {
	                        _iterator3.return();
	                    }
	                } finally {
	                    if (_didIteratorError3) {
	                        throw _iteratorError3;
	                    }
	                }
	            }

	            return false;
	        }
	    }]);

	    return AggregateInput;
	}();

/***/ },
/* 6 */
/***/ function(module, exports) {

	/**
	 * @name Input
	 * @interface
	 */

	/**
	 * An engine will call this function to inform the device that it should update the input state.
	 *
	 * It means that the devices should never update the input state by themselves, but rather wait for the engine order. It is also important that the update is done synchronously, so that right after returning, the engines are able to call {@link Input#getState}.
	 *
	 * @method
	 * @name Input#pollInputs
	 */

	/**
	 * An engine will call this function to check the current state of a specified input. The function will return true if the input is currently active (pressed), and false otherwise.
	 *
	 * @method
	 * @name Input#getState
	 *
	 * @param {number} port - The input controller port.
	 * @param {number} code - The input code.
	 */
	"use strict";

/***/ },
/* 7 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.KeyboardInput = undefined;

	var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _ManualInput = __webpack_require__(8);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var DEFAULT_KEY_MAP = {

	    /* eslint-disable no-magic-numbers */

	    37: [0, 'LEFT'], // arrow left
	    39: [0, 'RIGHT'], // arrow right
	    38: [0, 'UP'], // arrow up
	    40: [0, 'DOWN'], // arrow down

	    65: [0, 'A'], // 'A'
	    81: [0, 'A'], // 'Q'

	    90: [0, 'B'], // 'Z'
	    87: [0, 'B'], // 'W'
	    66: [0, 'B'], // 'B'

	    76: [0, 'L'], // 'L'
	    82: [0, 'R'], // 'R'

	    13: [0, 'START'], // enter

	    8: [0, 'SELECT'], // backspace
	    32: [0, 'SELECT'] // space

	    /* eslint-enable no-magic-numbers */

	};

	var KeyboardInput = exports.KeyboardInput = function () {

	    /**
	     * A KeyboardInput is an input device that will monitor the keystrokes on a specified DOM element and transmit those actions to the engines.
	     *
	     * @constructor
	     * @implements {Input}
	     *
	     * @param {object} [options] - The device options.
	     * @param {Element} [options.element] - The element on which will be bound the DOM listeners.
	     * @param {KeyMap} [options.keyMap] - The initial key map.
	     */

	    function KeyboardInput() {
	        var _ref = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

	        var _ref$element = _ref.element;
	        var element = _ref$element === undefined ? document.body : _ref$element;
	        var _ref$keyMap = _ref.keyMap;
	        var keyMap = _ref$keyMap === undefined ? DEFAULT_KEY_MAP : _ref$keyMap;
	        var _ref$codeMap = _ref.codeMap;
	        var codeMap = _ref$codeMap === undefined ? null : _ref$codeMap;

	        _classCallCheck(this, KeyboardInput);

	        /**
	         * This value contains the element on which the DOM listeners have been bound.
	         *
	         * @member
	         * @readonly
	         * @type {Element}
	         */

	        this.element = null;

	        /**
	         * This value contains the current key map used to filter keys.
	         *
	         * @member
	         * @readonly
	         * @type {KeyMap}
	         */

	        this.keyMap = null;

	        /**
	         * @borrows ManualInput#codeMap as KeyboardInput#codeMap
	         */

	        Reflect.defineProperty(this, 'codeMap', {
	            get: function get() {
	                return this.input.codeMap;
	            }
	        });

	        this.input = new _ManualInput.ManualInput({ codeMap: codeMap });

	        this.onKeyDown = this.onKeyDown.bind(this);
	        this.onKeyUp = this.onKeyUp.bind(this);

	        this.setKeyMap(keyMap);
	        this.setElement(element);
	    }

	    /**
	     * Change the element on which are bound the DOM listeners.
	     */

	    _createClass(KeyboardInput, [{
	        key: 'setElement',
	        value: function setElement(element) {

	            if (element === this.element) return;

	            if (this.element !== null) this.detachEvents();

	            this.element = element;

	            if (this.element !== null) {
	                this.attachEvents();
	            }
	        }

	        /**
	         * Set the key map that will be used to translate key codes into inputs.
	         *
	         * Any old key that doesn't map to the same input anymore will be automatically released.
	         *
	         * @param {KeyMap} keyMap - The new key map.
	         */

	    }, {
	        key: 'setKeyMap',
	        value: function setKeyMap(keyMap) {

	            if (keyMap === this.keyMap) return;

	            if (this.keyMap) {
	                var _iteratorNormalCompletion = true;
	                var _didIteratorError = false;
	                var _iteratorError = undefined;

	                try {
	                    for (var _iterator = Reflect.ownKeys(this.keyMap)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	                        var key = _step.value;

	                        var _keyMap$key = _slicedToArray(this.keyMap[key], 2);

	                        var port = _keyMap$key[0];
	                        var code = _keyMap$key[1];


	                        if (keyMap && Reflect.has(keyMap, key) && keyMap[key][0] === port && keyMap[key][1] === code) continue;

	                        this.input.up(port, code);
	                    }
	                } catch (err) {
	                    _didIteratorError = true;
	                    _iteratorError = err;
	                } finally {
	                    try {
	                        if (!_iteratorNormalCompletion && _iterator.return) {
	                            _iterator.return();
	                        }
	                    } finally {
	                        if (_didIteratorError) {
	                            throw _iteratorError;
	                        }
	                    }
	                }
	            }

	            this.keyMap = keyMap;
	        }

	        /**
	         * @borrows ManualInput#setCodeMap as KeyboardInput#setCodeMap
	         */

	    }, {
	        key: 'setCodeMap',
	        value: function setCodeMap(codeMap) {

	            this.input.setCodeMap(codeMap);
	        }
	    }, {
	        key: 'pollInputs',
	        value: function pollInputs() {

	            this.input.pollInputs();
	        }
	    }, {
	        key: 'getState',
	        value: function getState(port, code) {

	            return this.input.getState(port, code);
	        }
	    }, {
	        key: 'attachEvents',
	        value: function attachEvents() {

	            this.element.addEventListener('keydown', this.onKeyDown);
	            this.element.addEventListener('keyup', this.onKeyUp);
	        }
	    }, {
	        key: 'detachEvents',
	        value: function detachEvents() {

	            this.element.removeEventListener('keydown', this.onKeyDown);
	            this.element.removeEventListener('keyup', this.onKeyUp);
	        }
	    }, {
	        key: 'onKeyDown',
	        value: function onKeyDown(e) {

	            if (['select', 'input', 'textarea'].includes(e.target.tagName.toLowerCase())) return;

	            if (e.keyCode === 8 /* backspace */) // eslint-disable-line no-magic-numbers
	                e.preventDefault();

	            if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey) return;

	            if (!Reflect.has(this.keyMap, e.keyCode)) return;

	            e.preventDefault();

	            var _keyMap$e$keyCode = _slicedToArray(this.keyMap[e.keyCode], 2);

	            var port = _keyMap$e$keyCode[0];
	            var code = _keyMap$e$keyCode[1];

	            this.input.down(port, code);
	        }
	    }, {
	        key: 'onKeyUp',
	        value: function onKeyUp(e) {

	            if (!Reflect.has(this.keyMap, e.keyCode)) return;

	            var _keyMap$e$keyCode2 = _slicedToArray(this.keyMap[e.keyCode], 2);

	            var port = _keyMap$e$keyCode2[0];
	            var code = _keyMap$e$keyCode2[1];

	            this.input.up(port, code);
	        }
	    }]);

	    return KeyboardInput;
	}();

/***/ },
/* 8 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var ManualInput = exports.ManualInput = function () {

	    /**
	     * A ManualInput is an input device that will transmit any state you manually set from a Javascript API. It's a strictly better {@link NullInput}, that works on any environment while still giving you a way to trigger some events when you need to.
	     *
	     * @constructor
	     * @implements {Input}
	     *
	     * @param {object} [options] - The device options.
	     * @param {object} [options.codeMap] - The initial code map.
	     */

	    function ManualInput() {
	        var _ref = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

	        var _ref$codeMap = _ref.codeMap;
	        var codeMap = _ref$codeMap === undefined ? null : _ref$codeMap;

	        _classCallCheck(this, ManualInput);

	        /**
	         * This value contains the current code map used to translate codes.
	         *
	         * @member
	         * @readonly
	         * @type {object}
	         */

	        this.codeMap = null;

	        this.devices = {};
	        this.pending = {};

	        this.setCodeMap(codeMap);
	    }

	    /**
	     * Set the code map that will be used to translate input codes from one to another.
	     *
	     * @param {object} codeMap - The new input map.
	     */

	    _createClass(ManualInput, [{
	        key: "setCodeMap",
	        value: function setCodeMap(codeMap) {

	            if (codeMap === this.codeMap) return;

	            this.codeMap = codeMap;
	        }

	        /**
	         * Set an input slot as being pressed.
	         *
	         * @param {number} port - The input slot controller port.
	         * @param {number} code - The input slot code.
	         */

	    }, {
	        key: "down",
	        value: function down(port, code) {

	            if (this.codeMap) code = this.codeMap[code];

	            this.pending[port] = this.pending[port] || {};
	            this.pending[port][code] = true;
	        }

	        /**
	         * Set an input slot as being released.
	         *
	         * @param {number} port - The input slot controller port.
	         * @param {number} code - The input slot code.
	         */

	    }, {
	        key: "up",
	        value: function up(port, code) {

	            if (this.codeMap) code = this.codeMap[code];

	            this.pending[port] = this.pending[port] || {};
	            this.pending[port][code] = false;
	        }
	    }, {
	        key: "pollInputs",
	        value: function pollInputs() {

	            var pending = this.pending;
	            this.pending = {};

	            var _iteratorNormalCompletion = true;
	            var _didIteratorError = false;
	            var _iteratorError = undefined;

	            try {
	                for (var _iterator = Reflect.ownKeys(pending)[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	                    var port = _step.value;
	                    var _iteratorNormalCompletion2 = true;
	                    var _didIteratorError2 = false;
	                    var _iteratorError2 = undefined;

	                    try {
	                        for (var _iterator2 = Reflect.ownKeys(pending[port])[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	                            var code = _step2.value;

	                            this.devices[port] = this.devices[port] || {};
	                            this.devices[port][code] = pending[port][code];
	                        }
	                    } catch (err) {
	                        _didIteratorError2 = true;
	                        _iteratorError2 = err;
	                    } finally {
	                        try {
	                            if (!_iteratorNormalCompletion2 && _iterator2.return) {
	                                _iterator2.return();
	                            }
	                        } finally {
	                            if (_didIteratorError2) {
	                                throw _iteratorError2;
	                            }
	                        }
	                    }
	                }
	            } catch (err) {
	                _didIteratorError = true;
	                _iteratorError = err;
	            } finally {
	                try {
	                    if (!_iteratorNormalCompletion && _iterator.return) {
	                        _iterator.return();
	                    }
	                } finally {
	                    if (_didIteratorError) {
	                        throw _iteratorError;
	                    }
	                }
	            }
	        }
	    }, {
	        key: "getState",
	        value: function getState(port, code) {

	            return Boolean(this.devices[port] && this.devices[port][code]);
	        }
	    }]);

	    return ManualInput;
	}();

/***/ },
/* 9 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var NullInput = exports.NullInput = function () {

	    /**
	     * A NullInput is an input device that will never transmit any key as pressed. Even if you don't want any fancy keyboard support or similar, {@link ManualInput} is probably a better candidate than NullInput since the later allows you to programmatically trigger key events should you need to, whereas NullInput will never ever do anything.
	     *
	     * @constructor
	     * @implements {Input}
	     */

	    function NullInput() {// eslint-disable-line no-useless-constructor

	        // nothing

	        _classCallCheck(this, NullInput);
	    }

	    _createClass(NullInput, [{
	        key: "pollInputs",
	        value: function pollInputs() {

	            // nothing

	        }
	    }, {
	        key: "getState",
	        value: function getState(port, inputCode) {

	            return false;
	        }
	    }]);

	    return NullInput;
	}();

/***/ },
/* 10 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var NullScreen = exports.NullScreen = function () {

	    /**
	     * A NullScreen is a screen device that doesn't actually render anything. It might be useful if you want to run an engine on Node.
	     *
	     * @constructor
	     * @implements {Screen}
	     */

	    function NullScreen() {
	        _classCallCheck(this, NullScreen);

	        this.inputWidth = 0;
	        this.inputHeight = 0;
	        this.inputPitch = 0;

	        this.inputFormat = null;
	        this.inputData = null;

	        this.outputWidth = 0;
	        this.outputHeight = 0;
	    }

	    _createClass(NullScreen, [{
	        key: "validateInputFormat",
	        value: function validateInputFormat(format) {

	            return true;
	        }
	    }, {
	        key: "setInputFormat",
	        value: function setInputFormat(format) {

	            this.inputFormat = format;
	        }
	    }, {
	        key: "setInputSize",
	        value: function setInputSize(width, height) {
	            var pitch = arguments.length <= 2 || arguments[2] === undefined ? width : arguments[2];


	            this.inputWidth = width;
	            this.inputHeight = height;
	            this.inputPitch = pitch;
	        }
	    }, {
	        key: "setInputData",
	        value: function setInputData(data) {

	            this.inputData = data;
	        }
	    }, {
	        key: "setOutputSize",
	        value: function setOutputSize(width, height) {

	            this.outputWidth = width;
	            this.outputHeight = height;
	        }
	    }, {
	        key: "flushScreen",
	        value: function flushScreen() {

	            // nothing

	        }
	    }]);

	    return NullScreen;
	}();

/***/ },
/* 11 */
/***/ function(module, exports) {

	/**
	 * @name Screen
	 * @interface
	 */

	/**
	 * This value contains the width of the input that the screen is expecting to render.
	 *
	 * Use {@link Screen#setInputSize} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#inputWidth
	 * @type {number}
	 */

	/**
	 * This value contains the height of the input that the screen is expecting to render.
	 *
	 * Use {@link Screen#setInputSize} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#inputHeight
	 * @type {number}
	 */

	/**
	 * This value contains the pitch of the input that the screen is expecting to render.
	 *
	 * The pitch is the actual amount of data in a pixel row. Some engines add extra data after each row in order to align the data size.
	 *
	 * Use {@link Screen#setInputSize} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#inputPitch
	 * @type {number}
	 */

	/**
	 * This value contains the input format that the screen is expecting to render.
	 *
	 * Use {@link Screen#setInputFormat} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#inputFormat
	 * @type {ScreenInputFormat}
	 */

	/**
	 * This value contains the data that the screen is currently rendering.
	 *
	 * Use {@link Screen#setInputData} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#inputData
	 * @type {*}
	 */

	/**
	 * This value contains the output width of the rendered data.
	 *
	 * Use {@link Screen#setOutputSize} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#outputWidth
	 * @type {number}
	 */

	/**
	 * This value contains the output height of the rendered data.
	 *
	 * Use {@link Screen#setOutputSize} to change it.
	 *
	 * @member
	 * @readonly
	 * @name Screen#outputHeight
	 * @type {number}
	 */

	/**
	 * An engine will call this function to inform the device of the new input size.
	 *
	 * @method
	 * @name Screen#setInputSize
	 *
	 * @param {number} width - The new input width.
	 * @param {number} height - The new input height.
	 * @param {number} [pitch] - The new input pitch.
	 */

	/**
	 * An engine will call this function to check if the device supports the specified input format.
	 *
	 * Return true if the screen device supports the specified input format.
	 *
	 * @method
	 * @name Screen#validateInputFormat
	 *
	 * @param {ScreenInputFormat} format - The input format to validate.
	 *
	 * @return {bool}
	 */

	/**
	 * An engine will call this function to inform the device of the new input format.
	 *
	 * Throw an exception if the screen device doesn't support the new input format.
	 *
	 * @method
	 * @name Screen#setInputFormat
	 *
	 * @param {ScreenInputFormat} format - The new input format.
	 */

	/**
	 * An engine will call this function to inform the device of the new input data.
	 *
	 * @method
	 * @name Screen#setInputData
	 *
	 * @param {*} data - The new input data.
	 */

	/**
	 * Change the output size.
	 *
	 * @method
	 * @name Screen#setOutputSize
	 *
	 * @param {number} width - The new output width.
	 * @param {number} height - The new output height.
	 */

	/**
	 * Render the input data on the screen.
	 *
	 * @method
	 * @name Screen#flushScreen
	 */
	"use strict";

/***/ },
/* 12 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _ref;

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	var BITS_PER_BYTE = 8;
	var RENDER_DEPTH = 100;

	var TYPED_VIEW = Symbol();
	var GL_FORMAT = Symbol();
	var GL_TYPE = Symbol();

	var gWebGlSupportedInputFormats = [(_ref = {

	    depth: 16,

	    rMask: 63488,
	    gMask: 2016,
	    bMask: 31,
	    aMask: 0

	}, _defineProperty(_ref, TYPED_VIEW, Uint16Array), _defineProperty(_ref, GL_FORMAT, "RGB"), _defineProperty(_ref, GL_TYPE, "UNSIGNED_SHORT_5_6_5"), _ref)];

	var gVertexShaderScript = "\n\n    precision mediump float;\n\n    uniform mat4 uMatrix;\n\n    attribute vec3 aVertexPosition;\n    attribute vec2 aVertexTextureUv;\n\n    varying vec2 vTextureCoordinates;\n\n    void main( void ) {\n\n        vTextureCoordinates = vec2( aVertexTextureUv.s, 1.0 - aVertexTextureUv.t );\n\n        gl_Position = uMatrix * vec4( aVertexPosition, 1.0 );\n\n    }\n\n";

	var gFragmentShaderScript = "\n\n    precision mediump float;\n\n    uniform sampler2D uScreenTexture;\n\n    varying vec2 vTextureCoordinates;\n\n    void main( void ) {\n\n        gl_FragColor = texture2D( uScreenTexture, vTextureCoordinates );\n\n    }\n\n";

	function getMatchingInputFormat(_ref2) {
	    var depth = _ref2.depth;
	    var rMask = _ref2.rMask;
	    var gMask = _ref2.gMask;
	    var bMask = _ref2.bMask;
	    var aMask = _ref2.aMask;
	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {

	        for (var _iterator = gWebGlSupportedInputFormats[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	            var supported = _step.value;

	            if (depth === supported.depth && rMask === supported.rMask && gMask === supported.gMask && bMask === supported.bMask && aMask === supported.aMask) return supported;
	        }
	    } catch (err) {
	        _didIteratorError = true;
	        _iteratorError = err;
	    } finally {
	        try {
	            if (!_iteratorNormalCompletion && _iterator.return) {
	                _iterator.return();
	            }
	        } finally {
	            if (_didIteratorError) {
	                throw _iteratorError;
	            }
	        }
	    }

	    return null;
	}

	function makeCanvasGlBuilder(canvas, options) {

	    return function () {
	        return canvas.getContext("webgl", options) || canvas.getContext("experimental-webgl", options);
	    };
	}

	var WebGLScreen = exports.WebGLScreen = function () {

	    /**
	     * A WebGLScreen is a screen device that uses a WebGL canvas as rendering target. Note that you can also use a headless-gl instance as rendering context, in which case you can simply pass null as canvas parameter.
	     *
	     * @constructor
	     * @implements {Screen}
	     *
	     * @param {object} [options] - The screen options.
	     * @param {CanvasElement} [options.canvas] - The target canvas.
	     * @param {object} [options.glOptions] - The extra option used to setup the WebGL context.
	     * @param {function} [options.glBuilder] - A factory that will build the WebGL context.
	     */

	    function WebGLScreen() {
	        var _ref3 = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

	        var _ref3$canvas = _ref3.canvas;
	        var canvas = _ref3$canvas === undefined ? document.createElement("canvas") : _ref3$canvas;
	        var _ref3$glOptions = _ref3.glOptions;
	        var glOptions = _ref3$glOptions === undefined ? null : _ref3$glOptions;
	        var _ref3$glBuilder = _ref3.glBuilder;
	        var glBuilder = _ref3$glBuilder === undefined ? makeCanvasGlBuilder(canvas, glOptions) : _ref3$glBuilder;

	        _classCallCheck(this, WebGLScreen);

	        /**
	         * The target canvas on which will be rendered the input data.
	         *
	         * @member
	         * @readonly
	         * @type {CanvasElement}
	         */

	        this.canvas = canvas;

	        /**
	         * The WebGL context used to render the input data.
	         *
	         * @member
	         * @readonly
	         * @type {WebGLRenderingContext}
	         */

	        this.gl = null;

	        this.inputWidth = 0;
	        this.inputHeight = 0;
	        this.inputPitch = 0;

	        this.inputFormat = null;
	        this.inputData = null;

	        this.outputWidth = 0;
	        this.outputHeight = 0;

	        this.pitchedInputData = null;

	        this.shaderProgram = null;

	        this.uMatrixLocation = null;
	        this.uScreenTextureLocation = null;
	        this.uInputResolutionLocation = null;
	        this.uOutputResolutionLocation = null;

	        this.aVertexPositionLocation = null;
	        this.aVertexTextureUvLocation = null;

	        this.textureIndex = 0;
	        this.setupGl(glBuilder);

	        var boundingBox = this.canvas && this.canvas.getBoundingClientRect();

	        var _ref4 = boundingBox || { width: 100, height: 100 };

	        var width = _ref4.width;
	        var height = _ref4.height;


	        this.setInputSize(width, height);
	        this.setOutputSize(width, height);
	    }

	    _createClass(WebGLScreen, [{
	        key: "setInputSize",
	        value: function setInputSize(width, height) {
	            var pitch = arguments.length <= 2 || arguments[2] === undefined ? width : arguments[2];


	            if (width === null && height === null) throw new Error("Input width, height, and pitch cannot be null");

	            if (width === this.inputWidth && height === this.inputHeight && pitch === this.inputPitch) return;

	            this.inputWidth = width;
	            this.inputHeight = height;
	            this.inputPitch = pitch;

	            this.setupAlignmentBuffer();

	            this.updateViewport();
	            this.draw();
	        }
	    }, {
	        key: "setOutputSize",
	        value: function setOutputSize() {
	            var width = arguments.length <= 0 || arguments[0] === undefined ? null : arguments[0];
	            var height = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];


	            if (width === this.outputWidth && height === this.outputHeight) return;

	            this.outputWidth = width;
	            this.outputHeight = height;

	            this.updateViewport();
	            this.draw();
	        }
	    }, {
	        key: "setShaderProgram",
	        value: function setShaderProgram(shaderProgram) {

	            if (shaderProgram === this.shaderProgram) return;

	            if (this.shaderProgram !== null) this.gl.deleteProgram(this.shaderProgram);

	            this.shaderProgram = shaderProgram;
	            this.gl.useProgram(shaderProgram);

	            this.uMatrixLocation = this.gl.getUniformLocation(shaderProgram, "uMatrix");

	            this.uScreenTextureLocation = this.gl.getUniformLocation(shaderProgram, "uScreenTexture");
	            this.gl.uniform1i(this.uScreenTextureLocation, 0);

	            this.uInputResolutionLocation = this.gl.getUniformLocation(shaderProgram, "uInputResolution");
	            this.uOutputResolutionLocation = this.gl.getUniformLocation(shaderProgram, "uOutputResolution");
	            this.uViewportResolutionLocation = this.gl.getUniformLocation(shaderProgram, "uViewportResolution");

	            this.aVertexPositionLocation = this.gl.getAttribLocation(shaderProgram, "aVertexPosition");
	            this.gl.enableVertexAttribArray(this.aVertexPositionLocation);

	            this.aVertexTextureUvLocation = this.gl.getAttribLocation(shaderProgram, "aVertexTextureUv");
	            this.gl.enableVertexAttribArray(this.aVertexTextureUvLocation);

	            this.gl.bindBuffer(this.vertexPositionBuffer.bufferTarget, this.vertexPositionBuffer);
	            this.gl.vertexAttribPointer(this.aVertexPositionLocation, this.vertexPositionBuffer.itemSize, this.gl.FLOAT, false, 0, 0);

	            this.gl.bindBuffer(this.vertexTextureUvBuffer.bufferTarget, this.vertexTextureUvBuffer);
	            this.gl.vertexAttribPointer(this.aVertexTextureUvLocation, this.vertexTextureUvBuffer.itemSize, this.gl.FLOAT, false, 0, 0);
	        }
	    }, {
	        key: "validateInputFormat",
	        value: function validateInputFormat(format) {

	            return getMatchingInputFormat(format) !== null;
	        }
	    }, {
	        key: "setInputFormat",
	        value: function setInputFormat(partialFormat) {

	            var fullFormat = getMatchingInputFormat(partialFormat);

	            if (!fullFormat) throw new Error("Invalid input format");

	            this.inputFormat = fullFormat;

	            this.setupAlignmentBuffer();
	        }
	    }, {
	        key: "setInputData",
	        value: function setInputData(data) {

	            if (!data) return;

	            this.inputData = data;
	        }
	    }, {
	        key: "flushScreen",
	        value: function flushScreen() {

	            this.draw();
	        }
	    }, {
	        key: "createTexture",
	        value: function createTexture() {

	            var texture = this.gl.createTexture();

	            return texture;
	        }
	    }, {
	        key: "createBuffer",
	        value: function createBuffer(target, count, content) {

	            var buffer = this.gl.createBuffer();
	            buffer.bufferTarget = target;
	            buffer.itemCount = count;
	            buffer.itemSize = content.length / count;

	            this.gl.bindBuffer(buffer.bufferTarget, buffer);
	            this.gl.bufferData(buffer.bufferTarget, content, this.gl.STATIC_DRAW);

	            return buffer;
	        }
	    }, {
	        key: "createOrthoMatrix",
	        value: function createOrthoMatrix(left, right, bottom, top, near, far) {

	            var lr = 1 / (left - right);
	            var bt = 1 / (bottom - top);
	            var nf = 1 / (near - far);

	            /* eslint-disable no-magic-numbers */

	            return [-2 * lr, 0, 0, 0, 0, -2 * bt, 0, 0, 0, 0, 2 * nf, 0, (left + right) * lr, (bottom + top) * bt, (near + far) * nf, 1];

	            /* eslint-enable no-magic-numbers */
	        }
	    }, {
	        key: "setupBuffers",
	        value: function setupBuffers() {

	            /* eslint-disable no-magic-numbers */

	            this.vertexPositionBuffer = this.createBuffer(this.gl.ARRAY_BUFFER, 4, new Float32Array([-1, -1, 0, /**/1, -1, 0, /**/1, 1, 0, /**/-1, 1, 0]));
	            this.vertexTextureUvBuffer = this.createBuffer(this.gl.ARRAY_BUFFER, 4, new Float32Array([0, 0, /**/1, 0, /**/1, 1, /**/0, 1]));
	            this.vertexIndexBuffer = this.createBuffer(this.gl.ELEMENT_ARRAY_BUFFER, 4, new Uint16Array([0, 1, 3, 2]));

	            /* eslint-enable no-magic-numbers */
	        }
	    }, {
	        key: "setupShaders",
	        value: function setupShaders() {

	            this.fragmentShader = this.createShader(this.gl.FRAGMENT_SHADER, gFragmentShaderScript);
	            this.vertexShader = this.createShader(this.gl.VERTEX_SHADER, gVertexShaderScript);
	            this.linkShaders(this.fragmentShader, this.vertexShader);
	        }
	    }, {
	        key: "setupTextures",
	        value: function setupTextures() {
	            var _this = this;

	            this.gl.activeTexture(this.gl.TEXTURE0);

	            this.textures = [this.createTexture(), this.createTexture()];

	            this.textures.forEach(function (texture) {

	                _this.gl.bindTexture(_this.gl.TEXTURE_2D, texture);

	                _this.gl.texParameteri(_this.gl.TEXTURE_2D, _this.gl.TEXTURE_MAG_FILTER, _this.gl.NEAREST);
	                _this.gl.texParameteri(_this.gl.TEXTURE_2D, _this.gl.TEXTURE_MIN_FILTER, _this.gl.NEAREST);
	                _this.gl.texParameteri(_this.gl.TEXTURE_2D, _this.gl.TEXTURE_WRAP_S, _this.gl.CLAMP_TO_EDGE);
	                _this.gl.texParameteri(_this.gl.TEXTURE_2D, _this.gl.TEXTURE_WRAP_T, _this.gl.CLAMP_TO_EDGE);
	            });
	        }
	    }, {
	        key: "setupGl",
	        value: function setupGl(glBuilder) {

	            this.gl = glBuilder();
	            this.gl.clearColor(0, 0, 0, 0);

	            this.setupBuffers();
	            this.setupShaders();
	            this.setupTextures();
	        }
	    }, {
	        key: "createShader",
	        value: function createShader(type, script) {

	            var shader = this.gl.createShader(type);

	            this.gl.shaderSource(shader, script);
	            this.gl.compileShader(shader);

	            if (!this.gl.getShaderParameter(shader, this.gl.COMPILE_STATUS)) throw new Error("Shader compilation failed: " + this.gl.getShaderInfoLog(shader));

	            return shader;
	        }
	    }, {
	        key: "linkShaders",
	        value: function linkShaders(vertexShader, fragmentShader) {

	            var shaderProgram = this.gl.createProgram();

	            this.gl.attachShader(shaderProgram, vertexShader);
	            this.gl.attachShader(shaderProgram, fragmentShader);

	            this.gl.linkProgram(shaderProgram);

	            if (!this.gl.getProgramParameter(shaderProgram, this.gl.LINK_STATUS)) throw new Error("Shader linking failed: " + this.gl.getError());

	            this.setShaderProgram(shaderProgram);
	        }
	    }, {
	        key: "setupAlignmentBuffer",
	        value: function setupAlignmentBuffer() {

	            if (!this.inputFormat) return;

	            if (this.inputPitch === this.inputWidth * this.inputFormat.depth / BITS_PER_BYTE) {
	                this.alignedData = null;
	            } else {
	                this.alignedData = new this.inputFormat[TYPED_VIEW](this.inputWidth * this.inputHeight);
	            }
	        }
	    }, {
	        key: "getAlignedData",
	        value: function getAlignedData() {

	            if (!this.alignedData) return this.inputData;

	            var height = this.inputHeight;
	            var byteLength = this.inputFormat.depth / BITS_PER_BYTE;

	            var sourceRowSize = this.inputPitch / byteLength;
	            var destinationRowSize = this.inputWidth;

	            var source = this.inputData;
	            var destination = this.alignedData;

	            var sourceIndex = 0;
	            var destinationIndex = 0;

	            for (var y = 0; y < height; ++y) {

	                for (var t = 0; t < destinationRowSize; ++t) {
	                    destination[destinationIndex + t] = source[sourceIndex + t];
	                }sourceIndex += sourceRowSize;
	                destinationIndex += destinationRowSize;
	            }

	            return this.alignedData;
	        }
	    }, {
	        key: "updateViewport",
	        value: function updateViewport() {

	            var inputWidth = Math.max(1, this.inputWidth);
	            var inputHeight = Math.max(1, this.inputHeight);

	            var outputWidth = Math.max(1, this.outputWidth);
	            var outputHeight = Math.max(1, this.outputHeight);

	            if (outputWidth === null && outputHeight === null) {
	                outputWidth = inputWidth;
	                outputHeight = inputHeight;
	            }

	            if (outputWidth === null) outputWidth = inputWidth * (outputHeight / inputHeight);

	            if (outputHeight === null) outputHeight = inputHeight * (outputWidth / inputWidth);

	            var widthRatio = outputWidth / inputWidth;
	            var heightRatio = outputHeight / inputHeight;

	            var ratio = Math.min(widthRatio, heightRatio);

	            var viewportWidth = widthRatio / ratio;
	            var viewportHeight = heightRatio / ratio;

	            if (this.canvas) {
	                this.canvas.width = outputWidth;
	                this.canvas.height = outputHeight;
	            }

	            if (this.gl.resize) this.gl.resize(outputWidth, outputHeight);

	            var matrix = this.createOrthoMatrix(-viewportWidth, viewportWidth, -viewportHeight, viewportHeight, -RENDER_DEPTH, RENDER_DEPTH);
	            this.gl.uniformMatrix4fv(this.uMatrixLocation, false, matrix);

	            this.gl.uniform2f(this.uInputResolutionLocation, inputWidth, inputHeight);
	            this.gl.uniform2f(this.uOutputResolutionLocation, outputWidth, outputHeight);
	            this.gl.uniform2f(this.uViewportResolutionLocation, viewportWidth * inputWidth, viewportHeight * inputHeight);

	            this.gl.viewport(0, 0, outputWidth, outputHeight);
	        }
	    }, {
	        key: "draw",
	        value: function draw() {

	            this.gl.clear(this.gl.COLOR_BUFFER_BIT);

	            if (!this.inputData || this.inputWidth === 0 || this.inputHeight === 0) return;

	            var format = this.gl[this.inputFormat[GL_FORMAT]];
	            var type = this.gl[this.inputFormat[GL_TYPE]];
	            var data = this.getAlignedData();

	            var textureIndex = this.textureIndex++ % 2;
	            this.gl.bindTexture(this.gl.TEXTURE_2D, this.textures[textureIndex]);
	            this.gl.texImage2D(this.gl.TEXTURE_2D, 0, this.gl.RGB, this.inputWidth, this.inputHeight, 0, format, type, data);

	            this.gl.bindBuffer(this.vertexIndexBuffer.bufferTarget, this.vertexIndexBuffer);
	            this.gl.drawElements(this.gl.TRIANGLE_STRIP, this.vertexIndexBuffer.itemCount, this.gl.UNSIGNED_SHORT, 0);
	        }
	    }]);

	    return WebGLScreen;
	}();

/***/ },
/* 13 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.AnimationFrameTimer = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _AsyncTimer2 = __webpack_require__(14);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var AnimationFrameTimer = exports.AnimationFrameTimer = function (_AsyncTimer) {
	    _inherits(AnimationFrameTimer, _AsyncTimer);

	    /**
	     * An AnimationFrameTimer is timer device that makes use of the requestAnimationFrame/cancelAnimationFrame API from modern browsers to trigger asynchronous ticks.
	     *
	     * @constructor
	     */

	    function AnimationFrameTimer() {
	        _classCallCheck(this, AnimationFrameTimer);

	        // eslint-disable-line no-useless-constructor

	        return _possibleConstructorReturn(this, Object.getPrototypeOf(AnimationFrameTimer).call(this));
	    }

	    _createClass(AnimationFrameTimer, [{
	        key: 'prepare',
	        value: function prepare(callback) {

	            return window.requestAnimationFrame(callback);
	        }
	    }, {
	        key: 'cancel',
	        value: function cancel(animationFrameId) {

	            window.cancelAnimationFrame(animationFrameId);
	        }
	    }]);

	    return AnimationFrameTimer;
	}(_AsyncTimer2.AsyncTimer);

/***/ },
/* 14 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.AsyncTimer = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _SerialTimer = __webpack_require__(15);

	var _utils = __webpack_require__(16);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var AsyncTimer = exports.AsyncTimer = function () {

	    /**
	     * An AsyncTimer is an asynchronous timer device. You can use it to run your emulator without blocking your main thread. However, unless you really want to implement a new asynchronous device on top of a new API, you're probably looking for {@link AnimationFrameTimer} for browser environments, or {@link ImmediateTimer} for Node.js environments.
	     *
	     * @constructor
	     * @implements {Timer}
	     *
	     * @param {object} [options] - The timer options.
	     * @param {function} [options.prepare] - The callback that will schedule the next cycle
	     * @param {function} [options.cancel] - The callback that will abort the next cycle
	     *
	     * @see {@link AnimationFrameTimer}
	     * @see {@link ImmediateTimer}
	     */

	    function AsyncTimer() {
	        var _ref = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

	        var prepare = _ref.prepare;
	        var cancel = _ref.cancel;

	        _classCallCheck(this, AsyncTimer);

	        if (prepare) this.prepare = prepare;

	        if (cancel) this.cancel = cancel;

	        this.running = false;
	        this.nested = false;

	        this.loopHandler = null;
	        this.fastLoop = null;

	        this.timer = new _SerialTimer.SerialTimer();
	    }

	    _createClass(AsyncTimer, [{
	        key: 'nextTick',
	        value: function nextTick(callback) {

	            return this.timer.nextTick(callback);
	        }
	    }, {
	        key: 'cancelTick',
	        value: function cancelTick(handler) {

	            return this.timer.cancelTick(handler);
	        }
	    }, {
	        key: 'start',
	        value: function start(beginning, ending) {
	            var _this = this;

	            if (this.running) throw new Error('You can\'t start a timer that is already running');

	            if (this.nested) throw new Error('You can\'t start a timer from its callbacks - use resume instead');

	            this.running = true;

	            var resolve = void 0;
	            var reject = void 0;

	            var promise = new Promise(function (resolveFn, rejectFn) {

	                resolve = resolveFn;
	                reject = rejectFn;
	            });

	            var fastTick = (0, _utils.makeFastTick)(beginning, ending, function () {

	                _this.timer.one();
	            });

	            var mainLoop = function mainLoop() {

	                if (!_this.running) {

	                    resolve();
	                } else try {

	                    _this.prepare(mainLoop);

	                    _this.nested = true;
	                    fastTick();
	                    _this.nested = false;
	                } catch (e) {

	                    _this.running = false;
	                    _this.nested = false;

	                    reject(e);
	                }
	            };

	            this.prepare(mainLoop);

	            return promise;
	        }
	    }, {
	        key: 'resume',
	        value: function resume() {

	            if (!this.nested) throw new Error('You can\'t resume a timer from anywhere else than its callbacks - use start instead');

	            if (this.running) return;

	            this.running = true;
	        }
	    }, {
	        key: 'stop',
	        value: function stop() {

	            if (!this.running) return;

	            this.running = false;
	        }

	        /**
	         * This method should be specialized, either via subclassing, or by passing the proper parameter when instanciating the timer.
	         *
	         * @protected
	         *
	         * @type {prepareCallback}
	         */

	    }, {
	        key: 'prepare',
	        value: function prepare() {

	            throw new Error('Unimplemented');
	        }

	        /**
	         * This method should be specialized, either via subclassing, or by passing the proper parameter when instanciating the timer.
	         *
	         * @protected
	         *
	         * @type {cancelCallback}
	         */

	    }, {
	        key: 'cancel',
	        value: function cancel() {

	            throw new Error('Unimplemented');
	        }
	    }]);

	    return AsyncTimer;
	}();

/***/ },
/* 15 */
/***/ function(module, exports, __webpack_require__) {

	'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.SerialTimer = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _utils = __webpack_require__(16);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var HANDLER_FN_SIZE = 31;
	var HANDLER_FN_PATTERN = 0x7FFFFFFF;

	var SerialTimer = exports.SerialTimer = function () {

	    /**
	     * A SerialTimer is a synchronous timer device. You can use it to run your emulator synchronously (ie. blocking the main thread). It also has the ability to only run a finite number of ticks before returning, which is quite valuable when debugging engines.
	     *
	     * @constructor
	     * @implements {Timer}
	     */

	    function SerialTimer() {
	        _classCallCheck(this, SerialTimer);

	        this.running = false;
	        this.nested = false;

	        this.queues = [[], []];
	        this.activeQueueIndex = 0;
	    }

	    _createClass(SerialTimer, [{
	        key: 'nextTick',
	        value: function nextTick(callback) {

	            var activeQueueIndex = this.activeQueueIndex;
	            var queue = this.queues[activeQueueIndex];
	            var callbackIndex = queue.length;

	            queue.push(callback);

	            return activeQueueIndex << HANDLER_FN_SIZE | callbackIndex;
	        }
	    }, {
	        key: 'cancelTick',
	        value: function cancelTick(handler) {

	            var activeQueueIndex = handler >>> HANDLER_FN_SIZE;
	            var callbackIndex = handler & HANDLER_FN_PATTERN;

	            this.queues[activeQueueIndex][callbackIndex] = null;
	        }
	    }, {
	        key: 'start',
	        value: function start(beginning, ending) {
	            var _this = this;

	            if (this.running) throw new Error('You can\'t start a timer that is already running');

	            if (this.nested) throw new Error('You can\'t start a timer from its callbacks - use resume instead');

	            var fastTick = (0, _utils.makeFastTick)(beginning, ending, function () {
	                _this.one();
	            });

	            this.running = true;
	            this.nested = true;

	            while (this.running) {
	                fastTick();
	            }this.nested = false;
	        }
	    }, {
	        key: 'resume',
	        value: function resume() {

	            if (!this.nested) throw new Error('You can\'t resume a timer from anywhere else than its callbacks - use start instead');

	            if (this.running) return;

	            this.running = true;
	        }
	    }, {
	        key: 'stop',
	        value: function stop() {

	            if (!this.running) return;

	            this.running = false;
	        }

	        /**
	         * Start the emulator. Run a single cycle then exit.
	         */

	    }, {
	        key: 'one',
	        value: function one() {

	            var activeQueueIndex = this.activeQueueIndex;
	            this.activeQueueIndex = activeQueueIndex ^ 1;

	            var queue = this.queues[activeQueueIndex];

	            for (var t = 0, T = queue.length; t < T; ++t) {
	                queue[t] && queue[t]();
	            }queue.length = 0;
	        }
	    }]);

	    return SerialTimer;
	}();

/***/ },
/* 16 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.makeFastTick = makeFastTick;
	function makeFastTick(beginning, ending, main) {

	    /* eslint-disable no-nested-ternary */

	    return beginning && ending ? function fastTickBE() {

	        beginning();
	        main();
	        ending();
	    } : beginning ? function fastTickB() {

	        beginning();
	        main();
	    } : ending ? function fastTickE() {

	        main();
	        ending();
	    } : main;

	    /* eslint-enable no-nested-ternary */
	}

/***/ },
/* 17 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(setImmediate, clearImmediate) {'use strict';

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.ImmediateTimer = undefined;

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	var _AsyncTimer2 = __webpack_require__(14);

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	var ImmediateTimer = exports.ImmediateTimer = function (_AsyncTimer) {
	    _inherits(ImmediateTimer, _AsyncTimer);

	    /**
	     * An ImmediateTimer is a timer device that makes use of the setImmediate/clearImmediate API from Node to trigger aynchronous ticks.
	     *
	     * @constructor
	     */

	    function ImmediateTimer() {
	        _classCallCheck(this, ImmediateTimer);

	        // eslint-disable-line no-useless-constructor

	        return _possibleConstructorReturn(this, Object.getPrototypeOf(ImmediateTimer).call(this));
	    }

	    _createClass(ImmediateTimer, [{
	        key: 'prepare',
	        value: function prepare(callback) {

	            return setImmediate(callback);
	        }
	    }, {
	        key: 'cancel',
	        value: function cancel(handler) {

	            clearImmediate(handler);
	        }
	    }]);

	    return ImmediateTimer;
	}(_AsyncTimer2.AsyncTimer);
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(18).setImmediate, __webpack_require__(18).clearImmediate))

/***/ },
/* 18 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(setImmediate, clearImmediate) {var nextTick = __webpack_require__(19).nextTick;
	var apply = Function.prototype.apply;
	var slice = Array.prototype.slice;
	var immediateIds = {};
	var nextImmediateId = 0;

	// DOM APIs, for completeness

	exports.setTimeout = function() {
	  return new Timeout(apply.call(setTimeout, window, arguments), clearTimeout);
	};
	exports.setInterval = function() {
	  return new Timeout(apply.call(setInterval, window, arguments), clearInterval);
	};
	exports.clearTimeout =
	exports.clearInterval = function(timeout) { timeout.close(); };

	function Timeout(id, clearFn) {
	  this._id = id;
	  this._clearFn = clearFn;
	}
	Timeout.prototype.unref = Timeout.prototype.ref = function() {};
	Timeout.prototype.close = function() {
	  this._clearFn.call(window, this._id);
	};

	// Does not start the time, just sets up the members needed.
	exports.enroll = function(item, msecs) {
	  clearTimeout(item._idleTimeoutId);
	  item._idleTimeout = msecs;
	};

	exports.unenroll = function(item) {
	  clearTimeout(item._idleTimeoutId);
	  item._idleTimeout = -1;
	};

	exports._unrefActive = exports.active = function(item) {
	  clearTimeout(item._idleTimeoutId);

	  var msecs = item._idleTimeout;
	  if (msecs >= 0) {
	    item._idleTimeoutId = setTimeout(function onTimeout() {
	      if (item._onTimeout)
	        item._onTimeout();
	    }, msecs);
	  }
	};

	// That's not how node.js implements it but the exposed api is the same.
	exports.setImmediate = typeof setImmediate === "function" ? setImmediate : function(fn) {
	  var id = nextImmediateId++;
	  var args = arguments.length < 2 ? false : slice.call(arguments, 1);

	  immediateIds[id] = true;

	  nextTick(function onNextTick() {
	    if (immediateIds[id]) {
	      // fn.call() is faster so we optimize for the common use-case
	      // @see http://jsperf.com/call-apply-segu
	      if (args) {
	        fn.apply(null, args);
	      } else {
	        fn.call(null);
	      }
	      // Prevent ids from leaking
	      exports.clearImmediate(id);
	    }
	  });

	  return id;
	};

	exports.clearImmediate = typeof clearImmediate === "function" ? clearImmediate : function(id) {
	  delete immediateIds[id];
	};
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(18).setImmediate, __webpack_require__(18).clearImmediate))

/***/ },
/* 19 */
/***/ function(module, exports) {

	// shim for using process in browser

	var process = module.exports = {};
	var queue = [];
	var draining = false;
	var currentQueue;
	var queueIndex = -1;

	function cleanUpNextTick() {
	    if (!draining || !currentQueue) {
	        return;
	    }
	    draining = false;
	    if (currentQueue.length) {
	        queue = currentQueue.concat(queue);
	    } else {
	        queueIndex = -1;
	    }
	    if (queue.length) {
	        drainQueue();
	    }
	}

	function drainQueue() {
	    if (draining) {
	        return;
	    }
	    var timeout = setTimeout(cleanUpNextTick);
	    draining = true;

	    var len = queue.length;
	    while(len) {
	        currentQueue = queue;
	        queue = [];
	        while (++queueIndex < len) {
	            if (currentQueue) {
	                currentQueue[queueIndex].run();
	            }
	        }
	        queueIndex = -1;
	        len = queue.length;
	    }
	    currentQueue = null;
	    draining = false;
	    clearTimeout(timeout);
	}

	process.nextTick = function (fun) {
	    var args = new Array(arguments.length - 1);
	    if (arguments.length > 1) {
	        for (var i = 1; i < arguments.length; i++) {
	            args[i - 1] = arguments[i];
	        }
	    }
	    queue.push(new Item(fun, args));
	    if (queue.length === 1 && !draining) {
	        setTimeout(drainQueue, 0);
	    }
	};

	// v8 likes predictible objects
	function Item(fun, array) {
	    this.fun = fun;
	    this.array = array;
	}
	Item.prototype.run = function () {
	    this.fun.apply(null, this.array);
	};
	process.title = 'browser';
	process.browser = true;
	process.env = {};
	process.argv = [];
	process.version = ''; // empty string to avoid regexp issues
	process.versions = {};

	function noop() {}

	process.on = noop;
	process.addListener = noop;
	process.once = noop;
	process.off = noop;
	process.removeListener = noop;
	process.removeAllListeners = noop;
	process.emit = noop;

	process.binding = function (name) {
	    throw new Error('process.binding is not supported');
	};

	process.cwd = function () { return '/' };
	process.chdir = function (dir) {
	    throw new Error('process.chdir is not supported');
	};
	process.umask = function() { return 0; };


/***/ },
/* 20 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var NullTimer = exports.NullTimer = function () {

	    /**
	     * A NullTimer is a timer device that will never tick. You probably don't want to use it. If you're looking for a synchronous timer, check {@link SerialTimer} instead. If you're looking for an asynchronous timer that works on Node.js, check {@link ImmediateTimer} instead. If you're looking for a synchronous timer that works on Node.js, check {@link SerialTimer} instead.
	     *
	     * @constructor
	     * @implements {Timer}
	     *
	     * @see {@link SerialTimer}
	     */

	    function NullTimer() {// eslint-disable-line no-useless-constructor

	        // nothing

	        _classCallCheck(this, NullTimer);
	    }

	    _createClass(NullTimer, [{
	        key: "nextTick",
	        value: function nextTick(callback) {

	            // nothing

	        }
	    }, {
	        key: "cancelTick",
	        value: function cancelTick(nextTickId) {

	            // nothing

	        }
	    }, {
	        key: "start",
	        value: function start(beginning, ending) {

	            return new Promise(function () {});
	        }
	    }, {
	        key: "stop",
	        value: function stop() {

	            // nothing

	        }
	    }]);

	    return NullTimer;
	}();

/***/ },
/* 21 */
/***/ function(module, exports) {

	/**
	 * @name Timer
	 * @interface
	 */

	/**
	 * An engine will call this function if it wants to schedule a function to be called at the next tick.
	 *
	 * @method
	 * @name Timer#nextTick
	 *
	 * @param {function} fn - The function that should be registered.
	 * @return {Opaque} handler
	 */

	/**
	 * An engine will call this function if it wants to prevent a scheduled function from being executed.
	 *
	 * @method
	 * @name Timer#cancelTick
	 *
	 * @param {Opaque} handler - The handler returned by {@link Timer#nextTick}.
	 */

	/**
	 * Start the timer.
	 *
	 * @method
	 * @name Timer#start
	 *
	 * @param {function} [beginning] - An optional function that will be called before each tick.
	 * @param {function} [ending] - An optional function that will be caled after each tick.
	 */

	/**
	 * Stop the timer.
	 *
	 * @method
	 * @name Timer#stop
	 */
	"use strict";

/***/ },
/* 22 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});

	var _slicedToArray = function () { function sliceIterator(arr, i) { var _arr = []; var _n = true; var _d = false; var _e = undefined; try { for (var _i = arr[Symbol.iterator](), _s; !(_n = (_s = _i.next()).done); _n = true) { _arr.push(_s.value); if (i && _arr.length === i) break; } } catch (err) { _d = true; _e = err; } finally { try { if (!_n && _i["return"]) _i["return"](); } finally { if (_d) throw _e; } } return _arr; } return function (arr, i) { if (Array.isArray(arr)) { return arr; } else if (Symbol.iterator in Object(arr)) { return sliceIterator(arr, i); } else { throw new TypeError("Invalid attempt to destructure non-iterable instance"); } }; }();

	var _createClass = function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; }();

	function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	var LISTENERS = Symbol();

	var EmitterMixin = exports.EmitterMixin = function () {
	    function EmitterMixin() {
	        _classCallCheck(this, EmitterMixin);

	        this[LISTENERS] = _defineProperty({}, "*", []);
	    }

	    _createClass(EmitterMixin, [{
	        key: "on",
	        value: function on(event, callback, context) {

	            if (typeof this[LISTENERS][event] === "undefined") this[LISTENERS][event] = [];

	            this[LISTENERS][event].push([callback, context]);
	        }
	    }, {
	        key: "off",
	        value: function off(event, callback, context) {

	            if (typeof this[LISTENERS][event] === "undefined") return;

	            var listeners = this[LISTENERS][event];

	            for (var t = 0, T = listeners.length; t < T; ++t) {
	                if (listeners[t][0] === callback && listeners[t][1] === context) break;
	            }listeners.splice(listeners.findIndex(function (_ref) {
	                var _ref2 = _slicedToArray(_ref, 2);

	                var lCallback = _ref2[0];
	                var lContext = _ref2[1];

	                return lCallback === callback && lContext === context;
	            }), 1);
	        }
	    }, {
	        key: "emit",
	        value: function emit(event, data) {

	            if (typeof this[LISTENERS][event] === "undefined") return;

	            this[LISTENERS][event].forEach(function (_ref3) {
	                var _ref4 = _slicedToArray(_ref3, 2);

	                var callback = _ref4[0];
	                var context = _ref4[1];

	                Reflect.apply(callback, context, [data]);
	            });

	            this[LISTENERS]["*"].forEach(function (_ref5) {
	                var _ref6 = _slicedToArray(_ref5, 2);

	                var callback = _ref6[0];
	                var context = _ref6[1];

	                Reflect.apply(callback, context, [event, data]);
	            });
	        }
	    }]);

	    return EmitterMixin;
	}();

/***/ },
/* 23 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(Buffer, module) {"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.binaryStringToUint8 = binaryStringToUint8;
	exports.base64ToUint8 = base64ToUint8;
	exports.fetchArrayBuffer = fetchArrayBuffer;

	function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) { arr2[i] = arr[i]; } return arr2; } else { return Array.from(arr); } }

	var base64DataUrl = /^data:[^;]*;base64,([a-zA-Z0-9+/]+={0,2})$/;

	function nodeToUint8() {
	    for (var _len = arguments.length, buffers = Array(_len), _key = 0; _key < _len; _key++) {
	        buffers[_key] = arguments[_key];
	    }

	    var totalByteLength = buffers.reduce(function (sum, buffer) {
	        return sum + buffer.length;
	    }, 0);

	    var array = new Uint8Array(totalByteLength);
	    var offset = 0;

	    buffers.forEach(function (buffer) {
	        for (var t = 0, T = array.length; t < T; ++t) {
	            array[offset++] = buffer[t];
	        }
	    });

	    return array;
	}

	function binaryStringToUint8() {
	    for (var _len2 = arguments.length, strings = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
	        strings[_key2] = arguments[_key2];
	    }

	    var totalByteLength = strings.reduce(function (sum, string) {
	        return sum + string.length;
	    }, 0);

	    var array = new Uint8Array(totalByteLength);
	    var offset = 0;

	    strings.forEach(function (string) {
	        for (var t = 0, T = string.length; t < T; ++t) {
	            array[offset++] = string.charCodeAt(t);
	        }
	    });

	    return array;
	}

	function base64ToUint8() {

	    var isBrowser = typeof window !== "undefined";

	    for (var _len3 = arguments.length, strings = Array(_len3), _key3 = 0; _key3 < _len3; _key3++) {
	        strings[_key3] = arguments[_key3];
	    }

	    if (isBrowser) {
	        return binaryStringToUint8.apply(undefined, _toConsumableArray(strings.map(function (string) {
	            return atob(string);
	        })));
	    } else {
	        return nodeToUint8.apply(undefined, _toConsumableArray(strings.map(function (string) {
	            return new Buffer(string, "base64");
	        })));
	    }
	}

	function fetchArrayBuffer(path) {

	    return new Promise(function (resolve, reject) {

	        var isBlob = typeof Blob !== "undefined" && path instanceof Blob;
	        var isDataURI = typeof path === "string" && path.match(base64DataUrl);
	        var isBrowser = typeof window !== "undefined";
	        var isWeb = isBrowser || /^(https?:\/\/|blob:)/.test(path);

	        if (!isWeb && path.indexOf(":") !== -1) throw new Error("Invalid protocol");

	        if (isBlob) {

	            var fileReader = new FileReader();

	            fileReader.addEventListener("load", function (e) {
	                resolve(e.target.result);
	            });

	            fileReader.addEventListener("error", function (e) {
	                reject();
	            });

	            fileReader.readAsArrayBuffer(path);
	        } else if (isDataURI) {

	            resolve(base64ToUint8(isDataURI[1]).buffer);
	        } else if (isBrowser) {
	            (function () {

	                var xhr = new XMLHttpRequest();

	                xhr.open("GET", path, true);
	                xhr.responseType = "arraybuffer";

	                xhr.onload = function () {
	                    resolve(xhr.response);
	                };

	                xhr.onerror = function () {
	                    reject(xhr.status);
	                };

	                xhr.send(null);
	            })();
	        } else if (isWeb) {
	            (function () {

	                var protocol = path.substr(0, path.indexOf(":"));
	                var web = module.require(protocol /* http or https */);

	                var buffers = [];

	                web.get(path, function (res) {

	                    res.on("data", function (chunk) {
	                        buffers.push(chunk);
	                    });

	                    res.on("error", function (err) {
	                        reject(err.message);
	                    });

	                    res.on("end", function () {
	                        resolve(nodeToUint8.apply(undefined, buffers).buffer);
	                    });
	                });
	            })();
	        } else {

	            var fs = module.require("fs");

	            fs.readFile(path, function (err, buffer) {

	                if (err) {
	                    reject(err);
	                } else {
	                    resolve(nodeToUint8(buffer).buffer);
	                }
	            });
	        }
	    });
	}
	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(24).Buffer, __webpack_require__(28)(module)))

/***/ },
/* 24 */
/***/ function(module, exports, __webpack_require__) {

	/* WEBPACK VAR INJECTION */(function(Buffer, global) {/*!
	 * The buffer module from node.js, for the browser.
	 *
	 * @author   Feross Aboukhadijeh <feross@feross.org> <http://feross.org>
	 * @license  MIT
	 */
	/* eslint-disable no-proto */

	'use strict'

	var base64 = __webpack_require__(25)
	var ieee754 = __webpack_require__(26)
	var isArray = __webpack_require__(27)

	exports.Buffer = Buffer
	exports.SlowBuffer = SlowBuffer
	exports.INSPECT_MAX_BYTES = 50
	Buffer.poolSize = 8192 // not used by this implementation

	var rootParent = {}

	/**
	 * If `Buffer.TYPED_ARRAY_SUPPORT`:
	 *   === true    Use Uint8Array implementation (fastest)
	 *   === false   Use Object implementation (most compatible, even IE6)
	 *
	 * Browsers that support typed arrays are IE 10+, Firefox 4+, Chrome 7+, Safari 5.1+,
	 * Opera 11.6+, iOS 4.2+.
	 *
	 * Due to various browser bugs, sometimes the Object implementation will be used even
	 * when the browser supports typed arrays.
	 *
	 * Note:
	 *
	 *   - Firefox 4-29 lacks support for adding new properties to `Uint8Array` instances,
	 *     See: https://bugzilla.mozilla.org/show_bug.cgi?id=695438.
	 *
	 *   - Safari 5-7 lacks support for changing the `Object.prototype.constructor` property
	 *     on objects.
	 *
	 *   - Chrome 9-10 is missing the `TypedArray.prototype.subarray` function.
	 *
	 *   - IE10 has a broken `TypedArray.prototype.subarray` function which returns arrays of
	 *     incorrect length in some situations.

	 * We detect these buggy browsers and set `Buffer.TYPED_ARRAY_SUPPORT` to `false` so they
	 * get the Object implementation, which is slower but behaves correctly.
	 */
	Buffer.TYPED_ARRAY_SUPPORT = global.TYPED_ARRAY_SUPPORT !== undefined
	  ? global.TYPED_ARRAY_SUPPORT
	  : typedArraySupport()

	function typedArraySupport () {
	  function Bar () {}
	  try {
	    var arr = new Uint8Array(1)
	    arr.foo = function () { return 42 }
	    arr.constructor = Bar
	    return arr.foo() === 42 && // typed array instances can be augmented
	        arr.constructor === Bar && // constructor can be set
	        typeof arr.subarray === 'function' && // chrome 9-10 lack `subarray`
	        arr.subarray(1, 1).byteLength === 0 // ie10 has broken `subarray`
	  } catch (e) {
	    return false
	  }
	}

	function kMaxLength () {
	  return Buffer.TYPED_ARRAY_SUPPORT
	    ? 0x7fffffff
	    : 0x3fffffff
	}

	/**
	 * Class: Buffer
	 * =============
	 *
	 * The Buffer constructor returns instances of `Uint8Array` that are augmented
	 * with function properties for all the node `Buffer` API functions. We use
	 * `Uint8Array` so that square bracket notation works as expected -- it returns
	 * a single octet.
	 *
	 * By augmenting the instances, we can avoid modifying the `Uint8Array`
	 * prototype.
	 */
	function Buffer (arg) {
	  if (!(this instanceof Buffer)) {
	    // Avoid going through an ArgumentsAdaptorTrampoline in the common case.
	    if (arguments.length > 1) return new Buffer(arg, arguments[1])
	    return new Buffer(arg)
	  }

	  if (!Buffer.TYPED_ARRAY_SUPPORT) {
	    this.length = 0
	    this.parent = undefined
	  }

	  // Common case.
	  if (typeof arg === 'number') {
	    return fromNumber(this, arg)
	  }

	  // Slightly less common case.
	  if (typeof arg === 'string') {
	    return fromString(this, arg, arguments.length > 1 ? arguments[1] : 'utf8')
	  }

	  // Unusual.
	  return fromObject(this, arg)
	}

	function fromNumber (that, length) {
	  that = allocate(that, length < 0 ? 0 : checked(length) | 0)
	  if (!Buffer.TYPED_ARRAY_SUPPORT) {
	    for (var i = 0; i < length; i++) {
	      that[i] = 0
	    }
	  }
	  return that
	}

	function fromString (that, string, encoding) {
	  if (typeof encoding !== 'string' || encoding === '') encoding = 'utf8'

	  // Assumption: byteLength() return value is always < kMaxLength.
	  var length = byteLength(string, encoding) | 0
	  that = allocate(that, length)

	  that.write(string, encoding)
	  return that
	}

	function fromObject (that, object) {
	  if (Buffer.isBuffer(object)) return fromBuffer(that, object)

	  if (isArray(object)) return fromArray(that, object)

	  if (object == null) {
	    throw new TypeError('must start with number, buffer, array or string')
	  }

	  if (typeof ArrayBuffer !== 'undefined') {
	    if (object.buffer instanceof ArrayBuffer) {
	      return fromTypedArray(that, object)
	    }
	    if (object instanceof ArrayBuffer) {
	      return fromArrayBuffer(that, object)
	    }
	  }

	  if (object.length) return fromArrayLike(that, object)

	  return fromJsonObject(that, object)
	}

	function fromBuffer (that, buffer) {
	  var length = checked(buffer.length) | 0
	  that = allocate(that, length)
	  buffer.copy(that, 0, 0, length)
	  return that
	}

	function fromArray (that, array) {
	  var length = checked(array.length) | 0
	  that = allocate(that, length)
	  for (var i = 0; i < length; i += 1) {
	    that[i] = array[i] & 255
	  }
	  return that
	}

	// Duplicate of fromArray() to keep fromArray() monomorphic.
	function fromTypedArray (that, array) {
	  var length = checked(array.length) | 0
	  that = allocate(that, length)
	  // Truncating the elements is probably not what people expect from typed
	  // arrays with BYTES_PER_ELEMENT > 1 but it's compatible with the behavior
	  // of the old Buffer constructor.
	  for (var i = 0; i < length; i += 1) {
	    that[i] = array[i] & 255
	  }
	  return that
	}

	function fromArrayBuffer (that, array) {
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    // Return an augmented `Uint8Array` instance, for best performance
	    array.byteLength
	    that = Buffer._augment(new Uint8Array(array))
	  } else {
	    // Fallback: Return an object instance of the Buffer class
	    that = fromTypedArray(that, new Uint8Array(array))
	  }
	  return that
	}

	function fromArrayLike (that, array) {
	  var length = checked(array.length) | 0
	  that = allocate(that, length)
	  for (var i = 0; i < length; i += 1) {
	    that[i] = array[i] & 255
	  }
	  return that
	}

	// Deserialize { type: 'Buffer', data: [1,2,3,...] } into a Buffer object.
	// Returns a zero-length buffer for inputs that don't conform to the spec.
	function fromJsonObject (that, object) {
	  var array
	  var length = 0

	  if (object.type === 'Buffer' && isArray(object.data)) {
	    array = object.data
	    length = checked(array.length) | 0
	  }
	  that = allocate(that, length)

	  for (var i = 0; i < length; i += 1) {
	    that[i] = array[i] & 255
	  }
	  return that
	}

	if (Buffer.TYPED_ARRAY_SUPPORT) {
	  Buffer.prototype.__proto__ = Uint8Array.prototype
	  Buffer.__proto__ = Uint8Array
	} else {
	  // pre-set for values that may exist in the future
	  Buffer.prototype.length = undefined
	  Buffer.prototype.parent = undefined
	}

	function allocate (that, length) {
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    // Return an augmented `Uint8Array` instance, for best performance
	    that = Buffer._augment(new Uint8Array(length))
	    that.__proto__ = Buffer.prototype
	  } else {
	    // Fallback: Return an object instance of the Buffer class
	    that.length = length
	    that._isBuffer = true
	  }

	  var fromPool = length !== 0 && length <= Buffer.poolSize >>> 1
	  if (fromPool) that.parent = rootParent

	  return that
	}

	function checked (length) {
	  // Note: cannot use `length < kMaxLength` here because that fails when
	  // length is NaN (which is otherwise coerced to zero.)
	  if (length >= kMaxLength()) {
	    throw new RangeError('Attempt to allocate Buffer larger than maximum ' +
	                         'size: 0x' + kMaxLength().toString(16) + ' bytes')
	  }
	  return length | 0
	}

	function SlowBuffer (subject, encoding) {
	  if (!(this instanceof SlowBuffer)) return new SlowBuffer(subject, encoding)

	  var buf = new Buffer(subject, encoding)
	  delete buf.parent
	  return buf
	}

	Buffer.isBuffer = function isBuffer (b) {
	  return !!(b != null && b._isBuffer)
	}

	Buffer.compare = function compare (a, b) {
	  if (!Buffer.isBuffer(a) || !Buffer.isBuffer(b)) {
	    throw new TypeError('Arguments must be Buffers')
	  }

	  if (a === b) return 0

	  var x = a.length
	  var y = b.length

	  var i = 0
	  var len = Math.min(x, y)
	  while (i < len) {
	    if (a[i] !== b[i]) break

	    ++i
	  }

	  if (i !== len) {
	    x = a[i]
	    y = b[i]
	  }

	  if (x < y) return -1
	  if (y < x) return 1
	  return 0
	}

	Buffer.isEncoding = function isEncoding (encoding) {
	  switch (String(encoding).toLowerCase()) {
	    case 'hex':
	    case 'utf8':
	    case 'utf-8':
	    case 'ascii':
	    case 'binary':
	    case 'base64':
	    case 'raw':
	    case 'ucs2':
	    case 'ucs-2':
	    case 'utf16le':
	    case 'utf-16le':
	      return true
	    default:
	      return false
	  }
	}

	Buffer.concat = function concat (list, length) {
	  if (!isArray(list)) throw new TypeError('list argument must be an Array of Buffers.')

	  if (list.length === 0) {
	    return new Buffer(0)
	  }

	  var i
	  if (length === undefined) {
	    length = 0
	    for (i = 0; i < list.length; i++) {
	      length += list[i].length
	    }
	  }

	  var buf = new Buffer(length)
	  var pos = 0
	  for (i = 0; i < list.length; i++) {
	    var item = list[i]
	    item.copy(buf, pos)
	    pos += item.length
	  }
	  return buf
	}

	function byteLength (string, encoding) {
	  if (typeof string !== 'string') string = '' + string

	  var len = string.length
	  if (len === 0) return 0

	  // Use a for loop to avoid recursion
	  var loweredCase = false
	  for (;;) {
	    switch (encoding) {
	      case 'ascii':
	      case 'binary':
	      // Deprecated
	      case 'raw':
	      case 'raws':
	        return len
	      case 'utf8':
	      case 'utf-8':
	        return utf8ToBytes(string).length
	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return len * 2
	      case 'hex':
	        return len >>> 1
	      case 'base64':
	        return base64ToBytes(string).length
	      default:
	        if (loweredCase) return utf8ToBytes(string).length // assume utf8
	        encoding = ('' + encoding).toLowerCase()
	        loweredCase = true
	    }
	  }
	}
	Buffer.byteLength = byteLength

	function slowToString (encoding, start, end) {
	  var loweredCase = false

	  start = start | 0
	  end = end === undefined || end === Infinity ? this.length : end | 0

	  if (!encoding) encoding = 'utf8'
	  if (start < 0) start = 0
	  if (end > this.length) end = this.length
	  if (end <= start) return ''

	  while (true) {
	    switch (encoding) {
	      case 'hex':
	        return hexSlice(this, start, end)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Slice(this, start, end)

	      case 'ascii':
	        return asciiSlice(this, start, end)

	      case 'binary':
	        return binarySlice(this, start, end)

	      case 'base64':
	        return base64Slice(this, start, end)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return utf16leSlice(this, start, end)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = (encoding + '').toLowerCase()
	        loweredCase = true
	    }
	  }
	}

	Buffer.prototype.toString = function toString () {
	  var length = this.length | 0
	  if (length === 0) return ''
	  if (arguments.length === 0) return utf8Slice(this, 0, length)
	  return slowToString.apply(this, arguments)
	}

	Buffer.prototype.equals = function equals (b) {
	  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
	  if (this === b) return true
	  return Buffer.compare(this, b) === 0
	}

	Buffer.prototype.inspect = function inspect () {
	  var str = ''
	  var max = exports.INSPECT_MAX_BYTES
	  if (this.length > 0) {
	    str = this.toString('hex', 0, max).match(/.{2}/g).join(' ')
	    if (this.length > max) str += ' ... '
	  }
	  return '<Buffer ' + str + '>'
	}

	Buffer.prototype.compare = function compare (b) {
	  if (!Buffer.isBuffer(b)) throw new TypeError('Argument must be a Buffer')
	  if (this === b) return 0
	  return Buffer.compare(this, b)
	}

	Buffer.prototype.indexOf = function indexOf (val, byteOffset) {
	  if (byteOffset > 0x7fffffff) byteOffset = 0x7fffffff
	  else if (byteOffset < -0x80000000) byteOffset = -0x80000000
	  byteOffset >>= 0

	  if (this.length === 0) return -1
	  if (byteOffset >= this.length) return -1

	  // Negative offsets start from the end of the buffer
	  if (byteOffset < 0) byteOffset = Math.max(this.length + byteOffset, 0)

	  if (typeof val === 'string') {
	    if (val.length === 0) return -1 // special case: looking for empty string always fails
	    return String.prototype.indexOf.call(this, val, byteOffset)
	  }
	  if (Buffer.isBuffer(val)) {
	    return arrayIndexOf(this, val, byteOffset)
	  }
	  if (typeof val === 'number') {
	    if (Buffer.TYPED_ARRAY_SUPPORT && Uint8Array.prototype.indexOf === 'function') {
	      return Uint8Array.prototype.indexOf.call(this, val, byteOffset)
	    }
	    return arrayIndexOf(this, [ val ], byteOffset)
	  }

	  function arrayIndexOf (arr, val, byteOffset) {
	    var foundIndex = -1
	    for (var i = 0; byteOffset + i < arr.length; i++) {
	      if (arr[byteOffset + i] === val[foundIndex === -1 ? 0 : i - foundIndex]) {
	        if (foundIndex === -1) foundIndex = i
	        if (i - foundIndex + 1 === val.length) return byteOffset + foundIndex
	      } else {
	        foundIndex = -1
	      }
	    }
	    return -1
	  }

	  throw new TypeError('val must be string, number or Buffer')
	}

	// `get` is deprecated
	Buffer.prototype.get = function get (offset) {
	  console.log('.get() is deprecated. Access using array indexes instead.')
	  return this.readUInt8(offset)
	}

	// `set` is deprecated
	Buffer.prototype.set = function set (v, offset) {
	  console.log('.set() is deprecated. Access using array indexes instead.')
	  return this.writeUInt8(v, offset)
	}

	function hexWrite (buf, string, offset, length) {
	  offset = Number(offset) || 0
	  var remaining = buf.length - offset
	  if (!length) {
	    length = remaining
	  } else {
	    length = Number(length)
	    if (length > remaining) {
	      length = remaining
	    }
	  }

	  // must be an even number of digits
	  var strLen = string.length
	  if (strLen % 2 !== 0) throw new Error('Invalid hex string')

	  if (length > strLen / 2) {
	    length = strLen / 2
	  }
	  for (var i = 0; i < length; i++) {
	    var parsed = parseInt(string.substr(i * 2, 2), 16)
	    if (isNaN(parsed)) throw new Error('Invalid hex string')
	    buf[offset + i] = parsed
	  }
	  return i
	}

	function utf8Write (buf, string, offset, length) {
	  return blitBuffer(utf8ToBytes(string, buf.length - offset), buf, offset, length)
	}

	function asciiWrite (buf, string, offset, length) {
	  return blitBuffer(asciiToBytes(string), buf, offset, length)
	}

	function binaryWrite (buf, string, offset, length) {
	  return asciiWrite(buf, string, offset, length)
	}

	function base64Write (buf, string, offset, length) {
	  return blitBuffer(base64ToBytes(string), buf, offset, length)
	}

	function ucs2Write (buf, string, offset, length) {
	  return blitBuffer(utf16leToBytes(string, buf.length - offset), buf, offset, length)
	}

	Buffer.prototype.write = function write (string, offset, length, encoding) {
	  // Buffer#write(string)
	  if (offset === undefined) {
	    encoding = 'utf8'
	    length = this.length
	    offset = 0
	  // Buffer#write(string, encoding)
	  } else if (length === undefined && typeof offset === 'string') {
	    encoding = offset
	    length = this.length
	    offset = 0
	  // Buffer#write(string, offset[, length][, encoding])
	  } else if (isFinite(offset)) {
	    offset = offset | 0
	    if (isFinite(length)) {
	      length = length | 0
	      if (encoding === undefined) encoding = 'utf8'
	    } else {
	      encoding = length
	      length = undefined
	    }
	  // legacy write(string, encoding, offset, length) - remove in v0.13
	  } else {
	    var swap = encoding
	    encoding = offset
	    offset = length | 0
	    length = swap
	  }

	  var remaining = this.length - offset
	  if (length === undefined || length > remaining) length = remaining

	  if ((string.length > 0 && (length < 0 || offset < 0)) || offset > this.length) {
	    throw new RangeError('attempt to write outside buffer bounds')
	  }

	  if (!encoding) encoding = 'utf8'

	  var loweredCase = false
	  for (;;) {
	    switch (encoding) {
	      case 'hex':
	        return hexWrite(this, string, offset, length)

	      case 'utf8':
	      case 'utf-8':
	        return utf8Write(this, string, offset, length)

	      case 'ascii':
	        return asciiWrite(this, string, offset, length)

	      case 'binary':
	        return binaryWrite(this, string, offset, length)

	      case 'base64':
	        // Warning: maxLength not taken into account in base64Write
	        return base64Write(this, string, offset, length)

	      case 'ucs2':
	      case 'ucs-2':
	      case 'utf16le':
	      case 'utf-16le':
	        return ucs2Write(this, string, offset, length)

	      default:
	        if (loweredCase) throw new TypeError('Unknown encoding: ' + encoding)
	        encoding = ('' + encoding).toLowerCase()
	        loweredCase = true
	    }
	  }
	}

	Buffer.prototype.toJSON = function toJSON () {
	  return {
	    type: 'Buffer',
	    data: Array.prototype.slice.call(this._arr || this, 0)
	  }
	}

	function base64Slice (buf, start, end) {
	  if (start === 0 && end === buf.length) {
	    return base64.fromByteArray(buf)
	  } else {
	    return base64.fromByteArray(buf.slice(start, end))
	  }
	}

	function utf8Slice (buf, start, end) {
	  end = Math.min(buf.length, end)
	  var res = []

	  var i = start
	  while (i < end) {
	    var firstByte = buf[i]
	    var codePoint = null
	    var bytesPerSequence = (firstByte > 0xEF) ? 4
	      : (firstByte > 0xDF) ? 3
	      : (firstByte > 0xBF) ? 2
	      : 1

	    if (i + bytesPerSequence <= end) {
	      var secondByte, thirdByte, fourthByte, tempCodePoint

	      switch (bytesPerSequence) {
	        case 1:
	          if (firstByte < 0x80) {
	            codePoint = firstByte
	          }
	          break
	        case 2:
	          secondByte = buf[i + 1]
	          if ((secondByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0x1F) << 0x6 | (secondByte & 0x3F)
	            if (tempCodePoint > 0x7F) {
	              codePoint = tempCodePoint
	            }
	          }
	          break
	        case 3:
	          secondByte = buf[i + 1]
	          thirdByte = buf[i + 2]
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0xC | (secondByte & 0x3F) << 0x6 | (thirdByte & 0x3F)
	            if (tempCodePoint > 0x7FF && (tempCodePoint < 0xD800 || tempCodePoint > 0xDFFF)) {
	              codePoint = tempCodePoint
	            }
	          }
	          break
	        case 4:
	          secondByte = buf[i + 1]
	          thirdByte = buf[i + 2]
	          fourthByte = buf[i + 3]
	          if ((secondByte & 0xC0) === 0x80 && (thirdByte & 0xC0) === 0x80 && (fourthByte & 0xC0) === 0x80) {
	            tempCodePoint = (firstByte & 0xF) << 0x12 | (secondByte & 0x3F) << 0xC | (thirdByte & 0x3F) << 0x6 | (fourthByte & 0x3F)
	            if (tempCodePoint > 0xFFFF && tempCodePoint < 0x110000) {
	              codePoint = tempCodePoint
	            }
	          }
	      }
	    }

	    if (codePoint === null) {
	      // we did not generate a valid codePoint so insert a
	      // replacement char (U+FFFD) and advance only 1 byte
	      codePoint = 0xFFFD
	      bytesPerSequence = 1
	    } else if (codePoint > 0xFFFF) {
	      // encode to utf16 (surrogate pair dance)
	      codePoint -= 0x10000
	      res.push(codePoint >>> 10 & 0x3FF | 0xD800)
	      codePoint = 0xDC00 | codePoint & 0x3FF
	    }

	    res.push(codePoint)
	    i += bytesPerSequence
	  }

	  return decodeCodePointsArray(res)
	}

	// Based on http://stackoverflow.com/a/22747272/680742, the browser with
	// the lowest limit is Chrome, with 0x10000 args.
	// We go 1 magnitude less, for safety
	var MAX_ARGUMENTS_LENGTH = 0x1000

	function decodeCodePointsArray (codePoints) {
	  var len = codePoints.length
	  if (len <= MAX_ARGUMENTS_LENGTH) {
	    return String.fromCharCode.apply(String, codePoints) // avoid extra slice()
	  }

	  // Decode in chunks to avoid "call stack size exceeded".
	  var res = ''
	  var i = 0
	  while (i < len) {
	    res += String.fromCharCode.apply(
	      String,
	      codePoints.slice(i, i += MAX_ARGUMENTS_LENGTH)
	    )
	  }
	  return res
	}

	function asciiSlice (buf, start, end) {
	  var ret = ''
	  end = Math.min(buf.length, end)

	  for (var i = start; i < end; i++) {
	    ret += String.fromCharCode(buf[i] & 0x7F)
	  }
	  return ret
	}

	function binarySlice (buf, start, end) {
	  var ret = ''
	  end = Math.min(buf.length, end)

	  for (var i = start; i < end; i++) {
	    ret += String.fromCharCode(buf[i])
	  }
	  return ret
	}

	function hexSlice (buf, start, end) {
	  var len = buf.length

	  if (!start || start < 0) start = 0
	  if (!end || end < 0 || end > len) end = len

	  var out = ''
	  for (var i = start; i < end; i++) {
	    out += toHex(buf[i])
	  }
	  return out
	}

	function utf16leSlice (buf, start, end) {
	  var bytes = buf.slice(start, end)
	  var res = ''
	  for (var i = 0; i < bytes.length; i += 2) {
	    res += String.fromCharCode(bytes[i] + bytes[i + 1] * 256)
	  }
	  return res
	}

	Buffer.prototype.slice = function slice (start, end) {
	  var len = this.length
	  start = ~~start
	  end = end === undefined ? len : ~~end

	  if (start < 0) {
	    start += len
	    if (start < 0) start = 0
	  } else if (start > len) {
	    start = len
	  }

	  if (end < 0) {
	    end += len
	    if (end < 0) end = 0
	  } else if (end > len) {
	    end = len
	  }

	  if (end < start) end = start

	  var newBuf
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    newBuf = Buffer._augment(this.subarray(start, end))
	  } else {
	    var sliceLen = end - start
	    newBuf = new Buffer(sliceLen, undefined)
	    for (var i = 0; i < sliceLen; i++) {
	      newBuf[i] = this[i + start]
	    }
	  }

	  if (newBuf.length) newBuf.parent = this.parent || this

	  return newBuf
	}

	/*
	 * Need to make sure that buffer isn't trying to write out of bounds.
	 */
	function checkOffset (offset, ext, length) {
	  if ((offset % 1) !== 0 || offset < 0) throw new RangeError('offset is not uint')
	  if (offset + ext > length) throw new RangeError('Trying to access beyond buffer length')
	}

	Buffer.prototype.readUIntLE = function readUIntLE (offset, byteLength, noAssert) {
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) checkOffset(offset, byteLength, this.length)

	  var val = this[offset]
	  var mul = 1
	  var i = 0
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul
	  }

	  return val
	}

	Buffer.prototype.readUIntBE = function readUIntBE (offset, byteLength, noAssert) {
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) {
	    checkOffset(offset, byteLength, this.length)
	  }

	  var val = this[offset + --byteLength]
	  var mul = 1
	  while (byteLength > 0 && (mul *= 0x100)) {
	    val += this[offset + --byteLength] * mul
	  }

	  return val
	}

	Buffer.prototype.readUInt8 = function readUInt8 (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 1, this.length)
	  return this[offset]
	}

	Buffer.prototype.readUInt16LE = function readUInt16LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length)
	  return this[offset] | (this[offset + 1] << 8)
	}

	Buffer.prototype.readUInt16BE = function readUInt16BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length)
	  return (this[offset] << 8) | this[offset + 1]
	}

	Buffer.prototype.readUInt32LE = function readUInt32LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)

	  return ((this[offset]) |
	      (this[offset + 1] << 8) |
	      (this[offset + 2] << 16)) +
	      (this[offset + 3] * 0x1000000)
	}

	Buffer.prototype.readUInt32BE = function readUInt32BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)

	  return (this[offset] * 0x1000000) +
	    ((this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    this[offset + 3])
	}

	Buffer.prototype.readIntLE = function readIntLE (offset, byteLength, noAssert) {
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) checkOffset(offset, byteLength, this.length)

	  var val = this[offset]
	  var mul = 1
	  var i = 0
	  while (++i < byteLength && (mul *= 0x100)) {
	    val += this[offset + i] * mul
	  }
	  mul *= 0x80

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

	  return val
	}

	Buffer.prototype.readIntBE = function readIntBE (offset, byteLength, noAssert) {
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) checkOffset(offset, byteLength, this.length)

	  var i = byteLength
	  var mul = 1
	  var val = this[offset + --i]
	  while (i > 0 && (mul *= 0x100)) {
	    val += this[offset + --i] * mul
	  }
	  mul *= 0x80

	  if (val >= mul) val -= Math.pow(2, 8 * byteLength)

	  return val
	}

	Buffer.prototype.readInt8 = function readInt8 (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 1, this.length)
	  if (!(this[offset] & 0x80)) return (this[offset])
	  return ((0xff - this[offset] + 1) * -1)
	}

	Buffer.prototype.readInt16LE = function readInt16LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length)
	  var val = this[offset] | (this[offset + 1] << 8)
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	}

	Buffer.prototype.readInt16BE = function readInt16BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 2, this.length)
	  var val = this[offset + 1] | (this[offset] << 8)
	  return (val & 0x8000) ? val | 0xFFFF0000 : val
	}

	Buffer.prototype.readInt32LE = function readInt32LE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)

	  return (this[offset]) |
	    (this[offset + 1] << 8) |
	    (this[offset + 2] << 16) |
	    (this[offset + 3] << 24)
	}

	Buffer.prototype.readInt32BE = function readInt32BE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)

	  return (this[offset] << 24) |
	    (this[offset + 1] << 16) |
	    (this[offset + 2] << 8) |
	    (this[offset + 3])
	}

	Buffer.prototype.readFloatLE = function readFloatLE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)
	  return ieee754.read(this, offset, true, 23, 4)
	}

	Buffer.prototype.readFloatBE = function readFloatBE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 4, this.length)
	  return ieee754.read(this, offset, false, 23, 4)
	}

	Buffer.prototype.readDoubleLE = function readDoubleLE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 8, this.length)
	  return ieee754.read(this, offset, true, 52, 8)
	}

	Buffer.prototype.readDoubleBE = function readDoubleBE (offset, noAssert) {
	  if (!noAssert) checkOffset(offset, 8, this.length)
	  return ieee754.read(this, offset, false, 52, 8)
	}

	function checkInt (buf, value, offset, ext, max, min) {
	  if (!Buffer.isBuffer(buf)) throw new TypeError('buffer must be a Buffer instance')
	  if (value > max || value < min) throw new RangeError('value is out of bounds')
	  if (offset + ext > buf.length) throw new RangeError('index out of range')
	}

	Buffer.prototype.writeUIntLE = function writeUIntLE (value, offset, byteLength, noAssert) {
	  value = +value
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) checkInt(this, value, offset, byteLength, Math.pow(2, 8 * byteLength), 0)

	  var mul = 1
	  var i = 0
	  this[offset] = value & 0xFF
	  while (++i < byteLength && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF
	  }

	  return offset + byteLength
	}

	Buffer.prototype.writeUIntBE = function writeUIntBE (value, offset, byteLength, noAssert) {
	  value = +value
	  offset = offset | 0
	  byteLength = byteLength | 0
	  if (!noAssert) checkInt(this, value, offset, byteLength, Math.pow(2, 8 * byteLength), 0)

	  var i = byteLength - 1
	  var mul = 1
	  this[offset + i] = value & 0xFF
	  while (--i >= 0 && (mul *= 0x100)) {
	    this[offset + i] = (value / mul) & 0xFF
	  }

	  return offset + byteLength
	}

	Buffer.prototype.writeUInt8 = function writeUInt8 (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 1, 0xff, 0)
	  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
	  this[offset] = (value & 0xff)
	  return offset + 1
	}

	function objectWriteUInt16 (buf, value, offset, littleEndian) {
	  if (value < 0) value = 0xffff + value + 1
	  for (var i = 0, j = Math.min(buf.length - offset, 2); i < j; i++) {
	    buf[offset + i] = (value & (0xff << (8 * (littleEndian ? i : 1 - i)))) >>>
	      (littleEndian ? i : 1 - i) * 8
	  }
	}

	Buffer.prototype.writeUInt16LE = function writeUInt16LE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff)
	    this[offset + 1] = (value >>> 8)
	  } else {
	    objectWriteUInt16(this, value, offset, true)
	  }
	  return offset + 2
	}

	Buffer.prototype.writeUInt16BE = function writeUInt16BE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 2, 0xffff, 0)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 8)
	    this[offset + 1] = (value & 0xff)
	  } else {
	    objectWriteUInt16(this, value, offset, false)
	  }
	  return offset + 2
	}

	function objectWriteUInt32 (buf, value, offset, littleEndian) {
	  if (value < 0) value = 0xffffffff + value + 1
	  for (var i = 0, j = Math.min(buf.length - offset, 4); i < j; i++) {
	    buf[offset + i] = (value >>> (littleEndian ? i : 3 - i) * 8) & 0xff
	  }
	}

	Buffer.prototype.writeUInt32LE = function writeUInt32LE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset + 3] = (value >>> 24)
	    this[offset + 2] = (value >>> 16)
	    this[offset + 1] = (value >>> 8)
	    this[offset] = (value & 0xff)
	  } else {
	    objectWriteUInt32(this, value, offset, true)
	  }
	  return offset + 4
	}

	Buffer.prototype.writeUInt32BE = function writeUInt32BE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 4, 0xffffffff, 0)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 24)
	    this[offset + 1] = (value >>> 16)
	    this[offset + 2] = (value >>> 8)
	    this[offset + 3] = (value & 0xff)
	  } else {
	    objectWriteUInt32(this, value, offset, false)
	  }
	  return offset + 4
	}

	Buffer.prototype.writeIntLE = function writeIntLE (value, offset, byteLength, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) {
	    var limit = Math.pow(2, 8 * byteLength - 1)

	    checkInt(this, value, offset, byteLength, limit - 1, -limit)
	  }

	  var i = 0
	  var mul = 1
	  var sub = value < 0 ? 1 : 0
	  this[offset] = value & 0xFF
	  while (++i < byteLength && (mul *= 0x100)) {
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
	  }

	  return offset + byteLength
	}

	Buffer.prototype.writeIntBE = function writeIntBE (value, offset, byteLength, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) {
	    var limit = Math.pow(2, 8 * byteLength - 1)

	    checkInt(this, value, offset, byteLength, limit - 1, -limit)
	  }

	  var i = byteLength - 1
	  var mul = 1
	  var sub = value < 0 ? 1 : 0
	  this[offset + i] = value & 0xFF
	  while (--i >= 0 && (mul *= 0x100)) {
	    this[offset + i] = ((value / mul) >> 0) - sub & 0xFF
	  }

	  return offset + byteLength
	}

	Buffer.prototype.writeInt8 = function writeInt8 (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 1, 0x7f, -0x80)
	  if (!Buffer.TYPED_ARRAY_SUPPORT) value = Math.floor(value)
	  if (value < 0) value = 0xff + value + 1
	  this[offset] = (value & 0xff)
	  return offset + 1
	}

	Buffer.prototype.writeInt16LE = function writeInt16LE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff)
	    this[offset + 1] = (value >>> 8)
	  } else {
	    objectWriteUInt16(this, value, offset, true)
	  }
	  return offset + 2
	}

	Buffer.prototype.writeInt16BE = function writeInt16BE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 2, 0x7fff, -0x8000)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 8)
	    this[offset + 1] = (value & 0xff)
	  } else {
	    objectWriteUInt16(this, value, offset, false)
	  }
	  return offset + 2
	}

	Buffer.prototype.writeInt32LE = function writeInt32LE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value & 0xff)
	    this[offset + 1] = (value >>> 8)
	    this[offset + 2] = (value >>> 16)
	    this[offset + 3] = (value >>> 24)
	  } else {
	    objectWriteUInt32(this, value, offset, true)
	  }
	  return offset + 4
	}

	Buffer.prototype.writeInt32BE = function writeInt32BE (value, offset, noAssert) {
	  value = +value
	  offset = offset | 0
	  if (!noAssert) checkInt(this, value, offset, 4, 0x7fffffff, -0x80000000)
	  if (value < 0) value = 0xffffffff + value + 1
	  if (Buffer.TYPED_ARRAY_SUPPORT) {
	    this[offset] = (value >>> 24)
	    this[offset + 1] = (value >>> 16)
	    this[offset + 2] = (value >>> 8)
	    this[offset + 3] = (value & 0xff)
	  } else {
	    objectWriteUInt32(this, value, offset, false)
	  }
	  return offset + 4
	}

	function checkIEEE754 (buf, value, offset, ext, max, min) {
	  if (value > max || value < min) throw new RangeError('value is out of bounds')
	  if (offset + ext > buf.length) throw new RangeError('index out of range')
	  if (offset < 0) throw new RangeError('index out of range')
	}

	function writeFloat (buf, value, offset, littleEndian, noAssert) {
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 4, 3.4028234663852886e+38, -3.4028234663852886e+38)
	  }
	  ieee754.write(buf, value, offset, littleEndian, 23, 4)
	  return offset + 4
	}

	Buffer.prototype.writeFloatLE = function writeFloatLE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, true, noAssert)
	}

	Buffer.prototype.writeFloatBE = function writeFloatBE (value, offset, noAssert) {
	  return writeFloat(this, value, offset, false, noAssert)
	}

	function writeDouble (buf, value, offset, littleEndian, noAssert) {
	  if (!noAssert) {
	    checkIEEE754(buf, value, offset, 8, 1.7976931348623157E+308, -1.7976931348623157E+308)
	  }
	  ieee754.write(buf, value, offset, littleEndian, 52, 8)
	  return offset + 8
	}

	Buffer.prototype.writeDoubleLE = function writeDoubleLE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, true, noAssert)
	}

	Buffer.prototype.writeDoubleBE = function writeDoubleBE (value, offset, noAssert) {
	  return writeDouble(this, value, offset, false, noAssert)
	}

	// copy(targetBuffer, targetStart=0, sourceStart=0, sourceEnd=buffer.length)
	Buffer.prototype.copy = function copy (target, targetStart, start, end) {
	  if (!start) start = 0
	  if (!end && end !== 0) end = this.length
	  if (targetStart >= target.length) targetStart = target.length
	  if (!targetStart) targetStart = 0
	  if (end > 0 && end < start) end = start

	  // Copy 0 bytes; we're done
	  if (end === start) return 0
	  if (target.length === 0 || this.length === 0) return 0

	  // Fatal error conditions
	  if (targetStart < 0) {
	    throw new RangeError('targetStart out of bounds')
	  }
	  if (start < 0 || start >= this.length) throw new RangeError('sourceStart out of bounds')
	  if (end < 0) throw new RangeError('sourceEnd out of bounds')

	  // Are we oob?
	  if (end > this.length) end = this.length
	  if (target.length - targetStart < end - start) {
	    end = target.length - targetStart + start
	  }

	  var len = end - start
	  var i

	  if (this === target && start < targetStart && targetStart < end) {
	    // descending copy from end
	    for (i = len - 1; i >= 0; i--) {
	      target[i + targetStart] = this[i + start]
	    }
	  } else if (len < 1000 || !Buffer.TYPED_ARRAY_SUPPORT) {
	    // ascending copy from start
	    for (i = 0; i < len; i++) {
	      target[i + targetStart] = this[i + start]
	    }
	  } else {
	    target._set(this.subarray(start, start + len), targetStart)
	  }

	  return len
	}

	// fill(value, start=0, end=buffer.length)
	Buffer.prototype.fill = function fill (value, start, end) {
	  if (!value) value = 0
	  if (!start) start = 0
	  if (!end) end = this.length

	  if (end < start) throw new RangeError('end < start')

	  // Fill 0 bytes; we're done
	  if (end === start) return
	  if (this.length === 0) return

	  if (start < 0 || start >= this.length) throw new RangeError('start out of bounds')
	  if (end < 0 || end > this.length) throw new RangeError('end out of bounds')

	  var i
	  if (typeof value === 'number') {
	    for (i = start; i < end; i++) {
	      this[i] = value
	    }
	  } else {
	    var bytes = utf8ToBytes(value.toString())
	    var len = bytes.length
	    for (i = start; i < end; i++) {
	      this[i] = bytes[i % len]
	    }
	  }

	  return this
	}

	/**
	 * Creates a new `ArrayBuffer` with the *copied* memory of the buffer instance.
	 * Added in Node 0.12. Only available in browsers that support ArrayBuffer.
	 */
	Buffer.prototype.toArrayBuffer = function toArrayBuffer () {
	  if (typeof Uint8Array !== 'undefined') {
	    if (Buffer.TYPED_ARRAY_SUPPORT) {
	      return (new Buffer(this)).buffer
	    } else {
	      var buf = new Uint8Array(this.length)
	      for (var i = 0, len = buf.length; i < len; i += 1) {
	        buf[i] = this[i]
	      }
	      return buf.buffer
	    }
	  } else {
	    throw new TypeError('Buffer.toArrayBuffer not supported in this browser')
	  }
	}

	// HELPER FUNCTIONS
	// ================

	var BP = Buffer.prototype

	/**
	 * Augment a Uint8Array *instance* (not the Uint8Array class!) with Buffer methods
	 */
	Buffer._augment = function _augment (arr) {
	  arr.constructor = Buffer
	  arr._isBuffer = true

	  // save reference to original Uint8Array set method before overwriting
	  arr._set = arr.set

	  // deprecated
	  arr.get = BP.get
	  arr.set = BP.set

	  arr.write = BP.write
	  arr.toString = BP.toString
	  arr.toLocaleString = BP.toString
	  arr.toJSON = BP.toJSON
	  arr.equals = BP.equals
	  arr.compare = BP.compare
	  arr.indexOf = BP.indexOf
	  arr.copy = BP.copy
	  arr.slice = BP.slice
	  arr.readUIntLE = BP.readUIntLE
	  arr.readUIntBE = BP.readUIntBE
	  arr.readUInt8 = BP.readUInt8
	  arr.readUInt16LE = BP.readUInt16LE
	  arr.readUInt16BE = BP.readUInt16BE
	  arr.readUInt32LE = BP.readUInt32LE
	  arr.readUInt32BE = BP.readUInt32BE
	  arr.readIntLE = BP.readIntLE
	  arr.readIntBE = BP.readIntBE
	  arr.readInt8 = BP.readInt8
	  arr.readInt16LE = BP.readInt16LE
	  arr.readInt16BE = BP.readInt16BE
	  arr.readInt32LE = BP.readInt32LE
	  arr.readInt32BE = BP.readInt32BE
	  arr.readFloatLE = BP.readFloatLE
	  arr.readFloatBE = BP.readFloatBE
	  arr.readDoubleLE = BP.readDoubleLE
	  arr.readDoubleBE = BP.readDoubleBE
	  arr.writeUInt8 = BP.writeUInt8
	  arr.writeUIntLE = BP.writeUIntLE
	  arr.writeUIntBE = BP.writeUIntBE
	  arr.writeUInt16LE = BP.writeUInt16LE
	  arr.writeUInt16BE = BP.writeUInt16BE
	  arr.writeUInt32LE = BP.writeUInt32LE
	  arr.writeUInt32BE = BP.writeUInt32BE
	  arr.writeIntLE = BP.writeIntLE
	  arr.writeIntBE = BP.writeIntBE
	  arr.writeInt8 = BP.writeInt8
	  arr.writeInt16LE = BP.writeInt16LE
	  arr.writeInt16BE = BP.writeInt16BE
	  arr.writeInt32LE = BP.writeInt32LE
	  arr.writeInt32BE = BP.writeInt32BE
	  arr.writeFloatLE = BP.writeFloatLE
	  arr.writeFloatBE = BP.writeFloatBE
	  arr.writeDoubleLE = BP.writeDoubleLE
	  arr.writeDoubleBE = BP.writeDoubleBE
	  arr.fill = BP.fill
	  arr.inspect = BP.inspect
	  arr.toArrayBuffer = BP.toArrayBuffer

	  return arr
	}

	var INVALID_BASE64_RE = /[^+\/0-9A-Za-z-_]/g

	function base64clean (str) {
	  // Node strips out invalid characters like \n and \t from the string, base64-js does not
	  str = stringtrim(str).replace(INVALID_BASE64_RE, '')
	  // Node converts strings with length < 2 to ''
	  if (str.length < 2) return ''
	  // Node allows for non-padded base64 strings (missing trailing ===), base64-js does not
	  while (str.length % 4 !== 0) {
	    str = str + '='
	  }
	  return str
	}

	function stringtrim (str) {
	  if (str.trim) return str.trim()
	  return str.replace(/^\s+|\s+$/g, '')
	}

	function toHex (n) {
	  if (n < 16) return '0' + n.toString(16)
	  return n.toString(16)
	}

	function utf8ToBytes (string, units) {
	  units = units || Infinity
	  var codePoint
	  var length = string.length
	  var leadSurrogate = null
	  var bytes = []

	  for (var i = 0; i < length; i++) {
	    codePoint = string.charCodeAt(i)

	    // is surrogate component
	    if (codePoint > 0xD7FF && codePoint < 0xE000) {
	      // last char was a lead
	      if (!leadSurrogate) {
	        // no lead yet
	        if (codePoint > 0xDBFF) {
	          // unexpected trail
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
	          continue
	        } else if (i + 1 === length) {
	          // unpaired lead
	          if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
	          continue
	        }

	        // valid lead
	        leadSurrogate = codePoint

	        continue
	      }

	      // 2 leads in a row
	      if (codePoint < 0xDC00) {
	        if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
	        leadSurrogate = codePoint
	        continue
	      }

	      // valid surrogate pair
	      codePoint = (leadSurrogate - 0xD800 << 10 | codePoint - 0xDC00) + 0x10000
	    } else if (leadSurrogate) {
	      // valid bmp char, but last char was a lead
	      if ((units -= 3) > -1) bytes.push(0xEF, 0xBF, 0xBD)
	    }

	    leadSurrogate = null

	    // encode utf8
	    if (codePoint < 0x80) {
	      if ((units -= 1) < 0) break
	      bytes.push(codePoint)
	    } else if (codePoint < 0x800) {
	      if ((units -= 2) < 0) break
	      bytes.push(
	        codePoint >> 0x6 | 0xC0,
	        codePoint & 0x3F | 0x80
	      )
	    } else if (codePoint < 0x10000) {
	      if ((units -= 3) < 0) break
	      bytes.push(
	        codePoint >> 0xC | 0xE0,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      )
	    } else if (codePoint < 0x110000) {
	      if ((units -= 4) < 0) break
	      bytes.push(
	        codePoint >> 0x12 | 0xF0,
	        codePoint >> 0xC & 0x3F | 0x80,
	        codePoint >> 0x6 & 0x3F | 0x80,
	        codePoint & 0x3F | 0x80
	      )
	    } else {
	      throw new Error('Invalid code point')
	    }
	  }

	  return bytes
	}

	function asciiToBytes (str) {
	  var byteArray = []
	  for (var i = 0; i < str.length; i++) {
	    // Node's code seems to be doing this and not & 0x7F..
	    byteArray.push(str.charCodeAt(i) & 0xFF)
	  }
	  return byteArray
	}

	function utf16leToBytes (str, units) {
	  var c, hi, lo
	  var byteArray = []
	  for (var i = 0; i < str.length; i++) {
	    if ((units -= 2) < 0) break

	    c = str.charCodeAt(i)
	    hi = c >> 8
	    lo = c % 256
	    byteArray.push(lo)
	    byteArray.push(hi)
	  }

	  return byteArray
	}

	function base64ToBytes (str) {
	  return base64.toByteArray(base64clean(str))
	}

	function blitBuffer (src, dst, offset, length) {
	  for (var i = 0; i < length; i++) {
	    if ((i + offset >= dst.length) || (i >= src.length)) break
	    dst[i + offset] = src[i]
	  }
	  return i
	}

	/* WEBPACK VAR INJECTION */}.call(exports, __webpack_require__(24).Buffer, (function() { return this; }())))

/***/ },
/* 25 */
/***/ function(module, exports, __webpack_require__) {

	var lookup = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/';

	;(function (exports) {
		'use strict';

	  var Arr = (typeof Uint8Array !== 'undefined')
	    ? Uint8Array
	    : Array

		var PLUS   = '+'.charCodeAt(0)
		var SLASH  = '/'.charCodeAt(0)
		var NUMBER = '0'.charCodeAt(0)
		var LOWER  = 'a'.charCodeAt(0)
		var UPPER  = 'A'.charCodeAt(0)
		var PLUS_URL_SAFE = '-'.charCodeAt(0)
		var SLASH_URL_SAFE = '_'.charCodeAt(0)

		function decode (elt) {
			var code = elt.charCodeAt(0)
			if (code === PLUS ||
			    code === PLUS_URL_SAFE)
				return 62 // '+'
			if (code === SLASH ||
			    code === SLASH_URL_SAFE)
				return 63 // '/'
			if (code < NUMBER)
				return -1 //no match
			if (code < NUMBER + 10)
				return code - NUMBER + 26 + 26
			if (code < UPPER + 26)
				return code - UPPER
			if (code < LOWER + 26)
				return code - LOWER + 26
		}

		function b64ToByteArray (b64) {
			var i, j, l, tmp, placeHolders, arr

			if (b64.length % 4 > 0) {
				throw new Error('Invalid string. Length must be a multiple of 4')
			}

			// the number of equal signs (place holders)
			// if there are two placeholders, than the two characters before it
			// represent one byte
			// if there is only one, then the three characters before it represent 2 bytes
			// this is just a cheap hack to not do indexOf twice
			var len = b64.length
			placeHolders = '=' === b64.charAt(len - 2) ? 2 : '=' === b64.charAt(len - 1) ? 1 : 0

			// base64 is 4/3 + up to two characters of the original data
			arr = new Arr(b64.length * 3 / 4 - placeHolders)

			// if there are placeholders, only get up to the last complete 4 chars
			l = placeHolders > 0 ? b64.length - 4 : b64.length

			var L = 0

			function push (v) {
				arr[L++] = v
			}

			for (i = 0, j = 0; i < l; i += 4, j += 3) {
				tmp = (decode(b64.charAt(i)) << 18) | (decode(b64.charAt(i + 1)) << 12) | (decode(b64.charAt(i + 2)) << 6) | decode(b64.charAt(i + 3))
				push((tmp & 0xFF0000) >> 16)
				push((tmp & 0xFF00) >> 8)
				push(tmp & 0xFF)
			}

			if (placeHolders === 2) {
				tmp = (decode(b64.charAt(i)) << 2) | (decode(b64.charAt(i + 1)) >> 4)
				push(tmp & 0xFF)
			} else if (placeHolders === 1) {
				tmp = (decode(b64.charAt(i)) << 10) | (decode(b64.charAt(i + 1)) << 4) | (decode(b64.charAt(i + 2)) >> 2)
				push((tmp >> 8) & 0xFF)
				push(tmp & 0xFF)
			}

			return arr
		}

		function uint8ToBase64 (uint8) {
			var i,
				extraBytes = uint8.length % 3, // if we have 1 byte left, pad 2 bytes
				output = "",
				temp, length

			function encode (num) {
				return lookup.charAt(num)
			}

			function tripletToBase64 (num) {
				return encode(num >> 18 & 0x3F) + encode(num >> 12 & 0x3F) + encode(num >> 6 & 0x3F) + encode(num & 0x3F)
			}

			// go through the array every three bytes, we'll deal with trailing stuff later
			for (i = 0, length = uint8.length - extraBytes; i < length; i += 3) {
				temp = (uint8[i] << 16) + (uint8[i + 1] << 8) + (uint8[i + 2])
				output += tripletToBase64(temp)
			}

			// pad the end with zeros, but make sure to not forget the extra bytes
			switch (extraBytes) {
				case 1:
					temp = uint8[uint8.length - 1]
					output += encode(temp >> 2)
					output += encode((temp << 4) & 0x3F)
					output += '=='
					break
				case 2:
					temp = (uint8[uint8.length - 2] << 8) + (uint8[uint8.length - 1])
					output += encode(temp >> 10)
					output += encode((temp >> 4) & 0x3F)
					output += encode((temp << 2) & 0x3F)
					output += '='
					break
			}

			return output
		}

		exports.toByteArray = b64ToByteArray
		exports.fromByteArray = uint8ToBase64
	}( false ? (this.base64js = {}) : exports))


/***/ },
/* 26 */
/***/ function(module, exports) {

	exports.read = function (buffer, offset, isLE, mLen, nBytes) {
	  var e, m
	  var eLen = nBytes * 8 - mLen - 1
	  var eMax = (1 << eLen) - 1
	  var eBias = eMax >> 1
	  var nBits = -7
	  var i = isLE ? (nBytes - 1) : 0
	  var d = isLE ? -1 : 1
	  var s = buffer[offset + i]

	  i += d

	  e = s & ((1 << (-nBits)) - 1)
	  s >>= (-nBits)
	  nBits += eLen
	  for (; nBits > 0; e = e * 256 + buffer[offset + i], i += d, nBits -= 8) {}

	  m = e & ((1 << (-nBits)) - 1)
	  e >>= (-nBits)
	  nBits += mLen
	  for (; nBits > 0; m = m * 256 + buffer[offset + i], i += d, nBits -= 8) {}

	  if (e === 0) {
	    e = 1 - eBias
	  } else if (e === eMax) {
	    return m ? NaN : ((s ? -1 : 1) * Infinity)
	  } else {
	    m = m + Math.pow(2, mLen)
	    e = e - eBias
	  }
	  return (s ? -1 : 1) * m * Math.pow(2, e - mLen)
	}

	exports.write = function (buffer, value, offset, isLE, mLen, nBytes) {
	  var e, m, c
	  var eLen = nBytes * 8 - mLen - 1
	  var eMax = (1 << eLen) - 1
	  var eBias = eMax >> 1
	  var rt = (mLen === 23 ? Math.pow(2, -24) - Math.pow(2, -77) : 0)
	  var i = isLE ? 0 : (nBytes - 1)
	  var d = isLE ? 1 : -1
	  var s = value < 0 || (value === 0 && 1 / value < 0) ? 1 : 0

	  value = Math.abs(value)

	  if (isNaN(value) || value === Infinity) {
	    m = isNaN(value) ? 1 : 0
	    e = eMax
	  } else {
	    e = Math.floor(Math.log(value) / Math.LN2)
	    if (value * (c = Math.pow(2, -e)) < 1) {
	      e--
	      c *= 2
	    }
	    if (e + eBias >= 1) {
	      value += rt / c
	    } else {
	      value += rt * Math.pow(2, 1 - eBias)
	    }
	    if (value * c >= 2) {
	      e++
	      c /= 2
	    }

	    if (e + eBias >= eMax) {
	      m = 0
	      e = eMax
	    } else if (e + eBias >= 1) {
	      m = (value * c - 1) * Math.pow(2, mLen)
	      e = e + eBias
	    } else {
	      m = value * Math.pow(2, eBias - 1) * Math.pow(2, mLen)
	      e = 0
	    }
	  }

	  for (; mLen >= 8; buffer[offset + i] = m & 0xff, i += d, m /= 256, mLen -= 8) {}

	  e = (e << mLen) | m
	  eLen += mLen
	  for (; eLen > 0; buffer[offset + i] = e & 0xff, i += d, e /= 256, eLen -= 8) {}

	  buffer[offset + i - d] |= s * 128
	}


/***/ },
/* 27 */
/***/ function(module, exports) {

	var toString = {}.toString;

	module.exports = Array.isArray || function (arr) {
	  return toString.call(arr) == '[object Array]';
	};


/***/ },
/* 28 */
/***/ function(module, exports) {

	module.exports = function(module) {
		if(!module.webpackPolyfill) {
			module.deprecate = function() {};
			module.paths = [];
			// module.parent = undefined by default
			module.children = [];
			module.webpackPolyfill = 1;
		}
		return module;
	}


/***/ },
/* 29 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.formatAddress = formatAddress;
	exports.formatRelativeAddress = formatRelativeAddress;
	exports.formatDecimal = formatDecimal;
	exports.formatString = formatString;
	exports.formatHexadecimal = formatHexadecimal;
	exports.formatBinary = formatBinary;
	var BITS_PER_HEX_CHAR = 4;
	var HEX_BASE = 16;

	function formatAddress(address, bits) {
	    var withPrefix = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];


	    if (isNaN(address)) return "NaN";

	    var str = Number(address).toString(HEX_BASE).toLowerCase();

	    if (typeof bits !== "undefined") while (str.length < Math.ceil(bits / BITS_PER_HEX_CHAR)) {
	        str = "0" + str;
	    } // eslint-disable-line prefer-template

	    if (withPrefix) str = "$" + str; // eslint-disable-line prefer-template

	    return str;
	}

	function formatRelativeAddress(sourceAddress, relativeAddress, sourceBits, relativeBits) {

	    var sign = relativeAddress < 0 ? "-" : "+";

	    if (typeof relativeAddress !== "string" || !isNaN(relativeAddress)) relativeAddress = formatAddress(Math.abs(relativeAddress), relativeBits, false);

	    return formatAddress(sourceAddress, sourceBits) + sign + relativeAddress;
	}

	function formatDecimal(value, size) {

	    if (isNaN(value)) return "NaN";

	    var str = Number(value).toString();

	    if (typeof size === "undefined") return str;

	    for (var t = str.length; t < size; ++t) {
	        str = "0" + str;
	    } // eslint-disable-line prefer-template

	    return str;
	}

	function formatString(str, size) {
	    var leftAligned = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];


	    str = str.toString();

	    if (typeof size === "undefined") return str;

	    for (var t = str.length; t < size; ++t) {
	        if (leftAligned) {
	            str = str + " "; // eslint-disable-line prefer-template
	        } else {
	                str = " " + str; // eslint-disable-line prefer-template
	            }
	    }

	    return str;
	}

	function formatHexadecimal(value, bits) {
	    var withPrefix = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];


	    if (isNaN(value)) return "NaN";

	    var str = Number(value).toString(HEX_BASE).toLowerCase();

	    if (typeof bits !== "undefined") while (str.length < Math.ceil(bits / BITS_PER_HEX_CHAR)) {
	        str = "0" + str;
	    } // eslint-disable-line prefer-template

	    if (withPrefix) str = "0x" + str; // eslint-disable-line prefer-template

	    return str;
	}

	function formatBinary(value, bits) {
	    var withPrefix = arguments.length <= 2 || arguments[2] === undefined ? true : arguments[2];


	    if (isNaN(value)) return "NaN";

	    var str = Number(value).toString(2);

	    if (typeof bits !== "undefined") while (str.length < bits) {
	        str = "0" + str;
	    } // eslint-disable-line prefer-template

	    if (withPrefix) str = "0b" + str; // eslint-disable-line prefer-template

	    return str;
	}

/***/ },
/* 30 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.memset = memset;
	function memset(destination, value, offset, size) {

	    for (var t = 0; t < size; ++t) {
	        destination[offset + t] = value;
	    }return destination;
	}

/***/ },
/* 31 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	exports.createDefensiveProxy = createDefensiveProxy;
	exports.mixin = mixin;
	exports.serializeArrayBuffer = serializeArrayBuffer;
	exports.serialize = serialize;
	exports.unserializeArrayBuffer = unserializeArrayBuffer;
	exports.unserialize = unserialize;
	exports.clone = clone;

	function _possibleConstructorReturn(self, call) { if (!self) { throw new ReferenceError("this hasn't been initialised - super() hasn't been called"); } return call && (typeof call === "object" || typeof call === "function") ? call : self; }

	function _inherits(subClass, superClass) { if (typeof superClass !== "function" && superClass !== null) { throw new TypeError("Super expression must either be null or a function, not " + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

	function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

	function createDefensiveProxy(object) {

	    if (typeof Proxy === "undefined") {

	        console.warn("Proxies are not available in your browser, and have been turned off."); // eslint-disable-line no-console

	        return object;
	    } else {

	        console.warn("Proxies are slows, and should not be enabled in production."); // eslint-disable-line no-console

	        return new Proxy(object, {
	            get: function get(target, property) {

	                if (Reflect.has(target, property)) {

	                    return target[property];
	                } else {

	                    throw new Error("Undefined property cannot be get: " + property);
	                }
	            },
	            set: function set(target, property, value) {

	                if (Reflect.has(target, property)) {

	                    target[property] = value;
	                } else {

	                    throw new Error("Undefined property cannot be set: " + property);
	                }
	            }
	        });
	    }
	}

	function mixin(Base) {
	    for (var _len = arguments.length, mixins = Array(_len > 1 ? _len - 1 : 0), _key = 1; _key < _len; _key++) {
	        mixins[_key - 1] = arguments[_key];
	    }

	    if (!Base) Base = function Base() {
	        _classCallCheck(this, Base);
	    };

	    var mixed = function (_Base) {
	        _inherits(mixed, _Base);

	        function mixed() {
	            var _Object$getPrototypeO;

	            _classCallCheck(this, mixed);

	            for (var _len2 = arguments.length, parameters = Array(_len2), _key2 = 0; _key2 < _len2; _key2++) {
	                parameters[_key2] = arguments[_key2];
	            }

	            // eslint-disable-next-line no-shadow

	            var _this = _possibleConstructorReturn(this, (_Object$getPrototypeO = Object.getPrototypeOf(mixed)).call.apply(_Object$getPrototypeO, [this].concat(parameters)));

	            mixins.forEach(function (mixin) {
	                Reflect.apply(mixin, _this);
	            });

	            return _this;
	        }

	        return mixed;
	    }(Base);

	    var _iteratorNormalCompletion = true;
	    var _didIteratorError = false;
	    var _iteratorError = undefined;

	    try {
	        for (var _iterator = mixins[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
	            var _mixin = _step.value;
	            // eslint-disable-line no-shadow
	            var _iteratorNormalCompletion2 = true;
	            var _didIteratorError2 = false;
	            var _iteratorError2 = undefined;

	            try {
	                for (var _iterator2 = Object.keys(_mixin.prototype)[Symbol.iterator](), _step2; !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
	                    var method = _step2.value;

	                    mixed.prototype[method] = _mixin.prototype[method];
	                }
	            } catch (err) {
	                _didIteratorError2 = true;
	                _iteratorError2 = err;
	            } finally {
	                try {
	                    if (!_iteratorNormalCompletion2 && _iterator2.return) {
	                        _iterator2.return();
	                    }
	                } finally {
	                    if (_didIteratorError2) {
	                        throw _iteratorError2;
	                    }
	                }
	            }
	        }
	    } catch (err) {
	        _didIteratorError = true;
	        _iteratorError = err;
	    } finally {
	        try {
	            if (!_iteratorNormalCompletion && _iterator.return) {
	                _iterator.return();
	            }
	        } finally {
	            if (_didIteratorError) {
	                throw _iteratorError;
	            }
	        }
	    }

	    return mixed;
	}

	function serializeArrayBuffer(arrayBuffer) {

	    var serialization = "";

	    for (var array = new Uint8Array(arrayBuffer), t = 0, T = array.length; t < T; ++t) {
	        serialization += String.fromCharCode(array[t]);
	    }return serialization;
	}

	function serialize(data) {

	    // eslint-disable-next-line no-shadow
	    var getFormat = function getFormat(data) {
	        return Object.keys(data).reduce(function (format, key) {

	            var value = data[key];

	            if (value instanceof ArrayBuffer) {
	                format[key] = "arraybuffer";
	            } else if (value && value.constructor === Object) {
	                format[key] = getFormat(value);
	            } else {
	                format[key] = null;
	            }

	            return format;
	        }, {});
	    };

	    // eslint-disable-next-line no-shadow
	    var simplify = function simplify(data) {
	        return Object.keys(data).reduce(function (simplified, key) {

	            var value = data[key];

	            if (value instanceof ArrayBuffer) {
	                simplified[key] = serializeArrayBuffer(value);
	            } else if (value && value.constructor === Object) {
	                simplified[key] = simplify(value);
	            } else {
	                simplified[key] = value;
	            }

	            return simplified;
	        }, {});
	    };

	    return JSON.stringify({

	        format: getFormat(data),
	        tree: simplify(data)

	    });
	}

	function unserializeArrayBuffer(serialization) {

	    var buffer = new ArrayBuffer(serialization.length);
	    var bufferView = new Uint8Array(buffer);

	    for (var t = 0, T = bufferView.length; t < T; ++t) {
	        bufferView[t] = serialization.charCodeAt(t);
	    }return bufferView.buffer;
	}

	function unserialize(serialization) {

	    var complexify = function complexify(format, tree) {
	        return Object.keys(format).reduce(function (complexified, key) {

	            var type = format[key];
	            var node = tree[key];

	            if (type === "arraybuffer") {
	                complexified[key] = unserializeArrayBuffer(node);
	            } else if (type && type.constructor === Object) {
	                complexified[key] = complexify(type, node);
	            } else {
	                complexified[key] = node;
	            }

	            return complexified;
	        }, {});
	    };

	    var _ref = typeof serialization === "object" ? serialization : JSON.parse(serialization);

	    var format = _ref.format;
	    var tree = _ref.tree;

	    return complexify(format, tree);
	}

	function clone(input) {

	    if (typeof input !== "object") return input;

	    if (input instanceof Array) return input.map(function (value) {
	        return clone(value);
	    });

	    if (input instanceof ArrayBuffer) return input.slice(0);

	    var output = {};

	    var _iteratorNormalCompletion3 = true;
	    var _didIteratorError3 = false;
	    var _iteratorError3 = undefined;

	    try {
	        for (var _iterator3 = Object.keys(input)[Symbol.iterator](), _step3; !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
	            var key = _step3.value;

	            output[key] = clone(input[key]);
	        }
	    } catch (err) {
	        _didIteratorError3 = true;
	        _iteratorError3 = err;
	    } finally {
	        try {
	            if (!_iteratorNormalCompletion3 && _iterator3.return) {
	                _iterator3.return();
	            }
	        } finally {
	            if (_didIteratorError3) {
	                throw _iteratorError3;
	            }
	        }
	    }

	    return output;
	}

/***/ },
/* 32 */
/***/ function(module, exports) {

	"use strict";

	Object.defineProperty(exports, "__esModule", {
	    value: true
	});
	var toSigned8 = exports.toSigned8 = function () {

	    var tmp = new Int8Array(1);

	    return function (n) {

	        tmp[0] = n;

	        return tmp[0];
	    };
	}();

/***/ }
/******/ ])
});
;