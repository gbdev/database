#ifndef SPRITE_SKULL_H
#define SPRITE_SKULL_H

#include "main.h"

DECLARE_SPRITE(SPRITE_SKULL);

#endif