#ifndef SPRITE_SKELTAL_H
#define SPRITE_SKELTAL_H

#include "main.h"

DECLARE_SPRITE(SPRITE_SKELTAL);

#endif