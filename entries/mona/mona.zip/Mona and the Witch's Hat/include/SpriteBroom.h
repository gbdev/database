#ifndef SPRITE_BROOM_H
#define SPRITE_BROOM_H

#include "main.h"

DECLARE_SPRITE(SPRITE_BROOM);

#endif