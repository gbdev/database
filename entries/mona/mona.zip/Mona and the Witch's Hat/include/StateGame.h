#ifndef STATE_GAME_H
#define STATE_GAME_H

#include "main.h"

DECLARE_STATE(STATE_GAME);

#endif