#ifndef SPRITE_BARREL_H
#define SPRITE_BARREL_H

#include "main.h"

DECLARE_SPRITE(SPRITE_BARREL);

#endif