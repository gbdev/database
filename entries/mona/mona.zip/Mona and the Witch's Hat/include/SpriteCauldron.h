#ifndef SPRITE_CAULDRON_H
#define SPRITE_CAULDRON_H

#include "main.h"

DECLARE_SPRITE(SPRITE_CAULDRON);

#endif