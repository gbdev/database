#ifndef SPRITE_PLAYER_H
#define SPRITE_PLAYER_H

#include "main.h"

DECLARE_SPRITE(SPRITE_PLAYER);

#endif