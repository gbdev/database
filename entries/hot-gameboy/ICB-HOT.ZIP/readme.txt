___ ^hotGB^  by icebird console section ___
  made and released at Mekka/Symposium 98
 
credits
~~~~~~~~~ ~~
    code : exoticorn/icebird
           mrhill/icebird
graphics : gizmo/icebird
   music : exoticorn/icebird

notes about this release
~~~~~~~~~~~~~~~~~~~~~~~~~~ ~~

hotGB is icebird's first gameboy production. We did it entirely at
Mekka/Symposium party 98 held near Hamburg/Germany.

Don't expect this demo to be a state of the art production, just
understand it as a party fun release! Oh yes, it does not run on
real gameboy, because we could not test it at MS98. So wait for
a patch...

future
~~~~~~~~ ~~

Icebird is a demogroup on the Acorn Archimedes, we founded
a console section intending to produce demos for GB/GBC/SNES/N64.
So wait for some nice productions, especially for GBC!

icebird members
~~~~~~~~~~~~~~~~~ ~~
  .            .                .
  | handle     | member state   | system
 -*------------*----------------*------------------ -
  | 7          | coder          | acorn
  | Gizmo      | graphician     | acorn
  | Merlyn     | coder          | any
  | MrCoke     | coder, sounder | acorn
  | mR hiLL    | coder          | acorn, console
  | red        | graphician     | amiga
  | Skid       | sounder        | amiga
  | ThyFro     | coder          | acorn, console

icebird contact
~~~~~~~~~~~~~~~~~ ~~
email :    mrhill - bawa@thepentagon.com
        exoticorn - dennis_ranke@maus.de
            gizmo - gizmo@smaug.netwave.de

www   : http://www.germany.net/teilnehmer/100/160485 (temporary site)
