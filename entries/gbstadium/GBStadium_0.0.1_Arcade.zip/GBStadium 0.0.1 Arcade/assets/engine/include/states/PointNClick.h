#ifndef STATE_POINT_N_CLICK_H
#define STATE_POINT_N_CLICK_H

#include <gb/gb.h>

void Start_PointNClick();
void Update_PointNClick();

#endif
