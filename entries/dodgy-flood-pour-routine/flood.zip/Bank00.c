///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////
// Dodgy Flood/Pour routine                                                  //
// by quang 18/04/2000                                                       //
// quang@mindless.com                                                        //
///////////////////////////////////////////////////////////////////////////////
///////////////////////////////////////////////////////////////////////////////

#include <gb.h>
#include "TitleTiles.c"
#include "TitleTiles.h"
#include "TitleMap.c"

UBYTE Joy;
UBYTE x,y,z;
UWORD xx,yy,zz;
UBYTE FloodLine,FloodType;

UWORD TitlePal[]={
TitleTilesCGBPal0c0,TitleTilesCGBPal0c1,TitleTilesCGBPal0c2,TitleTilesCGBPal0c3,
TitleTilesCGBPal1c0,TitleTilesCGBPal1c1,TitleTilesCGBPal1c2,TitleTilesCGBPal1c3,
TitleTilesCGBPal2c0,TitleTilesCGBPal2c1,TitleTilesCGBPal2c2,TitleTilesCGBPal2c3,
TitleTilesCGBPal3c0,TitleTilesCGBPal3c1,TitleTilesCGBPal3c2,TitleTilesCGBPal3c3,
TitleTilesCGBPal4c0,TitleTilesCGBPal4c1,TitleTilesCGBPal4c2,TitleTilesCGBPal4c3,
TitleTilesCGBPal5c0,TitleTilesCGBPal5c1,TitleTilesCGBPal5c2,TitleTilesCGBPal5c3,
TitleTilesCGBPal6c0,TitleTilesCGBPal6c1,TitleTilesCGBPal6c2,TitleTilesCGBPal6c3,
TitleTilesCGBPal7c0,TitleTilesCGBPal7c1,TitleTilesCGBPal7c2,TitleTilesCGBPal7c3
};

void FloodLCD(){
	if(FloodType==1){										//Pour in Picture
		while(STAT_REG&0x02);SCY_REG=FloodLine-LY_REG;
		if(LYC_REG==FloodLine) {LYC_REG=0; SCY_REG=0;}
		else LYC_REG++;
	}
	if(FloodType==2){										//Pour picture away
		while(STAT_REG&0x02);SCY_REG=FloodLine-LY_REG;
		if(LYC_REG==144) {LYC_REG=FloodLine; SCY_REG=0;}
		else LYC_REG++;
	}
}

void main(){
	cpu_fast();												//Double speed needed as C is too slow otherwise.

	FloodType=0;
	disable_interrupts();											//Setup LCD interrupt
	add_LCD(FloodLCD);
	set_interrupts(VBL_IFLAG|LCD_IFLAG);
	STAT_REG |= 0x40; LYC_REG=0;
	enable_interrupts();

	wait_vbl_done();
	move_bkg(0,0);													//Setup the screen.
	move_win(200,200);
	for(x=0;x!=40;x++) move_sprite(x,200,200);
	SHOW_BKG;HIDE_WIN;HIDE_SPRITES;
	delay(1000);
	while(1){
		DISPLAY_OFF;
		wait_vbl_done();
		for (xx=0x9800;xx!=0x9c00;xx++) {								//Clear both bkg maps
			VBK_REG=0; while(STAT_REG&0x02);(*(UBYTE *)xx)=0;
			VBK_REG=1; while(STAT_REG&0x02);(*(UBYTE *)xx)=0;
		}
		wait_vbl_done();
		VBK_REG=0; set_bkg_data(0,0,TitleTiles);						//Load in the image
		VBK_REG=1; set_bkg_data(0,0,&TitleTiles[256<<4]);
		VBK_REG=1; set_bkg_tiles(0,0,20,18,TitleMapPLN1);
		VBK_REG=0; set_bkg_tiles(0,0,20,18,TitleMapPLN0);	

		wait_vbl_done();
		set_bkg_palette(0,8,TitlePal);								//Set the palette
		DISPLAY_ON;

		FloodType=1;LYC_REG=0;
		for(FloodLine=144;FloodLine!=0;FloodLine--)	wait_vbl_done();
		FloodType=0;

		while(joypad()!=0);
		while(joypad()==0);

		FloodType=2;LYC_REG=144;
		for(FloodLine=144;FloodLine!=0;FloodLine--)	wait_vbl_done();
		FloodType=0;
	}
}


