/* GBamaTron by Ventzislav Tzvetkov <drHirudo@Amigascne.org>
                                     http://drhirudo.hit.bg

Copyright � 2004-2006

Coded from scratch for the PDROMs coding competition 2
All graphics sounds and music by me.

Works on Classic and Color Gameboys. 

Version 1.02 - Fixed some sound bugs (The music is still bad).
             - Less colour cycling and head rotating.
             - Source code beautification.

compile with GBDK and following command line:
lcc -Wl-yp0x143=0x80 GBamaTron.c -o GBamaTron.gb

*/

#include <gb.h>
#include <drawing.h>
#include <rand.h>
#include <cgb.h>
#include "GBamaTron.h"

UINT8 Bullet[15][4],Alien[42][4],Level,ModeS_ID,ModeID,ModeID2,direction,
             Fdirection,count,Lives,ManX,ManY,AlienNo,Aliens,KilledAliens,
             Screen[20][17],Ax,Ay,Q1,Q2,Q3,Q4,BlackCycle,SoundFlag,Weapon,
             LevelFlag,ItemRandom,GameBoyMode;

INT8 DeltaBX,DeltaBY;

void fadein(INT8 palettenumber){
if (GameBoyMode==CGB_TYPE) set_bkg_palette(0x00U,0x01U,&background_palette[palettenumber]);
 else
{BGP_REG = 0x40U;delay(59U); BGP_REG = 0x90U;delay(59U); BGP_REG = 0xE4U;}}

void fadeout() {
     if(GameBoyMode==CGB_TYPE) set_bkg_palette( 0x00U, 0x01U, &background_palette[0x08U] ); else 
{    BGP_REG = OBP0_REG = OBP1_REG = 0x90U;
     delay(59); BGP_REG = OBP0_REG = OBP1_REG = 0x40U;
     delay(59); NR52_REG = NR50_REG = NR51_REG = BGP_REG = OBP0_REG = OBP1_REG = 0x00U;}HIDE_SPRITES;}

unsigned long Score,TmpScore,HighScore;

char Scores[6];

void BlackPCycle(){
wait_vbl_done();
if (++BlackCycle==0x7FU) BlackCycle=0;

if (GameBoyMode==CGB_TYPE)
{if (BlackCycle==43) set_bkg_palette( 0, 1, &background_palette[12] );
if (BlackCycle==86) set_bkg_palette( 0, 1, &background_palette[16] );
if (BlackCycle==0)  set_bkg_palette( 0, 1, &background_palette[4] );}

else {
if (BlackCycle==43) BGP_REG = 0xA4U;
if (BlackCycle==86) BGP_REG = 0x64U;
if (BlackCycle==0)  BGP_REG = 0xE4U;}}

void RandomAlien() {Alien[Aliens][0]=(rand()%0x68U)+0x78U;}

void Bullets(){
if (SoundFlag==1) {NR42_REG = SoundFlag = 0x00U;}
wait_vbl_done();
for (direction=0;direction!=13;direction++){
Bullet[direction][0]=Bullet[direction][0]+Bullet[direction][2];
Bullet[direction][1]=Bullet[direction][1]+Bullet[direction][3];
Ax=Screen[(Bullet[direction][0]-6)/8][(Bullet[direction][1]-12)/8];
if (Bullet[direction][0]<0x06U || Bullet[direction][0]>0xA2U ||
Bullet[direction][1]<0x0CU || Bullet[direction][1]>0x9AU || Ax==0x6EU)
Bullet[direction][0]=Bullet[direction][1]=Bullet[direction][2]=Bullet[direction][3]=0;
else if (Aliens+1>Ax && Ax>0x00U) // Hit an Alien
{
Bullet[direction][2]=Bullet[direction][3]=0;set_sprite_tile(direction+1,13);
if (Weapon==15 && Alien[Ax][3]>1) Alien[Ax][3]--;
      Alien[Ax][3]--;
if (Alien[Ax][3]==0) {
                    NR52_REG = 0x8FU; /* make sure sound is enabled */
                    NR50_REG = 0xBBU;
                    NR51_REG = 0xFFU; /* send sound to left and rignt */
                    NR10_REG = 0x60U;
                    NR11_REG = 0x01U;
                    NR12_REG = 0xF1U;
                    NR13_REG = 100U;
                    NR14_REG = 135U;
                    KilledAliens++;Score+=Level;
                    gotogxy(Alien[Ax][1],Alien[Ax][2]);
                    Screen[Alien[Ax][1]][Alien[Ax][2]]=0;
                    wrtchr(0x20U);} else {
NR52_REG = 0x8FU;
NR50_REG = 0xAAU;
NR51_REG = 0xFFU;
NR31_REG = 0x10U;
NR30_REG = 0x80U;
NR44_REG = 0x80U;
NR41_REG = 0x01U;
NR42_REG = 243U;
NR43_REG = 51U;
SoundFlag = 1U;
}
}
else if (Bullet[direction][2]!=0 || Bullet[direction][3]!=0) set_sprite_tile(direction+1,Weapon);
move_sprite(direction+1,Bullet[direction][0],Bullet[direction][1]);
}
}

void sound2(long freq1,long freq2)
{
NR52_REG = 0x8F; /* make sure sound is enabled */
NR50_REG = 0xAAU; /* Set average volume. */
NR51_REG = 0xFF; /* send sound to left and rignt */

NR10_REG = 127U;

NR11_REG = NR21_REG = 0x01U;
NR12_REG = 242U;
NR13_REG = freq1 & 0x00FFL;
NR14_REG = freq1 >> 8;

NR22_REG = 34U;
NR23_REG = freq2 & 0x00FFL;
NR24_REG = freq2 >> 8;
}


void CalculateScore() /* Converts the Score to String. Score stays untouched */
{TmpScore=Score;
Scores[0]=(TmpScore/10000)+0x10U; TmpScore=TmpScore%10000;
Scores[1]=(TmpScore/1000)+0x10U;   TmpScore=TmpScore%1000;
Scores[2]=(TmpScore/100)+0x10U;     TmpScore=TmpScore%100;
Scores[3]=(TmpScore/10)+0x10U;       TmpScore=TmpScore%10;
Scores[4]=TmpScore+0x10U;}

void DrawLevel(UINT8 LevelNumber){
NR42_REG = NR43_REG = NR44_REG = 0;
fadeout();color(WHITE,WHITE,SOLID);
box(0,0,159,143,M_FILL);color(BLACK,WHITE,SOLID);
gotogxy(6,6);gprintf("Level %d",Level);
color(DKGREY,WHITE,SOLID);
CalculateScore();LevelFlag=1;
gotogxy(4,8);gprint("Score ");gprint(Scores);
color(LTGREY,WHITE,SOLID);
gotogxy(6,10);gprintf("Lives %d",Lives);
fadein(4);
for (count=0;LevelMusic1[count]!=END;count++){
if (LevelMusic1[count]!=PAUSE) {
 sound2( frequencies[LevelMusic1[count]],frequencies[LevelMusic2[count]]);
 }if (joypad()&(J_A|J_B|J_START)) break;
delay(97);}
fadeout();
color(BLACK,WHITE,SOLID);box(0,0,159,143,M_FILL);box(1,1,158,142,M_FILL);
for (direction=0;direction!=20;direction++) {for (count=0;count!=17;count++)
{Screen[direction][count]=0;Screen[0][count]=0x6FU;Screen[19][count]=0x6FU;}
Screen[direction][0]=0x6FU;Screen[direction][17]=0x6FU;} // Level Init (Borders);
color(DKGREY,WHITE,SOLID);

switch (LevelNumber) {
case 1:Q1=Q2=20;Q3=Q4=0;break; /* Every level encoded */
case 2:Q1=Q2=0;Q3=Q4=20;break;
case 3:Q1=Q4=0;Q2=Q3=20;break;
case 4:Q1=Q2=Q3=Q4=5;break;
case 5:Q1=Q2=Q3=Q4=8;break;
case 6:Q1=Q2=Q3=Q4=6;LevelNumber=15;color(BLACK,BLACK,SOLID);
for (count=6;count!=13;count++){gotogxy(count,6);wrtchr(0x20);
gotogxy(count,12);wrtchr(0x20);Screen[count][6]=Screen[count][12]=0x6EU;}break;
case 7:Q1=Q2=Q3=Q4=8;LevelNumber=25;break;
case 8:Q1=Q2=Q3=Q4=5;break;
case 9:Q1=Q2=Q3=Q4=10;gotogxy(8,6);color(BLACK,BLACK,SOLID);
wrtchr(0x20);Screen[8][6]=0x6EU;break;
case 10: Q3=1;Q4=0xFF;for (Q1=7;Q1!=3;Q1--) for (Q2=7;Q2!=3;Q2--)
{gotogxy(Alien[Q3][1]=Q2,Alien[Q3][2]=Q1);Alien[Q3][3]=160;
wrtchr(Alien[Q3][0]=Q4);Q4--;Q3++;}LevelFlag=0;ItemRandom=1;Aliens=16;
color(LTGREY,BLACK,SOLID);gotogxy(10,5);gprint("  DammeS  ");
for (Q1=10;Q1!=20;Q1++)Screen[Q1][5]=0x6EU;color(DKGREY,WHITE,SOLID);break;
case 11:Q1=Q2=Q3=Q4=6;LevelNumber=66;break;
case 12:Q1=10;Q2=2;Q3=5;Q4=1;break;
case 13:Q1=Q2=Q3=Q4=4;gotogxy(6,6);color(BLACK,BLACK,SOLID);
gprint(" :)");Screen[6][6]=Screen[7][6]=Screen[8][6]=0x6EU;color(DKGREY,WHITE,SOLID);break;
case 14:Q1=Q3=3;Q2=Q4=4;break;
case 15:Q1=Q2=Q3=Q4=3;break;
case 16:Q1=Q2=Q3=Q4=2;break;
case 17:Q1=Q2=Q3=Q4=3;LevelNumber=38;break;
case 18:color(BLACK,BLACK,SOLID);for (Q1=3;Q1!=15;Q1+=2) for (Q2=3;Q2!=19;Q2+=4)
{gotogxy(Q2,Q1);wrtchr(0x20);Screen[Q2][Q1]=0x6EU;}Q1=Q2=Q3=Q4=4;break;
case 19:color(BLACK,BLACK,SOLID);for (Q1=3;Q1!=15;Q1+=2)
for (Q2=3;Q2!=19;Q2+=4) {gotogxy(Q2,Q1);wrtchr(0x20);
Screen[Q2][Q1]=0x6EU;} Q1=Q2=Q3=Q4=4;LevelNumber=105;break;
case 20: Q3=1;Q4=0xEF;for (Q1=6;Q1!=2;Q1--) for (Q2=5;Q2!=1;Q2--)
{gotogxy(Alien[Q3][1]=Q2,Alien[Q3][2]=Q1);Alien[Q3][3]=200;
wrtchr(Alien[Q3][0]=Q4);Q4--;Q3++;}LevelFlag=0;ItemRandom=1;Aliens=16;
color(LTGREY,BLACK,SOLID);gotogxy(9,5);gprint(" Gentlemen ");
for (Q1=9;Q1!=20;Q1++)Screen[Q1][5]=0x6EU;color(DKGREY,WHITE,SOLID);break;
case 21: Q1=Q2=Q3=Q4=10;LevelNumber=88;break;
case 22: Q1=Q2=Q3=Q4=8;LevelNumber=99;break;
case 23: Q1=4;Q2=Q3=0;Q4=3;LevelNumber=101;break;
case 24: color(LTGREY,BLACK,SOLID);gotogxy(4,4);gprint(" Amiga Room ");
for (Q1=4;Q1!=16;Q1++)Screen[Q1][4]=0x6EU;Q1=Q2=Q2=Q4=3;LevelNumber=105;break;
case 25: Q1=Q2=Q3=Q4=8;LevelNumber=110;break;
case 26: LevelNumber=115;gotogxy(4,6);color(LTGREY,BLACK,SOLID);
gprint(" drhirudo.hit.bg");for (Q1=4;Q1!=20;Q1++) Screen[Q1][6]=0x6EU;
Q1=Q2=Q3=Q4=7;break;
case 27: Q1=Q2=Q3=Q4=3;LevelNumber=112;break;
case 28: color(BLACK,BLACK,SOLID);for (Q1=3;Q1!=18;Q1+=3) for (Q2=3;Q2!=18;Q2+=3)
{gotogxy(Q2,Q1);wrtchr(0x20);Screen[Q2][Q1]=0x6EU;}Q1=Q2=Q3=Q4=4;LevelNumber=115;break;
case 29: color(LTGREY,BLACK,SOLID);for (Q1=3;Q1!=18;Q1+=3) 
{gotogxy(3,Q1);gprint("***");Screen[3][Q1]=Screen[4][Q1]=Screen[5][Q1]=0x6EU;
gotogxy(15,Q1);gprint("***");Screen[15][Q1]=Screen[16][Q1]=Screen[17][Q1]=0x6EU;
}Q1=Q2=Q3=Q4=4;LevelNumber=118;break;
case 30: Q1=Q2=Q3=Q4=2;break;
case 31: Q1=Q2=3;Q3=Q4=4;LevelNumber=124;break;
case 32: Q3=1;Q4=0xE0;for (Q1=12;Q1!=16;Q1++) for (Q2=14;Q2!=18;Q2++)
{gotogxy(Alien[Q3][1]=Q2,Alien[Q3][2]=Q1);Alien[Q3][3]=0xFFU;
wrtchr(Alien[Q3++][0]=Q4++);}color(DKGREY,WHITE,SOLID);
Q4=0xFF;for (Q1=7;Q1!=3;Q1--) for (Q2=7;Q2!=3;Q2--)
{gotogxy(Alien[Q3][1]=Q2,Alien[Q3][2]=Q1);Alien[Q3][3]=0xDFU;
wrtchr(Alien[Q3][0]=Q4);Q4--;Q3++;}
color(LTGREY,BLACK,SOLID);gotogxy(10,5);gprint("  DammeS  ");
for (Q1=10;Q1!=20;Q1++)Screen[Q1][5]=0x6EU;
gotogxy(0,12);gprint(" Gentlemen ");
for (Q1=0;Q1!=11;Q1++)Screen[Q1][12]=0x6EU;Aliens=32;
LevelFlag=0;ItemRandom=1;color(DKGREY,WHITE,SOLID);break;
default: break;
}
if (LevelFlag==1) {Aliens=1;color(DKGREY,WHITE,SOLID);
for (direction=0;direction!=Q1;direction++){
RandomAlien();
Alien[Aliens][1]=rand()%6+1;
Alien[Aliens][2]=rand()%5+1;
Alien[Aliens][3]=LevelNumber*2;
if (Screen[Alien[Aliens][1]][Alien[Aliens][2]]!=0) {direction--;continue;}
gotogxy(Alien[Aliens][1],Alien[Aliens][2]);
wrtchr(Alien[Aliens][0]);
Screen[Alien[Aliens][1]][Alien[Aliens][2]]=Aliens;Aliens++;}

for (direction=0;direction!=Q2;direction++){
RandomAlien();
Alien[Aliens][1]=rand()%6+13;
Alien[Aliens][2]=rand()%5+1;
Alien[Aliens][3]=LevelNumber*2;
if (Screen[Alien[Aliens][1]][Alien[Aliens][2]]!=0) {direction--;continue;}
gotogxy(Alien[Aliens][1],Alien[Aliens][2]);
wrtchr(Alien[Aliens][0]);
Screen[Alien[Aliens][1]][Alien[Aliens][2]]=Aliens;Aliens++;
}

for (direction=0;direction!=Q3;direction++){
RandomAlien();
Alien[Aliens][1]=rand()%6+1;
Alien[Aliens][2]=rand()%5+11;
Alien[Aliens][3]=LevelNumber*2;
if (Screen[Alien[Aliens][1]][Alien[Aliens][2]]!=0) {direction--;continue;}
gotogxy(Alien[Aliens][1],Alien[Aliens][2]);
wrtchr(Alien[Aliens][0]);
Screen[Alien[Aliens][1]][Alien[Aliens][2]]=Aliens;Aliens++;
}

for (direction=0;direction!=Q4;direction++){
RandomAlien();
Alien[Aliens][1]=rand()%6+13;
Alien[Aliens][2]=rand()%5+11;
Alien[Aliens][3]=LevelNumber*2;
if (Screen[Alien[Aliens][1]][Alien[Aliens][2]]!=0) {direction--;continue;}
gotogxy(Alien[Aliens][1],Alien[Aliens][2]);
wrtchr(Alien[Aliens][0]);
Screen[Alien[Aliens][1]][Alien[Aliens][2]]=Aliens;Aliens++;
}

Aliens=Q1+Q2+Q3+Q4;ItemRandom=0xFAU;}
set_sprite_data(0x00, 16, Man_sprite);
for (direction=1;direction!=14;direction++)
set_sprite_tile(direction,12);
set_sprite_tile (0x00, ModeS_ID=0x00);ManX=87;ManY=91;
move_sprite(0,ManX,ManY);
for (direction=0;direction!=15;direction++){
move_sprite(direction+1,0,0);
Bullet[direction][0]=Bullet[direction][1]=Bullet[direction][2]=Bullet[direction][3]=0;
}
count=AlienNo=KilledAliens=DeltaBX=ModeID=ModeID2=BlackCycle=SoundFlag=LevelFlag=Alien[41][3]=0;
DeltaBY=4;AlienNo++;fadein(4);SHOW_SPRITES;OBP0_REG = OBP1_REG = 0xE4U;
}

void main() {
BGP_REG = OBP0_REG = OBP1_REG = GameBoyMode = 0x00U;
if(_cpu==CGB_TYPE) {    // Color gameboy detected
    /* Transfer color palette */
    set_bkg_palette( 0, 1, &background_palette[8] );
    set_sprite_palette( 0, 1, &sprites_palette[0] );GameBoyMode=CGB_TYPE;}
 move_bkg(0,0);
SPRITES_8x8;SHOW_BKG;DISPLAY_ON;HIDE_WIN;HIDE_SPRITES;

NR14_REG = 0x80U;

//Title Logo.
#ifdef CONSOLEFEVER
disable_interrupts();
set_bkg_data(0,0xA1,image_data);
for (Q1=0;Q1!=20;Q1++) for (Q2=0;Q2!=18;Q2++)
set_bkg_tiles(Q1,Q2,1,1,image_tiles);
set_bkg_tiles(0,8,20,1,console_tiles);
SHOW_BKG;fadein(0);
sound2(frequencies[D4],frequencies[E4]);
delay(1400);fadeout();
#endif

// Game Main cycle
for(;;){disable_interrupts();
 set_bkg_data(0,0xA1,image_data);
 set_bkg_tiles(0,0,20,18,image_tiles);
Level=1;Lives=5;Weapon=12;
Score=HighScore;CalculateScore();
for (Q1=0;Q1!=5;Q1++) Scores[Q1]+=0x87;
set_bkg_tiles(13,13,5,1,(unsigned char *) Scores);SHOW_BKG;
fadein(4);

for (count=0;;count++){
   sound2( frequencies[TitleMusic[count]],frequencies[TitleMusic[count]+12]);
if (TitleMusic[count]==END) count=0;
delay(97);
if (joypad() & J_START) break;}

mode(M_DRAWING|M_NO_SCROLL);enable_interrupts();
initrand(count);Score=0;DrawLevel(Level);

for (;;){set_sprite_tile (0x00, ModeS_ID+ModeID); // Game Here
BlackPCycle();
move_sprite(0,ManX,ManY);

if (Alien[AlienNo][3]!=0) {Ax=Alien[AlienNo][1];Ay=Alien[AlienNo][2];
if ((Alien[AlienNo][1]*8)>ManX-8)
Alien[AlienNo][1]-=(Screen[Ax-1][Ay]==0);
 else Alien[AlienNo][1]+=(Screen[Ax+1][Ay]==0);
if ((Alien[AlienNo][2]*8)>ManY-8)
Alien[AlienNo][2]-=(Screen[Alien[AlienNo][1]][Alien[AlienNo][2]-1]==0);
else Alien[AlienNo][2]+=(Screen[Alien[AlienNo][1]][Alien[AlienNo][2]+1]==0);
if (Ax!=Alien[AlienNo][1] || Ay!=Alien[AlienNo][2]){
gotogxy(Ax,Ay);wrtchr(0x20U);Screen[Ax][Ay]=0;
gotogxy(Alien[AlienNo][1],Alien[AlienNo][2]);
wrtchr(Alien[AlienNo][0]);Screen[Alien[AlienNo][1]][Alien[AlienNo][2]]=AlienNo;}
}

Bullets();
direction=joypad();
if (direction&J_A) {
if (direction&J_UP)   {ManY-=2;ModeS_ID=6;}
if (direction&J_DOWN) {ManY+=2;ModeS_ID=9;}
if (direction&J_LEFT) {ManX-=2;ModeS_ID=3;set_sprite_prop(0,S_FLIPX|S_PRIORITY);}   // Control
if (direction&J_RIGHT){ManX+=2;ModeS_ID=3;set_sprite_prop(0,S_PRIORITY);}
}
else {
if (direction&J_UP)   {ManY-=2;ModeS_ID=6;DeltaBX=0;DeltaBY=-4;}
if (direction&J_DOWN) {ManY+=2;ModeS_ID=9;DeltaBX=0;DeltaBY=4;}
if (direction&J_LEFT) {ManX-=2;ModeS_ID=3;set_sprite_prop(0,S_FLIPX|S_PRIORITY);DeltaBX=-4;}
if (direction&J_RIGHT) {ManX+=2;ModeS_ID=3;set_sprite_prop(0,S_PRIORITY);DeltaBX=4;}
if (direction==J_LEFT || direction==J_RIGHT) DeltaBY=0;}

//if (direction&J_B) {}
if (!(direction&(J_LEFT|J_RIGHT|J_UP|J_DOWN))) ModeS_ID=0;

if (direction&J_START) {NR42_REG=0;sound2(frequencies[D2],frequencies[C2]);delay(350);while(!(joypad()&J_START));
sound2(frequencies[E2],frequencies[D2]);delay(250);}

if (ManX<0x06U || ManX>0x9fU || ManY<0x0CU || ManY>0x97U) {if (++Level==32) {draw_image(end_image_data);delay(8000);break;} else DrawLevel(Level);continue;}

//collision detection for dead.
Q1=getpix(ManX,ManY-9);Q2=getpix(ManX-2,ManY-16);
Q3=getpix(ManX-8,ManY-9);Q4=getpix(ManX-6,ManY-16);
if (Q1>1 || Q2>1 || Q3>1 || Q4>1) { //*dead */
set_sprite_tile(0,14);for (Q1=0;Q1!=14;Q1++){
                    NR52_REG = 0x8FU; /* make sure sound is enabled */
                    NR50_REG = 0xFFU; /* Set Maximum volume for dead */
                    NR51_REG = 0xFFU; /* send sound to left and rignt */
                    NR44_REG = 0x80U;NR41_REG = 63U;
                    NR42_REG = 245U;NR43_REG = 51U;
if (++count==13) count=0;Bullets();SoundFlag=0;BlackPCycle();Bullet[count][0]=Bullet[count][1]=0;}
for (count=1;count<50;count++) {BlackPCycle();wait_vbl_done();}
Lives--;Weapon=12;NR42_REG = NR43_REG = NR44_REG = 0;if (Lives==0) break;else {DrawLevel(Level);continue;}

                 }

if (Q1==1 || Q2==1 || Q3==1 || Q4==1) {
sound2 (frequencies[G2-(Alien[41][3]-0x5AU)],frequencies[E2-(Alien[41][3]-0x5A)]);
switch(Alien[41][3]) {
case 0x57U: if (Weapon==15) Score+=12;else Weapon=15;break;  // Suitcase
case 0x58U: Score+=88; break;    // Vase
case 0x59U: Score+=110;break;   // Cup
case 0x5AU: Score+=100;break;  // Pear
case 0x5BU: Score+=150;break; // Crystal
case 0x5CU: Lives++;break;   // Man
case 0x5DU: if (Weapon==12) Score+=160; else Weapon=12;break; // Pack
case 0x5EU: if (Weapon==15) Score+=12;else Weapon=15;break;  // Suitcase
case 0x5FU: Score+=85;break;  // Apple
case 0x60U: Score+=180;break; // Bell
default: break;}

Screen[Alien[41][1]][Alien[41][2]]=Alien[41][3]=0;
gotogxy(Alien[41][1],Alien[41][2]);wrtchr(0x20);
ItemRandom--;}  // Took Something

if (KilledAliens==Aliens) {LevelFlag=1;KilledAliens++; //Set LevelComp flag
if (Alien[41][3]!=0)   // Remove the bonus
{Screen[Alien[41][1]][Alien[41][2]]=0;
gotogxy(Alien[41][1],Alien[41][2]);wrtchr(0x20);}}

if (LevelFlag==1) {
color(WHITE,WHITE,SOLID);
switch (rand()%4){

case 1:box(0,59,1,83,M_FILL);break;
case 2:box(158,59,159,83,M_FILL);break;
case 3:box(68,0,92,1,M_FILL);break;
default:box(68,142,92,143,M_FILL);break;
  }
color(DKGREY,WHITE,SOLID);LevelFlag++;
 }
if ((rand()%ItemRandom+Level)>0xFAU && Alien[41][3]==0 && LevelFlag==0) {//Bonuses
Alien[41][1]=rand()%17+2;Alien[41][2]=rand()%14+2;
if (Screen[Alien[41][1]][Alien[41][2]]==0) {
Alien[41][3]=0x57U+rand()%10;
Screen[Alien[41][1]][Alien[41][2]]=Alien[41][3];
color(LTGREY,0,SOLID);
gotogxy(Alien[41][1],Alien[41][2]);wrtchr(Alien[41][3]);
color(DKGREY,WHITE,SOLID);
  }
 }

if (++ModeID2==40) {if (++ModeID==3) ModeID=0; ModeID2=0;}
if (++count==13) count=0;
if (++AlienNo==Aliens+1) AlienNo=1;

Bullet[count][0]=ManX;
Bullet[count][1]=ManY;
Bullet[count][2]=DeltaBX;
Bullet[count][3]=DeltaBY;

 }
//Game Over sequence here
HIDE_SPRITES;fadeout();color(WHITE,WHITE,SOLID);
box(0,0,159,143,M_FILL);
color (LTGREY,DKGREY,SOLID);
gotogxy(5,5);gprint("Game Over");
color(DKGREY,WHITE,SOLID);CalculateScore();
gotogxy(4,9);gprint("Score ");gprint(Scores);
if (Score>HighScore) {HighScore=Score;
color(LTGREY,BLACK,SOLID);gotogxy(4,12);gprint("New HiScore");}
fadein(4);

for (count=0;EndMusic[count]!=END;count++){
                 if (EndMusic[count]!=PAUSE) {
   sound2( frequencies[EndMusic[count]],frequencies[EndMusic[count]+12]);
               }
             delay(120);
if (joypad() & (J_START|J_SELECT|J_B|J_A)) break;}
fadeout();
}

}
