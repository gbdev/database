#include <gb.h>

#define	MAX_NUM		15
#define	MAX_SET		2
#define	MAX_LEN		127

UBYTE header_nvm[MAX_NUM];
UBYTE nvm[MAX_NUM][MAX_SET*2][MAX_LEN];

/* EOF */
