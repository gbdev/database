# IR remote controller for GBC
Using Gameboy color IR feature !

## How to use

### 1. Start
<table>
<tr>
<td><img src="./pics/gb-rem.jpg" width="50%"></td>
</tr>
</table>
This is a Start Display. Point finger-cursor to each button on GBC display and press A button of also GBC, remote control signal will be generated. Depend on receiver side... Aprox 2-3meters will be reached. Usually no problem in Japanese situation :-< You pressed B button of GBC... Encoded data will be genrated...


### 2. Capture signal

<table>
<tr>
<td><img src="./pics/gb-rem2.jpg" width="50%"></td>
</tr>
</table>
For learning remote control signal. Point finger-cursor to target button on GBC display and click A button of GBC and then transmit signal to window of GBC for Ir. 


### 3. Display captured signal

<table>
<tr>
<td><img src="./pics/gb-rem3.jpg" width="50%"></td>
</tr>
</table>
Display learned signal. Raw data is displayed. Transmitting will be generated if you press [Send to PC] with A button of GBC by 9600bps None parity 1 Stopbit in Report format. Also C source list for GB-fREMe with B button pressed. 


### 4. Display encoded data

<table>
<tr>
<td><img src="./pics/gb-rem4.jpg" width="50%"></td>
</tr>
</table>
Display encoded data. Also as same as DUMP mode, A button transmits encoded data. B button transmits GB-fREMe format with encoded data. 


## Report

<table>
<tr>
<td><img src="./pics/teraraw.jpg"></td>
</tr>
</table>
Since Build20000318 It is possible to generate signal from Ir port of GBC. Save time to create report with this feature. In currently..."Ir tower" as LEGO MindStorms is used. Start terminal software of Windows, type any character in terminal sotware(Image shows 'a' key had been pressed...)then you press [Send to PC] button of GBC. Also IrDA has been supported. You don't have to type any character, if you used in IrDA. 


## How it works

### Ir port of GBC
GBC has a very primitive Ir port. Receiving device is connected to input port. Transmitting device is connected to output port. Ir receiving signal will be appeared at input port. Other one output signal will be decided corresponding either 0 or 1. OK, How to receive in actually... Monitoring at input port in periodically.(Usually, we say sampling). Ohter hand output means oppsite working of this. Output in periodically at same timing.

### How to decide sampling rate of Ir
Sampling means to check signal exsiting in periodically. Therefore, Short sampling timing means to obtain a precious data, however we need much more capacity for straging(e.g. RAM). We can not set up high sampling rate in infinity. We have to trade off presiousion and strage. Also we need double speed at sampleing for target frequency. It has been called sampling theory. In generally, normal remote controller is using Pulse Position Modulation, sampleing rate as 0 = 0.56/1.125[msec], 1 = 0.56/2.25[msec]. In stand of sampling theory, 0.56msec is minimum frequency. Therefore, we need to speed over 0.28[msec]. And we have to consider CPU processing speed. OK, I don't have to say... It is imposiible to set a sampling speed more than CPU processing speed. OK, I can decide sampling rate as 0.1[msec]. It is sense of enginering, to decided the value in quickly.

### Signal captureing
OK, we could decide sampling rate. Let's condsider data captureing in practically. Duration of signal will be realized in total number of each pulse length. In this case, duration will be reached to 75[msec]. Simple answer 75[msec] / 0.1[msec] = 750. If it puts on 0/1 to 1byte...Strage will be needed 750bytes. In fact total RAM size of GB is 8KB(8192byte), we can realize only 10 actions of remote controller. Not smart... This technic.

### Data How to strage
We should focus on data structure which is created either 0 or 1. We have to consider in case of leader-code part in Fig. Leader-code is 13.5[msec] (9[msec] + 4.5[msec]). In case of Dum sampling in 0.1[msec], 13.5[msec] / 0.1[msec] = 135bytes. Strage image is "111111...11(90byte), 00000...00(45byte). OK, You found out ?? If start value is 1 in absolutely, we can focus on value of ()... 90byte and 45byte will be data value. This procedure created data value from 135byte to 2byte. Data has been reduced in dramatically. OK, we can say "we have to record on only trigger (from 0 to 1 or 1 to 0) will be occured." in generally. OK, as same asH-90, L-90 focus on custom code H-5, L-5, H-5, L-15...therefore number of trigger should be counted... total 67byte. 

### Data encoding
OK, we should step in to next stage. Custom code is defined in each equipment. That means if you decied the equipment, custom code is also defined in automatically. Therefore, we have to consider only data code. (Final data code is one's complementary byte. we can calucuate.). In this sense, Remote controller code(except data code) is completely same if equipment as same. Remote control signal is serial data in basically. In this case, we can expand 4byte. And differential is only one byte in actually. Including leader-code and header-byte, it will be enough 10byte for reproducing. Encoding will be started from PPM bit stream. PPM recognize either 0 or 1 by length of l-level of signal. In case of custom code, to apply this rule, this signal means 01100111. Addtionally, H-5/L-5 means 0, H-5/L-15 means 1 are fixed. However, in real world, deviation will be happend... +/- 1 error must be occured. We have to consider this fact.

### Is it easy ?
I summarized how to sample and encode... I think you feel easy to implement. We were in trouble in each case.... Especially, encoding is qutite tough topic for us. Encoding routine has been developed by Oda in firtst time. In currently, Mr.N.U. optimized (as quite good job!!).


# License
Copyright (c) Osamu OHASHI  
Distributed under the MIT License either version 1.0 or any later version. 

