/****************************************************************************
 *	GB-REM																	*
 *	2000/10																	*
 ****************************************************************************/
#include <gb.h>
#include <stdlib.h>
#include "bkg.h"
#include "obj.h"

/* definition */
#define MODE_PLAY	0
#define MODE_REC	1
#define MODE_DUMP	2
#define MODE_ENCODE	3
#define FLAG_OFF	0
#define FLAG_ON		1
#define	MAX_NUM		15
#define	MAX_SET		2
#define	MAX_LEN		127
#define	MAX_BTN_X	5
#define	MAX_BTN_Y	3
#define HT			0x09
#define CR			0x0d
#define LF			0x0a
#define SP			0x20
#define CM			0x2c

/* ir comm driver */
//#define IR_COMM_SND	ir_snd	/* for Ir Tower of MindStorm (2400,odd) */
#define IR_COMM_SND	irda_snd	/* Irda SIR 1.0 */

/* extern */
extern UBYTE header_nvm[MAX_NUM];
extern UBYTE nvm[MAX_NUM][MAX_SET*2][MAX_LEN];
extern UBYTE ram[MAX_SET*2][MAX_LEN];

/* character data */
#include "bkg.c"
#include "obj.c"
UWORD bkg_palette[] = {
	bkgCGBPal0c0, bkgCGBPal0c1, bkgCGBPal0c2, bkgCGBPal0c3,
	bkgCGBPal1c0, bkgCGBPal1c1, bkgCGBPal1c2, bkgCGBPal1c3,
	bkgCGBPal2c0, bkgCGBPal2c1, bkgCGBPal2c2, bkgCGBPal2c3
};
UWORD obj_palette[] = {
	objCGBPal0c0, objCGBPal0c1, objCGBPal0c2, objCGBPal0c3
};

/* tile map data */
#include "form_play.c"
#include "form_rec.c"
#include "form_dump.c"
#include "form_encode.c"
unsigned char *form[] = { form_play, form_rec, form_dump, form_encode };

/* button */
unsigned char btn_break1[] = { 0x10,0x11,0x12,0x13 };
unsigned char btn_break2[] = { 0x14,0x15,0x16,0x17 };
unsigned char btn_press1[] = { 0x18,0x19,0x1A,0x1B };
unsigned char btn_press2[] = { 0x1C,0x1D,0x1E,0x1F };
unsigned char btn_attrb0[] = { 0,0,0,0,0,0,0,0,0 };
unsigned char btn_attrb1[] = { 1,1,1,1,1,1,1,1,1 };
unsigned char btn_attrb2[] = { 2,2,2,2,2,2,2,2,2 };

/* message */
unsigned char msg_clear[] = { "CLEAR NVRAM DATA" };
unsigned char msg_nogbc[] = { "ONLY GBC!!" };
unsigned char msg_noupdn[] = { "< >" };
unsigned char msg_side[][5] = { "HIGH","LOW" };
unsigned char msg_carrier[] = { "Carrier =   KHz" };
unsigned char msg_carrier_frq[][3] = { "--","33","35","38","40","44","48","52" };
unsigned char msg_pattern[][8] = { "1      ","1111...","1222...","1212..." };
unsigned char msg_elase[] = { "  " };
unsigned char msg_page[][6] = { "Page1","Page2" };
unsigned char msg_leader[] = { "Leader :  " };
unsigned char msg_trailer[] = { "Trailer:  " };
unsigned char msg_data0[] = { "Data-0 :  " };
unsigned char msg_data1[] = { "Data-1 :  " };
unsigned char msg_length[] = { "Length :  " };
unsigned char msg_code[] = { "Code:" };
unsigned char msg_soft[] = { "GB-REM" };
unsigned char msg_version[] = { "2000/10/26" };
unsigned char msg_credit[] = { "by TeamKNOx" };
unsigned char msg_elase2[] = { "                  " };
unsigned char msg_send_off[] = { "@ Send to PC" };
unsigned char msg_send_on[]	 = { "* Sending..." };
unsigned char msg_samp[] = { "10" };

/* send	 message for GB-fREMe */
unsigned char msg_raw_freme[]	= { "For GB-fREMe(raw data version)" };
unsigned char msg_enc_freme[]	= { "For GB-fREMe(encode data version)" };
unsigned char msg_button[]		= { "BUTTON " };
unsigned char msg_0x[]			= { "0x" };
unsigned char msg_0[]			= { "0" };
unsigned char msg_brace1[]		= { "{ " };
unsigned char msg_brace2[]		= { " }" };
unsigned char msg_type[]		= { "#define TYPE_PAGEx      " };
unsigned char msg_header[]		= { "#define HEADER_PAGEx    " };
unsigned char msg_leader_h[]	= { "#define LEADER_H_PAGEx  " };
unsigned char msg_leader_l[]	= { "#define LEADER_L_PAGEx  " };
unsigned char msg_trailer_h[]	= { "#define TRAILER_H_PAGEx " };
unsigned char msg_trailer_l[]	= { "#define TRAILER_L_PAGEx " };
unsigned char msg_data_0[]		= { "#define DATA_0_PAGEx    " };
unsigned char msg_data_1[]		= { "#define DATA_1_PAGEx    " };
unsigned char msg_length_[]		= { "#define LENGTH_PAGEx    " };
unsigned char msg_ppm_type[][9]	= { "PPM_HIGH","PPM_LOW" };
unsigned char msg_comment[][16]	= { " /* PAGEx_A */",
									" /* PAGEx_B */",
									" /* PAGEx_U */",
									" /* PAGEx_D */",
									" /* PAGEx_R */",
									"  /* PAGEx_L */"};
/* work area */
UBYTE cursor_x;
UBYTE cursor_y;
UBYTE cursor_max_x;
UBYTE cursor_max_y;
UBYTE cursor_off_x;
UBYTE cursor_off_y;
UBYTE cursor_add_x;
UBYTE cursor_add_y;
UBYTE cursor_chain;
UBYTE key;
UBYTE keycode_flag;
UBYTE keycode_pre;
UBYTE keycode;
UBYTE carrier;
UBYTE pattern;
UBYTE header;
UBYTE leader, trailer;
UBYTE data0, data1;
UBYTE border;
UBYTE code[16];			/* byte data */
UBYTE code_length;		/* number of bit */
UBYTE speed;
UBYTE parity;

/* functoins */
void set_bkg_attribute( UBYTE x, UBYTE y, UBYTE sx, UBYTE sy, unsigned char *p )
{
	if( _cpu == CGB_TYPE ) {
		VBK_REG = 1;
		set_bkg_tiles( x, y, sx, sy, p );
		VBK_REG = 0;
	}
}

void init_character()
{
	set_bkg_data( 0, 128, bkg );
	set_sprite_data( 0, 4, obj );
	set_bkg_palette( 0, 3, bkg_palette );
	set_sprite_tile( 0, 0 );
	set_sprite_tile( 1, 1 );
	set_sprite_tile( 2, 2 );
	set_sprite_tile( 3, 3 );
	set_sprite_palette( 0, 1, obj_palette );
	set_sprite_prop( 0, 0 );
	set_sprite_prop( 1, 0 );
	set_sprite_prop( 2, 0 );
	set_sprite_prop( 3, 0 );
	SHOW_BKG;
	SHOW_SPRITES;
	DISPLAY_ON;
	enable_interrupts();
}

void init_cursor( max_x, max_y, off_x, off_y, add_x, add_y, chain )
{
	cursor_max_x = max_x;
	cursor_max_y = max_y;
	cursor_off_x = off_x;
	cursor_off_y = off_y;
	cursor_add_x = add_x;
	cursor_add_y = add_y;
	cursor_chain = chain;
	keycode_pre = 0;
	keycode = 0;
}

void move_cursor()
{
	UBYTE x, y;

	key = joypad();
	if( keycode_flag == FLAG_OFF ) {
		if( key & (J_UP|J_DOWN|J_LEFT|J_RIGHT|J_A|J_B) ) {
			keycode_flag = FLAG_ON;
		}
		if( key & J_UP ) {
			if( cursor_y > 0 )				   cursor_y--;
		} else if( key & J_DOWN ) {
			if( cursor_y < (cursor_max_y-1) )  cursor_y++;
		} else if( key & J_LEFT ) {
			if( cursor_x > 0 ) {			   cursor_x--;
			} else if( cursor_chain ) {
				cursor_x = cursor_max_x-1;
				if( cursor_y == 1 ) {
					cursor_y = cursor_max_y-1;
				} else {
					cursor_y--;
				}
			}
		} else if( key & J_RIGHT ) {
			if( cursor_x < (cursor_max_x-1) ) { cursor_x++;
			} else if( cursor_chain ) {
				cursor_x = 0;
				if( cursor_y == cursor_max_y-1 ) {
					cursor_y = 1;
				} else {
					cursor_y++;
				}
			}
		} else if( key & J_A ) {
			keycode_pre |= J_A;
		} else if( key & J_B ) {
			keycode_pre |= J_B;
		}
	} else {
		if( !(key & (J_UP|J_DOWN|J_LEFT|J_RIGHT|J_A|J_B)) ) {
			keycode_flag = FLAG_OFF;
		}
		if( keycode_pre & J_A ) {
			if( !(key & J_A) ) {
				keycode_pre &= ~J_A;
				keycode |= J_A;
			}
		}
		if( keycode_pre & J_B) {
			if( !(key & J_B) ) {
				keycode_pre &= ~J_B;
				keycode |= J_B;
			}
		}
	}
	x = cursor_off_x + cursor_add_x * cursor_x;
	y = cursor_off_y + cursor_add_y * cursor_y;
	move_sprite( 0, x,	 y	 );
	move_sprite( 1, x,	 y+8 );
	move_sprite( 2, x+8, y	 );
	move_sprite( 3, x+8, y+8 );
}

void press_button( UBYTE x, UBYTE y )
{
	set_bkg_tiles( x,	y,	 3, 1, btn_press1 );
	set_bkg_tiles( x,	y+1, 1, 1, &btn_press1[3] );
	set_bkg_tiles( x+2, y+1, 1, 1, btn_press2 );
	set_bkg_tiles( x,	y+2, 3, 1, &btn_press2[1] );
}

void break_button( UBYTE x, UBYTE y )
{
	set_bkg_tiles( x,	y,	 3, 1, btn_break1 );
	set_bkg_tiles( x,	y+1, 1, 1, &btn_break1[3] );
	set_bkg_tiles( x+2, y+1, 1, 1, btn_break2 );
	set_bkg_tiles( x,	y+2, 3, 1, &btn_break2[1] );
}

void disp_value( UWORD d, UWORD e, UBYTE c, UBYTE x, UBYTE y )
{
  UWORD m;
  UBYTE i, n;
  unsigned char data[6];

  m = 1;
  if ( c > 1 ) {
	for( i=1; i<c; i++ ) {
	  m = m * e;
	}
  }
  for( i=0; i<c; i++ ) {
	n = d / m; d = d % m; m = m / e;
	data[i] = '0' + n;	  /* '0' - '9' */
	if( data[i] > '9' )	 data[i] += 7;
  }
  set_bkg_tiles( x, y, c, 1, data );
}

UBYTE value_asc( UBYTE data )
{
  UBYTE asc;
  asc = '0' + data;	   /* '0' - '9' */
  if( asc > '9' )  asc += 7;
  return( asc );
}

void snd_msg( unsigned char *msg )
{
  while ( *msg ) {
	IR_COMM_SND( *msg );
	msg++;
  }
}

void save_remo_data( UBYTE no )
{
	UBYTE i, j;

	for( i=0; i<MAX_SET*2; i++ ) {
		for( j=0; j<MAX_LEN; j++ ) {
			nvm[no][i][j] = ram[i][j];
		}
	}
}

void load_remo_data( UBYTE no )
{
	UBYTE i, j;

	for( i=0; i<MAX_SET*2; i++ ) {
		for( j=0; j<MAX_LEN; j++ ) {
		   ram[i][j] = nvm[no][i][j];
		}
	}
}

void save_header_data( UBYTE no )
{
	header_nvm[no] = header;
}

void load_header_data( UBYTE no )
{
	header = header_nvm[no];
}

UBYTE select_mode( UBYTE mode )
{
	UBYTE save_x;

	save_x = cursor_x;
	init_cursor( 4, 2, 22, 28, 40, 0, 0 );
	cursor_x = mode;
	while( cursor_y == 0 ) {
		move_cursor();
		if( keycode & J_A ) {
			keycode &= ~J_A;
			if( mode != cursor_x ) {
				mode = cursor_x;
				cursor_x = save_x;
				return( mode );
			}
		}
		if( mode < MODE_DUMP ) {
			if( key & J_SELECT ) {
				while( key & J_SELECT ) {
					move_cursor();
					set_bkg_tiles( 1, 16, 7, 1, msg_soft );
					set_bkg_tiles( 9, 16, 10, 1, msg_version );
				}
				set_bkg_tiles( 1, 16, 18, 1, msg_elase2 );
			} else if( key & J_START ) {
				while( key & J_START ) {
					move_cursor();
					set_bkg_tiles( 4, 16, 11, 1, msg_credit );
				}
				set_bkg_tiles( 1, 16, 18, 1, msg_elase2 );
			}
		}
	}
	cursor_x = save_x;
	return( mode );
}

void clear_button_attribute()
{
	UBYTE x, y;

	for( y=0; y<MAX_BTN_Y; y++ ) {
		for( x=0; x<MAX_BTN_X; x++ ) {
			 set_bkg_attribute( x*3+2, y*4+4, 3, 3, btn_attrb0 );
		}
	}
}

void set_button_attribute()
{
	UBYTE x, y;

	for( y=0; y<MAX_BTN_Y; y++ ) {
		for( x=0; x<MAX_BTN_X; x++ ) {
			if( nvm[y*MAX_BTN_X+x][0][0] == 0 ) {
				set_bkg_attribute( x*3+2, y*4+4, 3, 3, btn_attrb1 );
			} else {
				set_bkg_attribute( x*3+2, y*4+4, 3, 3, btn_attrb2 );
			}
		}
	}
}

void encode( UBYTE no, UBYTE set, UBYTE side )
{
	UBYTE n, i;
	UBYTE code_top = 1;

	i = set * 2 + side;

	leader = trailer = data0 = data1 = code_length = 0;
	for( n=0; n<16; n++ ) {
		code[n] = 0;
	}

	if( nvm[no][0][0] ) {
		leader = nvm[no][i][0];
	} else {
		return;
	}

	data0 = 0xFF;
	data1 = 0x00;
	n = 1;
	while( nvm[no][i][n+1] ){
		if( nvm[no][i][n] < data0 ){		/*	min. of data0 */
			data0 = nvm[no][i][n];
		}
		if( nvm[no][i][n] > data1 ){		/*	max. of data1 */
			data1 = nvm[no][i][n];
		}
		n ++;
	}

	trailer = nvm[no][i][n];
	if( i > 1 ) {
		if( nvm[no][i-2][n+1]>0 ) {
			leader = 0;
			code_top = 0;
		}
	}

	border = (data1 + data0) / 2;

	if( (data1 - data0) <= (data1 / 3) ) {	/* case of timing pulse */
		data0 = border;
		border = data1;
		data1 = data0;
	}

	code_length = n-1;

	for( n=0; n<code_length; n++ ) {		/* encode main */
		code[n/8] = code[n/8] >> 1;
		if( nvm[no][i][n+code_top] > border ){
			code[n/8] |= 0x80;
		}
	}
	if ( code_length % 8 ) {
		n--;
		code[n/8] = code[n/8] >> (8-code_length%8);
	}
}

void decode( UBYTE set, UBYTE side )
{
	UBYTE i, n;
	UBYTE code_top = 1;

	i = set * 2 + side;

	if( leader == 0 ) {
		code_top = 0;
	} else {
		ram[i][0] = leader;
	}
	for( n=0; n<code_length; n++ ) {		/* decode main */
		if( code[n/8] & 0x01 ) {
			ram[i][n+code_top] = data1;
		} else {
			ram[i][n+code_top] = data0;
		}
		code[n/8] = code[n/8] >> 1;
	}
	n++;
	ram[i][n+code_top] = trailer;
	n++;
	ram[i][n+code_top] = 0;
}

void encode2decode( UBYTE no )
{
	UBYTE set, side;

	for ( set=0; set<2; set++ ) {
		for ( side=0; side<2; side++ ) {
			encode( no, set, side );
			decode( set, side );
		}
	}
}
void send_raw_freme()
{
	UBYTE i, j, no;
//"For GB-fREMe(raw data version)"
	snd_msg( msg_raw_freme );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//Header
	snd_msg( msg_header );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( header_nvm[0]>>4&0x0F ) );
	IR_COMM_SND( value_asc( header_nvm[0]&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//Raw data
	for ( no=0; no<6; no++) {
		snd_msg( msg_button );
		IR_COMM_SND( no + 0x41 );
		IR_COMM_SND( CR );
		IR_COMM_SND( LF );
		for ( i=0; i<4; i++ ) {
			snd_msg( msg_brace1 );
			j=0;
			while ( nvm[no][i][j] ) {
				snd_msg( msg_0x );
				IR_COMM_SND( value_asc( nvm[no][i][j]>>4&0x0F ) );
				IR_COMM_SND( value_asc( nvm[no][i][j]&0x0F ) );
				IR_COMM_SND( CM );
				j++;
			}
			snd_msg( msg_0 );
			snd_msg( msg_brace2 );
			if( i < 3 ) IR_COMM_SND( CM );
			IR_COMM_SND( CR );
			IR_COMM_SND( LF );
		}
		IR_COMM_SND( CR );
		IR_COMM_SND( LF );
	}
}

void send_enc_freme()
{
	UBYTE i, j, no;
	UBYTE leader_h, leader_l, trailer_h, trailer_l;
	UBYTE type, data_0, data_1, length, rem_code[32];
	UBYTE wcode = 1;

	encode( 0, 0, 0 );
	leader_h = leader;
	trailer_h = trailer;
	length = code_length;
	if( data0 != data1 ) {
		type = 0;
		data_0 = data0;
		data_1 = data1;
	}
	
	encode( 0, 0, 1 );
	leader_l = leader;
	trailer_l = trailer;
	if( data0 != data1 ) {
		type = 1;
		data_0 = data0;
		data_1 = data1;
	}

//"For GB-fREMe(enc data version)"
	snd_msg( msg_enc_freme );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );

//type
	snd_msg( msg_type );
	snd_msg( msg_ppm_type[type] );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//Header
	snd_msg( msg_header );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( header_nvm[0]>>4&0x0F ) );
	IR_COMM_SND( value_asc( header_nvm[0]&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//leader_h
	snd_msg( msg_leader_h );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( leader_h>>4&0x0F ) );
	IR_COMM_SND( value_asc( leader_h&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//leader_l
	snd_msg( msg_leader_l );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( leader_l>>4&0x0F ) );
	IR_COMM_SND( value_asc( leader_l&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//trailer_h
	snd_msg( msg_trailer_h );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( trailer_h>>4&0x0F ) );
	IR_COMM_SND( value_asc( trailer_h&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//trailer_l
	snd_msg( msg_trailer_l );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( trailer_l>>4&0x0F ) );
	IR_COMM_SND( value_asc( trailer_l&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//data_0
	snd_msg( msg_data_0 );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( data_0>>4&0x0F ) );
	IR_COMM_SND( value_asc( data_0&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//data_1
	snd_msg( msg_data_1 );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( data_1>>4&0x0F ) );
	IR_COMM_SND( value_asc( data_1&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
//length
	snd_msg( msg_length_ );
	snd_msg( msg_0x );
	IR_COMM_SND( value_asc( length>>4&0x0F ) );
	IR_COMM_SND( value_asc( length&0x0F ) );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );

//code
	for( no=0; no<6; no++ ) {
		if( type ) {
			encode( no, 0, 1 );
		} else encode( no, 0, 0 );
		i = 0;
		for( j=0; j<((length+7)/8); j++ ) {
			rem_code[i] = code[j];
			i++;
		}
		if( (header_nvm[0]&0x03)==0x03 ) {
			if( type ) {
				encode( no, 1, 1 );
			} else encode( no, 1, 0 );
			for( j=0; j<((length+7)/8); j++ ) {
				rem_code[i] = code[j];
				i++;
			}
			wcode = 2;
		}
		snd_msg( msg_brace1 );
		for( j=0; j<((length+7)/8*wcode); j++ ) {
			snd_msg( msg_0x );
			IR_COMM_SND( value_asc( rem_code[j]>>4&0x0F ) );
			IR_COMM_SND( value_asc( rem_code[j]&0x0F ) );
			if( j < (((length+7)/8*wcode)-1) ) IR_COMM_SND( CM );
		}
		snd_msg( msg_brace2 );
		if( no < 5 ) IR_COMM_SND( CM );
		snd_msg( msg_comment[no] );
		IR_COMM_SND( CR );
		IR_COMM_SND( LF );
	}
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
}

void send_raw()
{
	UBYTE no, i, j;
	snd_msg( msg_carrier_frq[(header_nvm[0]&0x1C)>>2] );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	snd_msg( msg_samp );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	snd_msg( msg_pattern[(header_nvm[0]&0x03)] );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	IR_COMM_SND( CR );
	IR_COMM_SND( LF );
	for( no=0; no<15; no++ ) {
		for( i=0; i<4; i++ ) {
			j=0;
			while ( nvm[no][i][j] ) {
				IR_COMM_SND( value_asc( nvm[no][i][j]>>4&0x0F ) );
				IR_COMM_SND( value_asc( nvm[no][i][j]&0x0F ) );
				if( nvm[no][i][j+1] ) IR_COMM_SND( SP );
				else if( i < 3 ) IR_COMM_SND( CM );
				j++;
			}
		}
		IR_COMM_SND( CR );
		IR_COMM_SND( LF );
	}
}

void send_enc()
{
	UBYTE no, i, j;
	for( no=0; no<15; no++ ) {
		for ( i=0; i<4; i++ ) {
			encode( no, i/2, i%2 );
			j=0;
			while ( code[j] ) {
				IR_COMM_SND( value_asc( code[j]>>4&0x0F ) );
				IR_COMM_SND( value_asc( code[j]&0x0F ) );
				IR_COMM_SND( SP );
				j++;
			}
		}
		IR_COMM_SND( CR );
		IR_COMM_SND( LF );
	}
}

UBYTE mode_play( UBYTE mode )
{
	UBYTE no, i;
	UBYTE save_x;

	set_button_attribute();

	cursor_x = 0;
	while( 1 ) {
		mode = select_mode( mode );
		if( mode != MODE_PLAY )	 return( mode );
		init_cursor( MAX_BTN_X, MAX_BTN_Y+1, 30, 30, 24, 32, 1 );
		while( cursor_y > 0 ) {
			move_cursor();
			save_x = cursor_x;
			no = (cursor_y-1)*MAX_BTN_X+cursor_x;
			if( key&J_SELECT ) {
			  if( nvm[no][0][0] ) {
				load_header_data( no );
				carrier = header >> 2 & 0x07;
				set_bkg_tiles( 2, 16, 15, 1, msg_carrier );
				set_bkg_tiles( 12, 16, 2, 1, msg_carrier_frq[carrier] );
				keycode &= ~J_A;
				while( key&J_SELECT ){
					move_cursor();
					if( keycode & J_A ) {
						keycode &= ~J_A;
						if( carrier < 7 )	 carrier++;
						else				 carrier=0;
						set_bkg_tiles( 2, 16, 15, 1, msg_carrier );
						set_bkg_tiles( 12, 16, 2, 1, msg_carrier_frq[carrier] );
					}
				}
				set_bkg_tiles( 1, 16, 18, 1, msg_elase2 );
				header &= 0xE3;
				header |= carrier << 2;
				save_header_data( no );
			  }
			}
			if( ((keycode_pre&J_A)|(keycode_pre&J_B)) && (nvm[no][0][0]) ) {
				press_button( cursor_x*3+2, cursor_y*4 );
				if( keycode_pre&J_A ) {
					load_remo_data( no );
				} else if( keycode_pre&J_B ) {
					encode2decode( no );
				}
				load_header_data( no );
				pattern = header & 0x03;
				carrier = header >> 2 & 0x07;
				switch( carrier ) {
				  case 0:
					play_remcon00( 0 );
					break;
				  case 1:
					play_remcon33( 0 );
					break;
				  case 2:
					play_remcon35( 0 );
					break;
				  case 3:
					play_remcon38( 0 );
					break;
				  case 4:
					play_remcon40( 0 );
					break;
				  case 5:
					play_remcon44( 0 );
					break;
				  case 6:
					play_remcon48( 0 );
					break;
				  case 7:
					play_remcon52( 0 );
					break;
					}
				while( ((keycode_pre&J_A)|(keycode_pre&J_B)) && (pattern) ) {
					move_cursor();
					switch( pattern ) {
					  case 1:
						switch( carrier ) {
						  case 0:
							play_remcon00( 0 );
							break;
						  case 1:
							play_remcon33( 0 );
							break;
						  case 2:
							play_remcon35( 0 );
							break;
						  case 3:
							play_remcon38( 0 );
							break;
						  case 4:
							play_remcon40( 0 );
							break;
						  case 5:
							play_remcon44( 0 );
							break;
						  case 6:
							play_remcon48( 0 );
							break;
						  case 7:
							play_remcon52( 0 );
							break;
						}
						break;
					  case 2:
						switch( carrier ) {
						  case 0:
							play_remcon00( 1 );
							break;
						  case 1:
							play_remcon33( 1 );
							break;
						  case 2:
							play_remcon35( 1 );
							break;
						  case 3:
							play_remcon38( 1 );
							break;
						  case 4:
							play_remcon40( 1 );
							break;
						  case 5:
							play_remcon44( 1 );
							break;
						  case 6:
							play_remcon48( 1 );
							break;
						  case 7:
							play_remcon52( 1 );
							break;
						}
						break;
					  case 3:
						switch( carrier ) {
						  case 0:
							play_remcon00( 1 );
							play_remcon00( 0 );
							break;
						  case 1:
							play_remcon33( 1 );
							play_remcon33( 0 );
							break;
						  case 2:
							play_remcon35( 1 );
							play_remcon35( 0 );
							break;
						  case 3:
							play_remcon38( 1 );
							play_remcon38( 0 );
							break;
						  case 4:
							play_remcon40( 1 );
							play_remcon40( 0 );
							break;
						  case 5:
							play_remcon44( 1 );
							play_remcon44( 0 );
							break;
						  case 6:
							play_remcon48( 1 );
							play_remcon48( 0 );
							break;
						  case 7:
							play_remcon52( 1 );
							play_remcon52( 0 );
							break;
						}
						break;
					}
				}
				break_button( cursor_x*3+2, cursor_y*4 );
			}
		}
		cursor_x = save_x;
	}
	return( mode );
}

void set_header()
{

	UBYTE n;

	if(ram[2][0] == 0){
		header = 0x0C;		  /* pattern:1 */
	}else if(ram[2][2] == 0){
		header = 0x0E;		  /* pattern:1222... */
	}else{
		header = 0x0D;		  /* pattern:1111... */
		n = 1;
		while( ram[0][n] ){
			if( ram[0][n] > ram[2][n] ){
				if( (ram[0][n] - ram[2][n]) > 2 ){
					header = 0x0F;	  /* pattern:1212... */
				}
			}else if( (ram[2][n] - ram[0][n]) > 2 ){
				header = 0x0F;	  /* pattern:1212... */
			}
			if( ram[1][n] > ram[3][n] ){
				if( (ram[1][n] - ram[3][n]) > 2 ){
					header = 0x0F;	  /* pattern:1212... */
				}
			}else if( (ram[3][n] - ram[1][n]) > 2 ){
				header = 0x0F;	  /* pattern:1212... */
			}
			if( ram[2][n] == 0 ){
				header = 0x0E;		  /* pattern:1222... */
			}
			n ++;
		}
	}
}

/* Spec. of bit of header
�@�@�@�@�@�@  �@�@[pattern]
�@�@�@�@******00 : 1
�@�@�@�@******01 : 1111...
�@�@�@�@******10 : 1222...
�@�@�@�@******11 : 1212...
�@�@�@�@�@�@�@�@�@[carrier]
�@�@�@�@***000** : non
�@�@�@�@***001** : 33 KHz
�@�@�@�@***010** : 35 KHz
�@�@�@�@***011** : 38 KHz (default)
�@�@�@�@***100** : 40 KHz
�@�@�@�@***101** : 44 KHz
�@�@�@�@***110** : 48 KHz
�@�@�@�@***111** : 52 KHz
*/

UBYTE mode_rec( UBYTE mode )
{
	UBYTE no, i;
	UBYTE save_x;

	set_button_attribute();

	cursor_x = 0;
	while( 1 ) {
		mode = select_mode( mode );
		if( mode != MODE_REC )	return( mode );
		init_cursor( MAX_BTN_X, MAX_BTN_Y+1, 30, 30, 24, 32, 1 );
		while( cursor_y > 0 ) {
			move_cursor();
			save_x = cursor_x;
			no = (cursor_y-1)*MAX_BTN_X+cursor_x;
			if( keycode_pre & J_A ) {
				press_button( cursor_x*3+2, cursor_y*4 );
				rec_remcon();
				set_header();
				save_remo_data( no );
				save_header_data( no );
				set_button_attribute();
				break_button( cursor_x*3+2, cursor_y*4 );
				if( cursor_x < (cursor_max_x-1) ) { cursor_x++;
				} else {
					cursor_x = 0;
					if( cursor_y == cursor_max_y-1 ) {
						mode = MODE_DUMP;
						cursor_y = 2;
						return( mode );
					} else {
						cursor_y++;
					}
				}
			}
		}
		cursor_x = save_x;
	}
	return( mode );
}

void disp_dump( UBYTE no, UBYTE set, UBYTE side, UBYTE page )
{
	UBYTE f, i, j, x, y;
	unsigned char data;

	set_bkg_tiles( 1, 3, 3, 1, msg_noupdn );
	if ( no < MAX_NUM ) {
		data = no + 'A';
	} else {
		data = no - MAX_NUM + '1';
	}
	set_bkg_tiles( 2, 3, 1, 1, &data );
	data = set + '1';
	set_bkg_tiles( 5, 3, 1, 1, &data );
	set_bkg_tiles( 7, 3, 4, 1, msg_side[side]);
	set_bkg_tiles( 14, 3, 5, 1, msg_page[page]);

	if( nvm[no][0][0] ) {
		if( (set == 0) && (side == 0) && (page == 0) ){
			set_bkg_tiles( 2, 4, 2, 1, msg_carrier_frq[(header_nvm[no]&0x1C)>>2] );
			set_bkg_tiles( 4, 4, 3, 1, &msg_carrier[12] );
			set_bkg_tiles( 9, 4, 7, 1, msg_pattern[(header_nvm[no]&0x03)] );
			
		} else {
			set_bkg_tiles( 1, 4, 18, 1, msg_elase2 );
		}
	} else {
		set_bkg_tiles( 1, 4, 18, 1, msg_elase2 );
	}
	y = 5;
	x = 2;
	i = set * 2 + side;
	if( nvm[no][0][0] ) {
		f = FLAG_OFF;
	} else f = FLAG_ON;
	for( j=page*88; j<page*88+88; j++ ) {
		if( !nvm[no][i][j] ) {
			f = FLAG_ON;
		}
		if( f==FLAG_ON ) {
			set_bkg_tiles( x, y, 2, 1, msg_elase );
		} else {
			disp_value( nvm[no][i][j], 16, 2, x, y );
		}
		x ++;
		x ++;
		if( x > 17 ) {
			x = 2;
			y ++;
		}
	}
}

UBYTE mode_dump( UBYTE mode )
{
	UBYTE no, set, side, page;

	clear_button_attribute();
	set_bkg_tiles( 1, 3, 3, 1, msg_noupdn );
	set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
	no = 0; set = 0; side = 0; page = 0;

	disp_dump( no, set, side, page );
	cursor_x = 0;
	while( 1 ) {
		mode = select_mode( mode );
		if( mode != MODE_DUMP )	 return( mode );
		while( cursor_y > 0 ) {
			move_cursor();
			if ( cursor_x < 4 ) {
				init_cursor( 5, 3, 14, 44, 16, 0, 0 );
			}
			while( (cursor_y==1) && (cursor_x<4) ) {
				move_cursor();
				if( keycode & J_A ) {
					keycode &= ~J_A;
					switch( cursor_x ) {
					  case 0:
						if( no > 0 )  no--;
						else		  no=MAX_NUM-1;
						break;
					  case 1:
						if( no < MAX_NUM-1 ) no++;
						else		  no=0;
						break;
					  case 2:
						set = 1 - set;
						break;
					  case 3:
						side = 1 - side;
						break;
					}
					disp_dump( no, set, side, page );
				}
			}
			if ( ( cursor_y==1) && (cursor_x == 4) ) {
				init_cursor( 5, 3, 14, 44, 34, 0, 0 );
			}
			while( (cursor_y==1) && (cursor_x == 4) ) {
				move_cursor();
				if( keycode & J_A ) {
					keycode &= ~J_A;
					page = 1 - page;
					disp_dump( no, set, side, page );
				}
			}
			if ( cursor_y==2 ) {
				init_cursor( 1, 3, 15, 148, 0, 0, 0 );
			}
			while( cursor_y==2 ){
				move_cursor();
				if( keycode & J_A ) {
					keycode &= ~J_A;
					set_bkg_tiles( 1, 16, 12, 1, msg_send_on );
					send_raw();
					set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
				}
				if( keycode & J_B ) {
					keycode &= ~J_B;
					set_bkg_tiles( 1, 16, 12, 1, msg_send_on );
					send_raw_freme();
					set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
				}
			}
			set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
		}
	}
	return( mode );
}

void disp_encode( UBYTE no, UBYTE set, UBYTE side )
{
	UBYTE j, x, y;
	unsigned char data;

	set_bkg_tiles( 1, 3, 3, 1, msg_noupdn );
	if ( no < MAX_NUM ) {
		data = no + 'A';
	} else {
		data = no - MAX_NUM + '1';
	}
	set_bkg_tiles( 2, 3, 1, 1, &data );
	data = set + '1';
	set_bkg_tiles( 5, 3, 1, 1, &data );
	set_bkg_tiles( 7, 3, 4, 1, msg_side[side]);

	encode( no, set, side );
	disp_value( leader, 16, 2, 10, 5 );
	disp_value( trailer, 16, 2, 10, 6 );
	disp_value( data0, 16, 2, 10, 7 );
	disp_value( data1, 16, 2, 10, 8 );
	disp_value( code_length, 16, 2, 10, 9 );
	for ( y=12; y<16; y++ ) { 
		set_bkg_tiles( 1, y, 18, 1, msg_elase2 );
	}
	x = 4;
	y = 12;
	for( j=0; j<((code_length+7)/8); j++ ) {
		disp_value( code[j], 16, 2, x, y );
		x = x + 3;
		if( x > 13 ) {
		   x = 4;
		   y ++;
		}
	}
}

UBYTE mode_encode( UBYTE mode )
{
	UBYTE no, set, side, y;
	set_bkg_tiles( 1, 16, 12, 1, msg_send_off );

	clear_button_attribute();
	set_bkg_tiles( 1, 3, 3, 1, msg_noupdn );
	set_bkg_tiles( 2, 5, 10, 1, msg_leader );
	set_bkg_tiles( 2, 6, 10, 1, msg_trailer );
	set_bkg_tiles( 2, 7, 10, 1, msg_data0 );
	set_bkg_tiles( 2, 8, 10, 1, msg_data1 );
	set_bkg_tiles( 2, 9, 10, 1, msg_length );
	set_bkg_tiles( 2, 11, 5, 1, msg_code );
	no = set = side = 0;
	disp_encode( no, set, side );
	cursor_x = 0;
	while( 1 ) {
		mode = select_mode( mode );
		if( mode != MODE_ENCODE )  return( mode );
		while( cursor_y > 0 ) {
			init_cursor( 4, 3, 14, 44, 16, 0, 0 );
			move_cursor();
			while( cursor_y==1 ) {
				move_cursor();
				if( keycode & J_A ) {
					keycode &= ~J_A;
					switch( cursor_x ) {
						case 0:
						  if( no > 0 )	no--;
						  else			no=MAX_NUM-1;
						  break;
						case 1:
						  if( no < MAX_NUM-1 ) no++;
						  else			no=0;
						  break;
						case 2:
						  set = 1 - set;
						  break;
						  case 3:
						  side = 1 - side;
						  break;
					}
					disp_encode( no, set, side );
				}
			}
			if( cursor_y==2 ) {
				init_cursor( 1, 3, 15, 148, 0, 0, 0 );
			}
			while( cursor_y==2 ){
				move_cursor();
				if( keycode & J_A ) {
					keycode &= ~J_A;
					set_bkg_tiles( 1, 16, 12, 1, msg_send_on );
					send_enc();
					set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
				}
				if( keycode & J_B ) {
					keycode &= ~J_B;
					set_bkg_tiles( 1, 16, 12, 1, msg_send_on );
					send_enc_freme();
					set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
				}
			}
			set_bkg_tiles( 1, 16, 12, 1, msg_send_off );
		}
	}
	return( mode );
}

void main()
{
	UBYTE i, j, mode;

	init_character();

	/* initialize bank number */
	ENABLE_RAM_MBC1;
	SWITCH_RAM_MBC1( 0 );
	if( joypad() & J_START ) {
		for( i=0; i<MAX_NUM; i++ ) {
			header_nvm[i] = 0;
			for( j=0; j<MAX_SET*2; j++ ) {
				nvm[i][j][0] = 0;
			}
		}
		set_bkg_tiles( 2, 5, 16, 1, msg_clear );
		while( 1 );
	}
	if( _cpu != CGB_TYPE ) {
		set_bkg_tiles( 5, 5, 10, 1, msg_nogbc );
		while( 1 );
	}

	speed = 1;				// 0:2400bps, 1:9600bps
	parity = 0;				// 0:non, 1:odd, 2:even
	mode = MODE_PLAY;
	while( 1 ) {
		set_bkg_tiles( 0, 0, 20, 18, form[mode] );
		switch( mode ) {
		  case MODE_PLAY:
			mode = mode_play( mode );
			break;
		  case MODE_REC:
			mode = mode_rec( mode );
			break;
		  case MODE_DUMP:
			mode = mode_dump( mode );
			break;
		  case MODE_ENCODE:
			mode = mode_encode( mode );
			break;
		}
	}
}

/* EOF */