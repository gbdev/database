#include <gb/gb.h>
#include <gb/drawing.h>

extern const UWORD GrayScale[];

extern int Program;
extern int Scene;
extern int TIMER;
extern int v;
extern int X;
extern int Y;
extern int X1;
extern int Y1;
extern int X2;
extern int Y2;
extern int X3;
extern int Y3;
extern int X4;
extern int Y4;
extern int X5;
extern int Y5;
extern int X6;
extern int Y6;
extern int X07;
extern int Y07;
extern int D;
extern int Frame;
extern int F2;
extern int YS2;
extern int FCount;
int Vmusic;
extern int exitloop;

const int RotaLines[360] = {
80, 80, 81, 82, 82, 83, 84, 84,
85, 86, 86, 87, 88, 88, 89, 90, 91, 91,
92, 93, 93, 94, 94, 95, 96, 96, 97, 98,
98, 99, 100, 100, 101, 101, 102, 102, 103, 104,
104, 105, 105, 106, 106, 107, 107, 108, 108, 109,
109, 110, 110, 111, 111, 111, 112, 112, 113, 113,
113, 114, 114, 114, 115, 115, 115, 116, 116, 116,
117, 117, 117, 117, 118, 118, 118, 118, 118, 118,
119, 119, 119, 119, 119, 119, 119, 119, 119, 119,
119, 119, 120, 119, 119, 119, 119, 119, 119, 119,
119, 119, 119, 119, 119, 118, 118, 118, 118, 118,
118, 117, 117, 117, 117, 116, 116, 116, 115, 115,
115, 114, 114, 114, 113, 113, 113, 112, 112, 111,
111, 111, 110, 110, 109, 109, 108, 108, 107, 107,
106, 106, 105, 105, 104, 104, 103, 102, 102, 101,
101, 100, 100, 99, 98, 98, 97, 96, 96, 95,
94, 94, 93, 93, 92, 91, 91, 90, 89, 88,
88, 87, 86, 86, 85, 84, 84, 83, 82, 82,
81, 80, 80, 79, 78, 77, 77, 76, 75, 75,
74, 73, 73, 72, 71, 71, 70, 69, 68, 68,
67, 66, 66, 65, 65, 64, 63, 63, 62, 61,
61, 60, 60, 59, 58, 58, 57, 57, 56, 55,
55, 54, 54, 53, 53, 52, 52, 51, 51, 50,
50, 49, 49, 48, 48, 48, 47, 47, 46, 46,
46, 45, 45, 45, 44, 44, 44, 43, 43, 43,
42, 42, 42, 42, 41, 41, 41, 41, 41, 41,
40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
40, 40, 40, 40, 40, 40, 40, 40, 40, 40,
40, 40, 40, 40, 40, 41, 41, 41, 41, 41,
41, 42, 42, 42, 42, 43, 43, 43, 44, 44,
44, 45, 45, 45, 46, 46, 46, 47, 47, 48,
48, 48, 49, 49, 50, 50, 51, 51, 52, 52,
53, 53, 54, 54, 55, 55, 56, 57, 57, 58,
58, 59, 59, 60, 61, 61, 62, 63, 63, 64,
65, 65, 66, 66, 67, 68, 68, 69, 70, 71,
71, 72, 73, 73, 74, 75, 75, 76, 77, 77,
78, 79, 79, 80,  
};

const int Center[] = {
70,90,
};

void MoveCircles(){
    if (X > 60) X = 1;
	if (X1 > 60) X1 = 1;
	if (X2 > 60) X2 = 1;
	if (X3 > 60) X3 = 1;
	if (X4 > 60) X4 = 1;
	if (D > 60) D = 1;
	
    //Circles
	color(0,0,SOLID);
    circle(v,72,X,M_NOFILL);
	color(3,3,SOLID);
    circle(v,72,X1,M_NOFILL);
	color(0,0,SOLID);
    circle(v,72,X2,M_NOFILL);
	color(3,3,SOLID);
    circle(v,72,X3,M_NOFILL);	
	color(0,0,SOLID);
    circle(v,72,X4,M_NOFILL);	
	color(3,3,SOLID);
    circle(v,72,D,M_NOFILL);	
	
	X++; X1++; X2++; X3++; X4++; D++; 
}

void CIRCLES(){

  switch (Scene){
  case 0:
    wait_vbl_done();
	 DISPLAY_OFF;
	 delay(5);
        disable_interrupts();
        DISPLAY_OFF;
        for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
        LCDC_REG =  0x47;
        mode (0xE2);
        move_bkg(0,0);
        DISPLAY_ON;
        enable_interrupts();  
     TIMER = 0;
	 Frame = 0;
	 FCount = 0;
     X = 4; X1=12; X2=20; X3=28; X4=36;
	 Scene = 1;
	 v = 80;
  break;
  case 1:

    if (_cpu == 0x11){ 
	    cpu_fast(); //CPU a 8 Mhz 
		set_bkg_palette(0, 1, GrayScale);
    }
	SCX_REG = 0; SCY_REG = 0;
	 X = 10; X1=20; X2=30; X3=40; X4=50;
     D = 60;
	Scene = 3;
	
  break;
  case 3:
    MoveCircles();
	if (FCount == 2) FCount = 0;
    if (TIMER == 125){
	 X = 0; X1=0; X2=0; X3=0; X4=0;
     D = 0;	
	  TIMER = 0; 
	  Scene = 4;
	  SCX_REG = 0;
	    wait_vbl_done();
        disable_interrupts();
        DISPLAY_OFF;
        for  (v = 0; v < 257; v++){remove_VBL(v); remove_LCD(v);}
        LCDC_REG =  0x47;
        mode (0xE2);
        DISPLAY_ON;
        enable_interrupts();
		color(3,3,SOLID);
        box(0,0,159,143,M_FILL);
	  }
	if (TIMER > 70) v = Center[FCount];  
	TIMER++;
	FCount++;
	return;
  break;
  case 4:
      color(3,3,SOLID);
      box(0,X,40,X+8,M_FILL);
	  delay(30);
	  if (X < 136) X+=8; 
	  if ((X == 136) && (Y < 144)) {box(41,Y,80,Y+8,M_FILL); Y+=8;}
	  if ((Y == 144) && (X1 < 144)) {box(81,X1,120,X1+8,M_FILL); X1+=8;}
	  if ((X1 == 144) && (Y1 < 144)) {box(121,Y1,160,Y1+8,M_FILL); Y1+=8;}
	  if (Y1 == 144) {
	  	Scene = 0;
		Program = 110;
        X = 350; Y = 80; X1 = 190; Y1 = 280;
	    X2 = 10; Y2 = 100; X3 = 170; Y3 = 260;
		X4 = 80; Y4 = 170; X5 = 280; Y5 = 10;
		X6 = 100; Y6 = 190; X07 = 260; Y07 = 350;
	    wait_vbl_done();
        disable_interrupts();
        DISPLAY_OFF;
        for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
        LCDC_REG =  0x47;
        mode (0xE2);
        move_bkg(0,0);
        DISPLAY_ON;
        enable_interrupts(); 
	  }
	  return;
  break;  
  }
}
void LINES() {
  switch (Scene){
  case 0:
     if (X == -1) X = 359;
	 if (Y == -1) Y = 359;
     if (X1 == -1) X1 = 359;
	 if (Y1 == -1) Y1 = 359;
	 if (X2 == -1) X2 = 359;
	 if (Y2 == -1) Y2 = 359;
     if (X3 == -1) X3 = 359;
	 if (Y3 == -1) Y3 = 359;
     if (X4 > 359) X4 = 0;
	 if (Y4 > 359) Y4 = 0;
     if (X5 > 359) X5 = 0;
	 if (Y5 > 359) Y5 = 0;
     if (X6 > 359) X6 = 0;
	 if (Y6 > 359) Y6 = 0;	
     if (X07 > 359) X07 = 0;
	 if (Y07 > 359) Y07 = 0;	 
	 
     color(3,3,SOLID);
     if (RotaLines[X] < RotaLines[X1]) line(RotaLines[X],RotaLines[Y],RotaLines[X1],RotaLines[Y1]);
	 if (RotaLines[X] == RotaLines[X1]) line(RotaLines[X],RotaLines[Y],RotaLines[X1],RotaLines[Y1]);
	 if (RotaLines[X] > RotaLines[X1]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X],RotaLines[Y]);
     
     if (RotaLines[X2] < RotaLines[X3]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X2] == RotaLines[X3]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X2] > RotaLines[X3]) line(RotaLines[X3],RotaLines[Y3],RotaLines[X2],RotaLines[Y2]);

     if (RotaLines[X] < RotaLines[X2]) line(RotaLines[X],RotaLines[Y],RotaLines[X2],RotaLines[Y2]);
	 if (RotaLines[X] == RotaLines[X2]) line(RotaLines[X],RotaLines[Y],RotaLines[X2],RotaLines[Y2]);
	 if (RotaLines[X] > RotaLines[X2]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X],RotaLines[Y]);

     if (RotaLines[X1] < RotaLines[X3]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X1] == RotaLines[X3]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X1] > RotaLines[X3]) line(RotaLines[X3],RotaLines[Y3],RotaLines[X1],RotaLines[Y1]);
	 
	//
	 if (RotaLines[X4] < RotaLines[X5]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X5],RotaLines[Y5]);
	 if (RotaLines[X4] == RotaLines[X5]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X5],RotaLines[Y5]);
	 if (RotaLines[X4] > RotaLines[X5]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X4],RotaLines[Y4]);
 
	 if (RotaLines[X6] < RotaLines[X07]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X6] == RotaLines[X07]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X6] > RotaLines[X07]) line(RotaLines[X07],RotaLines[Y07],RotaLines[X6],RotaLines[Y6]);

	 if (RotaLines[X4] < RotaLines[X6]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X6],RotaLines[Y6]);
	 if (RotaLines[X4] == RotaLines[X6]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X6],RotaLines[Y6]);
	 if (RotaLines[X4] > RotaLines[X6]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X4],RotaLines[Y4]);
 
	 if (RotaLines[X5] < RotaLines[X07]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X5] == RotaLines[X07]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X5] > RotaLines[X07]) line(RotaLines[X07],RotaLines[Y07],RotaLines[X5],RotaLines[Y5]);
	 
	 
     color(0,0,SOLID);
     if (RotaLines[X] < RotaLines[X1]) line(RotaLines[X],RotaLines[Y],RotaLines[X1],RotaLines[Y1]);
	 if (RotaLines[X] == RotaLines[X1]) line(RotaLines[X],RotaLines[Y],RotaLines[X1],RotaLines[Y1]);
	 if (RotaLines[X] > RotaLines[X1]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X],RotaLines[Y]);	 

     if (RotaLines[X2] < RotaLines[X3]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X2] == RotaLines[X3]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X2] > RotaLines[X3]) line(RotaLines[X3],RotaLines[Y3],RotaLines[X2],RotaLines[Y2]);

     if (RotaLines[X] < RotaLines[X2]) line(RotaLines[X],RotaLines[Y],RotaLines[X2],RotaLines[Y2]);
	 if (RotaLines[X] == RotaLines[X2]) line(RotaLines[X],RotaLines[Y],RotaLines[X2],RotaLines[Y2]);
	 if (RotaLines[X] > RotaLines[X2]) line(RotaLines[X2],RotaLines[Y2],RotaLines[X],RotaLines[Y]);
	
     if (RotaLines[X1] < RotaLines[X3]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X1] == RotaLines[X3]) line(RotaLines[X1],RotaLines[Y1],RotaLines[X3],RotaLines[Y3]);
	 if (RotaLines[X1] > RotaLines[X3]) line(RotaLines[X3],RotaLines[Y3],RotaLines[X1],RotaLines[Y1]);
	 
	 //
	 if (RotaLines[X4] < RotaLines[X5]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X5],RotaLines[Y5]);
	 if (RotaLines[X4] == RotaLines[X5]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X5],RotaLines[Y5]);
	 if (RotaLines[X4] > RotaLines[X5]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X4],RotaLines[Y4]);	 

	 if (RotaLines[X6] < RotaLines[X07]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X6] == RotaLines[X07]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X6] > RotaLines[X07]) line(RotaLines[X07],RotaLines[Y07],RotaLines[X6],RotaLines[Y6]);

	 if (RotaLines[X4] < RotaLines[X6]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X6],RotaLines[Y6]);
	 if (RotaLines[X4] == RotaLines[X6]) line(RotaLines[X4],RotaLines[Y4],RotaLines[X6],RotaLines[Y6]);
	 if (RotaLines[X4] > RotaLines[X6]) line(RotaLines[X6],RotaLines[Y6],RotaLines[X4],RotaLines[Y4]);
 
	 if (RotaLines[X5] < RotaLines[X07]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X5] == RotaLines[X07]) line(RotaLines[X5],RotaLines[Y5],RotaLines[X07],RotaLines[Y07]);
	 if (RotaLines[X5] > RotaLines[X07]) line(RotaLines[X07],RotaLines[Y07],RotaLines[X5],RotaLines[Y5]);
	 /////////
	 
	 if (TIMER == 258) Scene = 1;
	 X--; Y--; X1--; Y1--; X2--; Y2--; X3--; Y3--; X4+=2; Y4+=2; X5+=2; Y5+=2; X6+=2; Y6+=2; X07+=2; Y07+=2;
	 TIMER++;
	 goto exit;
  break;
  case 1:
	 F2 = 0;
	 YS2 = 0;
	 if (_cpu == 0x11) cpu_slow();
	 
	 SCX_REG = 0;
	 SCY_REG = 0;
	 TIMER = 0;
	 X = 0;
	 Y = 0;
	 X1 = 0;
	 Y1 = 0;
	 X2 = 0;
	 Y2 = 0;
	 X3 = 0;
	 Y3 = 0;
	 X4 = 0;
	 Y4 = 0;
     X5 = 0;
     Y5 = 0;
     X6 = 0;
     Y6 = 0;
     X07 = 0;
     Y07 = 0;	 
	 D = 0;
     Frame = 0;
	 FCount = 0;
	 F2 = 0;
	 YS2 = 0;
	 Program = 4;
	 Scene = 0;
  break;
  }
  exit:
    return;
}
