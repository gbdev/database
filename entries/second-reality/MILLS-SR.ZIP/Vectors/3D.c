#include <gb/gb.h>
#include <gb/drawing.h>

extern int D;
extern int D1;
extern int X;
extern int Y;
extern int Scene;
extern int v;
extern int Program;
extern int TIMER;

//elipse
const int ELX[142] = {
102,101,100,
99,99,98,97,96,95,95,94,93,92,91,90,89,89,88,87,86,85,84,83,82,81,80,79,
78,77,76,75,74,73,72,71,70,70,69,68,67,66,65,64,64,63,62,61,60,60,59,58,
57,57,56,55,55,54,54,53,53,52,52,52,53,53,54,54,55,55,56,57,57,58,59,60,
60,61,62,63,64,64,65,66,67,68,69,70,70,71,72,73,74,75,76,77,78,79,80,81,
82,83,84,85,86,87,88,89,89,90,91,92,93,94,95,95,96,97,98,99,99,
100,101,102,102,103,104,104,105,105,106,106,107,107,107,107,106,
106,105,105,104,104,103,102,
}; 
const int ELY[142] = {
64,64,64,64,63,63,63,63,63,62,62,62,62,62,62,62,61,61,61,61,61,61,61,61,61,61,
61,61,61,61,61,61,61,61,61,61,62,62,62,62,62,62,62,63,63,63,63,63,64,64,64,64,
65,65,65,66,66,67,67,68,68,69,70,71,71,72,72,73,73,74,74,74,75,75,75,75,76,76,
76,76,76,77,77,77,77,77,77,77,78,78,78,78,78,78,78,78,78,78,78,78,78,78,78,78,
78,78,78,78,77,77,77,77,77,77,77,76,76,76,76,76,75,75,75,74,74,74,73,73,72,72,
71,71,70,69,68,68,67,67,66,66,65,65,65,
};

//puntas
int X7 = 80;
int Y7 = 50;

int X8 = 80;
int Y8 = 88;

//Vertices
int EL1 = 0;
int EL2 = 24;
int EL3 = 48;
int EL4 = 72;
int EL5 = 96;
int EL6 = 120;


const int ALT [] = {
22,18,15,12,11,8,6,4,2,1,0,0,0,0,1,2,4,6,8,11,12,15,18
};
int HI = 11;
const int ALT2 [] = {
22,21,20,18,16,14,10,8,4,2,1,0,0,0,1,2,3,4,5,8,12,16,18
};
int HI2 = 11;

int C1 = 0;

void VECTORS1() {
	
	//Elipse1
	if (EL1 > 141) EL1 = 0;
	if (EL2 > 141) EL2 = 0;
	if (EL3 > 141) EL3 = 0;
	if (EL4 > 141) EL4 = 0;
	if (EL5 > 141) EL5 = 0;
	if (EL6 > 141) EL6 = 0;	

	//draw
	color(DKGREY,WHITE);
	
	
	if (ELX[EL1] < ELX[EL2]) line(ELX[EL1],ELY[EL1]+ALT[HI],ELX[EL2],ELY[EL2]+ALT[HI]);
	if (ELX[EL1] > ELX[EL2]) line(ELX[EL2],ELY[EL2]+ALT[HI],ELX[EL1],ELY[EL1]+ALT[HI]);
	
	if (ELX[EL2] < ELX[EL3]) line(ELX[EL2],ELY[EL2]+ALT[HI],ELX[EL3],ELY[EL3]+ALT[HI]);
	if (ELX[EL2] > ELX[EL3]) line(ELX[EL3],ELY[EL3]+ALT[HI],ELX[EL2],ELY[EL2]+ALT[HI]);
	
	if (ELX[EL3] < ELX[EL4]) line(ELX[EL3],ELY[EL3]+ALT[HI],ELX[EL4],ELY[EL4]+ALT[HI]);
	if (ELX[EL3] > ELX[EL4]) line(ELX[EL4],ELY[EL4]+ALT[HI],ELX[EL3],ELY[EL3]+ALT[HI]);		
}
void VECTORS2() {
	if (ELX[EL4] < ELX[EL5]) line(ELX[EL4],ELY[EL4]+ALT[HI],ELX[EL5],ELY[EL5]+ALT[HI]);
	if (ELX[EL4] > ELX[EL5]) line(ELX[EL5],ELY[EL5]+ALT[HI],ELX[EL4],ELY[EL4]+ALT[HI]);	
	
	if (ELX[EL5] < ELX[EL6]) line(ELX[EL5],ELY[EL5]+ALT[HI],ELX[EL6],ELY[EL6]+ALT[HI]);
	if (ELX[EL5] > ELX[EL6]) line(ELX[EL6],ELY[EL6]+ALT[HI],ELX[EL5],ELY[EL5]+ALT[HI]);	
	
	if (ELX[EL6] < ELX[EL1]) line(ELX[EL6],ELY[EL6]+ALT[HI],ELX[EL1],ELY[EL1]+ALT[HI]);
	if (ELX[EL6] > ELX[EL1]) line(ELX[EL1],ELY[EL1]+ALT[HI],ELX[EL6],ELY[EL6]+ALT[HI]);	
}
void VECTORS3() {
    //punta1	
	color(LTGREY,WHITE);
	if (ELX[EL1] < X7) line(ELX[EL1],ELY[EL1]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL1] > X7) line(X7,Y7+ALT2[HI2],ELX[EL1],ELY[EL1]+ALT[HI]);
    color(DKGREY,WHITE);	
	if (ELX[EL2] < X7) line(ELX[EL2],ELY[EL2]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL2] > X7) line(X7,Y7+ALT2[HI2],ELX[EL2],ELY[EL2]+ALT[HI]);
	color(LTGREY,WHITE);
	if (ELX[EL3] < X7) line(ELX[EL3],ELY[EL3]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL3] > X7) line(X7,Y7+ALT2[HI2],ELX[EL3],ELY[EL3]+ALT[HI]);	
}
void VECTORS4(){
	color(DKGREY,WHITE);
	if (ELX[EL4] < X7) line(ELX[EL4],ELY[EL4]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL4] > X7) line(X7,Y7+ALT2[HI2],ELX[EL4],ELY[EL4]+ALT[HI]);
    color(LTGREY,WHITE);	
	if (ELX[EL5] < X7) line(ELX[EL5],ELY[EL5]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL5] > X7) line(X7,Y7+ALT2[HI2],ELX[EL5],ELY[EL5]+ALT[HI]);
    color(DKGREY,WHITE);	
	if (ELX[EL6] < X7) line(ELX[EL6],ELY[EL6]+ALT[HI],X7,Y7+ALT2[HI2]);
	if (ELX[EL6] > X7) line(X7,Y7+ALT2[HI2],ELX[EL6],ELY[EL6]+ALT[HI]);	
}
void VECTORS5() {
	//punta2	
	if (ELX[EL1] < X8) line(ELX[EL1],ELY[EL1]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL1] > X8) line(X8,Y8+ALT2[HI2],ELX[EL1],ELY[EL1]+ALT[HI]);
    color(LTGREY,WHITE);	
	if (ELX[EL2] < X8) line(ELX[EL2],ELY[EL2]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL2] > X8) line(X8,Y8+ALT2[HI2],ELX[EL2],ELY[EL2]+ALT[HI]);
	color(DKGREY,WHITE);
	if (ELX[EL3] < X8) line(ELX[EL3],ELY[EL3]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL3] > X8) line(X8,Y8+ALT2[HI2],ELX[EL3],ELY[EL3]+ALT[HI]);
}
void VECTORS6() {
    color(LTGREY,WHITE);	
	if (ELX[EL4] < X8) line(ELX[EL4],ELY[EL4]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL4] > X8) line(X8,Y8+ALT2[HI2],ELX[EL4],ELY[EL4]+ALT[HI]);
    color(DKGREY,WHITE);	
	if (ELX[EL5] < X8) line(ELX[EL5],ELY[EL5]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL5] > X8) line(X8,Y8+ALT2[HI2],ELX[EL5],ELY[EL5]+ALT[HI]);
    color(LTGREY,WHITE);	
	if (ELX[EL6] < X8) line(ELX[EL6],ELY[EL6]+ALT[HI],X8,Y8+ALT2[HI2]);
	if (ELX[EL6] > X8) line(X8,Y8+ALT2[HI2],ELX[EL6],ELY[EL6]+ALT[HI]);	
}

void UPDATE_VECTORS(){
	//clear
    color(BLACK,BLACK);
    box(40,50+ALT2[HI2],120,88+ALT2[HI2],M_FILL);
	
	TIMER++;
	//bounce
	if (TIMER > 40) {
	HI++;
	HI2++;
	if (HI == 23) HI = 0; 
	if (HI2 == 23) HI2 = 0;
	}
	//Rotate 
	EL1++; EL2++; EL3++; EL4++; EL5++; EL6++;
	
	if (TIMER > 182){ 
	   wait_vbl_done();
       disable_interrupts();
       DISPLAY_OFF;
       for  (v = 0; v < 255; v++){remove_VBL(v); remove_LCD(v);}
       LCDC_REG =  0x47;
       mode (0xE2);
       move_bkg(0,0);
       DISPLAY_ON;
       enable_interrupts();	
	
	  Program = 120; 
      color(3,3);
	  box(0,120,159,143,M_FILL);
	  TIMER = 0;
	}
}