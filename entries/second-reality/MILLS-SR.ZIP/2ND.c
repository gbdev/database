#include <gb/gb.h>
#include <stdio.h>
#include "gbt_player.h"
extern const unsigned char * song_Data1[];
extern const unsigned char * song_Data2[];
extern const unsigned char * song_Data3[];
extern const unsigned char * song_Data4[];
extern const unsigned char * song_Data5[];
const UWORD GrayScale[] = {32733,21140,10570,0,};

int D = 0;
int D1 = 0;
int X = 0;
int Y = 0;
int X1 = 0;
int Y1 = 0;
int X2 = 0;
int Y2 = 0;
int X3 = 0;
int Y3 = 0;
int X4 = 0;
int Y4 = 0;
int X5 = 0;
int Y5 = 0;
int X6 = 0;
int Y6 = 0;
int X07 = 0;
int Y07 = 0;
int X08 = 0;
int Y08 = 0;
int X9 = 0;
int Y9 = 0;
int v = 0;
int Frame = 0;

int Mus = 0;

int exitloop = 0;
//bkg waves
int F2 = 0;
int YS2 = 0;

//Final
int BB = 0;

//=============================
///////////////////////////////
int Program = 0;
int Scene = 0;
int TIMER = 0;

int ModeScene = 0; //Single scene 1/ all scenes 0
void Scroll_Control() {	 
     Frame++;
	 F2 = YS2;
     BB = 0;		 
}


void INTRO();
void SELECTION();
void SPACE();
void LOGOSR();

void VECTORS1();
void VECTORS2();
void VECTORS3();
void VECTORS4();
void VECTORS5();
void VECTORS6();
void UPDATE_VECTORS();

void CIRCLES();
void LINES();
void ALIEN();

void SCROLL();

void FC();
void FCAtom();
void FC2();

void PLASMA();

void BOUNCE();
void TRANSMISION1();
void PSEC10();
void TRANSMISION2();
void UNI();
void FINAL();

void main() {
    gbt_play(song_Data1, 2, 7);
	gbt_loop(0);
    add_VBL(Scroll_Control);
	SWITCH_ROM_MBC1(10);
	INTRO();
	SWITCH_ROM_MBC1(0);
	
    while (1) {
	     switch (Program){
		 case 100:
		   SWITCH_ROM_MBC1(10);
		   SELECTION();
		   SWITCH_ROM_MBC1(0);
		 break;
	     case 0:
           SWITCH_ROM_MBC1(3);
		   SPACE();
           SWITCH_ROM_MBC1(0);
		   wait_vbl_done();	
	     break;
		 case 1:
		    SWITCH_ROM_MBC1(4);
		    LOGOSR();
			SWITCH_ROM_MBC1(0);
		    gbt_update();	
		    wait_vbl_done();
	     break;
		 case 2:
		   SWITCH_ROM_MBC1(5);
	       VECTORS1();
		   if (_cpu == 0x01){
		   SWITCH_ROM_MBC1(0);
           gbt_update();
           SWITCH_ROM_MBC1(5);		   
		   }		   
	       VECTORS2();
		   SWITCH_ROM_MBC1(0);
           gbt_update();
           SWITCH_ROM_MBC1(5);		   
	       VECTORS3();
		   if (_cpu == 0x01){
		   SWITCH_ROM_MBC1(0);
           gbt_update();
           SWITCH_ROM_MBC1(5);		   
		   }
	       VECTORS4();
		   SWITCH_ROM_MBC1(0);
           gbt_update();
		   SWITCH_ROM_MBC1(5);
	       VECTORS5();
		   SWITCH_ROM_MBC1(0);
           gbt_update();
		   SWITCH_ROM_MBC1(5);		   
	       VECTORS6();
		   SWITCH_ROM_MBC1(0);
           gbt_update();
		   delay(10);
		   SWITCH_ROM_MBC1(5);
	       UPDATE_VECTORS();
		   SWITCH_ROM_MBC1(0);
           gbt_update();		   
		 break;
		 case 120:
		   gbt_stop();
		   gbt_play(song_Data2, 2, 1);
		   add_VBL(Scroll_Control);	
		   Program = 3;
		 break;
		 case 3:
		   SWITCH_ROM_MBC1(7);
           CIRCLES();
		   SWITCH_ROM_MBC1(0);
		   gbt_update();
		 break;
		 case 110:
		   gbt_stop();
		   gbt_play(song_Data3, 2, 2);
           Program = 111;		   
		 break;
		 case 111:
		   SWITCH_ROM_MBC1(7);
           LINES();
		   SWITCH_ROM_MBC1(0);
		   gbt_update();
		 break;
		 case 4:
		   SWITCH_ROM_MBC1(10);
	       ALIEN();
		   SWITCH_ROM_MBC1(0);
		   gbt_update();	
		   wait_vbl_done();		   
		 break;
		 case 52:
		   gbt_stop();
		   gbt_play(song_Data4, 2, 7);
		   add_VBL(Scroll_Control);
           Program = 5;		   
		 break;
		 case 5: 
          while (exitloop == 0){		 
		   SWITCH_ROM_MBC1(4);
           SCROLL();
		   SWITCH_ROM_MBC1(0);
		   if (Mus == 44) {Mus = 0; gbt_update();}
          }		   
		 break;
		 case 6:
		   SWITCH_ROM_MBC1(8);
           FC();
		   SWITCH_ROM_MBC1(0);
           gbt_update();
           wait_vbl_done();		   
         break;		
		 case 7:
		   gbt_pause(30);
		   SWITCH_ROM_MBC1(9);
           FCAtom();
		   SWITCH_ROM_MBC1(0);
           add_VBL(Scroll_Control);		   
           Program = 8;	
           exitloop = 0;		   
         break;	
         case 8:
		  while (exitloop == 0){
		   SWITCH_ROM_MBC1(8);
           FC2();
		   SWITCH_ROM_MBC1(0);
		   if (Mus == 44) {Mus = 0; gbt_update();}
		  }
         break;
         case 11:
		   SWITCH_ROM_MBC1(12);
           PLASMA();
		   SWITCH_ROM_MBC1(0);
           gbt_update(); 
         break;	
         case 13:
		   SWITCH_ROM_MBC1(6);
           BOUNCE();
		   SWITCH_ROM_MBC1(0);
		   gbt_update();
		   wait_vbl_done();
         break;	
		 case 14:
		   gbt_stop();
		   SWITCH_ROM_MBC1(11);
	       TRANSMISION1();
		   SWITCH_ROM_MBC1(0);	
		   wait_vbl_done();		   
		 break;	
		 case 15:
		   SWITCH_ROM_MBC1(13);
           PSEC10();
		   SWITCH_ROM_MBC1(0);
		   gbt_play(song_Data5, 2, 7);
		 break;
		 case 16:
		   SWITCH_ROM_MBC1(11);
	       TRANSMISION2();
		   SWITCH_ROM_MBC1(0);
		   gbt_update();	
		   wait_vbl_done();		   
		 break;
         case 43:
		   add_VBL(Scroll_Control);
		   Program = 17;
		   exitloop = 0;
         break;		 
		 case 17:
          while (exitloop == 0){		 
		   SWITCH_ROM_MBC1(6);
	       UNI();
		   SWITCH_ROM_MBC1(0);
          }		   
		 break;	
         case 45:
		   add_VBL(Scroll_Control);
		   Program = 20;
         break;			 
         case 20:
		   SWITCH_ROM_MBC1(15);
           FINAL();
		   SWITCH_ROM_MBC1(0);
         break;			 
	    }			
	}
}	
