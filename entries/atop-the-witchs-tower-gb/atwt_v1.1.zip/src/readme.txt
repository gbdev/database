---HI THERE---

Atop the Witch's Tower is a ZZT videogame by John Thyer.
You probably downloaded this version on museumofzzt.com.
I hope you enjoy it!

You can play my other games here: 
https://farawaytimes.itch.io/

---TESTERS---

Polly - http://socksmakepeoplesexy.net/
Rhete - http://inthri.tumblr.com/
wasnotwhynot - https://vextro.itch.io/
Anna - https://twitter.com/secretlydecent

Thanks a whole bunch!!

---ALSO---

I made this game after reading anna anthropy's excellent book 
on ZZT and also playing her ZZT game Star Wench. Some of the
object code in this game is ripped straight from Star Wench 
(not to mention a bit of the puzzles/structure/tone), so thanks
a lot!

https://bossfightbooks.com/products/zzt-by-anna-anthropy
http://auntiepixelante.com/?p=2229

---THANKS FOR READING, YOU SHOULD GO PLAY THE GAME NOW---