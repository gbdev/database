/*
   Gabe Edit v0.1
   Gabe Edit changes morse code into plaintext. A stands for dit and B
   stands for dah. Gabe Edit uses the morse code translation found at
   http://manta.nosc.mil/~w6rdf/morse.html
*/

#include <gb.h>

void intro(void);
void cls(void);
void getkey(void);
void checkkey(void);

int x, y, upper, n;
char string[7];
char c;

main()
{
   intro();
   cls();
   strcpy(string, " ");
   upper = 0;
   while (1)
   {
      getkey();
      checkkey();
      putchar(c);
      c = ' ';
      x++;
      if (x > 30)
      {
         x = 0;
         y++;
      }
   }
   return(0);
}

void intro()
{
   puts("\n\n\n\n");
   puts("   Gabe Edit 0.1\n");
   puts("      push A\n    to continue");
   while (joypad() != J_A);
}

void cls()
{
   for(y = 0; y < 20; y++) 
      for(x = 0; x < 30; x++)
      {    
         gotoxy(x, y);             
         setchar(' '); 
      } 
   gotoxy(0, 0);     
   x = 0;
   y = 0;
}

void getkey()
{
   while(1)
   {
      if (joypad() == J_A)
      {
         strcat(string, "a");
         delay(150);
      }

      if (joypad() == J_B)
      {
         strcat(string, "b");
         delay(150);
      }

      if (joypad() == J_UP)
         upper = 1;

      if (joypad() == J_LEFT)
      {
         x--;
         gotoxy(x, y);
         putchar(' ');
         gotoxy(x, y);
         delay(300);
      }

      if (joypad() == J_DOWN)
         strcpy(string, " ");

      if(joypad() == J_RIGHT)
      {
         delay(300);
         break;
      }
   }
}

void checkkey()
{
   n = strcmp(string, " ab");
   if (n == 0)
      c = 'a';

   n = strcmp(string, " baaa");
   if (n == 0)
      c = 'b';

   n = strcmp(string, " baba");
   if (n == 0)
      c = 'c';

   n = strcmp(string, " baa");
   if (n == 0)
      c = 'd';

   n = strcmp(string, " a");
   if (n == 0)
      c = 'e';

   n = strcmp(string, " aaba");
   if (n == 0)
      c = 'f';

   n = strcmp(string, " bba");
   if (n == 0)
      c = 'g';

   n = strcmp(string, " aaaa");
   if (n == 0)
      c = 'h';

   n = strcmp(string, " aa");
   if (n == 0)
      c = 'i';

   n = strcmp(string, " abbb");
   if (n == 0)
      c = 'j';

   n = strcmp(string, " bab");
   if (n == 0)
      c = 'k';

   n = strcmp(string, " abaa");
   if (n == 0)
      c = 'l';

   n = strcmp(string, " bb");
   if (n == 0)
      c = 'm';

   n = strcmp(string, " ba");
   if (n == 0)
      c = 'n';

   n = strcmp(string, " bbb");
   if (n == 0)
      c = 'o';

   n = strcmp(string, " abba");
   if (n == 0)
      c = 'p';

   n = strcmp(string, " bbab");
   if (n == 0)
      c = 'q';

   n = strcmp(string, " aba");
   if (n == 0)
      c = 'r';

   n = strcmp(string, " aaa");
   if (n == 0)
      c = 's';

   n = strcmp(string, " b");
   if (n == 0)
      c = 't';

   n = strcmp(string, " aab");
   if (n == 0)
      c = 'u';

    n = strcmp(string, " aaab");
    if (n == 0)
       c = 'v';

    n = strcmp(string, " abb");
    if (n == 0)
       c = 'w';

    n = strcmp(string, " baab");
    if (n == 0)
       c = 'x';

    n = strcmp(string, " babb");
    if (n == 0)
       c = 'y';

    n = strcmp(string, " bbaa");
    if (n == 0)
       c = 'z';

    if (upper == 1)
       c = toupper(c);
    upper = 0;
    strcpy(string, " ");
}
