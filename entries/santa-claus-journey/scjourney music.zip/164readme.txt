santa claus journey
(c)2013 celestina software(r)
intro:
plug in the cartridge into the gameboy then power on.at the logo press start to continue.
press start again at title screen to begin playing.
you are santa claus and you must delivery the gifts to peoples.
move santa claus sleight with cross and press a to trow a gift.you want to trow into the chimneys of the houses to validate a delivery.
if you miss the target or hit the planes,you lost a life.each level had a certain number of gifts to delivery and when you complete a level,you gain a extra life.
you have a total time to complete the journey arround the world by delivery all the gifts ordered.