
#define COUNTRY_US     0
#define COUNTRY_JPN    1
#define COUNTRY_UK     2
#define COUNTRY_GER    3
#define COUNTRY_FRA    4
#define COUNTRY_ITA    5
#define COUNTRY_CAN    6
#define COUNTRY_RUS    7
#define COUNTRY_AUS    8
#define COUNTRY_NZL    9
#define COUNTRY_KOR    10
#define COUNTRY_CHN    11
#define COUNTRY_IND    12
#define COUNTRY_SWI    13
#define COUNTRY_FIN    14
#define COUNTRY_BRZ    15

#define DEFALUT_COUNTRY    COUNTRY_JPN
