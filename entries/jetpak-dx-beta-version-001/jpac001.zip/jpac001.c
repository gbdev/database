#include <gb.h>
#include <stdlib.h>

#include "jetman.c"

void main()
{
	UWORD PlayerX,PlayerY;
	BYTE PlayerGravity;
	UBYTE PlayerDirection;
	UBYTE PlayerWalkAnim[4], PlayerAnimCounter;
	UBYTE joystat;	

	unsigned char txt_title[]="JETPAC";
	unsigned char txt_ver[]="BETA V0.01";
	unsigned char blank[]=" ";

	BGP_REG = OBP0_REG = OBP1_REG = 27;
	
	HIDE_BKG;
	SPRITES_8x8;
	HIDE_SPRITES;

	for(PlayerX=0;PlayerX<21;PlayerX++) for(PlayerY=0;PlayerY<21;PlayerY++) set_bkg_tiles(PlayerX,PlayerY,1,1,blank);

	set_bkg_data(0,100,Jetman);
	
	set_sprite_data(0,20,Jetman);
	set_sprite_tile(0,0); set_sprite_tile(1,1);
	set_sprite_tile(2,2); set_sprite_tile(3,3);
	set_sprite_tile(4,4); set_sprite_tile(5,5);
	SHOW_SPRITES;
	
	set_bkg_tiles(0,0,6,1,txt_title);
	set_bkg_tiles(10,1,10,1,txt_ver);
	SHOW_BKG;
	delay(1000);

	PlayerX=72;
	PlayerY=128;
	PlayerDirection=1;
	PlayerWalkAnim[0]=4; PlayerWalkAnim[1]=6; PlayerWalkAnim[2]=8; PlayerWalkAnim[3]=6;
	PlayerAnimCounter=0;
	PlayerGravity=+2;

	while(1){
	joystat=joypad();
	if(joystat&J_LEFT) {
		PlayerAnimCounter=PlayerAnimCounter+1;
		if((PlayerDirection==1)||(PlayerDirection==3)){
			set_sprite_prop(0,S_FLIPX); set_sprite_prop(1,S_FLIPX);
			set_sprite_prop(2,S_FLIPX); set_sprite_prop(3,S_FLIPX);
			set_sprite_prop(4,S_FLIPX); set_sprite_prop(5,S_FLIPX);
			PlayerDirection=PlayerDirection-1; PlayerAnimCounter=0;
		} else {
			PlayerX=PlayerX-2;
			if (PlayerDirection==2) PlayerX=PlayerX-1;
			if (PlayerX<8) PlayerX=152;
		}
	}
	if(joystat&J_RIGHT) {
		PlayerAnimCounter=PlayerAnimCounter+1;
		if((PlayerDirection==0)||(PlayerDirection==2)){
			set_sprite_prop(0,!S_FLIPX); set_sprite_prop(1,!S_FLIPX);
			set_sprite_prop(2,!S_FLIPX); set_sprite_prop(3,!S_FLIPX);
			set_sprite_prop(4,!S_FLIPX); set_sprite_prop(5,!S_FLIPX);
			PlayerDirection=PlayerDirection+1; PlayerAnimCounter=0;
		} else {
			PlayerX=PlayerX+2;
			if(PlayerDirection==3) PlayerX=PlayerX+1;
			if (PlayerX>152) PlayerX=8;
		}
	}

	if(joystat&J_A) {
		if(PlayerDirection<2) {
			PlayerDirection=PlayerDirection+2;
			set_sprite_tile(2,10); set_sprite_tile(3,11);			
			set_sprite_tile(5,12);
		}
		PlayerGravity=PlayerGravity-2;
		if (PlayerGravity<-5) PlayerGravity=-5;
	}
	
	PlayerGravity=PlayerGravity+1;
	if (PlayerGravity>2) PlayerGravity=2;
	
	PlayerY=PlayerY+PlayerGravity;
	if(PlayerY>128) {
		PlayerY=PlayerY-PlayerGravity;
		if(PlayerDirection>1){
			PlayerDirection=PlayerDirection-2;
			set_sprite_tile(2,2); set_sprite_tile(3,3);
		}
	}
	if(PlayerY<32) PlayerY=32;
	if (PlayerDirection<2){
		if (PlayerAnimCounter>3) PlayerAnimCounter=0;
		set_sprite_tile(4,PlayerWalkAnim[PlayerAnimCounter]); set_sprite_tile(5,PlayerWalkAnim[PlayerAnimCounter]+1);
	}
	if (PlayerDirection>1){
		if (PlayerAnimCounter>2) PlayerAnimCounter=0;
		set_sprite_tile(4,13+PlayerAnimCounter);
	}
	
	if((PlayerDirection==1)||(PlayerDirection==3)){
		move_sprite(0,PlayerX,PlayerY   ); move_sprite(1,PlayerX+8,PlayerY   ); 
		move_sprite(2,PlayerX,PlayerY+8 ); move_sprite(3,PlayerX+8,PlayerY+8 ); 
		move_sprite(4,PlayerX,PlayerY+16); move_sprite(5,PlayerX+8,PlayerY+16); 
	}
	if((PlayerDirection==0)||(PlayerDirection==2)){
		move_sprite(1,PlayerX,PlayerY   ); move_sprite(0,PlayerX+8,PlayerY   ); 
		move_sprite(3,PlayerX,PlayerY+8 ); move_sprite(2,PlayerX+8,PlayerY+8 ); 
		move_sprite(5,PlayerX,PlayerY+16); move_sprite(4,PlayerX+8,PlayerY+16); 
	}
	delay(33);
	}
}
