Based on the OnlyPlatforms plugin, by Peter McDonald (Hauntology/becomingplural)
https://github.com/becomingplural/GBS_PlatformerPlus/blob/eb7488bf11204cca4056814939b2c7c3e9a3813a/plugins/OnlyPlatforms-INCOMPATIBLE%20WITH%20PPLUS.zip

Edited by KirbyKing186 to no longer clamp X-Velocities that are higher than the base walk/run velocities.
https://github.com/KirbyKing186

Edited by Finny to add automatic mid-air direction control.
https://flightbun.itch.io/
