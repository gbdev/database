
    20y - Release note:
    
     This demo is intended to be run on either the
     DMG, Pocket or the SGB. It's not compatible
     with GBC nor GBA and will produce graphical
     glitches when run on the latter systems.

     This demo relies heavily on the precise quirks
     of the hardware it's supposed to run on, and
     there's currently no emulator that is 100%
     accurate. So if you haven't the means to use
     real hardware I'd strongly recommend BGB
     (bgb.bircd.org) as it is the only emulator to
     my knowledge that only has a few minor issues
     with the demo, and they are barely noticeable.

     If you are using a flashcart make sure that
     you do not create a multicard but send it
     as a single bootable image instead; Otherwise
     you'll miss part of the intro.

     That's all folks,
     Snorpung.

 
