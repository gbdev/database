christmas lights simulator
controls:
start=go to next effect
select=reset simulation
a/b=increase/decrease n of times a effect is repeatet until the next take place in auto mode
cross=increase/decrease speed by different granularity of the execution
mode 0(first)is auto,it cicle around all the effects.mode 9(last)is steady on