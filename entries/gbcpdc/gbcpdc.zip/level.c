// radio level

/* work area */
UBYTE gGraph_data[36][4];

/* message */
unsigned char gMsg_indi_on[]   = { 19, 19, 0 };
unsigned char gMsg_indi_off[]  = { 20, 21, 0 };
unsigned char gMsg_clear[]     = { 0, 0 };

void init_bkg2()
{
  disable_interrupts();
  DISPLAY_OFF;
  set_bkg_data( 0, 128, bkg_level );
  SHOW_BKG;
  DISPLAY_ON;
  enable_interrupts();
}

void init_level()
{
  UBYTE i, j;

  for( i = 0; i < 36; i++ ) {
    for( j = 0; j < 5; j++ ) {
      gGraph_data[i][j] = 0;
    }
  }
}

void disp_value( UWORD d, UWORD e, UBYTE c, UBYTE x, UBYTE y )
{
  UWORD m;
  UBYTE i, n;
  unsigned char data[6];

  m = 1;
  if ( c > 1 ) {
    for ( i = 1; i < c; i++ ) {
      m = m * e;
    }
  }
  for ( i=0; i<c; i++ ) {
    n = d / m; d = d % m; m = m / e;
    data[i] = '0' + n;		 /* '0' - '9' */
    if ( data[i] > '9' )  data[i] += 7;
  }
  set_bkg_tiles( x, y, c, 1, data );
}

void disp_indicater( UBYTE level)
{
  UBYTE i;
  for( i = 0; i < level+1; i++ ) {
    set_bkg_tiles( i + 3, 3, 1, 2, gMsg_indi_on );
  }
  for( i = level+1; i < 16; i++ ) {
    set_bkg_tiles( i + 3, 3, 1, 2, gMsg_indi_off );
  }
}

void disp_level( UBYTE level)
{
  if( level*2 < 10 ) {
    set_bkg_tiles( 9, 8, 1, 1, gMsg_clear );
    disp_value( level*2, 10, 1, 10, 8 );
    set_bkg_tiles( 12, 8, 1, 1, gMsg_clear );
    disp_value( level*2+1, 10, 1, 13, 8 );
  } else if( level*2 < 30 ) {
    disp_value( level*2, 10, 2, 9, 8 );
    disp_value( level*2+1, 10, 2, 12, 8 );
  } else {
    disp_value( level*2, 10, 2, 9, 8 );
    set_bkg_tiles( 12, 8, 2, 1, gMsg_clear );
  }
}

void shift_graph_data()
{
  UBYTE i, j;

  for( i = 0; i < 35; i++ ) {
    for( j = 0; j < 4; j++ ) {
      gGraph_data[i][j] = gGraph_data[i+1][j];
    }
  }
}

void set_new_graph_data( UBYTE level )
{
  if( level > 11 ){
    gGraph_data[35][0] = level - 11;
    gGraph_data[35][1] = 4;
    gGraph_data[35][2] = 4;
    gGraph_data[35][3] = 4;
  } else if( level > 7 ) {
    gGraph_data[35][0] = 0;
    gGraph_data[35][1] = level - 7;
    gGraph_data[35][2] = 4;
    gGraph_data[35][3] = 4;
  } else if( level > 3 ) {
    gGraph_data[35][0] = 0;
    gGraph_data[35][1] = 0;
    gGraph_data[35][2] = level - 3;
    gGraph_data[35][3] = 4;
  } else {
    gGraph_data[35][0] = 0;
    gGraph_data[35][1] = 0;
    gGraph_data[35][2] = 0;
    gGraph_data[35][3] = level + 1;
  }
}

void disp_bargraph()
{
  UBYTE i, j;
  unsigned char graph_bar[5];

  for( i = 0; i < 36; i += 2 ) {
    for( j = 0; j < 4; j++ ) {
      graph_bar[j] = (gGraph_data[i][j] * 5) + gGraph_data[i+1][j] + 22;
    } 
    set_bkg_tiles( i / 2 + 1, 12, 1, 4, graph_bar ); 
  }
}

void clr_sprite()
{
  UBYTE i;

  for( i = 0; i < 40; i++ ) {
    move_sprite(i, 0, 0);
  }
}

void radio_level()
{
  UBYTE level, key1, key2;

  clr_sprite();
  init_bkg2();
  set_bkg_tiles( 0, 0, 20, 18, form_level );

  init_level();
  key2 = joypad();

  while( 1 ) {
    if( (!receive_gb232(1, 1)) && ((gRcvData[0] & 0xF0) == 0xC0) ) {
      level = gRcvData[0] & 0x0F;
      disp_indicater( level );
      disp_level( level );
      shift_graph_data();
      set_new_graph_data( level );
      disp_bargraph();
    }
    if( key1 = joypad() ) {
      if( key2 != key1 ) {
        return;
      }
    } else {
      key2 = key1;
    }
  }
}
/* EOF */