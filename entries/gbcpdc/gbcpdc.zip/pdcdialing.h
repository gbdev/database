// PDC dialing

// PDC definition
#define PDC_SERVICE_START	0x1AU
#define PDC_DIAL_END		0x86U
#define PDC_ON_HOOK			0xA6U
#define PDC_OFF_HOOK		0xA7U
#define PDC_DIAL_OK			0xEBU

#define PDC_DIAL_0			0x9AU
#define PDC_DIAL_1			0x91U
#define PDC_DIAL_2			0x92U
#define PDC_DIAL_3			0x93U
#define PDC_DIAL_4			0x94U
#define PDC_DIAL_5			0x95U
#define PDC_DIAL_6			0x96U
#define PDC_DIAL_7			0x97U
#define PDC_DIAL_8			0x98U
#define PDC_DIAL_9			0x99U
#define PDC_DIAL_A			0x9DU
#define PDC_DIAL_B			0x9EU
#define PDC_DIAL_C			0x9FU
#define PDC_DIAL_D			0x90U
#define PDC_DIAL_AS			0x9BU
#define PDC_DIAL_SH			0x9CU


