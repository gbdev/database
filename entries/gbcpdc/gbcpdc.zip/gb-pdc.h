// Gameboy Color palette 0 (Normal condition) 20010330
#define CGBPal0c0 32767
#define CGBPal0c1 24311
#define CGBPal0c2 15855
#define CGBPal0c3 0


UWORD pBkgPalette[] = {
	CGBPal0c0, CGBPal0c1, CGBPal0c2, CGBPal0c3
};


/* display */
#define TITLE "PHREAK-B0Y  PDC                  "	//mod

/* Background tile */
#define OFFSET 			27

/* Cursor obj start */
/* This number is depned on number of OBJ(SPRITE) */
#define CURSOR_OBJ		36
#define CURSOR_SIZE		 4

#define KEY_STEP 		16	/* Key matrix size as 16 x 16	*/
#define KEY_OFFSET_X	28
#define KEY_OFFSET_Y	44
#define START_CURSOR_X	12	/* CURSOR position	*/
#define START_CURSOR_Y	64
#define UNIT_SIZE_X		 9
#define UNIT_SIZE_Y		 5


#define LCD_X 			1	/* start position of X		*/
#define LCD_Y			2	/* start position of Y		*/
#define LCD_WIDTH		18	/* Horizontal size of LCD	*/
#define LCD_HIGHT		2	/* Vertical Size of LCD		*/


#define ON	1
#define OFF	0

/* DTMF */
#define DTMF_ON		50UL	/* Tone on time		*/
#define DTMF_OFF	50UL	/* Tone off time	*/

/* CCITT 5 */
#define SOUND_ON	60UL	/* Tone on time		*/

#define NICKLE		0		/*  5 cent coin in US */
#define DIME		1		/* 10 cent coin in US */
#define QUARTER		2		/* 25 cent coin in US */

#define NICKLE_TIME		66UL
#define DIME_TIME		66UL
#define QUARTER_TIME	33UL

#define MAX_DTMF	40		/* Maximum length of DTMF strings	*/
char gStr[MAX_DTMF];
UBYTE gChPos;


/* Display MODE */
#define DISP_DTMF	0
#define DISP_CCITT	1
#define DISP_WD		2

#define DTMF		"     DTMF M0DE    "
#define CCITT		"    CC1TT5 M0DE   "
#define WAR_DIAL    "  WAR-DIAL M0DE   "

#define FLASH_COUNT 2U
#define FLASH_ON_TIME   500UL
#define FLASH_OFF_TIME  100UL

/* Configuration */
#define CON_MSG1	"   C0NFIG M0DE "
#define CON_MSG2	"   0N TIME     "
#define CON_MSG3	"   0FF TIME    "
#define CON_MSG4	"   REPEAT N0   "
#define CON_MSG5	"   PAUSE TIME  "
#define CON_MSG6	"   C0NFIG END  "

#define NORMAL	0
#define CONFIG	1
#define CONFIG_LIMIT	12
#define CONFIG_PARM		4

// Long Key press value
#define LONG_KEY_PRESS_TIME		100UL

char  gWorkStr[6];

UWORD on_time, off_time;
UWORD rpt_time, pause_time;

UBYTE disp_mode;	// Display action mode as DTMF, CCITT5, WD
UBYTE config_st;	// Configuration status such as "ON TIME", "OFF TIME"..
UBYTE mode_excute;	// Display The status of this program if you choice config.
char on_str[CONFIG_PARM], off_str[CONFIG_PARM];
char rpt_str[CONFIG_PARM], pause_str[CONFIG_PARM];

unsigned char row_dtmf[4] = {R1,R2,R3,R4};	/* DTMF frequency strage of Row */	
unsigned char col_dtmf[4] = {C1,C2,C3,C4};	/* DTMF frequency strage of Col */

/* It is possible to set up initial screen by each BG data. */
unsigned char dtmf_tile[] = {
	 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4,

	 0, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 1, 2,
	 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5,
	 3, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 5,
	 6, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 7, 8,
	 
	  9,10,10,11, 9,11, 9,11, 9,11, 9,11, 9,10,10,10,10,10,10,11,
	 15,16,16,17,15,17,15,17,15,17,15,17,15,16,16,16,16,16,16,17,

	  9,10,10,11, 9,11, 9,11, 9,11, 9,11, 9,10,10,10,10,10,10,11,
	 15,16,16,17,15,17,15,17,15,17,15,17,15,16,16,16,16,16,16,17,

	  9,10,10,11, 9,11, 9,11, 9,11, 9,11, 9,10,10,10,10,10,10,11,
	 15,16,16,17,15,17,15,17,15,17,15,17,15,16,16,16,16,16,16,17,

	  9,10,10,11, 9,11, 9,11, 9,11, 9,11, 9,10,10,11, 9,10,10,11,
	 15,16,16,17,15,17,15,17,15,17,15,17,15,16,16,17,15,16,16,17,

	  9,10,10,11, 9,10,10,11, 9,11, 9,11, 9,10,10,11, 9,10,10,11,
	 15,16,16,17,15,16,16,17,15,17,15,17,15,16,16,17,15,16,16,17,

	  9,10,10,11, 9,11, 9,11, 9,11, 9,11, 9,10,10,11, 9,10,10,11,
	 15,16,16,17,15,17,15,17,15,17,15,17,15,16,16,17,15,16,16,17,

	 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4, 4
};

/*
	Button image 
	Hint:
	We are using 3 types of buttons.
	Normal size as 1 x 1(tiles are used in 2 x 2)
	Func.
	Special
*/
unsigned char break_tile_1x1[] = {
	 9,11,
	15,17
};

unsigned char break_tile_2x1[] = {
	 9,10,10,11,
	15,16,16,17
};

unsigned char break_tile_4x1[] = {
	 9,10,10,10,10,10,10,11,
	15,16,16,16,16,16,16,17
};

unsigned char press_tile_1x1[] = {
	18,20,
	24,26
};


unsigned char press_tile_2x1[] = {
	18,19,19,20,
	24,25,25,26
};

unsigned char press_tile_4x1[] = {
	18,19,19,19,19,19,19,20,
	24,25,25,25,25,25,25,26
};

/*
	LCD image at initial & AC
*/
unsigned char init_disp[] = {
	59,59,59,59,59,59,59,59,59,59,59,59,59,59,59,59,59,59,
	60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60,60
};


/*
	Key usage of phreak-boy
	Hint:
	z
*/
char	pad[6][10] = {		/* DTMF Pad assign */
	{'z','z','1','2','3','A','a','a','a','a'},
	{'y','y','4','5','6','B','b','b','b','b'},
	{'x','x','7','8','9','C','c','c','c','c'},
	{'w','w','*','0','#','D','d','d','g','g'},
	{'v','v','s','s','-','E','e','e','h','h'},
	{'u','u',',','?','+','F','f','f','i','i'}
};

