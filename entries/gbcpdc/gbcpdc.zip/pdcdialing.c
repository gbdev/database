// Functions for PDC system

#include "pdcdialing.h"

UBYTE pdc_dialing(char dialing_str[MAX_DTMF])
{
	UBYTE i;
	i = 0;

	while(dialing_str[i]){
		switch(dialing_str[i]){
			case '0':
				send_gb232(PDC_DIAL_0);
			break;
			case '1':
				send_gb232(PDC_DIAL_1);
			break;
			case '2':
				send_gb232(PDC_DIAL_2);
			break;
			case '3':
				send_gb232(PDC_DIAL_3);
			break;
			case '4':
				send_gb232(PDC_DIAL_4);
			break;
			case '5':
				send_gb232(PDC_DIAL_5);
			break;
			case '6':
				send_gb232(PDC_DIAL_6);
			break;
			case '7':
				send_gb232(PDC_DIAL_7);
			break;
			case '8':
				send_gb232(PDC_DIAL_8);
			break;
			case '9':
				send_gb232(PDC_DIAL_9);
			break;
			case 'a':
			case 'A':
				send_gb232(PDC_DIAL_A);
			break;
			case 'b':
			case 'B':
				send_gb232(PDC_DIAL_B);
			break;
			case 'c':
			case 'C':
				send_gb232(PDC_DIAL_C);
			break;
			case 'd':
			case 'D':
				send_gb232(PDC_DIAL_D);
			break;
			case '*':
				send_gb232(PDC_DIAL_AS);
			break;
			case '#':
				send_gb232(PDC_DIAL_SH);
			break;
			case '-':
			break;

			default:
			break;
		}
		i++;
	}
	return i;
}

