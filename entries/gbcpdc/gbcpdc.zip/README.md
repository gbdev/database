# PDC -2G Mobile phone- hacking by Gameboy color
"Radio life" is Japanese hacking magazine. I'm inspired from the magazine honestly...

<table>
<tr>
<td><img src="./pics/gb-pdc.jpg"></td>
</tr>
</table>

## History
This system can be used in Japan ONLY. PDC is an abbreviation of "Personal Digital Celluer" (a.k.a. 2G mobile phone). 

## How it works
Reffered from NTT-docomo official documents. In mean time, we could obtain from NTT-docomo site, however we can't it now...
<table>
<tr>
<td><img src="./pics/gb-pdc1.jpg"></td>
<td><img src="./pics/gb-pdc2.jpg"></td>
</tr>
</table>

## Applications
You can make/add your own applications. Use at your own risks.

### WarDialer
<table>
<tr>
<td><img src="./pics/gb-pdcwd1.jpg"></td>
<td><img src="./pics/gb-pdcwd2.jpg"></td>
</tr>
</table>

## Thanks to
Mr.Factor who makes first conecept and implement to Palm and Mr.K.I. makes GB-232 and implements radio-leve monitor. 


# License
Copyright (c) Osamu OHASHI  
Distributed under the MIT License either version 1.0 or any later version. 

