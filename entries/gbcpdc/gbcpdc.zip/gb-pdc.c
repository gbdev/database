/* ---------------------------------------- */
/*             GB-Phreak Ver1.0             */
/*                  by                      */
/*                TeamKNOx                  */
/*         Add new feature for PDC          */
/* ---------------------------------------- */

#include <gb.h>
#include <stdlib.h>
#include <stdio.h>
#include "gb232.h"

#include "freq.h"
#include "gb-pdc.h"


/* BG data */
#include "frame_lcd.c"	/* Back ground pattern */
#include "break_btn.c"	/* button image when broken */
#include "press_btn.c"	/* button image when pressed */

#include "7seg_lcd.c"	/* LCD characters */

#include "bkg_level.c"	//add
#include "form_level.c"	//add

/* Sprite data */
#include "key_num.c"	/* Sprite pattern for each key pad */
#include "cursor.c"		/* cursor pattern */

/* 
	usage of BG data
	file name	number of BG	type of matrix	amount
	-------------------------------------------------
	frame_lcd.c  9				8 x  8			 9
	break_btn.c	 9				8 x  8			 9
	press_btn.c  9				8 x  8			 9
	dtmf_lcd.c  33				8 x 16			66
	------------------------------------------------
	total										93


	usage of OBJ data
	file name	number of obj	type of matrix	amount
	--------------------------------------------------
	key_num.c	43				 8 x  8			43
	cursor.c	 1				16 x 16			 4
	--------------------------------------------------
	total										47(Full)
*/


// #include "pdcdialing.h"
// #include "wardialer.h"

unsigned char disp_tile[MAX_DTMF];

//* extern */
extern UBYTE gRcvData[127];	//add

/*
	Initialize for sound registers
	ch1, ch2 are used for this routine.
*/
void init_dial()
{

	NR52_REG = 0x83U;
	NR51_REG = 0x00U;
	NR50_REG = 0x77U;

	NR24_REG = 0x87U;
	NR22_REG = 0xffU;
	NR21_REG = 0xbfU;

	NR14_REG = 0x87U;
	NR12_REG = 0xffU;
	NR11_REG = 0xbfU;
	NR10_REG = 0x04U;
}


/* sound engine for DTMF */
void dialtone(UWORD dtmf_on, UWORD dtmf_off, char str[MAX_DTMF])
{
	UWORD i, j;

	for(j = 0;j < rpt_time;j++){
		i = 0;
		while(str[i]){
			switch(str[i]){
		    	case '1':
					NR13_REG = R1;
					NR23_REG = C1; 
				break;
				case '2':
					NR13_REG = R1;
					NR23_REG = C2;
				break;
				case '3':
					NR13_REG = R1;
					NR23_REG = C3;	
				break;
				case 'A':
				case 'a':
					NR13_REG = R1;
					NR23_REG = C4;  
				break;
				case '4':
					NR13_REG = R2;
					NR23_REG = C1;	
				break;
				case '5':
					NR13_REG = R2;
					NR23_REG = C2;	
				break;
				case '6':
					NR13_REG = R2;
					NR23_REG = C3;	
				break;
				case 'B':
				case 'b':
					NR13_REG = R2;
					NR23_REG = C4;	
				break;
				case '7':
					NR13_REG = R3;
					NR23_REG = C1;	
				break;
				case '8':
					NR13_REG = R3;
					NR23_REG = C2;	
				break;
				case '9':
					NR13_REG = R3;
					NR23_REG = C3;	
				break;
				case 'C':
				case 'c':
					NR13_REG = R3;
					NR23_REG = C4;	
				break;
				case '*':
					NR13_REG = R4;
					NR23_REG = C1;	
				break;
				case '0':
					NR13_REG = R4;
					NR23_REG = C2;	
				break;
				case '#':
					NR13_REG = R4;
					NR23_REG = C3;	
				break;
				case 'D':
				case 'd':
					NR13_REG = R4;
					NR23_REG = C4;	
				break;
				case '-':
				break;
				case ',':
					if(dtmf_on)
						delay(dtmf_on);	/* keep on */
					if(dtmf_off)
					delay(dtmf_off);/* keep off */

				default:
					NR51_REG = 0x00U;	/* sound off */
					goto skip;

			}
			NR24_REG = 0x87U;	/* ch2 tips */
			NR51_REG = 0x33U;	/* sound on */
			if(dtmf_on)
				delay(dtmf_on);	/* keep on */

			NR51_REG = 0x00U;	/* sound off */
			if(dtmf_off)
				delay(dtmf_off);/* keep off */

		skip:
			i++;
		}
		if(pause_time)
			delay(pause_time);
	}
}

void ccitttone(UWORD dtmf_on, UWORD dtmf_off, char str[MAX_DTMF])
{
	UWORD i, j;

	for(j = 0;j < rpt_time;j++){
		i = 0;
		while(str[i]){
			switch(str[i]){
		    	case '1':
					NR13_REG = F1;
					NR23_REG = F2;
				break;
				case '2':
					NR13_REG = F1;
					NR23_REG = F3;
				break;
				case '3':
					NR13_REG = F2;
					NR23_REG = F3;
				break;
				case '4':
					NR13_REG = F1;
					NR23_REG = F4;
				break;
				case '5':
					NR13_REG = F2;
					NR23_REG = F4;
				break;
				case '6':
					NR13_REG = F3;
					NR23_REG = F4;
				break;
				case '7':
					NR13_REG = F1;
					NR23_REG = F5;
				break;
				case '8':
					NR13_REG = F2;
					NR23_REG = F5;
				break;
				case '9':
					NR13_REG = F3;
					NR23_REG = F5;
				break;
				case '0':
					NR13_REG = F4;
					NR23_REG = F5;
				break;
				case '-':
				break;
				case ',':
					if(dtmf_on)
						delay(dtmf_on);	/* keep on */
					if(dtmf_off)
						delay(dtmf_off);/* keep off */

				default:
					NR51_REG = 0x00U;	/* sound off */
					goto skip;

			}
			NR24_REG = 0x87U;	/* ch2 tips */
			NR51_REG = 0x33U;	/* sound on */
			if(dtmf_on)
				delay(dtmf_on);	/* keep on */

			NR51_REG = 0x00U;	/* sound off */
			if(dtmf_off)
				delay(dtmf_off);/* keep off */

		skip:
			i++;
		}
		if(pause_time)
			delay(pause_time);
	}
}

void start_sound(UBYTE f1, UBYTE f2)
{
	NR13_REG = f1;
	NR23_REG = f2;
	NR24_REG = 0x87U;

	/* sound output on */
	NR51_REG = 0x33U;
}

void pause_sound(UWORD on_duration, UWORD off_duration)
{
	if(on_duration)
		delay(on_duration);
	/* sound output off */
	NR51_REG = 0x00U;
	if(off_duration)
		delay(off_duration);

}


void coin_sound(UBYTE coin)
{
	int i;

	switch(coin){
		case NICKLE:
			start_sound(F7, F6);
			pause_sound(NICKLE_TIME, NICKLE_TIME);
		break;
		case DIME:
			for(i = 0;i < 2;i++){
				start_sound(F7, F6);
				pause_sound(DIME_TIME, DIME_TIME);
			}
		break;
		case QUARTER:
			for(i = 0;i < 5;i++){
				start_sound(F7, F6);
				pause_sound(QUARTER_TIME, QUARTER_TIME);
			}
		break;
	}
}


/* Display looks like 7-SEGMENT LED */
void disp_lcd(UBYTE len, char str[MAX_DTMF])
{
	UBYTE i,j;

	j = len;

	i=0;
	while(str[i]){
		if(str[i] >= '0'||'9' <= str[i]){
			disp_tile[i] = OFFSET + (str[i] - '0') * 2;
			disp_tile[i+j] = OFFSET + (str[i] - '0') * 2 + 1;
		}
		switch(str[i]){
			case 'A':
				disp_tile[i] = OFFSET + 10 * 2;
				disp_tile[i+j] = OFFSET + 10 * 2 + 1;
			break;
			case 'B':
				disp_tile[i] = OFFSET + 11 * 2;
				disp_tile[i+j] = OFFSET + 11 * 2 + 1;
			break;
			case 'C':
				disp_tile[i] = OFFSET + 12 * 2;
				disp_tile[i+j] = OFFSET + 12 * 2 + 1;
			break;
			case 'D':
				disp_tile[i] = OFFSET + 13 * 2;
				disp_tile[i+j] = OFFSET + 13 * 2 + 1;
			break;
			case '#':
				disp_tile[i] = OFFSET + 14 * 2;
				disp_tile[i+j] = OFFSET + 14 * 2 + 1;
			break;
			case '*':
				disp_tile[i] = OFFSET + 15 * 2;
				disp_tile[i+j] = OFFSET + 15 * 2 + 1;
			break;
			case ' ':
				disp_tile[i] = OFFSET + 16 * 2;
				disp_tile[i+j] = OFFSET + 16 * 2 + 1;
			break;
			case 'Y':
				disp_tile[i] = OFFSET + 17 * 2;
				disp_tile[i+j] = OFFSET + 17 * 2 + 1;
			break;
			case 'M':
				disp_tile[i] = OFFSET + 18 * 2;
				disp_tile[i+j] = OFFSET + 18 * 2 + 1;
			break;
			case 'U':
				disp_tile[i] = OFFSET + 19 * 2;
				disp_tile[i+j] = OFFSET + 19 * 2 + 1;
			break;
			case 'G':
				disp_tile[i] = OFFSET + 20 * 2;
				disp_tile[i+j] = OFFSET + 20 * 2 + 1;
			break;
			case '-':
				disp_tile[i] = OFFSET + 21 * 2;
				disp_tile[i+j] = OFFSET + 21 * 2 + 1;
			break;
			case 'T':
				disp_tile[i] = OFFSET + 22 * 2;
				disp_tile[i+j] = OFFSET + 22 * 2 + 1;
			break;
			case ',':
				disp_tile[i] = OFFSET + 23 * 2;
				disp_tile[i+j] = OFFSET + 23 * 2 + 1;
			break;
			case 'F':
				disp_tile[i] = OFFSET + 24 * 2;
				disp_tile[i+j] = OFFSET + 24 * 2 + 1;
			break;
			case 'S':
				disp_tile[i] = OFFSET + ('5' - '0') * 2;
				disp_tile[i+j] = OFFSET + ('5' - '0') * 2 + 1;
			break;
			case 'N':
				disp_tile[i] = OFFSET + 25 * 2;
				disp_tile[i+j] = OFFSET + 25 * 2 + 1;
			break;
			case 'E':
				disp_tile[i] = OFFSET + 26 * 2;
				disp_tile[i+j] = OFFSET + 26 * 2 + 1;
			break;
			case 'R':
				disp_tile[i] = OFFSET + 27 * 2;
				disp_tile[i+j] = OFFSET + 27 * 2 + 1;
			break;
			case 'P':
				disp_tile[i] = OFFSET + 28 * 2;
				disp_tile[i+j] = OFFSET + 28 * 2 + 1;
			break;
			case 'H':
				disp_tile[i] = OFFSET + 29 * 2;
				disp_tile[i+j] = OFFSET + 29 * 2 + 1;
			break;
			case 'K':
				disp_tile[i] = OFFSET + 30 * 2;
				disp_tile[i+j] = OFFSET + 30 * 2 + 1;
			break;
			case '_':
				disp_tile[i] = OFFSET + 31 * 2;
				disp_tile[i+j] = OFFSET + 31 * 2 + 1;
			break;
			case 'I':
				disp_tile[i] = OFFSET + 32 * 2;
				disp_tile[i+j] = OFFSET + 32 * 2 + 1;
			break;
			case 'W':
			    disp_tile[i] = OFFSET + 33 * 2;
			    disp_tile[i+j] = OFFSET + 33 * 2 + 1;
			break;
			case 'L':
			    disp_tile[i] = OFFSET + 34 * 2;
			    disp_tile[i+j] = OFFSET + 34 * 2 + 1;
			break;
			case 'V':
			    disp_tile[i] = OFFSET + 35 * 2;
			    disp_tile[i+j] = OFFSET + 35 * 2 + 1;
			break;
		}
		i++;
	}
}

/* clear display */
void clr_disp()
{
	set_bkg_tiles(LCD_X, LCD_Y, LCD_WIDTH, LCD_HIGHT, init_disp);
}

/*
	CAUTION: Don't display the NULL code
*/
void disp(char str[MAX_DTMF])
{
	UBYTE no, left_pos;
	UBYTE i, start_ch, end_ch;
	char work[MAX_DTMF];

	clr_disp();

	no = 0;
	while(str[no]){
		no++;
	}

	if(no == NULL)
		return;

	if(no >= LCD_WIDTH){
		start_ch = no - LCD_WIDTH;
		end_ch = LCD_WIDTH;
	}
	else{
		start_ch = 0;
		end_ch = no;
	}
	for(i = 0;i < end_ch;i++){
		work[i] = str[i+start_ch];
	}
	work[end_ch] = 0x00;

	disp_lcd(end_ch, work);

	left_pos = 19 - end_ch;
	set_bkg_tiles(left_pos, LCD_Y, end_ch, LCD_HIGHT, disp_tile);
}

UBYTE flash_disp(UBYTE flash_no, UWORD on_time, UWORD off_time, char str[MAX_DTMF])
{
    UBYTE i;
    for(i = 0;i <= flash_no;i++){
        disp(str);
        delay(on_time);
        clr_disp();
        delay(off_time);
    }
    
    return flash_no;
}

UBYTE ticker(char tickerStr[MAX_DTMF], UWORD tickerSpeed)
{
    UBYTE i, j, strLen, startPos, endPos;
    char workStr[MAX_DTMF];
    
    startPos = endPos = strLen = 0;

    while(tickerStr[strLen]){
        strLen++;
    }
    
    while(!joypad()){
        for(i = startPos;i <= endPos;i++){
            workStr[i - startPos] = tickerStr[i];
        }
        workStr[i] = 0x00;

        disp(workStr);
        delay(tickerSpeed);
        
//        if((startPos < LCD_WIDTH) && (endPos <= strLen)){
        if(startPos < LCD_WIDTH){	//mod
            endPos++;
        }
//        if((endPos > LCD_WIDTH) && (endPos >= strLen)){
        if(endPos >= LCD_WIDTH){	//mod
            startPos++;
        }
//        if(startPos >= strLen) ){
        if(startPos >= LCD_WIDTH ){	//mod
            startPos = 0;
            endPos = 0;
        }
    
    }


    return 1;
}

/*
	3 button size
	1 x 1
	1 x 2
	1 x 4
*/
void press_button(UBYTE x, UBYTE y, UBYTE area)
{
	switch (area){
		case 0:
		  set_bkg_tiles(x, y, 2, 2, press_tile_1x1);
		  break;
		case 1:
		  set_bkg_tiles(x, y, 4, 2, press_tile_2x1);
		  break;
		case 2:
		  set_bkg_tiles(x, y, 8, 2, press_tile_4x1);
		  break;
	}
}

void break_button(UBYTE x, UBYTE y, UBYTE area)
{
	switch (area){
		case 0:
		  set_bkg_tiles(x, y, 2, 2, break_tile_1x1);
		  break;
		case 1:
		  set_bkg_tiles(x, y, 4, 2, break_tile_2x1);
		  break;
		case 2:
		  set_bkg_tiles(x, y, 8, 2, break_tile_4x1);
		  break;
	}
}


void init_key()
{
	UBYTE key_x, key_y, i, j;

	/* To make numeric KeyPad */
	set_sprite_data(0, CURSOR_OBJ, key_num);
	set_sprite_palette( 0, 1, pBkgPalette );

	/* key pad 1 - 3 */
	key_y = KEY_STEP + KEY_OFFSET_Y;
	for(i = 1;i <= 3;i++){
		key_x = i * KEY_STEP + KEY_OFFSET_X;
		set_sprite_tile(i, i);
		move_sprite(i, key_x, key_y);
	}

	/* key pad 4 - 6 */
	key_y = KEY_STEP * 2 + KEY_OFFSET_Y;
	for(i = 4;i <= 6;i++){
		key_x = (i - 3) * KEY_STEP + KEY_OFFSET_X;
		set_sprite_tile(i, i);
		move_sprite(i, key_x, key_y);
	}

	/* key pad 7 - 9 */
	key_y = KEY_STEP * 3 + KEY_OFFSET_Y;
		for(i = 7;i <= 9;i++){
			key_x = (i - 6) * KEY_STEP + KEY_OFFSET_X;
			set_sprite_tile(i, i);
			move_sprite(i, key_x, key_y);
		}

	/* key pad 'A' - 'D' */
	key_x = KEY_STEP * 4 + KEY_OFFSET_X;
	for(i = 0;i <= 3;i++){
		key_y = (i+1) * KEY_STEP + KEY_OFFSET_Y;
		set_sprite_tile(i+10, i+10);
		move_sprite(i+10, key_x, key_y);
	}

	/* key pad '*', '0', '#' */
	set_sprite_tile(15, 15);
	move_sprite(15, KEY_STEP * 1 + KEY_OFFSET_X, KEY_STEP * 4 + KEY_OFFSET_Y);
	set_sprite_tile(0, 0);
	move_sprite( 0, KEY_STEP * 2 + KEY_OFFSET_X, KEY_STEP * 4 + KEY_OFFSET_Y);
	set_sprite_tile(14, 14);
	move_sprite(14, KEY_STEP * 3 + KEY_OFFSET_X, KEY_STEP * 4 + KEY_OFFSET_Y);

	/* key pad 'E' */
	set_sprite_tile(16, 16);
	move_sprite(16, KEY_STEP * 4 + KEY_OFFSET_X, KEY_STEP * 5 + KEY_OFFSET_Y);
	
	/* func BS */
	set_sprite_tile(17, 17);
	move_sprite(17, KEY_STEP * 3 + KEY_OFFSET_X, KEY_STEP * 5 + KEY_OFFSET_Y);
	
	/* func ',' */
	set_sprite_tile(18, 18);
	move_sprite(18, KEY_STEP * 1 + KEY_OFFSET_X, KEY_STEP * 6 + KEY_OFFSET_Y);

	/* keypad 'F' */
	set_sprite_tile(19, 19);
	move_sprite(19, KEY_STEP * 4 + KEY_OFFSET_X, KEY_STEP * 6 + KEY_OFFSET_Y);


	/* func MODE */

	/* dialing button */
	set_sprite_tile(20, 20);
	move_sprite(20, KEY_STEP + KEY_STEP / 2 + KEY_OFFSET_X, KEY_STEP * 5 + KEY_OFFSET_Y);

	/* func Config. */
	set_sprite_tile(21, 21);
	move_sprite(21, KEY_STEP * 3 + KEY_OFFSET_X, KEY_STEP * 6 + KEY_OFFSET_Y);

	/* CCITT 2 6 0 0 */
	for(i = 0;i < 2;i++){
		set_sprite_tile(22 + i, 22 + i);
		move_sprite(22 + i, KEY_STEP / 2 * (i + 12) + KEY_OFFSET_X + 4, KEY_STEP * 1 + KEY_OFFSET_Y);
	}
	
	/* CCITT KP */
	set_sprite_tile(24, 24);
	move_sprite(24, KEY_STEP * 7 + KEY_OFFSET_X - 8, KEY_STEP * 2 + KEY_OFFSET_Y);

	
	/* CCITT ST */
	set_sprite_tile(25, 25);
	move_sprite(25, KEY_STEP * 7 + KEY_OFFSET_X - 8, KEY_STEP * 3 + KEY_OFFSET_Y);
	
	
	/* CCITT STp */
	for(i = 0;i < 2;i++){
		set_sprite_tile(26 + i, 26 + i);
		move_sprite(26 + i, KEY_STEP / 2 * (i + 11) + KEY_OFFSET_X - 4, KEY_STEP * 4 + KEY_OFFSET_Y);
	}
	
	/* CCITT ST2p */
	set_sprite_tile(28, 28);
	move_sprite(28, KEY_STEP / 2 * 11 + KEY_OFFSET_X, KEY_STEP * 5 + KEY_OFFSET_Y);
	
	
	/* CCITT ST3p */
	set_sprite_tile(29, 29);
	move_sprite(29, KEY_STEP / 2 * 11 + KEY_OFFSET_X, KEY_STEP * 6 + KEY_OFFSET_Y);
	
	
	/* CCITT 5cent */
	for(i = 0;i < 2;i++){
		set_sprite_tile(30 + i, 30 + i);
		move_sprite(30 + i, KEY_STEP / 2 * (i + 15) + KEY_OFFSET_X - 4, KEY_STEP * 4 + KEY_OFFSET_Y);
	}
	
	/* CCITT 10cent */
	for(i = 0;i < 2;i++){
		set_sprite_tile(32 + i, 32 + i);
		move_sprite(32 + i, KEY_STEP / 2 * (i + 15) + KEY_OFFSET_X - 4, KEY_STEP * 5 + KEY_OFFSET_Y);
	}
	
	/* CCITT 25cent */
	for(i = 0;i < 2;i++){
		set_sprite_tile(34 + i, 34 + i);
		move_sprite(34 + i, KEY_STEP / 2 * (i + 15) + KEY_OFFSET_X - 4, KEY_STEP * 6 + KEY_OFFSET_Y);
	}


}

void init_bkg()
{
	/* Initialize the background */
	set_bkg_data( 0, 9, frame_lcd);
	set_bkg_data( 9, 9, break_btn);
	set_bkg_data(18, 9, press_btn);

	set_bkg_data(OFFSET, 72, dtmf_lcd);

    set_bkg_tiles(0, 0, 20, 18, dtmf_tile);

	set_bkg_palette( 0, 1, pBkgPalette );	// 20010330
}

void init_cursor()
{
	UBYTE i;

	/* Setup the cursor data*/
	set_sprite_data(CURSOR_OBJ, CURSOR_OBJ + CURSOR_SIZE, cursor_data);

	for(i = CURSOR_OBJ;i < CURSOR_OBJ + CURSOR_SIZE;i++){
		set_sprite_tile(i, i);
	}
}

void move_cursor(UBYTE x, UBYTE y)
{
	move_sprite(CURSOR_OBJ, x, y);
	move_sprite(CURSOR_OBJ + 1, x, y+8);
	move_sprite(CURSOR_OBJ + 2, x+8, y);
	move_sprite(CURSOR_OBJ + 3, x+8, y+8);
}

//add(move)
void disp_init()
{
	disable_interrupts();

	DISPLAY_OFF;	//add
	
	SPRITES_8x8;   /* sprites are 8x8 */

	init_dial();
	
	init_bkg();
	
	init_key();

	init_cursor();

    disp(gStr);

	SHOW_BKG;
	SHOW_SPRITES;
	DISPLAY_ON;

	enable_interrupts();
}
//end add(move)

UWORD str02num()
{
	return (((gWorkStr[0] - '0') * 100UL) + ((gWorkStr[1] - '0') * 10UL) + (gWorkStr[2] - '0'));
}

UWORD str04num(char st2num[5])
{
	return (((st2num[0] - '0') * 1000UL) + ((st2num[1] - '0') * 100UL) + ((st2num[2] - '0') * 10UL) + (st2num[3] - '0'));
}

void num04str(UWORD number)

{
  UWORD m;
  UBYTE i, n, f;

  f = 0; m = 1000;
  for( i=0; i<4; i++ ) {
    n = number / m; number = number % m; m = m / 10;
    if( (n==0)&&(f==0) ) {
      gWorkStr[i] = 0x30;      /* '0' */
    } else {
      f = 1;
      gWorkStr[i] = 0x30+n;    /* '0' - '9' */
    }
  }
}



void config_ph(char ch)
{
	char work[30];

	switch(config_st){
		/* on time setting */
		case 0:
			on_str[0] = ch;
			strcpy(work, CON_MSG2);
			strcat(work, on_str);
			disp(work);
		break;
		case 1:
			on_str[1] = ch;
			strcpy(work, CON_MSG2);
			strcat(work, on_str);
			disp(work);
		break;
		case 2:
			on_str[2] = ch;
			on_str[3] = 0x00;
			strcpy(work, CON_MSG2);
			strcat(work, on_str);
			disp(work);

			strcpy(gWorkStr, on_str);
			on_time = str02num();
			delay(500);

			/* For the next step */
			strcpy(work, CON_MSG3);
			strcat(work, off_str);
			disp(work);
		break;

		/* off_time setting */
		case 3:
			off_str[0] = ch;
			strcpy(work, CON_MSG3);
			strcat(work, off_str);
			disp(work);
		break;
		case 4:
			off_str[1] = ch;
			strcpy(work, CON_MSG3);
			strcat(work, off_str);
			disp(work);
		break;
		case 5:
			off_str[2] = ch;
			off_str[3] = 0x00;
			strcpy(work, CON_MSG3);
			strcat(work, off_str);
			disp(work);
			
			strcpy(gWorkStr, off_str);
			off_time = str02num();
			delay(500);

			/* For the next step */
			strcpy(work, CON_MSG4);
			strcat(work, rpt_str);
			disp(work);
		break;

		/* repeat setting */
		case 6:
			rpt_str[0] = ch;
			strcpy(work, CON_MSG4);
			strcat(work, rpt_str);
			disp(work);
		break;
		case 7:
			rpt_str[1] = ch;
			strcpy(work, CON_MSG4);
			strcat(work, rpt_str);
			disp(work);
		break;
		case 8:
			rpt_str[2] = ch;
			rpt_str[3] = 0x00;
			strcpy(work, CON_MSG4);
			strcat(work, rpt_str);
			disp(work);
			
			strcpy(gWorkStr, rpt_str);
			rpt_time = str02num();
			delay(500);

			/* For the next step */
			strcpy(work, CON_MSG5);
			strcat(work, pause_str);
			disp(work);
		break;

		/* pause setting */
		case 9:
			pause_str[0] = ch;
			strcpy(work, CON_MSG5);
			strcat(work, pause_str);
			disp(work);
		break;
		case 10:
			pause_str[1] = ch;
			strcpy(work, CON_MSG5);
			strcat(work, pause_str);
			disp(work);
		break;
		case 11:
			pause_str[2] = ch;
			pause_str[3] = 0x00;
			strcpy(work, CON_MSG5);
			strcat(work, pause_str);
			disp(work);

			strcpy(gWorkStr, pause_str);
			pause_time = str02num();
			delay(500);
		break;

	}
	config_st++;
	if(config_st >= CONFIG_LIMIT){
		config_st = NORMAL;
		mode_excute = NORMAL;
		disp(CON_MSG6);
		delay(1000);
		disp(gStr);
	}
}
void parm_init()
{
	/* default dialling time setting */
	on_time = DTMF_ON;
	strcpy(on_str, "050");
	
	off_time = DTMF_OFF;
	strcpy(off_str, "050");
	
	rpt_time = 1;
	strcpy(rpt_str, "001");
	
	pause_time = 99;
	strcpy(pause_str, "099");

	config_st = NORMAL;
	mode_excute = NORMAL;
	disp_mode = DISP_DTMF;
	
}

#include "pdcdialing.c"

#include "level.c"


void main()
{
	UBYTE key1, key2, i, j, pos_x, pos_y, button_x, button_y;
	UBYTE non_flick = OFF;

	char work[20];
	char pad_key;

	UWORD BsLongPress, ConfigLongPress, BLongPress;
	
	BsLongPress = LONG_KEY_PRESS_TIME;
	ConfigLongPress = LONG_KEY_PRESS_TIME;

	BLongPress = LONG_KEY_PRESS_TIME;

	parm_init();

    strcpy(gStr, TITLE);
	disp_init();	//add(move)

    ticker(TITLE, 100);
    disp(TITLE);

	i = j = 0;

	gChPos = 0;
	
    set_gb232( SPEED_600 | DATA_8 | STOP_1 | PARITY_EVEN );
    init_gb232();
	send_gb232(PDC_SERVICE_START);	// make PDC service connection
	
	move_cursor(i * KEY_STEP + START_CURSOR_X, j * KEY_STEP + START_CURSOR_Y);		// cursor appear
	
	while(1) {
		delay(10);
//		wait_vbl_done();
		key1 = joypad();
		pad_key = pad[j][i];
		button_x = i * 2;
		button_y = j * 2 + 5;

		if(key1 != key2){
			pos_x = i * KEY_STEP + START_CURSOR_X;
			pos_y = j * KEY_STEP + START_CURSOR_Y;
			move_cursor(pos_x, pos_y);
		}

	/*
		KEY status
		
		-----------+            +-----------
             ^     |            |   ^
             |     |            |   |
             |     |            |   |
             |     +------------+   |
             |     ^      ^     ^   |
             |     |      |     |   +-------
             |     |      |     +-----------
             |     |      +-----------------
             |     +------------------------
             +------------------------------
             
    */
		if(key2 & J_A){
			if(key1 & J_A){
				switch (pad_key){
				/* We can not make matrix pattern at CCITT 5 as like as DTMF */
				/* Also we have to define a each digit with two combination Fx */
					case '0':
						switch (disp_mode){
						  	case DISP_CCITT:
								start_sound(F4, F5);
							break;
							default:
						  		start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '1':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F1, F2);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '2':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F1, F3);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '3':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F2, F3);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '4':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F1, F4);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '5':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F2, F4);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '6':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F3, F4);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '7':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F1, F5);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '8':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F2, F5);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case '9':
						switch (disp_mode){
							case DISP_CCITT:
								start_sound(F3, F5);
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
						break;
					case 'A':
					case 'B':
					case 'C':
					case 'D':
					case '#':
					case '*':
						switch (disp_mode){
							case DISP_CCITT:
							break;
							default:
								start_sound(row_dtmf[j],col_dtmf[i - 2]);
							break;
						}
					break;
					
					// BS button
					case '-':
						// LongKeyPress supported
						if(!BsLongPress){		// Just time up !!
							if(!mode_excute){
								gChPos = 0x00;
								strcpy(gStr,"");
								clr_disp();
							}
						}
						else{
							BsLongPress--;		// Still pressed in continusly...
						}
						
					break;

					case '+':
						// LongKeyPress supported
						if(!ConfigLongPress){	// Just time up !!
							if(!mode_excute){
								disp(CON_MSG1);
								delay(1000);
								mode_excute = CONFIG;
								config_st = NORMAL;
								/* initialize variable */
								strcpy(on_str, "---");
								strcpy(off_str, "---");
								strcpy(rpt_str, "---");
								strcpy(pause_str, "---");
								strcpy(work, "");

								/* For the on time */
								strcat(work, CON_MSG2);
								strcat(work, on_str);
								disp(work);
							}
						}
						else{
							ConfigLongPress--;
						}
					break;

					case '?':
						/* appear the title during press A button */
						if(!mode_excute){
							if(!non_flick){
								switch(disp_mode){
									case DISP_DTMF:
										disp(DTMF);
									break;
									case DISP_CCITT:
										disp(CCITT);
									break;
									case DISP_WD:
										disp(WAR_DIAL);
									break;
									default:
									break;
								}

								delay(1000);
								strcpy(work, " ");
								strcat(work, on_str);
								
								strcat(work, " ");
								strcat(work, off_str);
								
								strcat(work, " ");
								strcat(work, rpt_str);
								
								strcat(work, " ");
								strcat(work, pause_str);
								
								strcat(work, " ");
								disp(work);
								non_flick = ON;
							}
						}
					break;
					case 'a':
					  /* frequncy register set up for CCITT 5 */
					  NR13_REG = F9;
					  NR23_REG = F9;
					  NR24_REG = 0x87U;

					  /* sound output on */
					  NR51_REG = 0x33U;
					break;
				}
			}
			
			/* Button is just re-leased */
			/* Make -> Break */
			else{
				/* sound output off */
				NR51_REG = 0x00U;
				switch (pad_key){
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
					case 'A':
					case 'B':
					case 'C':
					case 'D':
					case 'E':
					case 'F':
					case '#':
					case '*':
					case '-':
					case '%':
					case ',':
					  break_button(button_x, button_y, 0);
					break;

					case '?':
						break_button(button_x, button_y, 0);
						if(!mode_excute){
							non_flick = OFF;
							if(gChPos == 0)
								clr_disp();
							else
								disp(gStr);
						}
					break;

					case '+':
						break_button(button_x, button_y, 0);
						if(ConfigLongPress){
							disp_mode = !disp_mode;
						
							switch(disp_mode){
								case DISP_DTMF:
									disp(DTMF);
								break;
								case DISP_CCITT:
									disp(CCITT);
								break;
								case DISP_WD:
								break;
								default:
								break;
							}

							delay(1000);
							disp(gStr);
						}
					break;

					case 's':
					  break_button(4, 13, 1);
					break;
					
					/* 2600 button */
					case 'a':
						break_button(12, 5, 2);
					break;
					
					/* Kp button */
					case 'b':
						break_button(12, 7, 2);
					break;
					
					/* ST button */
					case 'c':
						break_button(12, 9, 2);
					break;
					
					/* STp button */
					case 'd':
						break_button(12, 11, 1);
					break;
					
					/* ST2p button */
					case 'e':
						break_button(12, 13, 1);
					break;
					
					/* ST3p button */
					case 'f':
						break_button(12, 15, 1);
					break;
					
					/* 5cent button */
					case 'g':
						break_button(16, 11, 1);
					break;
					
					/* 10cent button */
					case 'h':
						break_button(16, 13, 1);
					break;
					
					/* 25cent button */
					case 'i':
						break_button(16, 15, 1);
					break;


					/* Function key setting */
					// z
					case 'z':
						break_button(0,  5, 1);
					break;

					// y
					case 'y':
						break_button(0,  7, 1);
					break;

					// x
					case 'x':
						break_button(0,  9, 1);
					break;

					/* w */
					case 'w':
						break_button(0, 11, 1);
					break;

					/* v */
					case 'v':
						break_button(0, 13, 1);
					break;

					/* u */
					case 'u':
						break_button(0, 15, 1);
					break;
					
				}
			}
		}
		else{
			/* Just pressed */
			/* Break --> Make */
			if(key1 & J_A){
				switch (pad_key){
					case '0':
					case '1':
					case '2':
					case '3':
					case '4':
					case '5':
					case '6':
					case '7':
					case '8':
					case '9':
						press_button(button_x, button_y, 0);
						if(!mode_excute){
							/* string length check */
							if(gChPos < MAX_DTMF - 1){
								gStr[gChPos] = pad[j][i];
								gChPos++;
								gStr[gChPos] = 0x00;
								disp(gStr);
							}
						}
						else
							config_ph(pad[j][i]);
					break;
					case 'A':
					case 'B':
					case 'C':
					case 'D':
					case 'E':
					case 'F':
					case '#':
					case '*':
					case ',':
						press_button(button_x, button_y, 0);
						if(!mode_excute){
							/* string length check */
							if(gChPos < MAX_DTMF - 1){
								gStr[gChPos] = pad[j][i];
								gChPos++;
								gStr[gChPos] = 0x00;
								disp(gStr);
							}
						}
					break;

					/* BS button */
					case '-':
						press_button(button_x, button_y, 0);
						if(!mode_excute){
							if(gChPos > 0){
								gChPos--;
								gStr[gChPos] = 0x00;
								if(gChPos == 0)
									clr_disp();
								else
									disp(gStr);
							}
						}
						BsLongPress = LONG_KEY_PRESS_TIME;
					break;

					/* ? button */
					case '?':
						press_button(button_x, button_y, 0);
						send_gb232(PDC_ON_HOOK);
					break;

					/* Config button */
					case '+':
						press_button(button_x, button_y, 0);
						ConfigLongPress = LONG_KEY_PRESS_TIME;
					break;

				 	/* dialing button */
					case 's':
						press_button(4, 13, 1);

						switch(disp_mode){
							case DISP_DTMF:
							    // Dialing PDC
        						send_gb232(PDC_OFF_HOOK);
		        				send_gb232(PDC_DIAL_OK);
				        		pdc_dialing(gStr);
						        send_gb232(PDC_DIAL_END);

								dialtone(on_time, off_time, gStr);
							break;
							case DISP_CCITT:
								ccitttone(on_time, off_time, gStr);
							break;
							case DISP_WD:
								wd_disp();

							break;
							default:
							break;
						}
					break;
					
					/* 2600 button */
					case 'a':
						press_button(12, 5, 2);
					break;
					
					/* Kp button */
					case 'b':
						press_button(12, 7, 2);
						start_sound(F3, F6);
						pause_sound(SOUND_ON, SOUND_ON);
					break;
					
					/* ST button */
					case 'c':
						press_button(12, 9, 2);
						start_sound(F5, F6);
						pause_sound(SOUND_ON, SOUND_ON);
					break;
					
					/* STp button */
					case 'd':
						press_button(12, 11, 1);
						start_sound(F2, F6);
						pause_sound(SOUND_ON, SOUND_ON);
					break;
					
					/* ST2p button */
					case 'e':
						press_button(12, 13, 1);
						start_sound(F4, F6);
						pause_sound(SOUND_ON, SOUND_ON);
					break;
					
					/* ST3p button */
					case 'f':
						press_button(12, 15, 1);
						start_sound(F1, F6);
						pause_sound(SOUND_ON, SOUND_ON);
					break;

					/* 5cent button */
					case 'g':
						press_button(16, 11, 1);
						coin_sound(NICKLE);
					break;

					/* 10cent button */
					case 'h':
						press_button(16, 13, 1);
						coin_sound(DIME);
					break;

					/* 25cent button */
					case 'i':
						press_button(16, 15, 1);
						coin_sound(QUARTER);
					break;


					/* Function key setting */
					// z
					// Receive Level
					case 'z':
						press_button(0,  5, 1);
                        radio_level();
                        disp_init();
					break;

					// y
					case 'y':
//						press_button(0,  7, 1);
					break;

					// x
					// Reserved
					case 'x':
//						press_button(0,  9, 1);
					break;

					/* w */
					// Reserved
					case 'w':
//						press_button(0, 11, 1);
					break;

					/* v */
					/* Answering machine cracking */
					case 'v':
						press_button(0, 13, 1);
						parm_init();
						on_time = 20;
						strcpy(on_str, "020");
						
						off_time = 0;
						strcpy(off_str, "000");
						
						rpt_time = 4;
						strcpy(rpt_str, "004");
						
						pause_time = 99;
						strcpy(pause_str, "099");
						
						strcpy(gStr, "1234567890");
						gChPos = 10;
						disp(gStr);
					break;

					/* u */
					/* fastest dialing setting */
					case 'u':
						press_button(0, 15, 1);
						parm_init();
						on_time = 25;
						strcpy(on_str, "025");
						
						off_time = 35;
						strcpy(off_str, "035");
					break;
					default:
					break;
					
				}
			}
		}

		if(key2 & J_B){
			if(key1 & J_B){
				// LongKeyPress supported
				if(!BLongPress){		// Just time up !!
					parm_init();
					disp(gStr);
				}
				else{
					BLongPress--;		// Still pressed in continusly...
				}
			}
			else{
			}
		}
		else{
			if(key1 & J_B){
				BLongPress = LONG_KEY_PRESS_TIME;
			}
			else{
			}
		}

		if(!(key1 & J_A)){
			if((key1 & J_UP) && !(key2 & J_UP) && j > 0)
				j--;
			else if((key1 & J_DOWN) && !(key2 & J_DOWN) && j < UNIT_SIZE_Y)
				j++;

			if((key1 & J_LEFT) && !(key2 & J_LEFT) && i > 0)
				i--;
			else if((key1 & J_RIGHT) && !(key2 & J_RIGHT) && i < UNIT_SIZE_X)
				i++;
		}
		key2 = key1;
	}
}
