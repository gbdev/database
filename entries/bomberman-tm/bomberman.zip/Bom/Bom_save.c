/********************************************************************
 * BOMBERMAN           																							*
 *	by																															*
 * T.M																															*
 ********************************************************************/
#include<gb.h>

UBYTE save_stage[3], save_speed[3], save_power[3];
UBYTE save_max_bomb[3],	save_item[3];
UWORD high_score;
