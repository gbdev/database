/********************************************************************
 * BOMBERMAN																												*
 *	by																															*
 * T.M																															*
 ********************************************************************/

#include <gb.h>
#include <rand.h>

/* system */
#define EMPTY			0xFFU		/* que empty */
#define NONE_TILE		0xF0U		/* none tile */

/* pmode */
#define MODE_TITLE		0U			/* title */
#define MODE_GAME		1U			/* game */
#define MODE_DIE		2U			/* player die */
#define MODE_OVER		3U			/* game over */
#define MODE_CLEAR		4U			/* stage clear */
#define MODE_ENDING		5U			/* ending */

/* max speed */
#define	MAX_SPEED		4U			/* max speed */

/* bomb */
#define MAX_TT			16U			/* number */
#define BOM_LIMIT		100U		/* bomb limiter */
#define MAX_POW			16U			/* bomb power max */

/* enemy */
#define MAX_ET			8U			/* number */
#define TM_WALK			0U			/* walk */
#define TM_REPEAT		1U			/* repeat */
#define TM_RUN			2U			/* run away */
#define TM_AIM			3U			/* aim player */
#define TM_STOP			4U			/* stop */

/* item */
#define GETTED			255U		/* When getting item, it is set in item_type */
#define RESET			254U		/* When setting item, it is set in item_type */
#define	FIREBARRIER		1U			/* When getting fire barrier, it is set in pmuteki */
#define	MUTEKI			2U			/* When getting ?, it is set in pmuteki */

/* map attrib */
#define ITEMS			0x04 		/* all items */
#define FIRES			0x08 		/* all fires */
#define BOMBS			0x10 		/* all bombs */
#define BREAKABLEBLOCKS	0x20 		/* all breakable blocks */
#define UNMOVABLE		0x40 		/* movable */

/* map */
#define MPSIZE_X			62U									/* max map x*2 */
#define MPSIZE_Y			30U									/* max map y*2 */
#define FLOOR				 0U									/* floor */
#define DOOR				 1U									/* door */
#define ITEM				ITEMS								/* item */
#define HIDDEN_ITEM			ITEMS + 1U							/* hidden item */
#define FIRE            	FIRES 								/* fire center */
#define FIREH           	FIRES + 1U							/* fire horizontal */
#define FIREV           	FIRES + 2U							/* fire vertical */
#define BOMBUNDERPLAYER		BOMBS								/* bomb under player = walkable */
#define UNBREAKABLEBLOCK	UNMOVABLE							/* unbreakable block */
#define BOMB				UNMOVABLE + BOMBS					/* bomb */
#define BREAKABLEBLOCK		UNMOVABLE + BREAKABLEBLOCKS			/* breakable block */
#define BREAKINGBLOCK		UNMOVABLE + BREAKABLEBLOCKS + FIRES	/* breaking block */

extern unsigned char anim_tiles[12][4];
extern unsigned char bkg_tiles[];
extern unsigned char bkg_attr[];
extern unsigned char *map_tiles[];
extern unsigned char *map_attr[];
extern unsigned char *fire_tiles[11][8];

extern unsigned char BomCGB[];
extern unsigned char time_tile[3], score_tile[5];
extern UBYTE pstat, pstage, pcnt, pspeed, ppower, premocon, pthroblock, pthrobomb, pmuteki;
extern UBYTE inbomb_flg, clear_flg, old_tile, time_cnt, wait_cnt;
extern UBYTE scpx, scpy;
extern UWORD scx, scy, px, py, x, y, pscore, high_score, old_time;
extern UBYTE num_bomb, max_bomb;
extern UBYTE num_teki, num_dieteki, bx_left, bx_right;
extern UBYTE map[MPSIZE_X][MPSIZE_Y];
extern UBYTE item_x, item_y, item_type, item_time, hidden_item;
extern UBYTE door_x, door_y;
extern UBYTE BQue_start, BQue_end;
extern UBYTE EQue_start, EQue_end;
extern UBYTE TQue_start, TQue_end;
extern UBYTE i, j, k, l, key_wait1, key_wait2, key, key_flg, die_wait, pmode;
extern UBYTE BQue_x[MAX_TT], BQue_y[MAX_TT], BQue_stat[MAX_TT];
extern UBYTE BQue_limit[MAX_TT], BQue_prev[MAX_TT], BQue_next[MAX_TT];
extern UBYTE EQue_x[MAX_TT], EQue_y[MAX_TT], EQue_stat[MAX_TT];
extern UBYTE EQue_pow[MAX_TT], EQue_i[MAX_TT], EQue_flg[MAX_TT];
extern UBYTE EQue_left[MAX_TT], EQue_right[MAX_TT], EQue_up[MAX_TT], EQue_down[MAX_TT];
extern UBYTE EQue_edge_l[MAX_TT], EQue_edge_r[MAX_TT], EQue_edge_u[MAX_TT], EQue_edge_d[MAX_TT];
extern UBYTE EQue_prev[MAX_TT], EQue_next[MAX_TT];
extern UWORD TQue_x[MAX_ET], TQue_y[MAX_ET];
extern UBYTE TQue_stat1[MAX_ET], TQue_stat2[MAX_ET], TQue_type[MAX_ET], TQue_move[MAX_ET];
extern UBYTE TQue_prev[MAX_ET], TQue_next[MAX_ET], TQue_score[MAX_ET], TQue_mode[MAX_ET];
extern UBYTE bonus_stage_teki[];

UWORD score_keta[]={1,10,100,1000,10000};
UBYTE stage[]={
	//<--   enemy   -->/door enemy/item/hidden item/unused/
	0x00,0x00,0x00,0x00,0x01,0x00,
	0x00,0x00,0x01,0x11,0x00,0x00,
	0x00,0x00,0x11,0x12,0x02,0x00,
	0x00,0x11,0x12,0x23,0x14,0x00,
	0x11,0x12,0x23,0x44,0x10,0x10,
	0x11,0x11,0x33,0x44,0x11,0x00,
	0x11,0x22,0x22,0x44,0x15,0x00,
	0x00,0x11,0x22,0x33,0x20,0x00,
	0x01,0x11,0x22,0x44,0x23,0x00,
	0x01,0x33,0x33,0x44,0x04,0x30,	//10
	0x11,0x11,0x22,0x44,0x25,0x00,
	0x11,0x11,0x22,0x33,0x23,0x00,
	0x01,0x22,0x33,0x34,0x30,0x10,
	0x11,0x22,0x23,0x44,0x44,0x00,
	0x11,0x12,0x22,0x45,0x15,0x30,
	0x01,0x23,0x34,0x44,0x33,0x00,
	0x01,0x11,0x22,0x44,0x34,0x00,
	0x11,0x12,0x22,0x45,0x05,0x40,
	0x11,0x12,0x22,0x44,0x10,0x00,
	0x01,0x11,0x22,0x44,0x43,0x20,	//20
	0x01,0x22,0x44,0x44,0x14,0x00,
	0x12,0x22,0x34,0x55,0x45,0x00,
	0x12,0x22,0x33,0x44,0x43,0x00,
	0x12,0x23,0x33,0x45,0x23,0x00,
	0x12,0x33,0x34,0x45,0x40,0x00,
	0x22,0x33,0x44,0x46,0x31,0x10,
	0x11,0x22,0x34,0x46,0x54,0x00,
	0x11,0x22,0x34,0x55,0x53,0x00,
	0x12,0x23,0x34,0x56,0x60,0x30,
	0x12,0x33,0x34,0x55,0x55,0x00,	//30
	0x13,0x34,0x44,0x55,0x56,0x00,
	0x00,0x02,0x35,0x56,0x60,0x70,
	0x12,0x23,0x35,0x56,0x44,0x20,
	0x02,0x23,0x35,0x56,0x56,0x00,
	0x23,0x24,0x45,0x56,0x51,0x50,
	0x12,0x24,0x45,0x66,0x73,0x00,
	0x23,0x24,0x55,0x66,0x64,0x00,
	0x22,0x34,0x45,0x66,0x60,0x00,
	0x23,0x45,0x55,0x66,0x77,0x60,
	0x23,0x33,0x55,0x67,0x46,0x40,	//40
	0x22,0x44,0x45,0x66,0x53,0x30,
	0x23,0x35,0x55,0x66,0x66,0x70,
	0x23,0x45,0x46,0x67,0x64,0x00,
	0x23,0x44,0x55,0x67,0x65,0x80,
	0x23,0x44,0x45,0x67,0x73,0x00,
	0x33,0x34,0x56,0x66,0x77,0x60,
	0x33,0x45,0x66,0x67,0x74,0x00,
	0x34,0x45,0x55,0x77,0x70,0x70,
	0x33,0x45,0x66,0x77,0x76,0x80,
	0x45,0x56,0x67,0x77,0x77,0x50	//50
};

UWORD absw( WORD );
void set_bkg_attr( UBYTE, UBYTE, UBYTE, UBYTE, unsigned char *);
void set_bkg_tiles2( UBYTE, UBYTE, UBYTE, UBYTE, unsigned char *);
void score_up( UWORD, UBYTE );
void set_hidden_item( UBYTE );
void istTekiQue( UWORD, UWORD, UBYTE );

void set_sprite_attrb( UBYTE nb, UBYTE tile )
{
	if( _cpu==CGB_TYPE ) {
		set_sprite_prop( nb, tile );
	}
}

UBYTE make_rnd( UBYTE i )
{
	return( arand()%i );
}

void istBombQue()
{
	//���eQUE�̑}��
	for(i=0;i<MAX_TT;i++)
		if(BQue_prev[i]==EMPTY) break;		
	if(BQue_start==EMPTY) {
		BQue_start = i;
		BQue_prev[i] = i;
	} else {
		BQue_prev[i] = BQue_end;
		BQue_next[BQue_end] = i;
	}
	BQue_next[i] = EMPTY;
	BQue_end=i;
	BQue_x[i]=((px-16UL)>>4U)&0xFE;
	BQue_y[i]=((py-16UL)>>4U)&0xFE;
	BQue_stat[i]=0;
	if(premocon==FALSE) {
		BQue_limit[i]=BOM_LIMIT;
	} else {
		BQue_limit[i]=255U;
	}
	set_bkg_attr( BQue_x[i], BQue_y[i], 2U, 2U, map_attr[BOMBS]);
	map[BQue_x[i]][BQue_y[i]]=BOMBUNDERPLAYER;	//�ʍs�\���e�i�ꎞ�I�j
	num_bomb++;
}

UBYTE delBombQue( UBYTE i )
{
	//���eQUE�̍폜
	num_bomb--;
	if(i==BQue_start) {
		if(i==BQue_end) {
			BQue_start=EMPTY;
			BQue_end=EMPTY;
			j=EMPTY;
		} else {
			BQue_prev[BQue_next[i]]=BQue_next[i];
			BQue_start=BQue_next[i];
			j=BQue_start;
		}
	} else {
		if(i==BQue_end) {
			BQue_end=BQue_prev[i];
		} else {
			BQue_prev[BQue_next[i]]=BQue_prev[i];
		}
		BQue_next[BQue_prev[i]]=BQue_next[i];
		j=BQue_next[i];
	}
	BQue_prev[i]=EMPTY;
	BQue_next[i]=EMPTY;
	set_bkg_attr( BQue_x[i], BQue_y[i], 2U, 2U, map_attr[FLOOR]);

	return(j);
}

void istExplQue( UBYTE i ) 
{
	//����QUE�̑}��
	for(j=0;j<MAX_TT;j++)
		if(EQue_prev[j]==EMPTY) break;
	if(EQue_start==EMPTY) {
		EQue_start = j;
		EQue_prev[j] = j;
	} else {
		EQue_prev[j] = EQue_end;
		EQue_next[EQue_end] = j;
	}
	EQue_next[j] = EMPTY;
	EQue_end=j;
	EQue_x[j]=BQue_x[i];
	EQue_y[j]=BQue_y[i];
	EQue_stat[j]=0U;
	EQue_pow[j]=ppower;
	EQue_i[j]=0U;
	EQue_flg[j]=0U;
	if(map[BQue_x[i]][BQue_y[i]]==BOMBUNDERPLAYER) inbomb_flg=FALSE;
	map[BQue_x[i]][BQue_y[i]]=FIRE;
	//�����̍��[������
	EQue_edge_l[j]=1U;
	for(k=2U;k<=EQue_pow[j];k+=2U)
		//�j��s�ǂ��邢�͔��������E���̏ꍇ
		if((map[EQue_x[j]-k][EQue_y[j]]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]-k][EQue_y[j]]==FIRE)||
			(map[EQue_x[j]-k][EQue_y[j]]==FIREH)) {	
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=2U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]-k][EQue_y[j]]&BOMBS)==BOMBS) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=2U;
			for(l=0;(((EQue_x[j]-k)!=BQue_x[l])||((EQue_y[j])!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]-k][EQue_y[j]]&ITEMS)==ITEMS) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=10U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]-k][EQue_y[j]]==DOOR) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=11U;
			break;
		} else {
			EQue_left[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]-k][EQue_y[j]]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_l[j]=9U;
				break;
			}
		}
	//�����̉E�[������
	EQue_edge_r[j]=5U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǂ��邢�͔��������E���̏ꍇ
		if((map[EQue_x[j]+k][EQue_y[j]]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]+k][EQue_y[j]]==FIRE)||
			(map[EQue_x[j]+k][EQue_y[j]]==FIREH)) {	
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=6U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]+k][EQue_y[j]]&BOMBS)==BOMBS) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=6U;
			for(l=0;(((EQue_x[j]+k)!=BQue_x[l])||((EQue_y[j])!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]+k][EQue_y[j]]&ITEMS)==ITEMS) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=14U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]+k][EQue_y[j]]==DOOR) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=15U;
			break;
		} else {
			EQue_right[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]+k][EQue_y[j]]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_r[j]=9U;
				break;
			}
		}
	//�����̏�[������
	EQue_edge_u[j]=7U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǂ��邢�͔��������E�c�̏ꍇ
		if((map[EQue_x[j]][EQue_y[j]-k]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]][EQue_y[j]-k]==FIRE)||
			(map[EQue_x[j]][EQue_y[j]-k]==FIREV)) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=8U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]-k]&BOMBS)==BOMBS) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=8U;
			for(l=0;((EQue_x[j]!=BQue_x[l])||(((EQue_y[j]-k))!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]-k]&ITEMS)==ITEMS) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=12U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]][EQue_y[j]-k]==DOOR) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=13U;
			break;
		} else {
			EQue_up[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]][EQue_y[j]-k]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_u[j]=9U;
				break;
			}
		}
	//�����̉��[������
	EQue_edge_d[j]=3U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǂ��邢�͔��������E�c�̏ꍇ
		if((map[EQue_x[j]][EQue_y[j]+k]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]][EQue_y[j]+k]==FIRE)||
			(map[EQue_x[j]][EQue_y[j]+k]==FIREV)) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=4U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]+k]&BOMBS)==BOMBS) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=4U;
			for(l=0;((EQue_x[j]!=BQue_x[l])||(((EQue_y[j]+k))!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]+k]&ITEMS)==ITEMS) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=16U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]][EQue_y[j]+k]==DOOR) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=17U;
			break;
		} else {
			EQue_down[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]][EQue_y[j]+k]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_d[j]=9U;
				break;
			}
		}
	s_play(4);
}

void istExplQueDirect() 
{
	//����QUE�̑}��
	for(j=0;j<MAX_TT;j++)
		if(EQue_prev[j]==EMPTY) break;
	if(EQue_start==EMPTY) {
		EQue_start = j;
		EQue_prev[j] = j;
	} else {
		EQue_prev[j] = EQue_end;
		EQue_next[EQue_end] = j;
	}
	EQue_next[j] = EMPTY;
	EQue_end=j;
	EQue_x[j]=((px-16UL)>>4U)&0xFE;
	EQue_y[j]=((py-16UL)>>4U)&0xFE;
	EQue_stat[j]=0U;
	EQue_pow[j]=ppower;
	EQue_i[j]=0U;
	EQue_flg[j]=0U;
	map[EQue_x[j]][EQue_y[j]]=FIRE;
	//�����̍��[������
	EQue_edge_l[j]=1U;
	for(k=2U;k<=EQue_pow[j];k+=2U)
		//�j��s�ǁE�j�󒆕ǂ̏ꍇ
		if((map[EQue_x[j]-k][EQue_y[j]]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]-k][EQue_y[j]]==BREAKINGBLOCK)) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=2U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]-k][EQue_y[j]]&BOMBS)==BOMBS) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=2U;
			for(l=0;(((EQue_x[j]-k)!=BQue_x[l])||((EQue_y[j])!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]-k][EQue_y[j]]&ITEMS)==ITEMS) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=10U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]-k][EQue_y[j]]==DOOR) {
			EQue_left[j]=k-2U;
			EQue_edge_l[j]=11U;
			break;
		} else {
			EQue_left[j]=k;
			//�j��\�ǂ̏ꍇ
			if(map[EQue_x[j]-k][EQue_y[j]]==BREAKABLEBLOCK) {
				EQue_edge_l[j]=9U;
				break;
			}
		}
	//�����̉E�[������
	EQue_edge_r[j]=5U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǁE�j�󒆕ǂ̏ꍇ
		if((map[EQue_x[j]+k][EQue_y[j]]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]+k][EQue_y[j]]==BREAKINGBLOCK)) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=6U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]+k][EQue_y[j]]&BOMBS)==BOMBS) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=6U;
			for(l=0;(((EQue_x[j]+k)!=BQue_x[l])||((EQue_y[j])!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]+k][EQue_y[j]]&ITEMS)==ITEMS) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=14U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]+k][EQue_y[j]]==DOOR) {
			EQue_right[j]=k-2U;
			EQue_edge_r[j]=15U;
			break;
		} else {
			EQue_right[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]+k][EQue_y[j]]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_r[j]=9U;
				break;
			}
		}
	//�����̏�[������
	EQue_edge_u[j]=7U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǁE�j�󒆕ǂ̏ꍇ
		if((map[EQue_x[j]][EQue_y[j]-k]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]][EQue_y[j]-k]==BREAKINGBLOCK)) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=8U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]-k]&BOMBS)==BOMBS) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=8U;
			for(l=0;((EQue_x[j]!=BQue_x[l])||(((EQue_y[j]-k))!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]-k]&ITEMS)==ITEMS) {
			EQue_up[j]=k-2U;
			EQue_edge_u[j]=12U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]][EQue_y[j]-k]==DOOR) {
				EQue_up[j]=k-2U;
			EQue_edge_u[j]=13U;
			break;
		} else {
			//�j��\�ǂ̏ꍇ
			EQue_up[j]=k;
			if((map[EQue_x[j]][EQue_y[j]-k]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_u[j]=9U;
				break;
			}
		}
	//�����̉��[������
	EQue_edge_d[j]=3U;
	for(k=2;k<=EQue_pow[j];k+=2)
		//�j��s�ǁE�j�󒆕ǂ̏ꍇ
		if((map[EQue_x[j]][EQue_y[j]+k]==UNBREAKABLEBLOCK)||
			(map[EQue_x[j]][EQue_y[j]+k]==BREAKINGBLOCK)) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=4U;
			break;
		//���e�̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]+k]&BOMBS)==BOMBS) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=4U;
			for(l=0;((EQue_x[j]!=BQue_x[l])||(((EQue_y[j]+k))!=BQue_y[l]));l++);
			BQue_limit[l]=(k-2U)/6U+3U;
			break;
		//�A�C�e���̏ꍇ
		} else if((map[EQue_x[j]][EQue_y[j]+k]&ITEMS)==ITEMS) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=16U;
			break;
		//���̏ꍇ
		} else if(map[EQue_x[j]][EQue_y[j]+k]==DOOR) {
			EQue_down[j]=k-2U;
			EQue_edge_d[j]=17U;
			break;
		} else {
			EQue_down[j]=k;
			//�j��\�ǂ̏ꍇ
			if((map[EQue_x[j]][EQue_y[j]+k]&BREAKABLEBLOCKS)==BREAKABLEBLOCKS) {
				EQue_edge_d[j]=9U;
				break;
			}
		}
	s_play(4);
}

UBYTE delExplQue( UBYTE j ) 
{
	//����QUE�̍폜
	if(j==EQue_start) {
		if(j==EQue_end) {
			EQue_start=EMPTY;
			EQue_end=EMPTY;
			k=EMPTY;
		} else {
			EQue_prev[EQue_next[j]]=EQue_next[j];
			EQue_start=EQue_next[j];
			k=EQue_start;
		}
	} else {
		if(j==EQue_end) {
			EQue_end=EQue_prev[j];
		} else {
			EQue_prev[EQue_next[j]]=EQue_prev[j];
		}	
		EQue_next[EQue_prev[j]]=EQue_next[j];
		k=EQue_next[j];
	}
	//�j�󂵂��ǂ̏���
	if(EQue_edge_l[j]==9U) 
		if((door_x==(EQue_x[j]-EQue_left[j]))&&(door_y==EQue_y[j])) {
			map[EQue_x[j]-EQue_left[j]][EQue_y[j]]=DOOR;
			set_bkg_attr(EQue_x[j]-EQue_left[j], EQue_y[j], 2U, 2U, map_attr[DOOR]);
			set_bkg_tiles2(EQue_x[j]-EQue_left[j], EQue_y[j], 2U, 2U, map_tiles[DOOR]);
		} else if((item_x==(EQue_x[j]-EQue_left[j]))&&(item_y==EQue_y[j])) {
			map[EQue_x[j]-EQue_left[j]][EQue_y[j]]=ITEM;
			set_bkg_attr(EQue_x[j]-EQue_left[j], EQue_y[j], 2U, 2U, map_attr[ITEM]);
			set_bkg_tiles2(EQue_x[j]-EQue_left[j], EQue_y[j], 2U, 2U, map_tiles[ITEM]);
		} else {
			map[EQue_x[j]-EQue_left[j]][EQue_y[j]]=FLOOR;
		}
	if(EQue_edge_r[j]==9U)
		if((door_x==(EQue_x[j]+EQue_right[j]))&&(door_y==EQue_y[j])) {
			map[EQue_x[j]+EQue_right[j]][EQue_y[j]]=DOOR;
			set_bkg_attr(EQue_x[j]+EQue_right[j], EQue_y[j], 2U, 2U, map_attr[DOOR]);
			set_bkg_tiles2(EQue_x[j]+EQue_right[j], EQue_y[j], 2U, 2U, map_tiles[DOOR]);
		} else if((item_x==(EQue_x[j]+EQue_right[j]))&&(item_y==EQue_y[j])) {
			map[EQue_x[j]+EQue_right[j]][EQue_y[j]]=ITEM;
			set_bkg_attr(EQue_x[j]+EQue_right[j], EQue_y[j], 2U, 2U, map_attr[ITEM]);
			set_bkg_tiles2(EQue_x[j]+EQue_right[j], EQue_y[j], 2U, 2U, map_tiles[ITEM]);
		} else {
			map[EQue_x[j]+EQue_right[j]][EQue_y[j]]=FLOOR;
		}
	if(EQue_edge_u[j]==9U)
		if((door_x==EQue_x[j])&&(door_y==(EQue_y[j]-EQue_up[j]))) {
			map[EQue_x[j]][EQue_y[j]-EQue_up[j]]=DOOR;
			set_bkg_attr(EQue_x[j], EQue_y[j]-EQue_up[j], 2U, 2U, map_attr[DOOR]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]-EQue_up[j], 2U, 2U, map_tiles[DOOR]);
		} else if((item_x==EQue_x[j])&&(item_y==(EQue_y[j]-EQue_up[j]))) {
			map[EQue_x[j]][EQue_y[j]-EQue_up[j]]=ITEM;
			set_bkg_attr(EQue_x[j], EQue_y[j]-EQue_up[j], 2U, 2U, map_attr[ITEM]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]-EQue_up[j], 2U, 2U, map_tiles[ITEM]);
		} else {
			map[EQue_x[j]][EQue_y[j]-EQue_up[j]]=FLOOR;
		}
	if(EQue_edge_d[j]==9U)
		if((door_x==EQue_x[j])&&(door_y==(EQue_y[j]+EQue_down[j]))) {
			map[EQue_x[j]][EQue_y[j]+EQue_down[j]]=DOOR;
			set_bkg_attr(EQue_x[j], EQue_y[j]+EQue_down[j], 2U, 2U, map_attr[DOOR]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]+EQue_down[j], 2U, 2U, map_tiles[DOOR]);
		} else if((item_x==EQue_x[j])&&(item_y==(EQue_y[j]+EQue_down[j]))) {
			map[EQue_x[j]][EQue_y[j]+EQue_down[j]]=ITEM;
			set_bkg_attr(EQue_x[j], EQue_y[j]+EQue_down[j], 2U, 2U, map_attr[ITEM]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]+EQue_down[j], 2U, 2U, map_tiles[ITEM]);
		} else {
			map[EQue_x[j]][EQue_y[j]+EQue_down[j]]=FLOOR;
		}
	EQue_prev[j]=EMPTY;
	EQue_next[j]=EMPTY;
	map[EQue_x[j]][EQue_y[j]]=FLOOR;

	//��or�A�C�e���𔚔j�����ꍇ�A�G�ǉ�
	if(EQue_edge_l[j]>=10U) {
		if(hidden_item==0x60) {
			set_hidden_item(1);
		}
		while(num_teki<MAX_ET)
			istTekiQue((EQue_x[j]-EQue_left[j])*8UL,(EQue_y[j]+2U)*8UL,stage[pstage*6UL-2UL]>>4);
		if(EQue_edge_l[j]==10U) {
			map[EQue_x[j]-EQue_left[j]-2U][EQue_y[j]]=FLOOR;
			set_bkg_attr(EQue_x[j]-EQue_left[j]-2U, EQue_y[j], 2U, 2U, map_attr[FLOOR]);
			set_bkg_tiles2(EQue_x[j]-EQue_left[j]-2U, EQue_y[j], 2U, 2U, map_tiles[FLOOR]);
		}
	}
	if(EQue_edge_r[j]>=14U) {
		if(hidden_item==0x60) {
			set_hidden_item(1);
		}
		while(num_teki<MAX_ET)
			istTekiQue((EQue_x[j]+EQue_right[j]+4U)*8UL,(EQue_y[j]+2U)*8UL,stage[pstage*6UL-2UL]>>4);
		if(EQue_edge_r[j]==14U) {
			map[EQue_x[j]+EQue_right[j]+2U][EQue_y[j]]=FLOOR;
			set_bkg_attr(EQue_x[j]+EQue_right[j]+2U, EQue_y[j], 2U, 2U, map_attr[FLOOR]);
			set_bkg_tiles2(EQue_x[j]+EQue_right[j]+2U, EQue_y[j], 2U, 2U, map_tiles[FLOOR]);
		}
	}
	if(EQue_edge_u[j]>=12U) {
		if(hidden_item==0x60) {
			set_hidden_item(1);
		}
		while(num_teki<MAX_ET)
			istTekiQue((EQue_x[j]+2U)*8UL,(EQue_y[j]-EQue_up[j])*8UL,stage[pstage*6UL-2UL]>>4);
		if(EQue_edge_u[j]==12U) {
			map[EQue_x[j]][EQue_y[j]-EQue_up[j]-2U]=FLOOR;
			set_bkg_attr(EQue_x[j], EQue_y[j]-EQue_up[j]-2U, 2U, 2U, map_attr[FLOOR]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]-EQue_up[j]-2U, 2U, 2U, map_tiles[FLOOR]);
		}
	}
	if(EQue_edge_d[j]>=16U) {
		if(hidden_item==0x60) {
			set_hidden_item(1);
		}
		while(num_teki<MAX_ET)
			istTekiQue((EQue_x[j]+2U)*8UL,(EQue_y[j]+EQue_down[j]+4U)*8UL,stage[pstage*6UL-2UL]>>4);
		if(EQue_edge_d[j]==16U) {
			map[EQue_x[j]][EQue_y[j]+EQue_down[j]+2U]=FLOOR;
			set_bkg_attr(EQue_x[j], EQue_y[j]+EQue_down[j]+2U, 2U, 2U, map_attr[FLOOR]);
			set_bkg_tiles2(EQue_x[j], EQue_y[j]+EQue_down[j]+2U, 2U, 2U, map_tiles[FLOOR]);
		}
	}
	return(k);
}

void istTekiQue( UWORD x, UWORD y, UBYTE t ) 
{
	//�GQUE�̑}��
	for(i=0;i<MAX_ET;i++)
		if(TQue_prev[i]==EMPTY) break;		
	if(TQue_start==EMPTY) {
		TQue_start = i;
		TQue_prev[i] = i;
	} else {
		TQue_prev[i] = TQue_end;
		TQue_next[TQue_end] = i;
	}
	TQue_next[i] = EMPTY;
	TQue_end=i;
	TQue_x[i]=x;
	TQue_y[i]=y;
	TQue_stat1[i]=0;
	TQue_move[i]=4;
	TQue_mode[i]=0;
	TQue_type[i]=t;
	num_teki++;
	clear_flg=FALSE;
	set_sprite_attrb((i<<1)+2U, BomCGB[TQue_type[i]] );	 set_sprite_attrb((i<<1)+3U, BomCGB[TQue_type[i]] );
}

UBYTE delTekiQue( UBYTE i )
{
	//�GQUE�̍폜
	num_teki--;
	num_dieteki--;
	if(i==TQue_start) {
		if(i==TQue_end) {
			TQue_start=EMPTY;
			TQue_end=EMPTY;
			j=EMPTY;
			if((time_cnt>=140U)&&(hidden_item>=0x70)) {
				set_hidden_item(1);
			}
		} else {
			TQue_prev[TQue_next[i]]=TQue_next[i];
			TQue_start=TQue_next[i];
			j=TQue_start;
		}
	} else {
		if(i==TQue_end) {
			TQue_end=TQue_prev[i];
		} else {
			TQue_prev[TQue_next[i]]=TQue_prev[i];
		}	
		TQue_next[TQue_prev[i]]=TQue_next[i];
		j=TQue_next[i];
	}
	TQue_prev[i]=EMPTY;
	TQue_next[i]=EMPTY;
	TQue_x[i]=0;
	if(TQue_score[i]<=3) {
		score_up(1U<<(TQue_score[i]&0x03),1);
	} else {
		score_up((1U<<(TQue_score[i]&0x03))*score_keta[TQue_score[i]>>2U],1);
	}
	//�{�[�i�X�X�e�[�W�̏ꍇ�A�����ɓG�ǉ�
	if(pstage>=0x80) {
		while(1) {
			x=make_rnd(MPSIZE_X>>1)*16UL;
			y=make_rnd(MPSIZE_Y>>1)*16UL;
			if((map[x>>3][y>>3]==FLOOR)&&((absw((px>>1)-x)>96U)||(absw((py>>1)-y)>80U))) {
				istTekiQue(x+16UL,y+16UL,bonus_stage_teki[(pstage-0x86)/5]);
				break;
			}
		};
	} 
	return(j);
}

void make_stage()
{
	UBYTE teki[8];

	//������
	BQue_start=EMPTY; BQue_end=EMPTY;
	EQue_start=EMPTY; EQue_end=EMPTY;
	TQue_start=EMPTY; TQue_end=EMPTY;
	for(i=0;i<MAX_TT;i++) {
		BQue_prev[i]=EMPTY;
		EQue_prev[i]=EMPTY;
	}
	for(i=0;i<MAX_ET;i++) {
		TQue_prev[i]=EMPTY;
		set_sprite_tile( i+(MAX_ET<<1U)+2U, 0xF0U);
	}
	//�j��s�u���b�N�z�u
	for( i=0; i!=MPSIZE_Y; i+=2 ) {
		for( j=0; j!=MPSIZE_X; j+=2 ) {
			if( (i==0)||(i==(MPSIZE_Y - 2U))) {
				map[j][i] = UNBREAKABLEBLOCK;
			} else if( (j==0)||(j==(MPSIZE_X - 2U))) {
				map[j][i] = UNBREAKABLEBLOCK;
			} else if( (!(i&2))&&(!(j&2)) ) {
				map[j][i] = UNBREAKABLEBLOCK;
			} else {
				map[j][i] = FLOOR;
			}
		}
	}
	//�ʏ�X�e�[�W
	if(pstage<0x80) {
		//�j��\�u���b�N�z�u
		i=0;
		l=48U+pstage;
		if(pstage>35U) {
			l+=(max_bomb+ppower);
		}
		while(i!=l) {
			j=make_rnd(MPSIZE_X)&0xFE;
			k=make_rnd(MPSIZE_Y)&0xFE;
			if((map[j][k]==FLOOR)&&((j!=2U)||(k!=2U))) {
				map[j][k]=BREAKABLEBLOCK;
				i++;
			}
		};
		map[4][2]=FLOOR; map[2][4]=FLOOR;
		//���z�u
		while(1) {
			j=make_rnd(MPSIZE_X)&0xFE;
			k=make_rnd(MPSIZE_Y)&0xFE;
			if((map[j][k]==BREAKABLEBLOCK)&&((j>8U)||(k>8U))) {
				door_x=j;
				door_y=k;
				break;
			}
		};
		//�A�C�e���z�u
		if((item_type!=GETTED)||((stage[pstage*6UL-2UL]&0x0F)>5U)) {
			while(1) {
				j=make_rnd(MPSIZE_X)&0xFE;
				k=make_rnd(MPSIZE_Y)&0xFE;
				if((map[j][k]==BREAKABLEBLOCK)&&((j>8U)||(k>8U))&&((door_x!=j)||(door_y!=k))) {
					item_x=j;
					item_y=k;
					item_type=stage[pstage*6UL-2UL]&0x0F;
					break;
				}
			};
		} else {
			item_x=0;
			item_y=0;
		}
		//�B���A�C�e���ݒ�
		hidden_item=stage[pstage*6UL-1UL]&0xF0;
		time_cnt=201U;
		pmuteki=0;
		for(i=0;i<4U;i++) {
			teki[(i<<1)]=stage[(pstage-1)*6UL+i]>>4;
			teki[(i<<1)+1]=stage[(pstage-1)*6UL+i]&0x0F;
		}
	} else {
		//�{�[�i�X�X�e�[�W
		time_cnt=31U;
		pmuteki=MUTEKI;
		for(i=0;i<8U;i++) {
			teki[i]=bonus_stage_teki[(pstage-0x86)/5];
		}
	}
	//�G�z�u
	bx_left=0;bx_right=30;
	num_teki=0;num_dieteki=0;
	while(num_teki<MAX_ET) {
		x=make_rnd(MPSIZE_X>>1)*16UL;
		y=make_rnd(MPSIZE_Y>>1)*16UL;
		if((map[x>>3][y>>3]==FLOOR)&&((x>100U)||(y>100U))) istTekiQue(x+16UL,y+16UL,teki[num_teki]);
	};
	BGP_REG=0xE4;	//11 10 01 00
	//�w�i�`��
	for( i=0; i!=30; i+=2 ) {
		for( j=0; j!=32; j+=2 ) {
			set_bkg_tiles2( j, i, 2, 2, map_tiles[map[j][i]]);
			set_bkg_attr( j, i, 2, 2, map_attr[map[j][i]]);
		}
	}
	px = 64UL; py = 64UL; pstat = 0U; scx = 0U; scy = 0U;
	num_bomb=0U; inbomb_flg=FALSE; 
	old_time=sys_time-60UL; item_time=0;
	set_sprite_tile( 0, 0x02U ); set_sprite_tile( 1, 0x00U );
	set_sprite_prop( 0, S_FLIPX ); set_sprite_prop( 1, S_FLIPX );
	move_sprite( 0, (px>>1U)-8U, py>>1U );	move_sprite( 1, px>>1U, py>>1U );
	score_up(0,1);
	SHOW_BKG;
	SHOW_SPRITES;
	SHOW_WIN;

	if(pstage<0x80) {
		m_play(3,1);
	} else
		m_play(7,1);
}
