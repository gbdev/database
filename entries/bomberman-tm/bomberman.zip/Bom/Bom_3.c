/********************************************************************
 * BOMBERMAN                                                        *
 *  by                                                              *
 * T.M                                                              *
 ********************************************************************/

#include <gb.h>
#include <rand.h>

/* system */
#define EMPTY			0xFFU		/* que empty */
#define NONE_TILE		0xF0U		/* none tile */

/* pmode */
#define MODE_TITLE		0U			/* title */
#define MODE_GAME		1U			/* game */
#define MODE_DIE		2U			/* player die */
#define MODE_OVER		3U			/* game over */
#define MODE_CLEAR		4U			/* stage clear */
#define MODE_ENDING		5U			/* ending */

/* max speed */
#define	MAX_SPEED		4U			/* max speed */

/* bomb */
#define MAX_TT			16U			/* number */
#define BOM_LIMIT		100U		/* bomb limiter */
#define MAX_POW			16U			/* bomb power max */

/* enemy */
#define MAX_ET			8U			/* number */
#define TM_WALK			0U			/* walk */
#define TM_REPEAT		1U			/* repeat */
#define TM_RUN			2U			/* run away */
#define TM_AIM			3U			/* aim player */
#define TM_STOP			4U			/* stop */

/* item */
#define GETTED			255U		/* When getting item, it is set in item_type */
#define RESET			254U		/* When setting item, it is set in item_type */
#define	FIREBARRIER		1U			/* When getting fire barrier, it is set in pmuteki */
#define	MUTEKI			2U			/* When getting ?, it is set in pmuteki */

/* map attrib */
#define ITEMS			0x04 		/* all items */
#define FIRES			0x08 		/* all fires */
#define BOMBS			0x10 		/* all bombs */
#define BREAKABLEBLOCKS	0x20 		/* all breakable blocks */
#define UNMOVABLE		0x40 		/* movable */

/* map */
#define MPSIZE_X			62U									/* max map x*2 */
#define MPSIZE_Y			30U									/* max map y*2 */
#define FLOOR				 0U									/* floor */
#define DOOR				 1U									/* door */
#define ITEM				ITEMS								/* item */
#define HIDDEN_ITEM			ITEMS + 1U							/* hidden item */
#define FIRE            	FIRES 								/* fire center */
#define FIREH           	FIRES + 1U							/* fire horizontal */
#define FIREV           	FIRES + 2U							/* fire vertical */
#define BOMBUNDERPLAYER		BOMBS								/* bomb under player = walkable */
#define UNBREAKABLEBLOCK	UNMOVABLE							/* unbreakable block */
#define BOMB				UNMOVABLE + BOMBS					/* bomb */
#define BREAKABLEBLOCK		UNMOVABLE + BREAKABLEBLOCKS			/* breakable block */
#define BREAKINGBLOCK		UNMOVABLE + BREAKABLEBLOCKS + FIRES	/* breaking block */

extern unsigned char fire_pattern[];
extern unsigned char BomCGB[];
extern unsigned char walk_anim[];
extern unsigned char teki_tile[];
extern unsigned char bkg_tiles[];
extern unsigned char bkg_attr[];
extern unsigned char *map_tiles[];
extern unsigned char *map_attr[];
extern unsigned char *fire_tiles[11][8];
extern unsigned char time_tile[3], score_tile[5];
extern UBYTE pstat, pstage, pcnt, pspeed, ppower, premocon, pthroblock, pthrobomb, pmuteki;
extern UBYTE inbomb_flg, clear_flg, old_tile, time_cnt, wait_cnt;
extern UBYTE scpx, scpy;
extern UWORD scx, scy, px, py, x, y, pscore, high_score, old_time;
extern UBYTE num_bomb, max_bomb;
extern UBYTE num_teki, num_dieteki, bx_left, bx_right;
extern UBYTE pstage, pspeed, ppower;
extern UWORD high_score;
extern UBYTE max_bomb;
extern UBYTE map[MPSIZE_X][MPSIZE_Y];
extern UBYTE item_x, item_y, item_type, item_time, hidden_item;
extern UBYTE door_x, door_y;
extern UBYTE BQue_start, BQue_end;
extern UBYTE EQue_start, EQue_end;
extern UBYTE TQue_start, TQue_end;
extern UBYTE i, j, k, l, key_wait1, key_wait2, key, key_flg, die_wait, pmode;
extern UBYTE tt,tx,ty,ts;
extern UBYTE BQue_x[MAX_TT], BQue_y[MAX_TT], BQue_stat[MAX_TT];
extern UBYTE BQue_limit[MAX_TT], BQue_prev[MAX_TT], BQue_next[MAX_TT];
extern UBYTE EQue_x[MAX_TT], EQue_y[MAX_TT], EQue_stat[MAX_TT];
extern UBYTE EQue_pow[MAX_TT], EQue_i[MAX_TT], EQue_flg[MAX_TT];
extern UBYTE EQue_left[MAX_TT], EQue_right[MAX_TT], EQue_up[MAX_TT], EQue_down[MAX_TT];
extern UBYTE EQue_edge_l[MAX_TT], EQue_edge_r[MAX_TT], EQue_edge_u[MAX_TT], EQue_edge_d[MAX_TT];
extern UBYTE EQue_prev[MAX_TT], EQue_next[MAX_TT];
extern UWORD TQue_x[MAX_ET], TQue_y[MAX_ET];
extern UBYTE TQue_stat1[MAX_ET], TQue_stat2[MAX_ET], TQue_type[MAX_ET], TQue_move[MAX_ET];
extern UBYTE TQue_prev[MAX_ET], TQue_next[MAX_ET], TQue_score[MAX_ET], TQue_mode[MAX_ET];
BYTE direct_x[]={0,2,0,-2,0}, direct_y[]={-2,0,2,0,0};
BYTE direct2_x[]={0,-2,0,2,-2,-2,2,2,0,-4,0,4,-4,-4,4,4};
BYTE direct2_y[]={2,0,-2,0,2,-2,-2,2,4,0,-4,0,4,-4,-4,4};
UBYTE teki_aim_rate[]={2,3,4,0,3,3,2,6};
UBYTE teki_speed[]={1,1,1,2,1,1,2,2};

UWORD absw( WORD );
void set_bkg_tiles2( UBYTE, UBYTE, UBYTE, UBYTE, unsigned char *);
void m_play( UBYTE, UBYTE );
void s_play( UBYTE );

/* explosion sub*/
void explosion_sub()
{
	//�������S
	set_bkg_tiles2( EQue_x[j], EQue_y[j], 2, 2, fire_tiles[0][EQue_stat[j]]);
	map[EQue_x[j]][EQue_y[j]]=FIRE;
	do {
		EQue_i[j]+=2;
		//������
		if(EQue_i[j]<=EQue_left[j]) {
			if(EQue_i[j]==EQue_left[j]) {
				set_bkg_attr( EQue_x[j]-EQue_i[j], EQue_y[j], 2, 2, map_attr[0]);
				set_bkg_tiles2( EQue_x[j]-EQue_i[j], EQue_y[j], 2, 2, fire_tiles[fire_pattern[EQue_edge_l[j]]][EQue_stat[j]]);
			} else {
				set_bkg_tiles2( EQue_x[j]-EQue_i[j], EQue_y[j], 2, 2, fire_tiles[2][EQue_stat[j]]);
			}
			if((EQue_edge_l[j]!=9U)||(EQue_i[j]!=EQue_left[j])) {							
				if(EQue_stat[j]!=7U) {
					map[EQue_x[j]-EQue_i[j]][EQue_y[j]]=FIREH;
				} else {
					map[EQue_x[j]-EQue_i[j]][EQue_y[j]]=FLOOR;
				}
			} else {
				map[EQue_x[j]-EQue_i[j]][EQue_y[j]]=BREAKINGBLOCK;
			}
		}
    	//�����E
		if(EQue_i[j]<=EQue_right[j]) {
			if(EQue_i[j]==EQue_right[j]) {
				set_bkg_attr( EQue_x[j]+EQue_i[j], EQue_y[j], 2, 2, map_attr[0]);
				set_bkg_tiles2( EQue_x[j]+EQue_i[j], EQue_y[j], 2, 2, fire_tiles[fire_pattern[EQue_edge_r[j]]][EQue_stat[j]]);
			} else {
				set_bkg_tiles2( EQue_x[j]+EQue_i[j], EQue_y[j], 2, 2, fire_tiles[6][EQue_stat[j]]);
			}
			if((EQue_edge_r[j]!=9U)||(EQue_i[j]!=EQue_right[j])) {							
				if(EQue_stat[j]!=7U) {
					map[EQue_x[j]+EQue_i[j]][EQue_y[j]]=FIREH;
				} else {
					map[EQue_x[j]+EQue_i[j]][EQue_y[j]]=FLOOR;
				}
			} else {
				map[EQue_x[j]+EQue_i[j]][EQue_y[j]]=BREAKINGBLOCK;
			}
		}
		//������
		if(EQue_i[j]<=EQue_up[j]) {
			if(EQue_i[j]==EQue_up[j]) {
				set_bkg_attr( EQue_x[j], EQue_y[j]-EQue_i[j], 2, 2, map_attr[0]);
				set_bkg_tiles2( EQue_x[j], EQue_y[j]-EQue_i[j], 2, 2, fire_tiles[fire_pattern[EQue_edge_u[j]]][EQue_stat[j]]);
			} else {
				set_bkg_tiles2( EQue_x[j], EQue_y[j]-EQue_i[j], 2, 2, fire_tiles[8][EQue_stat[j]]);
			}
			if((EQue_edge_u[j]!=9U)||(EQue_i[j]!=EQue_up[j])) {							
				if(EQue_stat[j]!=7U) {
					map[EQue_x[j]][EQue_y[j]-EQue_i[j]]=FIREV;
				} else {
					map[EQue_x[j]][EQue_y[j]-EQue_i[j]]=FLOOR;
				}
			} else {
				map[EQue_x[j]][EQue_y[j]-EQue_i[j]]=BREAKINGBLOCK;
			}
		}
		//������
		if(EQue_i[j]<=EQue_down[j]) {
			if(EQue_i[j]==EQue_down[j]) {
				set_bkg_attr( EQue_x[j], EQue_y[j]+EQue_i[j], 2, 2, map_attr[0]);
				set_bkg_tiles2( EQue_x[j], EQue_y[j]+EQue_i[j], 2, 2, fire_tiles[fire_pattern[EQue_edge_d[j]]][EQue_stat[j]]);
			} else {
				set_bkg_tiles2( EQue_x[j], EQue_y[j]+EQue_i[j], 2, 2, fire_tiles[4][EQue_stat[j]]);
			}
			if((EQue_edge_d[j]!=9U)||(EQue_i[j]!=EQue_down[j])) {							
				if(EQue_stat[j]!=7U) {
					map[EQue_x[j]][EQue_y[j]+EQue_i[j]]=FIREV;
				} else {
					map[EQue_x[j]][EQue_y[j]+EQue_i[j]]=FLOOR;
				}
			} else {
				map[EQue_x[j]][EQue_y[j]+EQue_i[j]]=BREAKINGBLOCK;
			}
		}
	} while((EQue_i[j]!=EQue_pow[j])&&(EQue_i[j]!=6U)&&(EQue_i[j]!=12U));
	if(EQue_i[j]==EQue_pow[j]) {
		if((EQue_pow[j]<8U)&&(EQue_stat[j]!=7U)) {
			if(EQue_flg[j]==0) {
				EQue_flg[j]=1U;
			} else {
				EQue_stat[j]++;
				EQue_flg[j]=0;
			}
		} else {
			EQue_stat[j]++;
		}
		EQue_i[j]=0;
	}
}

/* enemy move while aim */
void enemy_aim_x()
{
	if((TQue_y[i]&0x000F)<=ts) {
		//�������ǂ�����
		if(TQue_x[i]>(px>>1)) {
			tx=((TQue_x[i]-16U-ts)>>3)&0xFE;
			ty=(TQue_y[i]>>3)-2U;
			if((map[tx][ty]<BOMBS)||
				((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
				TQue_y[i]&=0xFFF0;
				TQue_move[i]=(TQue_move[i]&0xF0)+3U;
				TQue_x[i]-=ts;
				j=1U;
			}
			//�������ǂ�����
		} else if(TQue_x[i]<(px>>1)) {
			tx=((TQue_x[i]+ts-1U)>>3)&0xFE;
			ty=(TQue_y[i]>>3)-2U;
			if((map[tx][ty]<BOMBS)||
				((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
				TQue_y[i]&=0xFFF0;
				TQue_move[i]=(TQue_move[i]&0xF0)+9U;
				TQue_x[i]+=ts;
				j=1U;
			}
		}
	}
}

void enemy_aim_y()
{
	if((TQue_x[i]&0x000F)<=ts) {
		//�������ǂ�����
		if(TQue_y[i]>(py>>1)) {
			tx=(TQue_x[i]>>3)-2U;
			ty=((TQue_y[i]-16U-ts)>>3)&0xFE;
			if((map[tx][ty]<BOMBS)||
				((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
				TQue_x[i]&=0xFFF0;
				TQue_move[i]=(TQue_move[i]&0xF8);
				TQue_y[i]-=ts;
				j=1U;
			}
		//�������ǂ�����
		} else if(TQue_y[i]<(py>>1)) {
			tx=(TQue_x[i]>>3)-2U;
			ty=((TQue_y[i]+ts-1U)>>3)&0xFE;
			if((map[tx][ty]<BOMBS)||
				((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
				TQue_x[i]&=0xFFF0;
				TQue_move[i]=(TQue_move[i]&0xF8)+2U;
				TQue_y[i]+=ts;
				j=1U;
			}
		}
	}
}

/* enemy move */
void enemy_move()
{
	if(TQue_stat1[i]<0x40U) {
		TQue_stat1[i]++;
		TQue_stat1[i]&=0x1FU;
		tt=TQue_type[i];
		ts=teki_speed[tt];
		if((tt!=4U)||((TQue_stat1[i]&0x01)==0)) {
			//��l���ǂ��������[�h�̏ꍇ
			if(TQue_mode[i]==TM_AIM) {
				j=0;
				TQue_move[i]+=0x10;
				if(absw(TQue_x[i]-(px>>1))>absw(TQue_y[i]-(py>>1))) {
					enemy_aim_x();
					if(j==0) {
						enemy_aim_y();
						if(j==0) {
							if(arand()<0x10) {
								TQue_mode[i]=TM_RUN;
							}
						}
					}
				} else {
					enemy_aim_y();
					if(j==0) {
						enemy_aim_x();
						if(j==0) {
							if(arand()<0x10) {
								TQue_mode[i]=TM_RUN;
							}
						}
					}
				}
				if(arand()<0x0A) {
					TQue_mode[i]=TM_RUN;
				}
			//�����Ȃ��ꍇ
			} else if(TQue_mode[i]==TM_STOP) {
				TQue_move[i]+=7U;
				j=TQue_move[i]&0x0F;
				if((map[(TQue_x[i]>>3)-2U+direct2_x[j]]
						[(TQue_y[i]>>3)-2U+direct2_y[j]]&FIRES)==FIRES) {
					TQue_mode[i]=TM_WALK;
					TQue_move[i]&=0x03;
				}
				//�g���H�̏ꍇ�A���ߋ����ɗ�����_��
				if((tt==6)&&(arand()<0x08)&&(absw(TQue_x[i]-(px>>1))<80UL)&&(absw(TQue_y[i]-(py>>1))<80UL)) {
					TQue_mode[i]=TM_AIM;
				} else if((arand()==0xFF)&&(arand()<0x10)) {
					TQue_mode[i]=TM_WALK;
				}
			} else {
				switch(TQue_move[i]&0x07) {
					case 0U:	//���ړ�
						tx=(TQue_x[i]>>3)-2U;
						ty=((TQue_y[i]-16U-ts)>>3)&0xFE;
						if((map[tx][ty]<BOMBS)||
							((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
							TQue_y[i]-=ts;
						} else {
							TQue_move[i]+=2U;
						}
						break;
					case 1U:	//���ړ�
						tx=((TQue_x[i]+ts-1U)>>3)&0xFE;
						ty=(TQue_y[i]>>3)-2U;
						if((map[tx][ty]<BOMBS)||
							((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
							TQue_x[i]+=ts;
						} else {
							TQue_move[i]=3U;
						}
						break;
					case 2U:	//���ړ�
						tx=(TQue_x[i]>>3)-2U;
						ty=((TQue_y[i]+ts-1U)>>3)&0xFE;
						if((map[tx][ty]<BOMBS)||
							((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
							TQue_y[i]+=ts;
						} else {
							TQue_move[i]-=2U;
						}
						break;
					case 3U:	//���ړ�
						tx=((TQue_x[i]-16U-ts)>>3)&0xFE;
						ty=(TQue_y[i]>>3)-2U;
						if((map[tx][ty]<BOMBS)||
							((map[tx][ty]==BREAKABLEBLOCK)&&((tt==4)||(tt==5)||(tt==7)))) {
							TQue_x[i]-=ts;
						} else {
							TQue_move[i]=9U;
						}
						break;
					case 4U:	//�ړ��Ȃ�
						tx=(TQue_x[i]>>3)-2U;
						ty=(TQue_y[i]>>3)-2U;
						break;				
				}
				if(((TQue_x[i]&0x000F)<ts)&&((TQue_y[i]&0x000F)<ts)) {
					TQue_x[i]&=0xFFF0;
					TQue_y[i]&=0xFFF0;
					TQue_move[i]+=0x10U;
					j=TQue_move[i]&0x07;
					//�ړ��s���̂ɂԂ����������ꍇ
					if((map[tx+direct_x[j]][ty+direct_y[j]]>=BOMBS)&&
						((map[tx+direct_x[j]][ty+direct_y[j]]!=BREAKABLEBLOCK)||
						((tt!=4)&&(tt!=5)&&(tt!=7)))) {
						j=(j+2)&0x03;
						if(TQue_mode[i]!=TM_REPEAT) {
							if((j&0x01)==0) {
								k=ty+direct_y[j];
								for(l=0;l<5U;l++)	{
									k+=direct_y[j];
									if(map[tx][k]>=BOMBS) {
										TQue_mode[i]=TM_REPEAT;
										break;
									}
								}
							} else {
								k=tx+direct_x[j];
								for(l=0;l<5U;l++) {
									k+=direct_x[j];
									if(map[k][ty]>=BOMBS) {
										TQue_mode[i]=TM_REPEAT;
										break;
									}
								}
							}
							if(TQue_mode[i]!=TM_REPEAT) {
								for(k=0;k<5U;k++) {
									j=arand()&0x03;
									if((TQue_move[i]&0x07)!=j) {
										if(map[tx+direct_x[j]][ty+direct_y[j]]<BOMBS) {
											break;
										}
									}
								}
							}
						}
					//���܂ɕ����]������ꍇ
					} else if(arand()<(TQue_move[i]>>2)) {
						TQue_mode[i]=TM_WALK;
						for(k=0;k<5U;k++) {
							j=arand()%5;
							if((TQue_move[i]&0x07)!=j) {
								if(map[tx+direct_x[j]][ty+direct_y[j]]<BOMBS) {
									break;
								}
							}
						}					
					}
					//��l���ǂ��������[�h�ւ̕ύX
					if((TQue_mode[i]!=TM_RUN)&&((arand()&0x1F)<teki_aim_rate[tt])) {
						if((absw(TQue_x[i]-(px>>1))>31UL)||(absw(TQue_y[i]-(py>>1))>31UL)) {
							TQue_mode[i]=TM_AIM;
							TQue_move[i]=4U;
						}
					//�����Ȃ��Ȃ�ꍇ
					} else if((((tt==2)||(tt==3))&&(arand()<0x02))||((tt==6)&&(arand()<0x10))) {
						TQue_mode[i]=TM_STOP;
					} else {
						//�ړ��悪�ړ��s���̂̏ꍇ
						if((map[tx+direct_x[j]][ty+direct_y[j]]>=BOMBS)&&
							((map[tx+direct_x[j]][ty+direct_y[j]]!=BREAKABLEBLOCK)||
							((tt!=4)&&(tt!=5)&&(tt!=7)))) {
							j=4;
							TQue_mode[i]=TM_WALK;
						}
						if((TQue_move[i]&0x07)!=j) {
							k=TQue_move[i]&0x08U;
							TQue_move[i]=j;
							switch(j) {
								case 0U:
									TQue_move[i]+=k;
									break;
								case 1U:
									TQue_move[i]=9U;
									break;
								case 2U:
									TQue_move[i]+=k;
									break;
								case 3U:
									break;
							}
						}
					}
				}
			}
		}
		//�^�C���Z�b�g
		if((TQue_move[i]&0x08)!=0U) {
			set_sprite_tile( (i<<1U)+2U, walk_anim[TQue_stat1[i]>>2] + teki_tile[TQue_type[i]]);
			set_sprite_tile( (i<<1U)+3U, walk_anim[TQue_stat1[i]>>2] + teki_tile[TQue_type[i]] + 2U );
			if( _cpu==CGB_TYPE ) {
				set_sprite_prop( (i<<1U)+2U, BomCGB[TQue_type[i]] );
				set_sprite_prop( (i<<1U)+3U, BomCGB[TQue_type[i]] );
			} else {
				set_sprite_prop( (i<<1U)+2U, 0x00 );
				set_sprite_prop( (i<<1U)+3U, 0x00 );
			}
  		} else {
			set_sprite_tile( (i<<1U)+3U, walk_anim[TQue_stat1[i]>>2] + teki_tile[TQue_type[i]]);
			set_sprite_tile( (i<<1U)+2U, walk_anim[TQue_stat1[i]>>2] + teki_tile[TQue_type[i]] + 2U );
			if( _cpu==CGB_TYPE ) {
				set_sprite_prop( (i<<1U)+2U, S_FLIPX+BomCGB[TQue_type[i]] );
				set_sprite_prop( (i<<1U)+3U, S_FLIPX+BomCGB[TQue_type[i]] );
			} else {
				set_sprite_prop( (i<<1U)+2U, S_FLIPX );
				set_sprite_prop( (i<<1U)+3U, S_FLIPX );
			}
		}
		//��l�������蔻��
		if((absw(TQue_x[i]-(px>>1))<13UL)&&(absw(TQue_y[i]-(py>>1))<13UL)&&(pstat<128U)
			&&(pmuteki!=MUTEKI)) {
			pstat=128U;
			s_play(8);
		}
		//���������蔻��
		if(((map[((TQue_x[i]-12)/16UL)<<1U][((TQue_y[i]-12)/16UL)<<1U]&FIRES)==FIRES)||
			((map[((TQue_x[i]-6)/16UL)<<1U][((TQue_y[i]-6)/16UL)<<1U]&FIRES)==FIRES)||
			((map[((TQue_x[i]-12)/16UL)<<1U][((TQue_y[i]-6)/16UL)<<1U]&FIRES)==FIRES)||
			((map[((TQue_x[i]-6)/16UL)<<1U][((TQue_y[i]-12)/16UL)<<1U]&FIRES)==FIRES)) {
			TQue_stat1[i]=255U;
			TQue_move[i]=0;
			TQue_score[i]=TQue_type[i]+num_dieteki;
			if( _cpu==CGB_TYPE ) {
				set_sprite_prop( (i<<1U)+2U, BomCGB[TQue_type[i]] );
				set_sprite_prop( (i<<1U)+3U, BomCGB[TQue_type[i]] );
			} else {
				set_sprite_prop( (i<<1U)+2U, 0x00 );
				set_sprite_prop( (i<<1U)+3U, 0x00 );
			}
			num_dieteki++;
			if(((time_cnt&0x0F)==0)&&(hidden_item==0x40)) {
				set_hidden_item(3);
			}
			if((pstage<0x80)&&((num_teki-num_dieteki)==0U)) {
				clear_flg=TRUE;
				s_play(7);
			}
		}
	} else {
		//���S�A�j��
		TQue_move[i]++;
		if(TQue_move[i]<40U) {
			set_sprite_tile( (i<<1U)+2U, teki_tile[TQue_type[i]]+12U);
			set_sprite_tile( (i<<1U)+3U, teki_tile[TQue_type[i]]+14U);
		} else if(TQue_move[i]<64U) {
			set_sprite_tile( (i<<1U)+2U, 0x40U+((TQue_move[i]>>3U)<<2U));
			set_sprite_tile( (i<<1U)+3U, 0x42U+((TQue_move[i]>>3U)<<2U));
			if( _cpu==CGB_TYPE ) {
				set_sprite_prop( (i<<1U)+2U, BomCGB[0] );
				set_sprite_prop( (i<<1U)+3U, BomCGB[0] );
			}
		} else if(TQue_move[i]<88U) {
			set_sprite_tile( (i<<1U)+2U, 0x40U+((TQue_score[i]&0x07)<<1U));
			set_sprite_tile( (i<<1U)+3U, 0x50U);
			if(TQue_score[i]>7U) {
				set_sprite_tile( i+(MAX_ET<<1U)+2U, 0x50U);
			}
		} else {
			set_sprite_tile( (i<<1U)+2U, NONE_TILE );
			set_sprite_tile( (i<<1U)+3U, NONE_TILE );
			set_sprite_tile( i+(MAX_ET<<1U)+2U, NONE_TILE );
			TQue_stat1[i]=254U;
		}
	}	
	//�\��
	if(((TQue_x[i]>scx)&&(TQue_x[i]<(scx+176UL)))&&
		((TQue_y[i]>scy)&&(TQue_y[i]<(scy+144UL)))) {
		move_sprite( (i<<1U)+2U, TQue_x[i]-scx-8U, TQue_y[i]-scy );
		move_sprite( (i<<1U)+3U, TQue_x[i]-scx, TQue_y[i]-scy );
		move_sprite(i+(MAX_ET<<1U)+2U,TQue_x[i]-scx+8U,TQue_y[i]-scy);
	} else {
		move_sprite( (i<<1U)+2U, 0, 0 );
		move_sprite( (i<<1U)+3U, 0, 0 );
		move_sprite( i+(MAX_ET<<1U)+2U, 0, 0 );
	}
}

void show_score()
{
	UWORD n;
	n = pscore/10000UL;
	score_tile[0] = 0x5D+n;
	n = pscore%10000UL;
	score_tile[1] = 0x5D+n/1000UL;
	n = pscore%1000UL;
	score_tile[2] = 0x5D+n/100UL;
	n = pscore%100UL;
	score_tile[3] = 0x5D+n/10UL;
	n = pscore%10UL;
	score_tile[4] = 0x5D+n;
	for(i=0;i<5;i++)	
		if(score_tile[i]==0x5D) {
			score_tile[i]=0x67;
		} else {
			break;
		}
	set_win_tiles( 11, 0, 5, 1, score_tile );
}

UBYTE score_rank( UWORD s )
{
	if(s<200UL) {
		return(0);
	} else if(s<500UL) {
		return(1);
	} else if(s<10000UL) {
		return((s/1000UL)+1U);
	} else {
		return((s/5000UL)+10U);
	}		
}

void score_up_sub( UWORD s )
{
	i=score_rank(pscore+s)-score_rank(pscore);
	if(i>0) {
		pcnt+=i;
		s_play(6);
	}
	pscore+=s;
	show_score();
}
