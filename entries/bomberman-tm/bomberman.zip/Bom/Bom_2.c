/********************************************************************
 * BOMBERMAN                                                        *
 *  by                                                              *
 * T.M                                                              *
 ********************************************************************/

#include <gb.h>
#include <rand.h>

/* bitmaps */
#include "Chara.c"
#include "Chara.h"
#include "bkg.c"
#include "bkg.h"
#include "title.c"

UWORD Chara_p[] =
{
  BomCGBPal0c0,BomCGBPal0c1,BomCGBPal0c2,BomCGBPal0c3,
  BomCGBPal1c0,BomCGBPal1c1,BomCGBPal1c2,BomCGBPal1c3,
  BomCGBPal2c0,BomCGBPal2c1,BomCGBPal2c2,BomCGBPal2c3,
  BomCGBPal3c0,BomCGBPal3c1,BomCGBPal3c2,BomCGBPal3c3,
  BomCGBPal4c0,BomCGBPal4c1,BomCGBPal4c2,BomCGBPal4c3,
  BomCGBPal5c0,BomCGBPal5c1,BomCGBPal5c2,BomCGBPal5c3,
  BomCGBPal6c0,BomCGBPal6c1,BomCGBPal6c2,BomCGBPal6c3,
  BomCGBPal7c0,BomCGBPal7c1,BomCGBPal7c2,BomCGBPal7c3
};

UWORD bkg_p[] =
{
  bkgCGBPal0c0,bkgCGBPal0c1,bkgCGBPal0c2,bkgCGBPal0c3,
  bkgCGBPal1c0,bkgCGBPal1c1,bkgCGBPal1c2,bkgCGBPal1c3,
  bkgCGBPal2c0,bkgCGBPal2c1,bkgCGBPal2c2,bkgCGBPal2c3,
  bkgCGBPal3c0,bkgCGBPal3c1,bkgCGBPal3c2,bkgCGBPal3c3,
  bkgCGBPal4c0,bkgCGBPal4c1,bkgCGBPal4c2,bkgCGBPal4c3,
  bkgCGBPal5c0,bkgCGBPal5c1,bkgCGBPal5c2,bkgCGBPal5c3,
  bkgCGBPal6c0,bkgCGBPal6c1,bkgCGBPal6c2,bkgCGBPal6c3,
  bkgCGBPal7c0,bkgCGBPal7c1,bkgCGBPal7c2,bkgCGBPal7c3
};

/* system */
#define EMPTY			0xFFU		/* que empty */
#define NONE_TILE		0xF0U		/* none tile */

/* pmode */
#define MODE_TITLE		0U			/* title */
#define MODE_GAME		1U			/* game */
#define MODE_DIE		2U			/* player die */
#define MODE_OVER		3U			/* game over */
#define MODE_CLEAR		4U			/* stage clear */
#define MODE_ENDING		5U			/* ending */

/* max speed */
#define	MAX_SPEED		4U			/* max speed */

/* bomb */
#define MAX_TT			16U			/* number */
#define BOM_LIMIT		100U		/* bomb limiter */
#define MAX_POW			16U			/* bomb power max */

/* enemy */
#define MAX_ET			8U			/* number */
#define TM_WALK			0U			/* walk */
#define TM_REPEAT		1U			/* repeat */
#define TM_RUN			2U			/* run away */
#define TM_AIM			3U			/* aim player */
#define TM_STOP			4U			/* stop */

/* item */
#define GETTED			255U		/* When getting item, it is set in item_type */
#define RESET			254U		/* When setting item, it is set in item_type */
#define	FIREBARRIER		1U			/* When getting fire barrier, it is set in pmuteki */
#define	MUTEKI			2U			/* When getting ?, it is set in pmuteki */

/* map attrib */
#define ITEMS			0x04 		/* all items */
#define FIRES			0x08 		/* all fires */
#define BOMBS			0x10 		/* all bombs */
#define BREAKABLEBLOCKS	0x20 		/* all breakable blocks */
#define UNMOVABLE		0x40 		/* movable */

/* map */
#define MPSIZE_X			62U									/* max map x*2 */
#define MPSIZE_Y			30U									/* max map y*2 */
#define FLOOR				 0U									/* floor */
#define DOOR				 1U									/* door */
#define ITEM				ITEMS								/* item */
#define HIDDEN_ITEM			ITEMS + 1U							/* hidden item */
#define FIRE            	FIRES 								/* fire center */
#define FIREH           	FIRES + 1U							/* fire horizontal */
#define FIREV           	FIRES + 2U							/* fire vertical */
#define BOMBUNDERPLAYER		BOMBS								/* bomb under player = walkable */
#define UNBREAKABLEBLOCK	UNMOVABLE							/* unbreakable block */
#define BOMB				UNMOVABLE + BOMBS					/* bomb */
#define BREAKABLEBLOCK		UNMOVABLE + BREAKABLEBLOCKS			/* breakable block */
#define BREAKINGBLOCK		UNMOVABLE + BREAKABLEBLOCKS + FIRES	/* breaking block */

extern UBYTE BomCGB[];
extern unsigned char walk_anim[];
extern unsigned char *map_tiles[];
extern unsigned char *map_attr[];
extern unsigned char time_tile[3], score_tile[5];
extern UBYTE i, j, k, l, key_wait1, key_wait2, key, key_flg, die_wait, pmode;
extern UBYTE map[MPSIZE_X][MPSIZE_Y];
extern UBYTE item_x, item_y, item_type, item_time, hidden_item;
extern UBYTE pstat, pstage, pcnt, pspeed, ppower, premocon, pthroblock, pthrobomb, pmuteki;
extern UWORD scx, scy, px, py, pscore, high_score, old_time;
extern UBYTE inbomb_flg, clear_flg, old_tile, time_cnt, wait_cnt;
extern UBYTE num_bomb, max_bomb;
extern UBYTE num_teki, num_dieteki, bx_left, bx_right;
extern UWORD frequencies[];
extern UBYTE save_stage[3], save_speed[3], save_power[3];
extern UBYTE save_max_bomb[3],	save_item[3];
unsigned char title_map[] = {
	0x80,0x81,0x82,0x83,0x81,0x84,0x85,0x86,
	0x87,0x88,0x81,0x89,0x8A,0x81,0x8B,0x81,
	0x8C,0x8D,0x8E,0x8F,0x90,0x91,0x92,0x93,
	0x94,0x95,0x96,0x97,0x98,0x99,0x9A,0x9B,
	0x9C,0x98,0x99,0x9D,0x8E,0x9E,0x9F,0xA0,
	0xA1,0xA2,0xA3,0xA4,0xA5,0xA6,0xA7,0xA8,
	0xA9,0xAA,0xAB,0xAC,0xAD,0xAE,0x8E,0xAF,
	0xB0,0xA0,0xA1,0xB1,0xA3,0xB2,0xB3,0xA6,
	0xB4,0xB5,0xB6,0xB7,0xB8,0xB9,0xBA,0xBB,
	0xBC,0xBD,0xBE,0xBF,0xBD,0xC0,0xC1,0xC2,
	0xC3,0xC4,0xBD,0xC5,0xC6,0xBD,0xC7,0xC8,
	0xC9,0xBB,0xCA,0xCB,0xCC,0xCD,0xCC,0xCE,
	0xCF,0xD0,0xD1,0xD2,0xD3,0xD4,0xD5,0xD6,
	0xD7,0xD8,0xD9,0xDA,0xCA,0xDB,0xDB,0xDB,
	0xDB,0xDC,0xDD,0xDE,0xDF,0xE0,0xE1,0xE2,
	0xE3,0xE4,0xDB,0xDB,0xDB,0xE5,0xCA,0xDB,
	0xDB,0xDB,0xDB,0xE6,0xE7,0xE8,0xE9,0xEA,
	0xEB,0xEC,0xED,0xE4,0xDB,0xDB,0xDB,0xE5,
	0xCA,0xDB,0xDB,0xDB,0xDB,0xE6,0xEE,0xEF,
	0xA0,0xA1,0xEB,0xF0,0xF1,0xF2,0xDB,0xDB,
	0xDB,0xE5,0xF3,0xF4,0xF4,0xF4,0xF4,0xF5,
	0xF6,0xF7,0xF8,0xF9,0xFA,0xFB,0xFC,0xFD,
	0xF4,0xF4,0xF4,0xFE
};

unsigned char numeric_tile[] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0xC0,0xC0,0xC0,0xE0,0x00,0xE0,	//.
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,
  0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,	//_
  0x7C,0x7E,0xC6,0xFF,0xCE,0xEF,0xD6,0xDF,
  0xE6,0xF7,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,	//0
  0x18,0x1C,0x38,0x3C,0x18,0x3C,0x18,0x1C,
  0x18,0x1C,0x18,0x1C,0x18,0x1C,0x00,0x1C,	//1
  0x7C,0x7E,0xC6,0xFF,0xC6,0xE7,0x1C,0xFF,
  0x70,0x7E,0xC0,0xF8,0xFE,0xFF,0x00,0xFF,	//2
  0x7C,0x7E,0xC6,0xFF,0x06,0xE7,0x1C,0x1F,
  0x06,0x1F,0xC6,0xC7,0x7C,0xFF,0x00,0x7E,	//3
  0x1C,0x1E,0x2C,0x3E,0x4C,0x6E,0xCC,0xEE,
  0xFE,0xFF,0x0C,0xFF,0x0C,0x0E,0x00,0x0E,	//4
  0xFE,0xFF,0xC0,0xFF,0xFC,0xFE,0x06,0xFF,
  0x06,0x07,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,	//5
  0x7C,0x7E,0xC6,0xFF,0xC0,0xE7,0xFC,0xFE,
  0xC6,0xFF,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,	//6
  0xFE,0xFF,0xC6,0xFF,0x06,0xE7,0x0C,0x0F,
  0x18,0x1E,0x18,0x1C,0x18,0x1C,0x00,0x1C,	//7
  0x7C,0x7E,0xC6,0xFF,0xC6,0xE7,0x7C,0xFF,
  0xC6,0xFF,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,	//8
  0x7C,0x7E,0xC6,0xFF,0xC6,0xE7,0x7E,0xFF,
  0x06,0x7F,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,	//9
  0xC0,0xE0,0xF0,0xF8,0xFC,0xFE,0xFF,0xFF,
  0xFC,0xFF,0xF0,0xFE,0xC0,0xF8,0x00,0xE0	//>
};

unsigned char alphabet_tile[] = {
  0x38,0x3C,0x6C,0x7E,0xC6,0xF7,0xC6,0xE7,
  0xFE,0xFF,0xC6,0xFF,0xC6,0xE7,0x00,0xE7,
  0xFC,0xFE,0xC6,0xFF,0xC6,0xE7,0xFC,0xFF,
  0xC6,0xFF,0xC6,0xE7,0xFC,0xFF,0x00,0xFE,
  0x3C,0x3E,0x66,0x7F,0xC0,0xF7,0xC0,0xE0,
  0xC0,0xE0,0x66,0xF7,0x3C,0x7F,0x00,0x3E,
  0xF8,0xFC,0xCC,0xFE,0xC6,0xEF,0xC6,0xE7,
  0xC6,0xE7,0xCC,0xEF,0xF8,0xFE,0x00,0xFC,
  0xFE,0xFF,0xC0,0xFF,0xC0,0xE0,0xF8,0xFC,
  0xC0,0xFC,0xC0,0xE0,0xFE,0xFF,0x00,0xFF,
  0xFE,0xFF,0xC0,0xFF,0xC0,0xE0,0xF8,0xFC,
  0xC0,0xFC,0xC0,0xE0,0xC0,0xE0,0x00,0xE0,
  0x3E,0x3F,0x60,0x7F,0xC0,0xF0,0xCE,0xEF,
  0xC6,0xEF,0x66,0xFF,0x3E,0x7F,0x00,0x3F,
  0xC6,0xE7,0xC6,0xE7,0xC6,0xE7,0xFE,0xFF,
  0xC6,0xFF,0xC6,0xE7,0xC6,0xE7,0x00,0xE7,
  0x78,0x7C,0x30,0x7C,0x30,0x38,0x30,0x38,
  0x30,0x38,0x30,0x38,0x78,0x7C,0x00,0x7C,
  0x06,0x07,0x06,0x07,0x06,0x07,0x06,0x07,
  0xC6,0xE7,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,
  0xC6,0xE7,0xCC,0xEE,0xD8,0xFC,0xF0,0xF8,
  0xF8,0xF8,0xCC,0xFC,0xC6,0xEF,0x00,0xE7,
  0xC0,0xE0,0xC0,0xE0,0xC0,0xE0,0xC0,0xE0,
  0xC0,0xE0,0xC0,0xE0,0xFE,0xFF,0x00,0xFF,
  0xC6,0xE7,0xEE,0xFF,0xFE,0xFF,0xD6,0xFF,
  0xC6,0xFF,0xC6,0xE7,0xC6,0xE7,0x00,0xE7,
  0xC6,0xE7,0xE6,0xF7,0xF6,0xFF,0xDE,0xFF,
  0xCE,0xFF,0xC6,0xEF,0xC6,0xE7,0x00,0xE7,
  0x7C,0x7E,0xC6,0xFF,0xC6,0xE7,0xC6,0xE7,
  0xC6,0xE7,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,
  0xFC,0xFE,0xC6,0xFF,0xC6,0xE7,0xC6,0xE7,
  0xFC,0xFF,0xC0,0xFE,0xC0,0xE0,0x00,0xE0,
  0x7C,0x7E,0xC6,0xFF,0xC6,0xE7,0xC6,0xE7,
  0xDE,0xFF,0xE4,0xFF,0x7A,0xFF,0x00,0x7F,
  0xFC,0xFE,0xC6,0xFF,0xC6,0xE7,0xCE,0xEF,
  0xF8,0xFF,0xDC,0xFE,0xCE,0xFF,0x00,0xEF,
  0x78,0x7C,0xCC,0xFE,0xC0,0xEE,0x7C,0xFE,
  0x06,0x7F,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,
  0xFC,0xFE,0x30,0xFE,0x30,0x38,0x30,0x38,
  0x30,0x38,0x30,0x38,0x30,0x38,0x00,0x38,
  0xC6,0xE7,0xC6,0xE7,0xC6,0xE7,0xC6,0xE7,
  0xC6,0xE7,0xC6,0xE7,0x7C,0xFF,0x00,0x7E,
  0xC6,0xE7,0xC6,0xE7,0xC6,0xE7,0xEE,0xFF,
  0x7C,0xFF,0x38,0x7E,0x10,0x3C,0x00,0x18,
  0xC6,0xE7,0xC6,0xE7,0xD6,0xF7,0xFE,0xFF,
  0xFE,0xFF,0xEE,0xFF,0xC6,0xFF,0x00,0xE7,
  0xC6,0xE7,0xEE,0xFF,0x7C,0xFF,0x38,0x7E,
  0x7C,0x7E,0xEE,0xFF,0xC6,0xFF,0x00,0xE7,
  0xCC,0xEE,0xCC,0xEE,0xCC,0xEE,0x78,0xFE,
  0x30,0x7C,0x30,0x38,0x30,0x38,0x00,0x38,
  0xFE,0xFF,0x0E,0xFF,0x1C,0x1F,0x38,0x3E,
  0x70,0x7C,0xE0,0xF8,0xFE,0xFF,0x00,0xFF
};

unsigned char space_tile[] = {
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00,
  0x00,0x00,0x00,0x00,0x00,0x00,0x00,0x00
};

unsigned char msg_start[] = "START";
unsigned char msg_continue[] = "CONTINUE";
unsigned char msg_top[] = "TOP       00";
unsigned char msg_over[] = "GAME OVER";
unsigned char msg_stage[] = "STAGE";
unsigned char msg_save[] = "SAVE";
unsigned char msg_end[] = "END";
unsigned char msg_space[] = "     ";
unsigned char msg_ending1[] = "CONGRATULATIONS";
unsigned char msg_ending2[] = "BOMBER MAN BECOMES";
unsigned char msg_ending3[] = "RUNNER";
unsigned char msg_ending4[] = "SEE YOU AGAIN";
unsigned char msg_ending5[] = "  PROGRAMED BY T.M  ";
unsigned char msg_ending6[] = "  GRAPHIC           ";
unsigned char msg_ending7[] = "  MUSIC             ";
unsigned char msg_ending8[] = "  SOUND             ";
unsigned char msg_ending9[] = "     BY HUDSON SOFT ";
unsigned char msg_endingA[] = " MUSIC EDITED WITH  ";
unsigned char msg_endingB[] = "   CARILLON PLAYER  ";
unsigned char msg_endingC[] = "ORIGINAL BOMBER MAN ";
unsigned char msg_endingD[] = "  COPYRIGHT         ";
unsigned char msg_endingE[] = "    HUDSON SOFT 1985";
unsigned char msg_endingF[] = "   THANK YOU FOR    ";
unsigned char msg_endingG[] = "    YOUR PLAYING    ";
unsigned char cursor1[] = ":";
unsigned char *msg_ending[] = {
	msg_ending5, msg_ending6, msg_ending7, msg_ending8, msg_ending9,
	msg_endingA, msg_endingB, msg_endingC, msg_endingD, msg_endingE,
	msg_endingF, msg_endingG
};
UBYTE emsg_line[] = {
	 1, 6, 7, 8,10,15,16,21,22,23, 1, 2,255
};

unsigned char win_color[] = {
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01,
  0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01, 0x01
};

unsigned char win_tile[] = {
  0x6B, 0x6C, 0x6D, 0x69, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67,
  0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x5D, 0x5D, 0x67, 0x67
};

unsigned char title_color1[] = {
  0x05,	0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05,
  0x05,	0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05
};

unsigned char title_color2[] = {
  0x03,	0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03,
  0x03,	0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03, 0x03
};

unsigned char clear_color[] = {
  0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06,
  0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06, 0x06
};

unsigned char clear_tile[] = {
  0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67,
  0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67, 0x67 
};

unsigned char stage_tile[] = {
  0x6E, 0x6B, 0x6F, 0x70, 0x69
};

unsigned char left_tile[] = {
  0x68, 0x69, 0x6A, 0x6B
};

unsigned char bonus_tile[] = {
  0x71, 0x72, 0x73, 0x74, 0x6E
};

void m_play( UBYTE, UBYTE );

void init_screen()
{
	if( _cpu==CGB_TYPE ) {
		/* Transfer color palette */
		set_bkg_palette( 0, 1, &bkg_p[0] );
		set_bkg_palette( 1, 1, &bkg_p[4] );
		set_bkg_palette( 2, 1, &bkg_p[8] );
		set_bkg_palette( 3, 1, &bkg_p[12] );
		set_bkg_palette( 4, 1, &bkg_p[16] );
		set_bkg_palette( 5, 1, &bkg_p[20] );
		set_bkg_palette( 6, 1, &bkg_p[24] );
		set_bkg_palette( 7, 1, &bkg_p[28] );
		set_sprite_palette( 0, 1, &Chara_p[0] );
		set_sprite_palette( 1, 1, &Chara_p[4] );
		set_sprite_palette( 2, 1, &Chara_p[8] );
		set_sprite_palette( 3, 1, &Chara_p[12] );
		set_sprite_palette( 4, 1, &Chara_p[16] );
		set_sprite_palette( 5, 1, &Chara_p[20] );
		set_sprite_palette( 6, 1, &Chara_p[24] );
		set_sprite_palette( 7, 1, &Chara_p[28] );
	}

	SPRITES_8x16;
	OBP0_REG=0xE1;	//11 10 00 01
	OBP1_REG=0x2F;	//00 10 11 11
	for( i=0; i<40; i++ ) {
		move_sprite( i, 0, 0 );
		set_sprite_prop( i, 1 );
	}
	VBK_REG = 1;		/* select palette bank */
	set_win_tiles( 0, 0, 20, 1, win_color );
	VBK_REG = 0;		/* select data bank */
	set_win_tiles( 0, 0, 20, 1, win_tile );
	WX_REG=7;
	WY_REG=136;
  
	NR10_REG = 0x00;
	NR11_REG = 0xC1;
	NR12_REG = 0xA3;
	NR13_REG = 0x73;
	NR14_REG = 0x06;

	NR21_REG = 0x41;
	NR22_REG = 0xA4;
	NR23_REG = 0xD7;
	NR24_REG = 0x06;

	NR30_REG = 0x80;
	NR31_REG = 0x00;
	NR32_REG = 0x20;
	NR33_REG = 0xD6;
	NR34_REG = 0x06;
						 
	NR41_REG = 0x32;
	NR42_REG = 0xA1;
	NR43_REG = 0x61;
	NR44_REG = 0x40;

	NR50_REG = 0x77;
	NR51_REG = 0xFF;
	NR52_REG = 0x80;
}

void start_stage()
{
	HIDE_WIN;
	HIDE_BKG;
	SCX_REG = 0U;
	SCY_REG = 0U;
	for( i=0; i<40; i++)
		move_sprite( i, 0, 0 );
	if( _cpu==CGB_TYPE ) {
		VBK_REG = 1;		/* select palette bank */
		for( i=0; i<18; i++)
			set_bkg_tiles( 0, i, 20, 1, clear_color );
		VBK_REG = 0;		/* select data bank */
	}
	for( i=0; i<18; i++)
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	if(pstage<0x80) {
		set_bkg_tiles( 5, 7, 5, 1, stage_tile );	/* stage */
		i=pstage/10U;
		if(i==0) {
			time_tile[0]=0x67;
		} else {
			time_tile[0]=0x5D+i;
		}
		i=pstage%10U;
		time_tile[1]=0x5D+i;
		set_bkg_tiles( 12, 7, 2, 1, time_tile );
		set_bkg_tiles( 5, 9, 4, 1, left_tile );	/* left */
		i=pcnt/10U;
		if(i==0) {
			time_tile[0]=0x67;
		} else {
			time_tile[0]=0x5D+i;
		}
		i=pcnt%10U;
		time_tile[1]=0x5D+i;
		set_bkg_tiles( 12, 9, 2, 1, time_tile );
	} else {
		set_bkg_tiles( 4, 7, 5, 1, bonus_tile );	/* bonus */
		set_bkg_tiles( 10, 7, 5, 1, stage_tile );	/* stage */
	}

	BGP_REG=0xB4;	//10 11 01 00
	SHOW_BKG;

	m_play(2,2);
	i=255;
	do {
		delay(9);
		i--;
	} while((!(joypad()&J_START))&&(i!=0));
}

void set_item_panel()
{
	set_bkg_data( 117, 4, &bkg[1872UL+item_type*64UL] );
}

void set_hidden_item_sub()
{
	set_bkg_data( 121, 4, &bkg[2320UL+hidden_item*4UL] );
	while(1) {
		i=(arand()%MPSIZE_X)&0xFE;
		j=(arand()%MPSIZE_Y)&0xFE;
		if((map[i][j]==FLOOR)&&((((px>>4U)-2U)!=i)||(((py>>4U)-2U)!=j))) {
			map[i][j]=HIDDEN_ITEM;
			break;
		}
	}
	set_bkg_tiles2( i, j, 2, 2, map_tiles[map[i][j]]);
	set_bkg_attr( i, j, 2, 2, map_attr[map[i][j]]);
	hidden_item=hidden_item>>4;
}

UBYTE save_select()
{
	HIDE_BKG;
	if( _cpu==CGB_TYPE ) {
		VBK_REG = 1;		// select palette bank 
		for(i=0;i<18;i++)
			set_bkg_tiles( 0, i, 20, 1, title_color2 );
		VBK_REG = 0;		// select data bank 
	}
	for( i=0; i<18; i++)
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	for( i=0; i<3; i++) {
		time_tile[0]=0x31+i;
		set_bkg_tiles( 5, 4+(i<<1), 1, 1, time_tile );
		j=save_stage[i]/10U;
		if(j==0) {
			time_tile[0]=0x20;
		} else {
			time_tile[0]=0x30+j;
		}
		j=save_stage[i]%10U;
		time_tile[1]=0x30+j;
		set_bkg_tiles( 7, 4+(i<<1), 5, 1, msg_stage );
		set_bkg_tiles( 14, 4+(i<<1), 2, 1, time_tile );
	}
	waitpadup();
	SHOW_BKG;
	j=0;
	set_bkg_tiles( 3, 4, 1, 1, cursor1 );
	do {
		key=joypad();
		if(key!=NULL) {
			if(key&J_UP) {
				if(j==0) {
					j=2;
				} else {
					j--;
				}
			} else if(key&(J_DOWN|J_SELECT)) {
				j=(j+1)%3;
			}
			set_bkg_tiles( 3, 4, 1, 5, msg_space );
			set_bkg_tiles( 3, 4+(j<<1), 1, 1, cursor1 );
			waitpadup();
		}
	} while(!(key&(J_START|J_A|J_B)));

	waitpadup();
	if(key==J_B) {
		return(255U);
	} else {
		return(j);
	}
}

void title()
{
	UWORD n;

	HIDE_BKG;	
	set_data( (unsigned char*)0x8800, titletile, 0x7F0 );
	set_data( (unsigned char*)0x9200, space_tile, 0x10 );
	set_data( (unsigned char*)0x9670, space_tile, 0x10 );
	set_data( (unsigned char*)0x92E0, numeric_tile, 0xD0 );
	set_data( (unsigned char*)0x9410, alphabet_tile, 0x1A0 );

	while(1) {
	  if( _cpu==CGB_TYPE ) {
			VBK_REG = 1;		/* select palette bank */
			for(i=0;i<12;i++)
				set_bkg_tiles( 0, i, 20, 1, title_color1 );
			for(i=12;i<18;i++)
				set_bkg_tiles( 0, i, 20, 1, title_color2 );
			VBK_REG = 0;		/* select data bank */
		}
		for(j=0;j<18;j++) 
			set_bkg_tiles( 0, j, 20, 1, clear_tile );
		set_bkg_tiles( 1, 1, 18, 10, title_map );
		set_bkg_tiles( 8, 12, 5, 1, msg_start );
		set_bkg_tiles( 8, 13, 8, 1, msg_continue );
		set_bkg_tiles( 3, 15, 12, 1, msg_top );
		set_bkg_tiles( 6, 12, 1, 1, cursor1 );
		n = high_score/10000UL;
		score_tile[0] = 0x30+n;
		n = high_score%10000UL;
		score_tile[1] = 0x30+n/1000UL;
		n = high_score%1000UL;
		score_tile[2] = 0x30+n/100UL;
		n = high_score%100UL;
		score_tile[3] = 0x30+n/10UL;
		n = high_score%10UL;
		score_tile[4] = 0x30+n;
		for(i=0;i<5;i++)	
			if(score_tile[i]==0x30) {
				score_tile[i]=0x20;
			} else {
				break;
			}
		set_bkg_tiles( 8, 15, 5, 1, score_tile );
		BGP_REG=0x27;	//00 10 01 11
		SHOW_BKG;
		m_play(1,2);
		i=0;
		do {
			key=joypad();
			arand();
			if(key&(J_UP|J_DOWN|J_SELECT)) {
				i=1-i;
				set_bkg_tiles( 6, 12+i, 1, 1, cursor1 );
				set_bkg_tiles( 6, 13-i, 1, 1, msg_space );
				waitpadup();
			}
		} while(!(key&(J_START|J_A)));
		pstage=1;	pspeed=3U;	ppower=2U;	max_bomb=1U;	item_type=0U;
		pcnt=3U;	pscore=0U;	premocon=FALSE;
		pthroblock=255U;	pthrobomb=0U;	pmuteki=0U;
		if(i==0) {
			break;
		} else {
			j=save_select();
			if(j!=255U) {
				pstage=save_stage[j];	ppower=save_power[j];	pspeed=save_speed[j];
				max_bomb=save_max_bomb[j];	item_type=save_item[j];
				break;;
			}
		}
	};
	HIDE_BKG;
	waitpadup();
	for( i=0; i<18; i++)
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	set_sprite_data( 0, 242, Bom );
	set_bkg_data(  0, 128, bkg );
}

UBYTE game_over()
{
	HIDE_WIN;
	HIDE_BKG;
	SCX_REG = 0U;
	SCY_REG = 0U;
	if(pscore>high_score) high_score=pscore;
	for( i=0; i<40; i++)
		move_sprite( i, 0, 0 );
	if( _cpu==CGB_TYPE ) {
		VBK_REG = 1;		/* select palette bank */
		for( i=0; i<18; i++)
			set_bkg_tiles( 0, i, 20, 1, title_color2 );
		VBK_REG = 0;		/* select data bank */
	}
	set_data( (unsigned char*)0x9200, space_tile, 0x10 );
	set_data( (unsigned char*)0x9670, space_tile, 0x10 );
	set_data( (unsigned char*)0x92E0, numeric_tile, 0xD0 );
	set_data( (unsigned char*)0x9410, alphabet_tile, 0x01A0 );
	while(1) {
		for( i=0; i<18; i++) 
			set_bkg_tiles( 0, i, 20, 1, clear_tile );
		set_bkg_tiles( 5, 8, 9, 1, msg_over );
		set_bkg_tiles( 7, 11, 8, 1, msg_continue );
		set_bkg_tiles( 7, 13, 4, 1, msg_save );
		set_bkg_tiles( 7, 15, 3, 1, msg_end );
		BGP_REG=0x27;	//00 10 01 11
		SHOW_BKG;

		m_play(8,2);
		i=0;
		set_bkg_tiles( 5, 11, 1, 1, cursor1 );
		do {
			key=joypad();
			arand();
			if(key!=NULL) {
				if(key&J_UP) {
					if(i==0) {
						i=2;
					} else {
						i--;
					}
				} else if(key&(J_DOWN|J_SELECT)) {
					i=(i+1)%3;
				}
				set_bkg_tiles( 5, 11, 1, 5, msg_space );
				set_bkg_tiles( 5, 11+(i<<1), 1, 1, cursor1 );
				waitpadup();
			}
		} while(!(key&(J_START|J_A)));
		waitpadup();
		if(i==0U) {	//CONTINUE
			pcnt=3U;
			pscore=0U;
			HIDE_BKG;
			for( j=0; j<18; j++)
				set_bkg_tiles( 0, j, 20, 1, clear_tile );
			set_sprite_data( 0, 242, Bom );
			set_bkg_data(  0, 128, bkg );
			return(MODE_GAME);
			break;
		} else if(i==1U) {	//SAVE
			j=save_select();
			if(j!=255U) {
				save_stage[j]=pstage;	save_power[j]=ppower;	save_speed[j]=pspeed;
				save_max_bomb[j]=max_bomb;	save_item[j]=item_type;
				return(MODE_TITLE);
				break;
			}
		} else {	//END
			return(MODE_TITLE);
			break;
		}
	}
	return(0);
}

void ending()
{
	HIDE_WIN;
	HIDE_BKG;	
	SCX_REG = 0U;
	SCY_REG = 0U;
	bx_left=0;bx_right=30;
	for( i=0; i<40; i++)
		move_sprite( i, 0, 0 );
	set_data( (unsigned char*)0x9200, space_tile, 0x10 );
	set_data( (unsigned char*)0x9670, space_tile, 0x10 );
	set_data( (unsigned char*)0x92E0, numeric_tile, 0xD0 );
	set_data( (unsigned char*)0x9410, alphabet_tile, 0x1A0 );

	if( _cpu==CGB_TYPE ) {
		VBK_REG = 1;		/* select palette bank */
		for(i=0;i<18;i++)
			set_bkg_tiles( 0, i, 20, 1, title_color2 );
		VBK_REG = 0;		/* select data bank */
	}
	for(i=0;i<18;i++) 
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	for(i=0;i<10;i++) {
		set_bkg_tiles2( i<<1, 16, 2, 2, map_tiles[BREAKABLEBLOCK]);
		set_bkg_attr( i<<1, 16, 2, 2, map_attr[0]);
	}
	set_bkg_tiles( 2, 1, 15, 1, msg_ending1 );
	set_bkg_tiles( 1, 3, 18, 1, msg_ending2 );
	set_bkg_tiles( 7, 5,  6, 1, msg_ending3 );
	set_bkg_tiles( 3, 7, 13, 1, msg_ending4 );
	BGP_REG=0x27;	//00 10 01 11
	SHOW_BKG;
	m_play(9,2);
	for(i=0;i<240U;i++) {
		if(i>80U) {
			j=0xE4;
			set_sprite_prop( 0, S_FLIPX+0x07 ); set_sprite_prop( 1, S_FLIPX+0x07 );
		} else {
			j=0;
			set_sprite_prop( 0, S_FLIPX ); set_sprite_prop( 1, S_FLIPX );
		}
		set_sprite_tile( 0, walk_anim[i&0x07]+2+j); set_sprite_tile( 1, walk_anim[i&0x07]+j);
		if(i>160U) {
			k=i-160U;
		} else {
			k=i;
		}
		move_sprite(0,k,128);	move_sprite(1,k+8U,128);
		delay(51);
	}
	waitpad(J_START);
	move_sprite(0,0,0);	move_sprite(1,0,0);
	if( _cpu==CGB_TYPE ) {
		VBK_REG = 1;		/* select palette bank */
		for(i=0;i<32;i++)
			set_bkg_tiles( 0, i, 20, 1, title_color2 );
		VBK_REG = 0;		/* select data bank */
	}
	for(i=0;i<32;i++) 
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	i=0; j=0;
	m_play(1,2);
	do {
		set_bkg_tiles( 0, (i-8U)>>3, 20, 1, clear_tile );
		if((i>>3)==emsg_line[j]) {
			set_bkg_tiles( 0, (emsg_line[j]+18U)&0x1F,  20, 1, msg_ending[j] );
			j++;
		}
		i++;
		SCY_REG=i;
		delay(55);
	} while((j<12U)||(i!=88));
	waitpad(J_START);
	HIDE_BKG;
	waitpadup();
	for( i=0; i<18; i++)
		set_bkg_tiles( 0, i, 20, 1, clear_tile );
	set_bkg_data(  0, 128, bkg );
	pstage=1;	item_type=0U;
}
