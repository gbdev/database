/********************************************************************
 * BOMBERMAN           																							*
 *	by																															*
 * T.M																															*
 ********************************************************************/

#include <gb.h>
#include <rand.h>

/* system */
#define EMPTY			0xFFU		/* que empty */
#define NONE_TILE		0xF0U		/* none tile */

/* pmode */
#define MODE_TITLE		0U			/* title */
#define MODE_GAME		1U			/* game */
#define MODE_DIE		2U			/* player die */
#define MODE_OVER		3U			/* game over */
#define MODE_CLEAR		4U			/* stage clear */
#define MODE_ENDING		5U			/* ending */

/* max speed */
#define	MAX_SPEED		4U			/* max speed */

/* bomb */
#define MAX_TT			16U			/* number */
#define BOM_LIMIT		100U		/* bomb limiter */
#define MAX_POW			16U			/* bomb power max */

/* enemy */
#define MAX_ET			8U			/* number */
#define TM_WALK			0U			/* walk */
#define TM_REPEAT		1U			/* repeat */
#define TM_RUN			2U			/* run away */
#define TM_AIM			3U			/* aim player */
#define TM_STOP			4U			/* stop */

/* item */
#define GETTED			255U		/* When getting item, it is set in item_type */
#define RESET			254U		/* When setting item, it is set in item_type */
#define	FIREBARRIER		1U			/* When getting fire barrier, it is set in pmuteki */
#define	MUTEKI			2U			/* When getting ?, it is set in pmuteki */

/* map attrib */
#define ITEMS			0x04 		/* all items */
#define FIRES			0x08 		/* all fires */
#define BOMBS			0x10 		/* all bombs */
#define BREAKABLEBLOCKS	0x20 		/* all breakable blocks */
#define UNMOVABLE		0x40 		/* movable */

/* map */
#define MPSIZE_X			62U									/* max map x*2 */
#define MPSIZE_Y			30U									/* max map y*2 */
#define FLOOR				 0U									/* floor */
#define DOOR				 1U									/* door */
#define ITEM				ITEMS								/* item */
#define HIDDEN_ITEM			ITEMS + 1U							/* hidden item */
#define FIRE            	FIRES 								/* fire center */
#define FIREH           	FIRES + 1U							/* fire horizontal */
#define FIREV           	FIRES + 2U							/* fire vertical */
#define BOMBUNDERPLAYER		BOMBS								/* bomb under player = walkable */
#define UNBREAKABLEBLOCK	UNMOVABLE							/* unbreakable block */
#define BOMB				UNMOVABLE + BOMBS					/* bomb */
#define BREAKABLEBLOCK		UNMOVABLE + BREAKABLEBLOCKS			/* breakable block */
#define BREAKINGBLOCK		UNMOVABLE + BREAKABLEBLOCKS + FIRES	/* breaking block */

/* CGBpalette entries. */
UBYTE BomCGB[] = {
	0x01,0x02,0x03,0x01,
	0x02,0x03,0x01,0x01
};

unsigned char walk_anim[] = {
	0x00,0x00,0x04,0x04,0x08,0x08,0x04,0x04
};

unsigned char teki_tile[] = {			
	0x64,		/* 00: baloon */			
	0x74,		/* 01: onion */			
	0x84,		/* 02: chochin */			
	0x94,		/* 03: parth */			
	0xA4,		/* 04: ameba */			
	0xB4,		/* 05: ghost */			
	0xC4,		/* 06: tora */			
	0xD4 		/* 07: coin */			
};

unsigned char bkg_tiles[] = { 
	0x00,0x00,0x00,0x00,		/* 00: floor */
	0x75,0x76,0x77,0x78,		/* 01: item panel */
	0x79,0x7A,0x7B,0x7C,		/* 02: hidden item */
	0x29,0x2A,0x2B,0x2C,		/* 03: door */
	0x4D,0x2D,0x4F,0x2E,		/* 04: fire 1 left edge */
	0x2F,0x30,0x4F,0x50,		/* 05: fire 1 down edge */
	0x2D,0x4E,0x2E,0x50,		/* 06: fire 1 right edge */
	0x4D,0x4E,0x2F,0x30,		/* 07: fire 1 up edge */
	0x51,0x31,0x53,0x32,		/* 08: fire 2 left edge */
	0x33,0x34,0x53,0x54,		/* 09: fire 2 down edge */
	0x31,0x52,0x32,0x54,		/* 10: fire 2 right edge */
	0x51,0x52,0x33,0x34,		/* 11: fire 2 up edge */
	0x55,0x35,0x57,0x36,		/* 12: fire 3 left edge */
	0x37,0x38,0x57,0x58,		/* 13: fire 3 down edge */
	0x35,0x56,0x36,0x58,		/* 14: fire 3 right edge */
	0x55,0x56,0x37,0x38,		/* 15: fire 3 up edge */
	0x59,0x39,0x5B,0x3A,		/* 16: fire 4 left edge */
	0x3B,0x3C,0x5B,0x5C,		/* 17: fire 4 down edge */
	0x39,0x5A,0x3A,0x5C,		/* 18: fire 4 right edge */
	0x59,0x5A,0x3B,0x3C,		/* 19: fire 4 up edge */
	0x2D,0x2D,0x2E,0x2E,		/* 20: fire 1 left */
	0x2F,0x30,0x2F,0x30,		/* 21: fire 1 down */
	0x2D,0x2D,0x2E,0x2E,		/* 22: fire 1 right */
	0x2F,0x30,0x2F,0x30,		/* 23: fire 1 up */
	0x31,0x31,0x32,0x32,		/* 24: fire 2 left */
	0x33,0x34,0x33,0x34,		/* 25: fire 2 down */
	0x31,0x31,0x32,0x32,		/* 26: fire 2 right */
	0x33,0x34,0x33,0x34,		/* 27: fire 2 up */
	0x35,0x35,0x36,0x36,		/* 28: fire 3 left */
	0x37,0x38,0x37,0x38,		/* 29: fire 3 down */
	0x35,0x35,0x36,0x36,		/* 30: fire 3 right */
	0x37,0x38,0x37,0x38,		/* 31: fire 3 up */
	0x39,0x39,0x3A,0x3A,		/* 32: fire 4 left */
	0x3B,0x3C,0x3B,0x3C,		/* 33: fire 4 down */
	0x39,0x39,0x3A,0x3A,		/* 34: fire 4 right */
	0x3B,0x3C,0x3B,0x3C,		/* 35: fire 4 up */
	0x3D,0x3E,0x3F,0x40,		/* 36: fire 1 center */
	0x41,0x42,0x43,0x44,		/* 37: fire 2 center */
	0x45,0x46,0x47,0x48,		/* 38: fire 3 center */
	0x49,0x4A,0x4B,0x4C,		/* 39: fire 4 center */
	0x09,0x0A,0x0B,0x0C,		/* 40: breaking block 1 */
	0x0D,0x0E,0x0F,0x10,		/* 41: breaking block 2 */
	0x11,0x12,0x13,0x14,		/* 42: breaking block 3 */
	0x15,0x16,0x17,0x18,		/* 43: breaking block 4 */
	0x19,0x1A,0x1B,0x1C,		/* 44: breaking block 5 */
	0x05,0x06,0x07,0x08,		/* 45: breakable block */
	0x1D,0x1E,0x1F,0x20,		/* 46: bomb 1 */
	0x21,0x22,0x23,0x24,		/* 47: bomb 2 */
	0x25,0x26,0x27,0x28,		/* 48: bomb 3 */
	0x01,0x02,0x03,0x04			/* 49: unbreakable block */
};

unsigned char bkg_attr[] = {
	0x00,0x00,0x00,0x00,
	0x01,0x01,0x01,0x01,
	0x02,0x02,0x02,0x02,
	0x03,0x03,0x03,0x03,
	0x04,0x04,0x04,0x04,
	0x07,0x07,0x07,0x07
};

unsigned char *map_tiles[] = { 
	&bkg_tiles[	 0], &bkg_tiles[ 12], 0,0,&bkg_tiles[  4], &bkg_tiles[  8],0,0,	//00-07 
	&bkg_tiles[144], &bkg_tiles[ 80], &bkg_tiles[ 84], 0,0,0,0,0,				//08-0F
	&bkg_tiles[184],															//10
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//11-1F
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//20-2F
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//30-3F
	&bkg_tiles[196],															//40
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//41-4F
	&bkg_tiles[184],															//50
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//51-5F
	&bkg_tiles[180]																//60
};
														 
unsigned char *map_attr[] = {
	&bkg_attr[0], &bkg_attr[16],0,0, &bkg_attr[ 8], &bkg_attr[20],0,0,			//00-07
	&bkg_attr[0], &bkg_attr[ 0], &bkg_attr[ 0], 0,0,0,0,0,						//08-0F
	&bkg_attr[4],																//10
	  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//11-1F
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//20-2F
	0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//30-3F
	&bkg_attr[4],																//40
	  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//41-4F
	&bkg_attr[4],																//50
	  0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,											//51-5F
	&bkg_attr[4]																//60
};

unsigned char *fire_tiles[11][8] = {
	&bkg_tiles[144], &bkg_tiles[148], &bkg_tiles[152], &bkg_tiles[156],
	&bkg_tiles[152], &bkg_tiles[148], &bkg_tiles[144], &bkg_tiles[	0], /* 0: bomb explosion center */
	&bkg_tiles[ 16], &bkg_tiles[ 32], &bkg_tiles[ 48], &bkg_tiles[ 64],
	&bkg_tiles[ 48], &bkg_tiles[ 32], &bkg_tiles[ 16], &bkg_tiles[	0], /* 1: bomb explosion left edge */
	&bkg_tiles[ 80], &bkg_tiles[ 96], &bkg_tiles[112], &bkg_tiles[128],
	&bkg_tiles[112], &bkg_tiles[ 96], &bkg_tiles[ 80], &bkg_tiles[	0], /* 2: bomb explosion left */
	&bkg_tiles[ 20], &bkg_tiles[ 36], &bkg_tiles[ 52], &bkg_tiles[ 68],
	&bkg_tiles[ 52], &bkg_tiles[ 36], &bkg_tiles[ 20], &bkg_tiles[	0], /* 3: bomb explosion down edge */
	&bkg_tiles[ 84], &bkg_tiles[100], &bkg_tiles[116], &bkg_tiles[132],
	&bkg_tiles[116], &bkg_tiles[100], &bkg_tiles[ 84], &bkg_tiles[	0], /* 4: bomb explosion down */
	&bkg_tiles[ 24], &bkg_tiles[ 40], &bkg_tiles[ 56], &bkg_tiles[ 72],
	&bkg_tiles[ 56], &bkg_tiles[ 40], &bkg_tiles[ 24], &bkg_tiles[	0], /* 5: bomb explosion right edge */
	&bkg_tiles[ 88], &bkg_tiles[104], &bkg_tiles[120], &bkg_tiles[136],
	&bkg_tiles[120], &bkg_tiles[104], &bkg_tiles[ 88], &bkg_tiles[	0], /* 6: bomb explosion right */
	&bkg_tiles[ 28], &bkg_tiles[ 44], &bkg_tiles[ 60], &bkg_tiles[ 76],
	&bkg_tiles[ 60], &bkg_tiles[ 44], &bkg_tiles[ 28], &bkg_tiles[	0], /* 7: bomb explosion up edge */
	&bkg_tiles[ 92], &bkg_tiles[108], &bkg_tiles[124], &bkg_tiles[140],
	&bkg_tiles[124], &bkg_tiles[108], &bkg_tiles[ 92], &bkg_tiles[	0], /* 8: bomb explosion up */
	&bkg_tiles[164], &bkg_tiles[164], &bkg_tiles[168], &bkg_tiles[168],
	&bkg_tiles[172], &bkg_tiles[172], &bkg_tiles[176], &bkg_tiles[	0], /* 9: breaking block */
	&bkg_tiles[184], &bkg_tiles[184], &bkg_tiles[188], &bkg_tiles[188],
	&bkg_tiles[192], &bkg_tiles[192], &bkg_tiles[188], &bkg_tiles[188]	/* 10: bomb */
};

unsigned char fire_pattern[] = {
	0,1,2,3,4,5,6,7,8,9,2,2,4,4,6,6,8,8
};

UWORD bonus[] = {
	0,500UL,500UL,500UL,500UL,1000UL,1000UL,1000UL,2000UL
};

UBYTE bonus_stage_teki[]={0,1,2,3,4,5,6,7,7};
unsigned char time_tile[3], score_tile[5];
UBYTE pstat, pstage, pcnt, pspeed, ppower, premocon, pthroblock, pthrobomb, pmuteki;
UBYTE inbomb_flg, clear_flg, old_tile, time_cnt, wait_cnt;
UBYTE scpx, scpy;
UWORD scx, scy, px, py, x, y, pscore, old_time;
UBYTE num_bomb, max_bomb;
UBYTE num_teki, num_dieteki, bx_left, bx_right;
UBYTE map[MPSIZE_X][MPSIZE_Y];
UBYTE item_x, item_y, item_type, item_time, hidden_item;
UBYTE door_x, door_y;
UBYTE i, j, k, l, key_wait1, key_wait2, key, key_flg, die_wait, pmode;
UBYTE tt,tx,ty,ts;
UBYTE BQue_start, BQue_end;
UBYTE EQue_start, EQue_end;
UBYTE TQue_start, TQue_end;
UBYTE BQue_x[MAX_TT], BQue_y[MAX_TT], BQue_stat[MAX_TT];
UBYTE BQue_limit[MAX_TT], BQue_prev[MAX_TT], BQue_next[MAX_TT];
UBYTE EQue_x[MAX_TT], EQue_y[MAX_TT], EQue_stat[MAX_TT];
UBYTE EQue_pow[MAX_TT], EQue_i[MAX_TT], EQue_flg[MAX_TT];
UBYTE EQue_left[MAX_TT], EQue_right[MAX_TT], EQue_up[MAX_TT], EQue_down[MAX_TT];
UBYTE EQue_edge_l[MAX_TT], EQue_edge_r[MAX_TT], EQue_edge_u[MAX_TT], EQue_edge_d[MAX_TT];
UBYTE EQue_prev[MAX_TT], EQue_next[MAX_TT];
UWORD TQue_x[MAX_ET], TQue_y[MAX_ET];
UBYTE TQue_stat1[MAX_ET], TQue_stat2[MAX_ET], TQue_type[MAX_ET], TQue_move[MAX_ET];
UBYTE TQue_prev[MAX_ET], TQue_next[MAX_ET], TQue_score[MAX_ET], TQue_mode[MAX_ET];
extern UBYTE stage[];
extern UBYTE save_stage[3], save_speed[3], save_power[3];
extern UBYTE save_max_bomb[3],	save_item[3];
extern UWORD high_score;

UBYTE make_rnd( UBYTE );
void debug_print( UBYTE, UBYTE, UWORD );
void init_screen();
void istBombQue();
UBYTE delBombQue( UBYTE );
void istExplQue( UBYTE );
void istExplQueDirect();
UBYTE delExplQue( UBYTE );
void istTekiQue( UWORD, UWORD, UBYTE );
UBYTE delTekiQue( UBYTE );
void make_stage();
void start_stage();
void explosion_sub();
void enemy_move();
void score_up_sub( UWORD );
void set_item_panel();
void set_hidden_item();
void title();
UBYTE game_over();
void music();
void m_init();

void score_up( UWORD s, UBYTE bno )
{
	SWITCH_ROM_MBC1(3);
	score_up_sub(s);
	SWITCH_ROM_MBC1(bno);
}

void set_hidden_item( UBYTE bno )
{
	SWITCH_ROM_MBC1(2);
	set_hidden_item_sub();
	SWITCH_ROM_MBC1(bno);
}

void set_bkg_attr( UBYTE x, UBYTE y, UBYTE sx, UBYTE sy, unsigned char *d )
{
	if( _cpu==CGB_TYPE ) {
		if((bx_left<=x)&&(x<=bx_right)) {
			VBK_REG = 1;				/* select palette bank */
			set_bkg_tiles( x&0x1F, y, sx, sy, d );
			VBK_REG = 0;				/* select data bank */
		}
	}
}

void set_bkg_tiles2( UBYTE x, UBYTE y, UBYTE sx, UBYTE sy, unsigned char *d )
{
	if((bx_left<=x)&&(x<=bx_right))
		set_bkg_tiles( x&0x1F, y, sx, sy, d );
}

/* player */
void player()
{

	if(pstat>127U) {
		i=(pstat-128U)>>3;
		set_sprite_prop( 0, 0x00U );	set_sprite_prop( 1, 0x00U );
		set_sprite_tile( 0, 0x24+i*4);	set_sprite_tile( 1, 0x26+i*4);
		pstat++;
		if(pstat==184U) {
			move_sprite(0,0,0);	move_sprite(1,0,0);
			m_play(6,0);
			delay(2500UL);
			pcnt--;
			if(pcnt==0U) {
				pmode=MODE_OVER;
			} else {
				pmode=MODE_DIE;
			}
			premocon=FALSE;	pthroblock = 255U;	pthrobomb = 0U;
		}
		return;
	}

	key = joypad();

	if(key&(J_LEFT|J_RIGHT|J_UP|J_DOWN)) {
		pstat++;
		pstat&=0x07;
		//���� 
		if(pstat==1) {
			if(key&(J_LEFT|J_RIGHT)) {
				s_play(1);
			} else {
				s_play(2);
			}
		}
		// background tile set
		if((px>=256UL)&&(px<=736UL))
			if((px & 0x1F) == 0U) {
				bx_left=(px-256UL)>>4;
				bx_right=bx_left+30U;
				if(key&J_LEFT) {
					for(i=0U;i!=MPSIZE_Y;i+=2U) {
						set_bkg_tiles2( (px-256UL)>>4, i, 2U, 2U, map_tiles[map[(px-256UL)>>4][i]]);
						set_bkg_attr( (px-256UL)>>4, i, 2U, 2U, map_attr[map[(px-256UL)>>4][i]]);
					}
				}
				if(key&J_RIGHT) {
					for(i=0U;i!=MPSIZE_Y;i+=2U) {
						set_bkg_tiles2( (px+224UL)>>4, i, 2U, 2U, map_tiles[map[(px+224UL)>>4][i]]);
						set_bkg_attr( (px+224UL)>>4, i, 2U, 2U, map_attr[map[(px+224UL)>>4][i]]);
					}
				}
			}
		// move
		if( key&J_LEFT ) {
			set_sprite_tile( 0, walk_anim[pstat]); set_sprite_tile( 1, walk_anim[pstat] + 2 );
			set_sprite_prop( 0, 0x00U ); set_sprite_prop( 1, 0x00U );
			if((px&0x1F)==0U) {
				if((py&0x3F)==0U) {
					if((map[(px>>4)-4U][(py>>4)-2U]<UNMOVABLE)||(map[(px>>4)-4U][(py>>4)-2U]==pthrobomb)
						||((map[(px>>4)-4U][(py>>4)-2U]&BREAKABLEBLOCKS)==pthroblock)) {
						px-=pspeed;
					}
				} else if((py&0x1F)!=0U) {
					if((py&0x3F)<16U) {
						if((map[(px>>4)-4U][((py>>4)&0xFE)-2U]<UNMOVABLE)||(map[(px>>4)-4U][((py>>4)&0xFE)-2U]==pthrobomb)
							||((map[(px>>4)-4U][((py>>4)&0xFE)-2U]&BREAKABLEBLOCKS)==pthroblock)) {
							px-=pspeed;
							py-=4U;
						}
					} else if((py&0x3F)>48U) {
						if((map[(px>>4)-4U][((py>>4)&0xFE)]<UNMOVABLE)||(map[(px>>4)-4U][((py>>4)&0xFE)]==pthrobomb)
							||((map[(px>>4)-4U][((py>>4)&0xFE)]&BREAKABLEBLOCKS)==pthroblock)) {
							px-=pspeed;
							py+=4U;
						}
					}
				}
			} else {
				if((py&0x3F)==0U) {
					px-=pspeed;
				} else if((py&0x3F)<32U) {
					px-=pspeed;
					py-=4U;
				} else {
					px-=pspeed;
					py+=4U;
				}
				py&=0xFFFC;
			}		 
		} else if( key&J_RIGHT ) {
			set_sprite_tile( 0, walk_anim[pstat] + 2U); set_sprite_tile( 1, walk_anim[pstat]);
			set_sprite_prop( 0, S_FLIPX ); set_sprite_prop( 1, S_FLIPX );
			if((px&0x1F)==0U) {
				if((py&0x3F)==0U) {
					if((map[px>>4][(py>>4)-2U]<UNMOVABLE)||(map[px>>4][(py>>4)-2U]==pthrobomb)
						||((map[px>>4][(py>>4)-2U]&BREAKABLEBLOCKS)==pthroblock)) {
						px+=pspeed;
					}
				} else if((py&0x1F)!=0U) {
					if((py&0x3F)<16U) {
						if((map[px>>4][((py>>4)&0xFE)-2U]<UNMOVABLE)||(map[px>>4][((py>>4)&0xFE)-2U]==pthrobomb)
							||((map[px>>4][((py>>4)&0xFE)-2U]&BREAKABLEBLOCKS)==pthroblock)) {
							px+=pspeed;
							py-=4U;
						}
					} else if((py&0x3F)>48U) {
						if((map[px>>4][((py>>4)&0xFE)]<UNMOVABLE)||(map[px>>4][((py>>4)&0xFE)]==pthrobomb)
							||((map[px>>4][((py>>4)&0xFE)]&BREAKABLEBLOCKS)==pthroblock)) {
							px+=pspeed;
							py+=4U;
						}
					}
				}
			} else {
				if((py&0x3F)==0U) {
					px+=pspeed;
				} else if((py&0x3F)<32U) {
					px+=pspeed;
					py-=4U;
				} else {
					px+=pspeed;
					py+=4U;
				}
				py&=0xFFFC;
			}		 
		} else if( key&J_UP ) {
			set_sprite_tile( 0, walk_anim[pstat] + 0x18); set_sprite_tile( 1, walk_anim[pstat] + 0x1A);
			set_sprite_prop( 0, 0x00U ); set_sprite_prop( 1, 0x00U );
			if((py&0x1F)==0U) {
				if((px&0x3F)==0U) {
					if((map[(px>>4)-2U][(py>>4)-4U]<UNMOVABLE)||(map[(px>>4)-2U][(py>>4)-4U]==pthrobomb)
						||((map[(px>>4)-2U][(py>>4)-4U]&BREAKABLEBLOCKS)==pthroblock)) {
						py-=pspeed;
					}
				} else if((px&0x1F)!=0U) {
					if((px&0x3F)<16U) {
						if((map[((px>>4)&0xFE)-2U][(py>>4)-4U]<UNMOVABLE)||(map[((px>>4)&0xFE)-2U][(py>>4)-4U]==pthrobomb)
							||((map[((px>>4)&0xFE)-2U][(py>>4)-4U]&BREAKABLEBLOCKS)==pthroblock)) {
							px-=4U;
							py-=pspeed;
						}
					} else if((px&0x3F)>48U) {
						if((map[((px>>4)&0xFE)][(py>>4)-4U]<UNMOVABLE)||(map[((px>>4)&0xFE)][(py>>4)-4U]==pthrobomb)
							||((map[((px>>4)&0xFE)][(py>>4)-4U]&BREAKABLEBLOCKS)==pthroblock)) {
							px+=4U;
							py-=pspeed;
						}
					}
				}
			} else {
				if((px&0x3F)==0U) {
					py-=pspeed;
				} else if((px&0x3F)<32U) {
					py-=pspeed;
					px-=4U;
				} else {
					py-=pspeed;
					px+=4U;
				}
				px&=0xFFFC;
			}		 
		} else if( key&J_DOWN ) {
			set_sprite_tile( 0, walk_anim[pstat] + 0x0C); set_sprite_tile( 1, walk_anim[pstat] + 0x0E );
			set_sprite_prop( 0, 0x00U ); set_sprite_prop( 1, 0x00U );
			if((py&0x1F)==0U) {
				if((px&0x3F)==0U) {
					if((map[(px>>4)-2U][py>>4]<UNMOVABLE)||(map[(px>>4)-2U][py>>4]==pthrobomb)
						||((map[(px>>4)-2U][py>>4]&BREAKABLEBLOCKS)==pthroblock)) {
						py+=pspeed;
					}
				} else if((px&0x1F)!=0U) {
					if((px&0x3F)<16U) {
						if((map[((px>>4)&0xFE)-2U][py>>4]<UNMOVABLE)||(map[((px>>4)&0xFE)-2U][py>>4]==pthrobomb)
							||((map[((px>>4)&0xFE)-2U][py>>4]&BREAKABLEBLOCKS)==pthroblock)) {
							px-=4U;
							py+=pspeed;
						}
					} else if((px&0x3F)>48U) {
						if((map[((px>>4)&0xFE)][py>>4]<UNMOVABLE)||(map[((px>>4)&0xFE)][py>>4]==pthrobomb)
							||((map[((px>>4)&0xFE)][py>>4]&BREAKABLEBLOCKS)==pthroblock)) {
							px+=4U;
							py+=pspeed;
						}
					}
				}
			} else {
				if((px&0x3F)==0U) {
					py+=pspeed;
				} else if((px&0x3F)<32U) {
					py+=pspeed;
					px-=4U;
				} else {
					py+=pspeed;
					px+=4U;
				}
				px&=0xFFFC;
			}		 
		}
		if(((px & 0x1F) < pspeed)&&((py & 0x1F) < pspeed)) {
			px=px&0xFFE0;
			py=py&0xFFE0;
			i=map[(px>>4U)-2U][(py>>4U)-2U];
			if(i==DOOR) {
				if((pmuteki==0U)&&(key_wait2!=0U)) {
					pstat=128U;
					s_play(8);
				} else if(clear_flg==TRUE) {
					if(pstage==50U) {
						pmode=MODE_ENDING;
					} else {
						pmode=MODE_CLEAR;
						if((pstage%5)==0) pstage|=0x80;
						pstage++;
					}
				} else if(hidden_item==0x10) {
					set_hidden_item(0);
				}
			} else if((i&ITEMS)==ITEMS) {
				set_bkg_tiles2((px>>4U)-2U,(py>>4U)-2U,2,2,map_tiles[FLOOR]);
				set_bkg_attr((px>>4U)-2U,(py>>4U)-2U,2,2,map_attr[FLOOR]);
				map[(px>>4U)-2U][(py>>4U)-2U]=FLOOR;
				if(i==ITEM) {
					if((time_cnt>=140)&&((hidden_item==0x30)||(hidden_item==0x50))) {
						set_hidden_item(0);
					}
					switch(item_type)
					{
						case 0U:		//���e
							m_play(4,0);
							if(max_bomb<MAX_TT) max_bomb++;
							break;
						case 1U:		//�Η�
							m_play(4,0);
							if(ppower<MAX_POW) ppower+=2;
							break;
						case 2U:		//���[���[�X�P�[�g
							m_play(4,0);
							if(pspeed<MAX_SPEED) pspeed++;
							break;
						case 3U:		//�ǂ��蔲��
							m_play(4,0);
							pthroblock=BREAKABLEBLOCKS;
							break;
						case 4U:		//�����R��
							m_play(4,0);
							premocon=TRUE;
							break;
						case 5U:		//���e���蔲��
							m_play(4,0);
							pthrobomb=BOMB;
							break;
						case 6U:		//�Ή��o���A
							m_play(5,0);
							pmuteki=FIREBARRIER;
							item_time=60U;
							break;
						case 7U:		//�H
							m_play(5,0);
							pmuteki=MUTEKI;
							item_time=60U;
							break;
					}
					item_type=GETTED;
					s_play(5);
				} else {
					score_up(bonus[hidden_item],0);
					s_play(5);
					hidden_item=0;
				}
			}
		}
		if(inbomb_flg==TRUE) {
			if(((BQue_x[BQue_end]>>1)!=((px-16)>>5))||((BQue_y[BQue_end]>>1)!=((py-16)>>5))) {
				map[BQue_x[BQue_end]][BQue_y[BQue_end]]=BOMB;	//�ʍs�s���e
				inbomb_flg=FALSE;
			}
		}
		//scroll
		if(px<160UL) {
			scx=0;
			scpx=px>>1;
		} else if(px<832UL) {
			scx=(px-160UL)>>1;
			scpx=80U;
		} else {
			scx=336UL;
			scpx=(px-672UL)>>1;
		}
		if(py<160UL) {
			scy=0;
			scpy=py>>1;
		} else if(py<352UL) {
			scy=(py-160UL)>>1;
			scpy=80U;
		} else {
			scy=96U;
			scpy=(py-192UL)>>1;
		}
		SCX_REG = scx;
		SCY_REG = scy;
		move_sprite( 0, scpx-8U, scpy ); move_sprite( 1, scpx, scpy );
		key_wait1-=(key_wait1>0);
	}
	i=map[((px-16U)>>4)&0xFE][((py-16U)>>4)&0xFE];
	//�`�{�^�� = ���e
	if(key&J_A) {
		if(num_bomb<max_bomb) {
			if((old_tile&0xFC)==(i&0xFC)) {
				if(i==FLOOR) {
					SWITCH_ROM_MBC1(1);
					istBombQue();
					SWITCH_ROM_MBC1(0);
					inbomb_flg=TRUE;
					s_play(3);
					key_wait1=0;
					key_wait2=0;
				} else if((i&FIRES)==FIRES) {
					if(key_wait1==0) {
						if(ppower<=6U) {
							key_wait2=7U;
							key_wait1=2;
						} else if(ppower<=12U) {
							key_wait2=12U;
							key_wait1=4;
						} else {
							key_wait2=17U;
							key_wait1=7;
						}
						SWITCH_ROM_MBC1(1);
						istExplQueDirect();
						SWITCH_ROM_MBC1(0);
					} else {
						//�������蔻��
						if((pmuteki==0U)&&(key_wait2==0U)) {
							pstat=128U;
							s_play(8);
						}
					}
				}
			} else {
				old_tile=i;
			}
		} else if(hidden_item==0x20) {
			set_hidden_item(0);
		}
	} else {
		//�a�{�^�� = �����R��
		if(key&J_B) {
			if((premocon==TRUE)&&(key_flg==FALSE)) {
				if(BQue_start!=EMPTY) {
					BQue_limit[BQue_start]=1U;
					key_flg=TRUE;
					die_wait=0;
				}
			}
		} else if(key&J_START) {
			//�|�[�Y
			s_play(7);
			m_stop(0);
			waitpadup();
			waitpad(J_START);
			s_play(7);
			m_stop(1);
			waitpadup();
		} else {
			key_flg=FALSE;
		}
		//�������蔻��
		if((pmuteki==0U)&&((i&FIRES)==FIRES)) {
			die_wait++;
			if(die_wait>4U) {
				pstat=128U;
				s_play(8);
			}
		}
		key_wait1=0;
		key_wait2=0;
	}
	if(key_wait2>0) {
		key_wait2--;
		key_wait1-=(arand()&1);
	}
}

/* bomb */
void bomb()
{
	if(BQue_start!=EMPTY) {
		i=BQue_start;
		do {
			set_bkg_tiles2( BQue_x[i], BQue_y[i], 2, 2, fire_tiles[10][BQue_stat[i]>>2]);
			BQue_stat[i]++;
			BQue_stat[i]&=0x1F;
			BQue_limit[i]-=(BQue_limit[i]!=255U);
			if(BQue_limit[i]==0) {
				SWITCH_ROM_MBC1(1);
				istExplQue(i);
				i=delBombQue(i);
				SWITCH_ROM_MBC1(0);
			} else {
				i=BQue_next[i];
			}
		} while(i!=EMPTY);
	}
}

/* explosion */
void explosion()
{
	if(EQue_start!=EMPTY) {
		j=EQue_start;
		do {
			SWITCH_ROM_MBC1(3);
			explosion_sub();
			SWITCH_ROM_MBC1(0);
			if(EQue_stat[j]==8U) {
				SWITCH_ROM_MBC1(1);
				j=delExplQue(j);
				SWITCH_ROM_MBC1(0);
			} else {		
				j=EQue_next[j];
			}
		} while(j!=EMPTY);
	}
}

/* enemy */
void enemy()
{
	if(TQue_start!=EMPTY) {
		i=TQue_start;
		do {
			if(TQue_stat1[i]==254U) {
				SWITCH_ROM_MBC1(1);
				i=delTekiQue(i);
				SWITCH_ROM_MBC1(0);
			} else {
				SWITCH_ROM_MBC1(3);
				enemy_move();
				SWITCH_ROM_MBC1(0);		
				i=TQue_next[i];
			}
		} while(i!=EMPTY);
	}
}

void timer()
{
	if((time_cnt!=0)&&((sys_time-old_time)>=60U)) {
		time_cnt--;
		old_time=sys_time;
		time_tile[0]=0x5D+time_cnt/100UL;
		i=time_cnt%100UL;
		time_tile[1]=0x5D+i/10U;
		time_tile[2]=0x5D+time_cnt%10UL;
		if(time_tile[0]==0x5D) {
			time_tile[0]=0x67;
			if(time_tile[1]==0x5D)
				time_tile[1]=0x67;
		}
		set_win_tiles( 5, 0, 3, 1, time_tile );
		if(time_cnt==0) {
			//�ʏ�X�e�[�W�̏ꍇ�A�G�o��
			if(pstage<0x80) {
				TQue_start=EMPTY; TQue_end=EMPTY;
				for(i=0;i<MAX_ET;i++) {
					TQue_prev[i]=EMPTY;
					set_sprite_tile( i+(MAX_ET<<1U)+2U, 0xF0U);
				}
				SWITCH_ROM_MBC1(1);
				num_teki=0;	num_dieteki=0;
				while(num_teki<MAX_ET) {
					x=make_rnd(MPSIZE_X>>1)*16UL;
					y=make_rnd(MPSIZE_Y>>1)*16UL;
					if((map[x>>3][y>>3]==FLOOR)&&((absw((px>>1)-x)>96U)||(absw((py>>1)-y)>80U))) istTekiQue(x+16UL,y+16UL,stage[(pstage-1)*6UL+4]>>4);
				}
				SWITCH_ROM_MBC1(0);
			} else {
			//�{�[�i�X�X�e�[�W�̏ꍇ�A�X�e�[�W�I��
				pmode=MODE_CLEAR;
				pstage-=0x80;
			}
		}
		//�Ή��o���A�E���G�̎��Ԑ؂�
		if(item_time!=0) {
			item_time--;
			if(item_time==3U) {
				m_play(3,0);
			} else if(item_time==0U) {
				pmuteki=0U;
			}
		}
	}
}

/*--------------------------------------------------------------------------*
 | main program																														 |
 *--------------------------------------------------------------------------*/
void main()
{
	disable_interrupts();
	DISPLAY_OFF;

	initarand(0);
	SWITCH_ROM_MBC1(3);
	m_init();
	add_VBL( music );
	SWITCH_ROM_MBC1(2);
	init_screen();
	set_interrupts( VBL_IFLAG );
	DISPLAY_ON;
	enable_interrupts();
	ENABLE_RAM_MBC1;
	SWITCH_RAM_MBC1(0);

	//�Z�[�u�f�[�^������
	for(i=0; i<3; i++) 
		if(save_stage[i]==0) {
			save_stage[i]=1U;	save_speed[i]=3U;	save_power[i]=4U;
			save_max_bomb[i]=2U;	save_item[i]=0U;
		}
	if((joypad()&J_START)&&(joypad()&J_SELECT)) high_score=0;
	pmode=MODE_TITLE;
	while(1) {
		SWITCH_ROM_MBC1(2);
		title();
		pmode=MODE_GAME;
		while(pmode!=MODE_TITLE) {
			SWITCH_ROM_MBC1(2);
			start_stage();
			SWITCH_ROM_MBC1(1);
			make_stage();
			SWITCH_ROM_MBC1(2);
			set_item_panel();
			pmode=MODE_GAME;
			while(pmode==MODE_GAME) {
				wait_cnt=sys_time;
				timer();
				player();
				enemy();
				bomb();
				explosion();
				while((UBYTE)(sys_time-wait_cnt)<2U);
			}
			switch(pmode) {
				case MODE_OVER:
					SWITCH_ROM_MBC1(2);
					pmode=game_over();
					break;
				case MODE_CLEAR:
					m_play(10,0);
					delay(3400UL);
					item_type=RESET;
					break;
				case MODE_ENDING:
					m_play(10,0);
					delay(5000UL);
					SWITCH_ROM_MBC1(2);
					ending();
					pmode=MODE_GAME;
					break;
			}
		}
	}
}
