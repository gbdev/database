pushs
SECTION "varm", BSS
;vars:
;-------------------------------- Music vars
plvMusic        ds 2    ;Music addr
plvDelay        ds 1    ;Music delay
plvDelayC       ds 1    ;Left delay
plvMusLen       ds 1    ;Music length (positions)
plvLoopTo       ds 1    ;Loop to position

plvSampAddrs    ds 2    ;Sample addresses
plvOrnAddrs     ds 2    ;Ornament addresses
plvPosAddrs     ds 2    ;Position list address
plvPatAddrs     ds 2    ;Pattern addresses

plvChannelA     ds 2    ;Channel Addr
plvChannelB     ds 2
plvChannelC     ds 2
plvVolumeA      ds 1    ;Sample volume
plvVolumeB      ds 1
plvVolumeC      ds 1
plvNoteLeftA    ds 1    ;Note delay Left
plvNoteLeftB    ds 1
plvNoteLeftC    ds 1
plvNoteDelA     ds 1    ;Note delay
plvNoteDelB     ds 1
plvNoteDelC     ds 1
plvSampAddrA    ds 2    ;Addr of current sample
plvSampAddrB    ds 2
plvSampAddrC    ds 2
plvSampQuarkA   ds 1    ;Current quark in sample
plvSampQuarkB   ds 1
plvSampQuarkC   ds 1
plvSampQuarkTA  ds 1    ;Cycle sample to
plvSampQuarkTB  ds 1
plvSampQuarkTC  ds 1
plvSampQuarksA  ds 1    ;Quarks in sample
plvSampQuarksB  ds 1
plvSampQuarksC  ds 1
plvOrnQuarkA    ds 1    ;Current quark in ornament
plvOrnQuarkB    ds 1
plvOrnQuarkC    ds 1
plvOrnQuarkTA   ds 1    ;Cycle ornament to
plvOrnQuarkTB   ds 1
plvOrnQuarkTC   ds 1
plvOrnQuarksA   ds 1    ;Quarks in ornament
plvOrnQuarksB   ds 1
plvOrnQuarksC   ds 1
plvNoteA        ds 1    ;Note
plvNoteB        ds 1
plvNoteC        ds 1

plvDVolumeA     ds 1    ;Temporary Volume
plvDVolumeB     ds 1
plvDVolumeC     ds 1
plvDToneA       ds 2    ;Temporary Tone
plvDToneB       ds 2
plvDToneC       ds 2
plvNVolumeA     ds 1    ;Temporary noise volume
plvNVolumeB     ds 1
plvNVolumeC     ds 1
;-------------------- this 13 vars together
plvOrnAddrA     ds 2    ;Ornament address (if zero - no ornament)
plvOrnAddrB     ds 2
plvOrnAddrC     ds 2
plvEnvelopeA    ds 1    ;Envelope
plvEnvelopeB    ds 1
plvEnvelopeC    ds 1
plvNoiseAddA    ds 1    ;Noise addition (command)
plvNoiseAddB    ds 1
plvNoiseAddC    ds 1
plvPos          ds 1    ;Positions left to play
;-------------------------------------------------- end of 13 vars

plvEnvelope     ds 2    ;Envelope Value
plvNoise        ds 1    ;Noise value, $ff - no noise
plvONoise       ds 1    ;Old Noise value
plvNoiseC       ds 1    ;Noise channels out
plvONoiseV      ds 1    ;Old noise volume value

plvOVolumeA     ds 1    ;Old value of Volume
plvOVolumeB     ds 1
plvOVolumeC     ds 1
plvChannels     ds 1    ;to $FF25
pops