;
ObjFpsIndex    equ 0    ;FPS
ObjPntsIndex   equ 5    ;PNTS
ObjLinesIndex  equ 11   ;LINES
;
ObjFpsCoord    equ $1878
ObjPntsCoord   equ $8810
ObjLinesCoord  equ $9010

