Screen0     equ $9800
Screen1     equ $9c00
;
logoPause1  equ 10
logoPause2  equ 4
logoPause3  equ 60
logoPause4  equ 80
MyObjects   equ $c000
OAMbuf      equ $c000
TextPlace   equ $d000
dmaTrans    equ $fff5
;
Xwindow     equ 2
Ywindow     equ 1
ShapeMax    equ 2
pnts        equ 40
sbuf0       equ $d0
sbuf1       equ $d8
;
;------------------ CGB Control Registers -----------------
rIF         equ $ff0f
rLCDC       equ $ff40
rSTAT       equ $ff41
; --
; -- SCY ($FF42)
; -- Scroll Y (R/W)
; --
rSCY        equ $ff42

; --
; -- SCY ($FF43)
; -- Scroll X (R/W)
; --
rSCX        equ $ff43

; -- LY ($FF44)
; -- LCDC Y-Coordinate (R)
; --
; -- Values range from 0->153. 144->153 is the VBlank period.
; --
rLY         equ $ff44

; -- LYC ($FF45)
; -- LY Compare (R/W)
; --
; -- When LYEQUEQULYC, STATF_LYCF will be set in STAT
; --
rLYC        equ $ff45

rVBK        equ $ff4f

rHDMA1      equ $ff51   ; 5 registers for new DMA control
rHDMA2      equ $ff52   ;
rHDMA3      equ $ff53   ;
rHDMA4      equ $ff54   ;
rHDMA5      equ $ff55   ;

rSVBK       equ $ff70 
rIE         equ $ffff