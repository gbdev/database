SECTION "vars", BSS[$c000]
;vars:
                 ds 160 ; OAM bufer

VblankFlag       ds 1
rndStore         ds 1
Keys             ds 1 
angleX           ds 1   ; |
angleY           ds 1   ; | together
angleZ           ds 1   ; |
dist             equ 1 
Shape            ds 1
KeyDelay         ds 1 
numBuf           ds 6
Surfaces         ds 2
frames           ds 2
vblanks          db
vmode            db
vproc            db
TriStack         ds 2
RectXYsize       dw     ; | together
RectAttr         db     ; |
RectTile         db  
;
PrintXY          dw
PrintX           db
PrintMode        db
PrintTiles       dw
PrintAtr         db
;
SnowTemp         db
SpeedArray       equ $c100   ; zero at the end
HorizArray       equ $c200
yMax             equ 159
;
ObjScrStadia     db
ObjScrTextStore  dw
sdx              db  ; | together
sdy              db  ; |
wPal             db
isMotion
;
SECTION "varst", BSS[$c100]
EdgeBuffer       ds 256
CurrentTriangl   ds 256
CurrentPoints    ds 256 ; |
RotatedPoints    ds 256 ; | together
sqrTab           ds 1024 
VisibleSurfaces  ds 128
FreeMem          ds 128
FastTriCode      ds 512
LeftMaskAdress   ds 768