Jet Pak DX (aka GB JetPac)

Version History
0.06  - A day after v0.05 was released I got a small email from someone informing me
        that someone else had gone to the trouble of hacking my game, to produce a
        patch to get rid of the BETA v0.05 text from the centre of the screen. Now
        what I don't understand is, why the hell they even bothered. The fact of the
        matter is, the game isn't finished, and that's why the BETA text is there.
        Obviously, when the game is finish I'll remove it. Here I am writing a FREE
		Gameboy Colour game for you lot to play, and someone goes and rapes my code.
		I'm reluctant to release thise update, but here it is.
		You can now pick up the Spaceship pieces and assemble the craft, and also
		I added the bits of fuel for you to collect, to fuel up the ship.
		After fueling the ship up (turning it purple) I've yet to finish the code off
		for you to get into it and fly away to the next level.
0.05s - After some great feedback I got via email and IRC, I've changed a few things
        around in version 0.05, most importantly I've slowed the game down, as it
        seems alot of you think it's too fast. I don't but maybe that's because I
        play test it so much as I'm coding it. Also I've added a pause function, and
        the controls at the beginning on the splash screen.
0.05  - Big day today, added COLOUR!. Also redrew all the sprites, and rewrote all
        the source code. Hopefully things are a lot more neater now, but still
        not as great as I would like them to be.
        Added lives, so you can now die. HiScore, a core ingredient of the old ways.
        I put the three Spaceship parts in, and I know you can't do anything with
        them yet, but they're there just to see how things will come together.
        After seeing the response FoulOne got with his GB Lander Homepage, I've
        knocked one up with all the previous betas available with screenshots. And
        even the 'not so great' source code for the first Beta.
        http://datapotato.simplenet.com/gbdev/
	   
0.04  - Added very scruffy code for baddies, baddies detection, killing baddies,
        baddies killing man. I really gotta clean it up later.
        Simple animation for popped man, and dusted baddie.
        Added a quick 'Press Start' splash screen.
	   
0.03  - Rearranged code, started modularistion, and changed gravity routine
        Fixed walking of ledges and still walking while falling bug
        Added laser fire, with collision detection between lasers and platforms

0.02  - Redid all the graphics, making them smaller, so the play area is larger
        Put the tree platforms in and a floor, and did simple collision detection
        for man and platforms

0.01  - Ripped the graphics directly from the Spectrum version for the little space
        man. Had him floating about
	   	   

comments and stuff to : quang@mindless.com

	   