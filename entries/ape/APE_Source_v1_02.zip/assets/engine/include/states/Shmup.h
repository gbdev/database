#ifndef STATE_SHMUP_H
#define STATE_SHMUP_H

#include <gb/gb.h>

void Start_Shmup();
void Update_Shmup();

#endif
