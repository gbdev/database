#ifndef CORE_MAIN_H
#define CORE_MAIN_H

#include <gb/gb.h>

int core_start();
void SetScene(UINT16 state);

extern UINT16 current_state;

#endif
