 ____________________________________________________________________________
/                                                                            \
|--Bitte 8 Bit-------------------------------------------------------HITMEN--|
|                                                                            |
| Yeppa... another Hardware.... another Demo ;=P                             |
|                                                                            |
| WILD! demo contribution at mekka symposium 2000                            |
|                                                                            |
| * credits *                                                                |
|                                                                            |
| programming:      groepaz                                                  |
| graphics:         groepaz                                                  |
|                   curlin                                                   |
| music:            worthless                                                |
|                                                                            |
| * contact *                                                                |
|                                                                            |
| http://www.hitmen-console.org                                              |
|                                                                            |
\____________________________________________________________________________/
