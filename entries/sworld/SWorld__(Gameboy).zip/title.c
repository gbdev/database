/* title.c - Included in shootup.c 
  This file deals with the title screen only	
*/

void show_wave (void)
{
  UBYTE e;
  for ( e = 0 ; e < 3 ; e ++ )
  {
    set_sprite_tile ( e+25 , 82+(e*2) );
    move_sprite ( e+25 , 76+(e*8) , 70 );
  }

  set_sprite_tile ( 28, (wave*2)+28 );
  move_sprite (28,82,80);
}

void remove_wave (void)
{
  UBYTE e;
  for ( e = 0 ; e < 4 ; e ++ )
  {
    move_sprite( e+25 , 0 , 0 );
  }
}

void pause (void)
{
  UBYTE e;
  UBYTE joy = joypad();  

  for ( e = 0 ; e < 4 ; e++ )
  {
    set_sprite_tile ( e+25 , 88+(e*2) );  
    move_sprite ( e + 25 , 76 + (8*e) , 70 );
  }

  while (joy & J_START)
    joy = joypad ();
  while ((joy & J_START) == 0)
    joy = joypad ();
  while (joy & J_START)
    joy = joypad ();

  for ( e = 0 ; e < 4 ; e++ )
    move_sprite ( e + 25 , 0 , 0 );

  if (showwave > 0)
  {
     show_wave();
  }
}

void put_hiscore (long int s,UBYTE y, UBYTE sp)
{
  long int x;
  UBYTE t;

  for (t=0;t<5;t++)
  {
    move_sprite (sp+t,135+(t*5),y);
    set_sprite_prop(sp+t,0);
  }
  
  /*put the score on the screen */  
  x = (s / 10000) % 10;
  t = (unsigned char) x;
  t = (t * 2)+28;
  set_sprite_tile (sp,t);
  
  x = (s / 1000) % 10;
  t = (unsigned char) x;
  t = (t * 2)+28;
  set_sprite_tile (sp+1,t);
 
  x = (s / 100)% 10;
  t = (unsigned char) x;
  t = (t * 2)+28;
  set_sprite_tile (sp+2,t);

  x = (s /10)% 10;
  t = (unsigned char) x;
  t = (t * 2)+28;
  set_sprite_tile (sp+3,t);

  x = s % 10;
  t = (unsigned char) x;
  t = (t * 2)+28;
  set_sprite_tile (sp+4,t);
}

UBYTE title_page (void)
{
  UBYTE joy,last;
  UBYTE men;
  DISPLAY_OFF;
 
  for (joy=0;joy<40;joy++)
    move_sprite(joy,0,0);

  if( _cpu==CGB_TYPE )
  {
    /* set the title palettes */
    set_bkg_palette_entry(0,0,RGB(31,31,31));
  	set_bkg_palette_entry(0,1,RGB(5,5,31));
  	set_bkg_palette_entry(0,2,RGB(5,31,5));
    set_bkg_palette_entry(0,3,RGB(0,0,0));

    set_sprite_palette_entry(0,0,RGB(31,31,31));
    set_sprite_palette_entry(0,1,RGB(31,0,0)); 
    set_sprite_palette_entry(0,2,RGB(0,0,31));
    set_sprite_palette_entry(0,3,RGB(31,31,0));

    set_sprite_palette_entry(1,0,RGB(0,0,0));
    set_sprite_palette_entry(1,1,RGB(31,0,0));
    set_sprite_palette_entry(1,2,RGB(25,0,31));
    set_sprite_palette_entry(1,3,RGB(0,0,0));
  }
 
  move_bkg(0,0);

	set_bkg_data (0,118,tiledata);
	set_bkg_tiles (0,0,20,18,tilemap);

  SHOW_BKG;	
  DISPLAY_ON;
  SHOW_SPRITES;

  put_hiscore (score,110,0);
  put_hiscore (hiscore,120,5);

  /* setup prev*/
  set_sprite_tile(11,49);
  set_sprite_tile(12,50);
  set_sprite_tile(13,51);
  set_sprite_prop(11,1);
  set_sprite_prop(12,1);
  set_sprite_prop(13,1);
  
  move_sprite(11,116,110);
  move_sprite(12,124,110);
  move_sprite(13,132,110);

  /* setup hi*/
  set_sprite_tile(14,52);
  set_sprite_tile(15,53);
  set_sprite_prop(14,1);
  set_sprite_prop(15,1);
  
  move_sprite(14,125,120);
  move_sprite(15,133,120);
   
  /* setup sound */
  set_sprite_tile (16,54);
  set_sprite_tile (17,55+soundon);
  set_sprite_prop (16,1);
  set_sprite_prop (17,1);
  
  move_sprite (16,146,150);
  move_sprite (17,156,150);

  /* setup at sprite */
  set_sprite_tile (18,57);
  set_sprite_prop (18,1);
  
  last = 0;
  while ((joy & J_START) == 0)
  { 
    joy = joypad ();
    if ((joy & J_SELECT) && !(last & J_SELECT))
    {
      if (soundon == 0)
        soundon=1;
      else
        soundon=0;
      set_sprite_tile (17,55+soundon);
      save_hiscore();
    }
    if (joy & J_A)
    {
      move_sprite (18,68,150);
      men = 4;
    }
    else if (joy & J_B)
    { 
      move_sprite (18,68,150);
      men = 5;
    }
    else
    {
      move_sprite (18,0,0);
      men = 3;
    }
    last = joy;
  }
  while (joy & J_START)
    joy = joypad ();
  
  return men;
}

