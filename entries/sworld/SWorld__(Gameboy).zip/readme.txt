S World
-------

By Shen Mansell (shenmansell@hotmail.com)
Created for the www.lik-sang.com coding contest - April 2000.

a game for color or original gameboy (or emulator)

Story 
-----

Argh. The darn aliens are back again. They are trying to destroy the earth!
Fly into space and kill as many of them as you can. 

Start off fighting face to face with a single alien, then progress to
fighting more and more at once.

From The Menu
-------------

Start - Starts a new game
Select - Toggle the sound on and off

(hold A or B when you press start to start at a harder level)

In The Game
-----------

Start - Pause
Select - Toggle between single and double shots. Double shots cost 1 point
 each time you fire. Single shots are free.
A & B - Fire. You can have a maximium of 4 bullets on the screen at once.
 In double mode both buttons will fire from each side of the ship if
 possible. If you have 3 bullets on the screen, or are in single shot mode
 then A will fire from the left side of your ship, B from the right.

About The Code
--------------

S World was coded in C and compiled using GBDK-2.0 beta.
The sprites and backgrounds were created with Harry Mulders 
Tile (v2.2) and Map (v1.8) Designers.
The title screen was converted to gameboy tile format using pcx2gb
- Megaman X's picture converter. 

All Code and Artwork was created by Shen Mansell.
 
Running the sworld.bat file in the same directory as the code should 
recompile the game.
 
This game has been tested on:
Gameboy Color
Gameboy Original (circa 1993)
no$gmb
smygb
helloGAMEBOY

and it works on all of them, but is best on the color gameboy.

Have fun!

