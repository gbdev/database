#include <gb.h>
#include "sprites.c"
#include "monsters.c"
#include "words.c"
#include "map.c"
#include "bkg.c"

#include "t_tiles.c"
#include "t_map.c"

#define STRAIGHT 1
#define SIDE 2
#define HOMING 3
#define ENEMYNUM 6

UBYTE kill_limit [7] = {0,1,2,10,20,20,40}; /* the killnumber of each wave */

UBYTE enemy_x [ENEMYNUM], enemy_y [ENEMYNUM];
UBYTE enemy_firetype [ENEMYNUM];
UBYTE efire_x [ENEMYNUM],efire_y [ENEMYNUM];
UBYTE efire_t [ENEMYNUM];
UBYTE efire_moves [ENEMYNUM];
UBYTE edead[ENEMYNUM]; 
BYTE emove_x[ENEMYNUM]; /* the x direction of enemy movement */
BYTE emove_y[ENEMYNUM]; /* the y direction of enemy movement */

UBYTE homingspeed; /* the homingspeed of the enemy bullets */
UBYTE edelay; /* the lenght of time the enemy explosion stays on the screen */

UBYTE player_x; /* the players x position */
UBYTE pfire_x[4],pfire_y[4]; /* the x and y position of player bullets */
UBYTE pdead; /* is the player dead 0=no, more then 0 = yes */
UBYTE pinvincible; /* how much invincibility the player has 0 = none */
UBYTE numshots; /* how many shots the player wants to fire at once (1 or 2) */
UBYTE freeman; /* has the player gained a freeman */
UBYTE tookshot; /* did the player shoot successfully this turn */
UBYTE lives; /* number of lives the player has */

UBYTE wave; /* what wave the player is up to */
UBYTE showwave; /* should the wave # be on the screen? 0=no, more then 0 = yes */
UBYTE wavecolors; /* number of different colors the enemies can be during the wave */
UBYTE wave_enemies; /* number of enemies on the screen during the wave */
UBYTE level; /* what level the player is at (9 levels in a wave) */
UBYTE kills; /* how many enemies the player has killed this level */
UBYTE killnumber; /* how many enemies the player must kill to go up a level */

long int score, hiscore; /* player score and all time high score */
UBYTE soundon; /* is the sound on? */

void play (UBYTE men);
void show_lives (void);
void save_hiscore(void);
void setup_enemy(UBYTE e);

#include "title.c"

void sound_lazer (void)
{
  if (soundon)
  {
    NR21_REG = 0x0FU;
    NR22_REG = 0x69U;
    NR23_REG = 0x11U;
    NR24_REG = 0xC6U;
  
    NR51_REG = 0xF7U;
  }
}

void sound_shoot (void)
{
  if (soundon)
  {
    NR41_REG = 0x3FU;
    NR42_REG = 0xF1U;
    NR43_REG = 0x21U;
    NR44_REG = 0x80U;

    NR51_REG = 0xF7;
  }
}

void sound_you_die (void)
{
  if (soundon)
  {
    NR41_REG = 0x1FU;
    NR42_REG = 0xF7U;
    NR43_REG = 0x24U;
    NR44_REG = 0x80U;

    NR51_REG = 0xF7U;
  }
}

void put_score (void)
{
  long int x;
  unsigned char t;

  if ((freeman==0) && (score >500))
  {
    freeman=1;
    lives++;
    show_lives();
  }

  if (score < 480)
    edelay = 100 - (score / 5);
  else
    edelay = 10;
 
  put_hiscore (score,17,35);
}

void show_lives (void)
{
  UBYTE e;
  for (e = 0 ; e<5 ; e ++)
  {
    set_sprite_tile ( 30 + e , 48 );
    set_sprite_prop ( 30 + e , 2 );
    move_sprite ( 30 + e , 0 , 0 );
    if (lives > e+1)
    {
      move_sprite ( 30 + e , 7*(e+1)+1, 152 );
    }
  }
}

void init_score (void)
{
  UBYTE x;
  
  for (x=0;x<5;x++)
  {
    set_sprite_tile(x+35,22);
    set_sprite_prop(x+35,0);
    move_sprite(x+35,140+(x*5),18);
  }  

  put_score ();
}

void set_palettes (void)
{
  if( _cpu==CGB_TYPE )
  {
    /* your ship palette */
    set_sprite_palette_entry(0,0,RGB(0,0,0));
    set_sprite_palette_entry(0,1,RGB(23,23,23)); 
    set_sprite_palette_entry(0,2,RGB(15,15,15));
    set_sprite_palette_entry(0,3,RGB(0,0,0));

    /* lazer palette */
    set_sprite_palette_entry(1,0,RGB(0,0,0));
    set_sprite_palette_entry(1,1,RGB(31,0,0));
    set_sprite_palette_entry(1,2,RGB(23,0,23));
    set_sprite_palette_entry(1,3,RGB(0,0,0));

    /* your men palette */
    set_sprite_palette_entry(2,0,RGB(0,0,0)); 
    set_sprite_palette_entry(2,1,RGB(23,23,23));
    set_sprite_palette_entry(2,2,RGB(31,0,0));
    set_sprite_palette_entry(2,3,RGB(0,0,0));

    /* enemy wave 1 palette */
    set_sprite_palette_entry(3,0,RGB(0,0,0)); 
    set_sprite_palette_entry(3,1,RGB(23,23,23));
    set_sprite_palette_entry(3,2,RGB(15,15,15));
    set_sprite_palette_entry(3,3,RGB(0,0,0));

    /* enemy wave 2 palette */
    set_sprite_palette_entry(4,0,RGB(0,0,0));
    set_sprite_palette_entry(4,1,RGB(15,31,15));
    set_sprite_palette_entry(4,2,RGB(0,21,0));
    set_sprite_palette_entry(4,3,RGB(0,0,0));

    /* enemy wave 3 palette */ 
    set_sprite_palette_entry(5,0,RGB(0,0,0));
    set_sprite_palette_entry(5,1,RGB(31,10,10));
    set_sprite_palette_entry(5,2,RGB(21,0,0));
    set_sprite_palette_entry(5,3,RGB(0,0,0));

   /* enemy wave 4 palette */ 
    set_sprite_palette_entry(6,0,RGB(0,0,0));
    set_sprite_palette_entry(6,1,RGB(30,05,30));
    set_sprite_palette_entry(6,2,RGB(15,05,15));
    set_sprite_palette_entry(6,3,RGB(0,0,0));

   /* enemy wave 5 palette */ 
    set_sprite_palette_entry(7,0,RGB(0,0,0));
    set_sprite_palette_entry(7,1,RGB(0,31,31));
    set_sprite_palette_entry(7,2,RGB(05,05,31));
    set_sprite_palette_entry(7,3,RGB(0,0,0));

    /* background palette */
    set_bkg_palette_entry(31,31,31);
    set_bkg_palette_entry(0,1,RGB(0,0,31));
    set_bkg_palette_entry(0,2,RGB(31,31,0));
    set_bkg_palette_entry(0,3,RGB(31,0,0));
  }
}

void setup_all_enemy_fire(void)
{
  UBYTE e;
  
  for (e=0;e<ENEMYNUM;e++)
  {
    efire_x[e] = 0;
    efire_y[e] = 170;

    efire_t[e] = STRAIGHT;
    efire_moves[e] = 0;
  
    /* setup the enemy shot */
    set_sprite_tile(e+17,24); 
    set_sprite_prop(e+17,1);
  }
}

void setup_all_enemies (void)
{
  UBYTE e;
  for (e = 0 ; e < ENEMYNUM ; e ++)
      setup_enemy (e);
}
  
void setup_enemy (UBYTE e)
{
  UBYTE shiptype;


  enemy_y[e] = (((player_x+e) % 7)+2) * 10;

  if ((level >3) && (enemy_y[e] > 40))
    enemy_y[e] -=12;

  emove_y[e] = 0;
  if ((enemy_y[e] < 60) && (((e+kills)%3)==0))
    emove_y[e] = 1;
  if ((enemy_y[e] > 30) && (((e+kills)%3)==1))
    emove_y[e] = -1;

  if ((e+kills)%2 == 0)
  {
    emove_x[e] = 1;
    enemy_x[e] = 0;
    set_sprite_prop(e+9,((kills+e)%wavecolors)+3);
  }
  else
  {
    emove_x[e] = -1;
    enemy_x[e] = 170;  
    set_sprite_prop(e+9,32+((kills+e)%wavecolors)+3);
  }

  shiptype = (((player_x+e) % 2)*2)+60;  
  shiptype += level*2;
  
  if (level < 4)
    enemy_firetype [e] = level;
  else 
    enemy_firetype [e] = HOMING;

  set_sprite_tile(e+9, shiptype);
}

void increase_kills ()
{
  kills ++;

  if ((kills == killnumber))
  {
    kills = 0;
    if (level == 9)
    {
      wave ++;
      if (wave >6)
        wave = 6;
    
      showwave = 150;

      wave_enemies = wave;
      show_wave ();
  
      wavecolors ++;
      if (wavecolors ==6)
        wavecolors =5;

      level = 1;
      homingspeed = 2;
      killnumber = kill_limit[wave];
    }
    else 
      level++;
  }
}

void setup_player (void)
{
  UBYTE x;

  for (x=0;x<40;x++)
    move_sprite(x,0,0);

  player_x = 100;
  pdead = 0;
  pinvincible = 100;

  /* setup the player bullets */ 
  for (x=0;x<4;x++)
  {
    pfire_x[x] = 0;
    pfire_y[x] = 0;
    
    set_sprite_tile(4+x,14);
    set_sprite_prop(4+x,1);
  }

  set_sprite_tile (0,58); /* left side of ship */
  set_sprite_tile (1,2); /* left lazer turret */
  set_sprite_prop (1,1);
  set_sprite_tile (2,60); /* right side of ship */
  set_sprite_tile (3,6); /* right lazer turret */
  set_sprite_prop (3,1);

  /* single / double shot display */
  move_sprite (29,160,148);
  set_sprite_tile (29,20-numshots-numshots);
  set_sprite_prop (29,1);
}

void move_player (UBYTE x)
{
  move_sprite(0,x,140);
  move_sprite(1,x,140);
  move_sprite(2,x+8,140);
  move_sprite(3,x+8,140);
}

void move_enemy (UBYTE enemynum, UBYTE x, UBYTE y)
{
  move_sprite(9+enemynum,x,y);
}

void setup_bkg (void)
{
   set_bkg_tiles(0,0,20,32,stars);
}

/* still a bit buggy */
void scroll_bg ()
{
  scroll_bkg(0,-1);
}

/* move the player bullets, if they are active */
void move_fire(void)
{
  UBYTE x;

  /* move the players shots */  
  for (x=0;x<4;x++)
  {
    if (pfire_y[x] != 0)
    {
      pfire_y[x]-=2;
      move_sprite(4+x,pfire_x[x]-2,pfire_y[x]);
    }
    
  }

  /* move the enemies shots */
  for (x = 0 ; x < wave_enemies ; x++)
  {
    if (efire_y[x] < 170)
    {
        efire_moves[x]++;
        efire_y[x] += 2;
      if ((efire_t[x] == SIDE) && (efire_moves[x] ==4))
      {
        efire_x[x] += emove_x[x];
        efire_moves[x] = 0;
      }
      if ((efire_t[x] == HOMING) && (efire_moves[x] == homingspeed))
      {
        if (efire_x[x] < player_x)
          efire_x[x] ++;
        else 
          efire_x[x] --;
        efire_moves[x]=0;
      }
      move_sprite(17+x,efire_x[x],efire_y[x]);
    }
  }
}

/* makes the player take a shot, if they have a bullet available */
void player_fire_b(void)
{
  UBYTE x;

  for (x=0;x<4;x++)
  {
    if (pfire_y[x] == 0)
    {
      pfire_x[x] = player_x;
      pfire_y[x] = 140;
      tookshot = 1;
      break;
    }
  }
}

/* makes the player take a shot, if they have a bullet available */
void player_fire_a(void)
{
  UBYTE x;
  
  for (x=0;x<4;x++)
  {
    if (pfire_y[x] == 0)
    {
      pfire_x[x] = player_x + 12;
      pfire_y[x] = 140;
      tookshot = 1;
      break;
    }
  }
}

/* makes the enemy fire, if they can and the player is within range */
void enemy_fire (UBYTE e)
{
  UBYTE closeness;

  if (enemy_firetype [e] == STRAIGHT)
    closeness = 10;
  else 
    closeness =25;

  if ((efire_y[e] > 169) && (pdead==0))
  {
    if (abs(enemy_x[e] - player_x) < closeness) 
    {
      sound_lazer();
      efire_x[e] = enemy_x[e];
      efire_y[e] = enemy_y[e];   
      efire_t[e] = enemy_firetype[e];
      efire_moves[e] = 0;
    }
  }
}

 
/* make the enemy move */
void enemy_turn (void)
{
  UBYTE e;
  
  for (e=0;e<wave_enemies;e++)
  {
    if (edead[e] > 0)
    { 
      BYTE mdead;
      edead[e] --;
      
      mdead = edead[e] % 16;
      
      if (mdead == 12)
        set_sprite_prop(9+e,33);
      if (mdead == 8)
        set_sprite_prop(9+e,97);
      if (mdead == 4)
        set_sprite_prop(9+e,65);
      if (mdead == 0)
        set_sprite_prop(9+e,1);
      
      if (edead[e] == 0)
      {
        setup_enemy(e);
      }
    }
    else
    {
      enemy_x[e] += emove_x[e];

      if ((enemy_x[e] % 5) ==0)
        enemy_y[e] += emove_y[e];

      if ((emove_x[e] > 0) && (enemy_x[e] == 170))
        setup_enemy(e);     
      else if (enemy_x[e] == 0)
        setup_enemy(e);

      move_enemy(e,enemy_x[e],enemy_y[e]);
      enemy_fire (e);
    }
  }  
}

/* checks if the player wants to take an action */
void player_turn (void)
{
  UBYTE mdead;
  static UBYTE last; 
  UBYTE joy = joypad ();
  
  if ( joy & J_START)
  {
    pause ();
  }
  if (( joy & J_SELECT ) && !( last & J_SELECT ))
  {
    if (numshots == 2)
      numshots = 1;
    else
      numshots = 2;
    set_sprite_tile (29,20-numshots-numshots);
  }
  if (pdead == 0)
  {  
    if ( joy & J_LEFT ) 
    {
      if (player_x > 8)
        player_x -= 2;
      move_player (player_x);
    }
    if ( joy & J_RIGHT )
    {
      if (player_x < 152)
        player_x += 2;
      move_player (player_x);
    }    
    if ( (joy & J_B) && !(last & J_B) && !(last & J_A))
    {
      player_fire_b ();
      if (numshots == 2)
      {
        player_fire_a ();
      }
      if (tookshot == 1)
      {
        sound_shoot();
        tookshot = 0;
        if ( (numshots == 2) && (score != 0) )
        { 
          score --;
          put_score();
        }
      }
    }
    if ( (joy & J_A) && !(last & J_B) && !(last & J_A))
    {
      player_fire_a ();
      if (numshots == 2)
      {
        player_fire_b ();
      }
      if (tookshot == 1)
      {
        sound_shoot();
        tookshot=0;
        if ((numshots == 2) && (score!=0))
        { 
          score --;
          put_score();
        }  
      }
    }  
  }
  else 
  {
    pdead --;
  
    mdead = pdead % 16;

    if (mdead == 12)
    {
      set_sprite_prop (0,33);
      set_sprite_prop (2,33);
      move_sprite (0,player_x+8,140);
      move_sprite (2,player_x,140);
    }
    if (mdead == 8)
    {
      set_sprite_prop (0,97);
      set_sprite_prop (2,97);
    }
    if (mdead == 4)
    {
      set_sprite_prop (0,65);
      set_sprite_prop (2,65);
      move_sprite (0,player_x,140);
      move_sprite (2,player_x+8,140);
    }
    if (mdead == 0)
    {
      set_sprite_prop (0,1);
      set_sprite_prop (2,1);
    }
    if (pdead == 0 )
    {
      set_sprite_tile (0,58); /* left side of ship */
      set_sprite_prop (0,0);
      set_sprite_tile (2,60); /* right side of ship */
      set_sprite_prop (2,0);

      pinvincible = 100;

      move_sprite(1,player_x,140);
      move_sprite(3,player_x+8,140);      
      show_lives();
    }
  }
  
  last = joy;
   
}

/* collision detection for the dead */
void check_dead (void)
{
  UBYTE x,e;
  
  if ((pinvincible == 0) && (pdead == 0))
  for ( e = 0 ; e < wave_enemies ; e++)
  {
    if  ((efire_y[e] > 126) && (efire_y[e] < 140) && (efire_x[e] > (player_x - 5))
        && (efire_x[e] < (player_x+12)))
    {
      lives --;
     
      pdead = 100;
      sound_you_die();
      set_sprite_tile (0,8);
      set_sprite_prop (0,1);
      set_sprite_tile (2,10);
      set_sprite_prop (2,1);
      
      move_sprite(1,0,0); /* move the thrusters away */
      move_sprite(3,0,0);
  
      /* destroy the enemy fire that killed the player */
      efire_y[e]=170;
      move_sprite(17+e,efire_x[e],efire_y[e]);
    } 
  }

  for ( e = 0 ; e < wave_enemies ; e++)
  {
    for (x=0;x<4;x++)
    {
      if (((pfire_x[x] + 3) > enemy_x[e]) && (pfire_x[x]< (enemy_x[e]+6)) && (edead[e] == 0))
      {
        if ((pfire_y[x] < ( enemy_y[e] + 15 )) && (( pfire_y[x] + 2 ) > enemy_y[e] ))
        {
          /* set the enemy to dead */
          increase_kills ();
          edead[e] = edelay;
          set_sprite_tile(9+e,22);
          set_sprite_prop(9+e,1);
        
          /* destroy the bullet that killed the enemy */
          pfire_y[x] = 0;
          move_sprite(4+x,0,0);

          /* increase the score */
          score +=10;
          put_score();
        }
      }
    }
  }
}


void save_hiscore(void)
{
  long int* savepoint;
  UBYTE* soundsave;
  ENABLE_RAM_MBC1;
  savepoint = (long int *)0xa000;
  soundsave = (UBYTE *)0xa012;
  savepoint[0] = 12346 ; 
  savepoint[1] = hiscore; 
  savepoint[2] = score;
  soundsave[0] = soundon;
  DISABLE_RAM_MBC1;
}

void load_hiscore(void)
{
  long int* savepoint;
  UBYTE* soundsave;
  ENABLE_RAM_MBC1;
  savepoint = (long int *)0xa000;
  soundsave = (UBYTE *)0xa012;
  if (savepoint[0] == 12346) 
  {
    hiscore = savepoint[1]; 
    score = savepoint[2];
    soundon = (UBYTE) soundsave[0];
  }
  else
  {
    hiscore = 0;
    soundon = 1;
  }
  
  DISABLE_RAM_MBC1;
}

void main (void)
{
  UBYTE men;

  DISPLAY_ON;
  hiscore = 0;
  score = 0;
	set_sprite_data (0,62,TileLabel);
  set_sprite_data (62,20,monsters);
  set_sprite_data (82,14,words);

  NR52_REG = 0xF8U;
  NR51_REG = 0x00U;
  NR50_REG = 0xFFU;
  
  load_hiscore ();
  
  for (;;)
  {
    SPRITES_8x8;
    men = title_page();
    SPRITES_8x16;
    play(men);
    if (score > hiscore)
    {
      hiscore=score;
    }
    save_hiscore();
  }
}

void play (UBYTE men)
{
 
  set_palettes ();   

  set_bkg_data (0,15,bkg_tiles);

  score = 0;
  lives = men;
  edelay = 100;
  numshots = 2;
  freeman=0;
  tookshot=0;
  level = 1;
  if (men == 3 )
  {
    wave = 1;
    wavecolors = 1;
    wave_enemies = 1;
    homingspeed = 3;
  }
  else if (men == 4)
  {
    wave = 4;
    wavecolors = 4;
    wave_enemies = 4;
    homingspeed = 2;
  }
  else 
  { 
    wave = 6;
    wavecolors = 5;
    wave_enemies = 6;
    homingspeed = 2;
  }

  showwave = 150;

  killnumber = kill_limit[wave];
  kills = 0;

  setup_player();
  setup_bkg();
  setup_all_enemies();
  setup_all_enemy_fire();

  show_wave ();

  init_score();
  show_lives();

  move_player(player_x);
  
  move_enemy(0,enemy_x[0],enemy_y[0]);
  move_enemy(1,enemy_x[1],enemy_y[1]);

  SHOW_SPRITES;
  SHOW_BKG;

  /* main loop */
  while ((lives >0) || (pdead!=0))
  {
    scroll_bg();
    player_turn();
    enemy_turn();
    move_fire();
    check_dead();
    if (pinvincible > 0)
    {
      pinvincible --;
      if (pinvincible == 0)
      {
        set_sprite_tile (0,0); /* left side of ship */
        set_sprite_tile (2,4); /* right side of ship */
      }
    }

    if (showwave > 0)
    {
      showwave --;
      if (showwave == 0)
      {
        remove_wave();
      }
    }    
    wait_vbl_done();
  }
}

