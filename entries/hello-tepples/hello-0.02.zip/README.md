LR35902 is breaking my brain, but I managed to pull it off.
Gosh help me if I need to work in an array of objects.

