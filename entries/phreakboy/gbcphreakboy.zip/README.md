# Enhancd DTMF Dialer (a.k.a. Phreakboy)

Phreak boy is successor of GB-DTMF which is already contributed to GBDK-2.0. This software is developed for Phreaks. RED-BOX & BLUE-BOX are realized on GB. (CCITT 5 compliant). Also several function keys are existed on leftside, they are corresponding for phreaking scene as such as answering machine cracking and so on. Our policy... Source code should be disclosed. You can customize by your self. These functions are realized by sound feature of GB. GB has 4ch sound output. DTMF means to use 2ch. A lot of types of dialer in market. it is bit difficult to find out a dialer which is able to dial 'A'-'D'. 

<table>
<tr>
<td><img src="./pics/gb-phk1.gif"></td>
</tr>
</table>


# License
Copyright (c) Osamu OHASHI  
Distributed under the MIT License either version 1.0 or any later version. 
