
    OH! - Release note:
    
     Again, this demo is intended to be run on
     either the original DMG, Pocket or the SGB.
     It's not compatible with GBC nor GBA but it
     will run on these newer systems as well;
     albeit with graphical glitches.

     This demo relies on real hardware to run,
     sound and display correctly but if you
     haven't got the means to run the demo from
     a cartridge... I strongly recommend using
     the BGB emulator. (http://bgb.bircd.org)

     Over and out,
     Snorpung.

