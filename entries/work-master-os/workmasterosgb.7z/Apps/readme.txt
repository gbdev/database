https://web.archive.org/web/20081226145650/http://workmaster.ru/index.php?p=19

File: protect.zip
Name: Protector (v1.0.0)
Description: Program for hardware protection of FLASH memory (ATMEL AT49F040)

File: link.zip
Name: Link manager (v2.00, v2.20, v3.00)
Description: Program for PC communication

File: memory.zip
Name: Memory Viewer (v1.0.0)
Description: Program to visually inspect cartridge memory contents

File: basis.zip	
Name: Basis (v1.0.0)
Description: Database management system 
Requirements: SRAM 8KB/WM3

File: wmsetup.zip
Name: WM-Setup (v1.0.0)
Description: Program for additional customization of system sounds and color palettes
