https://web.archive.org/web/20081226145640/http://workmaster.ru/index.php?p=17

File		Type	WM	Driver			Note
amdf040.zip	FL	2	AMD AM29F040		Sector 64KB
amdf0402.zip	FL	2	AMD AM29F040		Sector 128KB (increased by software)
atmel.zip	FL	2	ATMEL AT49BV040		4 chips (new version)



