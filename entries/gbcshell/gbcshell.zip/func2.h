// Command Shell FrameWork for GBC
// Function 2

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC2_TITLE		" Func.2"	//Mod

#define FUNC2_TITLE_X	1
#define FUNC2_TITLE_Y	13
