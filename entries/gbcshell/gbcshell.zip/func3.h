// Command Shell FrameWork for GBC
// Function 3

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC3_TITLE		" Func.3"	//Mod

#define FUNC3_TITLE_X	11
#define FUNC3_TITLE_Y	7
