// Command Shell FrameWork for GBC
// 2001 TeamKNOx

#include "target.h"

void target_init()
{
	//Mod
}

UBYTE target()
{
	//Mod
	
	return 0;
}
