// Command Shell FrameWork for GBC
// Function 5

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC5_TITLE		" Func.5"	//Mod

#define FUNC5_TITLE_X	11
#define FUNC5_TITLE_Y	13
