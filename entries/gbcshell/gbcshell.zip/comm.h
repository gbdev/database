// Command Shell FrameWork for GBC
// 2001 TeamKNOx

#define RECEIVE_BUFFER_SIZE 127
#define CR 0x0D
#define LF 0x0A

// For communication
extern UBYTE gRcvData[RECEIVE_BUFFER_SIZE];

