// Command Shell FrameWork for GBC
// Function 1

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC1_TITLE		" Func.1"	//Mod

#define FUNC1_TITLE_X	1
#define FUNC1_TITLE_Y	10
