// Command Shell FrameWork for GBC
// Function 0

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC0_TITLE		" Func.0"	//Mod

#define FUNC0_TITLE_X	1
#define FUNC0_TITLE_Y	7
