// Command Shell FrameWork for GBC
// Function 4

// Max 8 characters
// You have to adjust by SPACE char for button title.
#define FUNC4_TITLE		" Func.4"	//Mod

#define FUNC4_TITLE_X	11
#define FUNC4_TITLE_Y	10
