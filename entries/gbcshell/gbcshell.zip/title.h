// Command Shell FrameWork for GBC
// 2001 TeamKNOx

// You have to put under 20characters !!
// Adjust with SPACE character in " ".
#define TITLE_MSG "Your Title is here!!"	//Mod
