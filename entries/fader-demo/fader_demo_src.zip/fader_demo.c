/* ���̃v���O�����\�[�X���̂̏��p���ւ� */
/* CGB Test Program by BouKiChi */
/* ����̓��K�f��(Megademo)�ł͂Ȃ��~���f��(Millidemo)�ł�(�� */

#include <gb.h>

unsigned char attrdata[30];

unsigned char chr[16]=
{0x00,0x00,0x00,0x00,0xFF,0x00,0xFF,0x00,
 0x00,0xFF,0x00,0xFF,0xFF,0xFF,0xFF,0xFF,
};

/* �J���[�R�[�h */
                         /*    Red    Green  Blue   White */
unsigned long     palcode[4]={0x001F,0x03e0,0x7c00,0x7FFF};
unsigned long     paldec[4] ={0x0001,0x0020,0x0400,0x0421};

void set_attr(void)
{
        unsigned char x,y;
        VBK_REG = 1; /* VRAM Bank = 1; */
        for(y=0; y < 18; y++) {  /* 144/18=?? */
                for(x=0; x < 20; x++) { /* 160/8=20 */
                        attrdata[x]=y/9;  /* ��ʏ㔼����0�A��������1 */
                        set_bkg_tiles(0,y,20,1,attrdata);
                }
        }
        VBK_REG = 0; /* VRAM Bank = 0; */
}

void set_bkg(void)
{
        unsigned char x,y;
        for(y=0; y < 18; y++) {  /* 144/18=?? */
                for(x=0; x < 20; x++) { /* 160/8=20 */
                        attrdata[x]=0;
                        set_bkg_tiles(0,y,20,1,attrdata);
                }
        }
}

unsigned long paldata;

void main(void)
{
  unsigned long i,k;
  unsigned char j;
  unsigned char c,a,sw;

  /* �ω�������ׂ����ɏ����܂��B */
  unsigned long     pal[4]    ={0x001F,0x03E0,0x7C00,0x001F};
  unsigned long     bound  [4]={0x001F,0x03E0,0x7C00,0x7FFF};
  unsigned long     npal,ndec,spal,sdec;

  if( _cpu!=0x11 ) {
        /* �Q�[���{�[�C�ł͓����Ȃ��ł� */
        while(1);
  }
  set_bkg_palette( 7, 1, &palcode[0]);
  set_bkg_palette( 6, 1, &pal[0]);
  set_bkg_data(0,1,chr);


  set_attr();
  set_bkg();

  /* �_��!  */

  SHOW_BKG;

  npal=palcode[0];
  ndec=paldec[0];
  sw=a=c=0;

  while(1) {
       for(j=0; j < 4; j++) {
                if (sw) k=0; else k=npal;
                for(i=0; i < 0x1F; i++) {
                       
                        if (sw) {
                                if (i < 0xF)
                                        k=k+(ndec<<1);
                                else
                                        if (k) k=k-(ndec<<1);
                        } else  k=k-ndec;

                        pal[j]=k;

                        set_bkg_palette( 6,1,&pal[0]);

                        if (a)
                                bound[j]+=paldec[j];
                        else 
                                bound[j]-=paldec[j];

                        set_bkg_palette( 7,1,&bound[0]);
                        delay(150);
                }
                if (sw) pal[j]=ndec;

                palcode[c]=npal;
                paldec [c]=ndec;
                c++; c=(c<3 ? c : 0);
                npal= palcode[c];
                ndec= paldec [c];
       }
       a^=1; /* ���] */
       sw=1;
  }
}

