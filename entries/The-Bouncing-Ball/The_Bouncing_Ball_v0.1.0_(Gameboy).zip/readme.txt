

		 _______ _                               
		|__   __| |                              
		   | |  | |__   ___                      
	  ____ | |  | '_ \ / _ \       _             
	 |  _ \| |  | | | |  __/      (_)            
	 | |_) |_|__|_| |_|\___|   ___ _ _ __   __ _ 
	 |  _ < / _ \| | | | '_ \ / __| | '_ \ / _` |
	 | |_) | (_) | |_| | | | | (__| | | | | (_| |
	 |____/ \___/ \__,_|_| |_|\___|_|_| |_|\__, |
						   |  _ \      | | |__/ |
						   | |_) | __ _| | |___/ 
						   |  _ < / _` | | |     
						   | |_) | (_| | | |     
						   |____/ \__,_|_|_|     
												 
												 
		GAMEBOY VERSION DEVELOPED BY CABBAGE

			BASED ON A GAME BY RAON GAMES

		THIS IS FREE SOFTWARE - NOT FOR SALE!

	DEVELOPED FROM AUGUST 8-18TH, 2015 FOR GBJAM4 


