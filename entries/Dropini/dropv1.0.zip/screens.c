#include <gb.h>

UBYTE t1[] = "     NoDrop         ";
UBYTE t2[] = "     Press Start    ";
UBYTE t3[] = " Gameboy Color only ";

UBYTE title ( void )
{
  unsigned char tmp1, tmp2;
  UBYTE x;

  HIDE_SPRITES;
  HIDE_BKG;
  HIDE_WIN;

  set_bkg_palette_entry(0,0,RGB(31,31,31)); 
  set_bkg_palette_entry(0,1,RGB(15,15,15)); 
  set_bkg_palette_entry(0,2,RGB(10,10,10)); 
  set_bkg_palette_entry(0,3,RGB(0,0,0)); 


  move_bkg(0,0);
   
  for (tmp1 = 0; tmp1<20; tmp1++)
  {
    tmp2 = t1[tmp1] + 128;
    set_bkg_tiles (tmp1,5,1,1,(unsigned char *)&tmp2);
    tmp2 = t2[tmp1] + 128;
    set_bkg_tiles (tmp1,6,1,1,(unsigned char*)&tmp2);
  }

  SHOW_BKG;
  SHOW_SPRITES;

  while (joypad() != 0);
  x = joypad();
  while (x == 0) 
    x = joypad();
  while (joypad() != 0);

  return x;
  
}

void check_cgb (void)
{
  unsigned char tmp1, tmp2;
  UBYTE x;

  if( _cpu!=CGB_TYPE )
  {
    HIDE_SPRITES;
    HIDE_BKG;
    HIDE_WIN;

    move_bkg(0,0);
   
    for (tmp1 = 0; tmp1<20; tmp1++)
    {
      tmp2 = t1[tmp1] + 128;
      set_bkg_tiles (tmp1,5,1,1,(unsigned char *)&tmp2);
      tmp2 = t3[tmp1] + 128;
      set_bkg_tiles (tmp1,6,1,1,(unsigned char*)&tmp2);
    }
  
    SHOW_BKG;
    SHOW_SPRITES;
  
    while (1==1);
  }
}
