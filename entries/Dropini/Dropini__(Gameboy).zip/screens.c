#include <gb.h>
#include "drop.h"
#include "hiscore.h"

#include "tiles\title_tiles.c"
#include "tiles\title_map.c"
#include "tiles\skull_map.c"
#include "tiles\skull_tiles.c"
#include "tiles\company_name_map.c"
#include "tiles\company_name_tiles.c"

UBYTE title ( void )
{
  UBYTE x;

  HIDE_SPRITES;
  HIDE_BKG;
  HIDE_WIN;

  empty_screen ();

  if( _cpu == CGB_TYPE )
  {  
    set_bkg_palette_entry(0,0,RGB(31,31,31)); 
    set_bkg_palette_entry(0,1,RGB(10,10,10)); 
    set_bkg_palette_entry(0,2,RGB(0,0,0)); 
    set_bkg_palette_entry(0,3,RGB(0,0,0)); 
  }

  move_bkg(0,0);
  set_bkg_data (0,140,title_tiles);   
  set_bkg_tiles (0,0,20,18,title_map);   

  SHOW_BKG;
  SHOW_SPRITES;

  while (joypad() != 0) rand();
  
  x = joypad ();
  while (x == 0) 
  {
    x = joypad();
    rand();
  }
   
  while (joypad() != 0);
  
  return x;
}

UBYTE CGB_ONLY1[] = "     NoDrop         ";
UBYTE CGB_ONLY2[] = "     Press Start    ";
UBYTE CGB_ONLY3[] = " Gameboy Color only ";

void check_cgb (void)
{
  unsigned char tmp1, tmp2;

  if( _cpu!=CGB_TYPE )
  {
    HIDE_SPRITES;
    HIDE_BKG;
    HIDE_WIN;

    move_bkg(0,0);
   
    for (tmp1 = 0; tmp1<20; tmp1++)
    {
      tmp2 = CGB_ONLY1[tmp1] + 128;
      set_bkg_tiles (tmp1,5,1,1,(unsigned char *)&tmp2);
      tmp2 = CGB_ONLY3[tmp1] + 128;
      set_bkg_tiles (tmp1,6,1,1,(unsigned char*)&tmp2);
    }
  
    SHOW_BKG;
    SHOW_SPRITES;
  
    while (1==1);
  }
}

void skull_screen (void)
{
  UBYTE joy,last;
  UBYTE x,y,c;
  UWORD w;

  empty_screen();

  DISPLAY_OFF;
  if( _cpu==CGB_TYPE )
  {
    /* set the title palettes */
    set_bkg_palette_entry(0,0,RGB(31,31,31));
  	set_bkg_palette_entry(0,1,RGB(21,21,21));
  	set_bkg_palette_entry(0,2,RGB(14,14,14));
    set_bkg_palette_entry(0,3,RGB(0,0,0));
  }
 
  set_bkg_data (0,102,skull_tiles);
  set_bkg_data (128,55,company_name_tiles);

  move_bkg(0,0);
  if ( 1 == 1 || _cpu != CGB_TYPE) // have to work out
  {
    // show the bug skull
	  set_bkg_tiles (0,0,20,18,skull_map);
    set_bkg_tiles (0,16,20,2,company_name_map);
  }
  else
  {
    // show the mad cow
    w = 0;
    for (y=0;y<18;y++)
    {
      w = w + 20;
      x = 14-y;
      set_bkg_tiles (0,x,20,1,(unsigned char *)&skull_map[w]);
    }
    
    VBK_REG = 1;
    c = 64;
    for (y=0;y<16;y++)
    for (x=0;x<20;x++)
    {
  	  set_bkg_tiles (x,y,1,1,(unsigned char *)&c);
    }
    VBK_REG = 0;

    set_bkg_tiles (0,16,20,2,(unsigned char *)&company_name_map[40]);
  }
  
  DISPLAY_ON;
  SHOW_BKG;	
  SHOW_SPRITES;

  wait_for_button();

  empty_screen();
}

char GO1[] = "     Game Over      ";
char GO2[] = "     Score:         ";
char GO3[] = "     Lines:         ";

void gameover (void)
{
  extern UBYTE temp1,temp2;
  extern long sc_score, sc_lines, display_number;
  
  empty_screen();

  if( _cpu==CGB_TYPE )
  {
    /* set the title palettes */
    /* background palette */
    set_bkg_palette_entry(0,0,RGB(0,0,0));
    set_bkg_palette_entry(0,1,RGB(31,0,31));
    set_bkg_palette_entry(0,2,RGB(31,0,0));
    set_bkg_palette_entry(0,3,RGB(31,31,31));

    set_bkg_palette_entry(1,0,RGB(31,0,0));
    set_bkg_palette_entry(1,1,RGB(31,0,31));
    set_bkg_palette_entry(1,2,RGB(31,0,0));
    set_bkg_palette_entry(1,3,RGB(0,0,0));
  }
 
  for (temp1 = 0; temp1<20; temp1++)
  {
    temp2 = GO1[temp1] + 128;
    set_bkg_tiles (temp1,1,1,1,(unsigned char *)&temp2);
    temp2 = GO2[temp1] + 128;
    set_bkg_tiles (temp1,6,1,1,(unsigned char*)&temp2);
    temp2 = GO3[temp1] + 128;
    set_bkg_tiles (temp1,8,1,1,(unsigned char*)&temp2);
  }
  
  display_number = sc_score;
  displaynumber(6);

  display_number = sc_lines;
  displaynumber(8);

  delay(600);

  VBK_REG = 0;
  wait_for_start ();

}


// empties the gameboard and displays "GAME OVER" or "YOU WIN"

unsigned char EB1 [] = {0,0,0,0,0,0,0,0,0,0,0,0,0};
unsigned char EB5 [] = {1,1,1,1,1,1,1,1,1,1,1,1,1};
unsigned char EB4 [] = {7,7,7,7,7,7,7,7,7,7,7,7,7};
char EB2 [] = "   You Win   ";
char EB3 [] = "  Try Again  ";

void empty_board (void)
{
  extern UBYTE show_score_t, show_score_x, show_score_y, joy, area_box_counter, area_box_timer;
  extern unsigned char gametiles [], sc_doiwin;
  extern UBYTE temp1,temp2;
  UBYTE t1,t2;

  t1 = 2;
  t2 = 0;

  while (t2 < 63)
  {
    t2++;
    wait_vbl_done();

    if (t2 % 3 == 0)
    {
      VBK_REG = 0;
      set_bkg_tiles (1,t1-1,13,1,EB1);
      set_bkg_tiles (1,t1,13,1,EB5);
      VBK_REG = 1;
      set_bkg_tiles (1,t1,13,1,EB5);
      t1 ++;
    }

    // if a score is being shown then count that down
    if (show_score_t > 0)
    {
      show_score_t --;

      if (show_score_t == 0)
      {
        show_score_y = 0;
        show_score();
      }

      if (show_score_t % 10 == 0)
      {
        joy = joypad();

        if (joy & J_LEFT)
          show_score_x --;
        if (joy & J_RIGHT)
          show_score_x ++;

        show_score_y--;
        show_score();
      }
    }

    // the sides of the board scroll
    area_box_timer ++;
    if (area_box_timer == 20)
    {
      area_box_timer = 0;
      area_box_counter++;
      if (area_box_counter == 13)
        area_box_counter = 9;
      VBK_REG = 0;
      set_bkg_data (9,1,&gametiles[16*area_box_counter]);      
      VBK_REG = 1;
    }
  }

  VBK_REG = 1;
  set_bkg_tiles (1,8,13,1,EB4);

  if (sc_doiwin == YES)
  {
    VBK_REG = 0;
    for (temp1 = 0; temp1<13; temp1++)
    {
      temp2 = EB2[temp1] + 128;
      set_bkg_tiles (temp1+1,8,1,1,(unsigned char *)&temp2);
    }
    VBK_REG = 1;
  }
  else
  {
    VBK_REG = 0;
    for (temp1 = 0; temp1<13; temp1++)
    {
      temp2 = EB3[temp1] + 128;
      set_bkg_tiles (temp1+1,8,1,1,(unsigned char *)&temp2);
    }
    VBK_REG = 1;
  }    

  wait_for_button();

}


