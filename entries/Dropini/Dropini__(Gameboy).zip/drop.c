#include <stdio.h>
#include <gb.h>
#include <rand.h>
#include <time.h>
#include "drop.h"
#include "hiscore.h"

#include "tiles\gametiles.c"
#include "tiles\numbers.c"
#include "font.c"

// hiscores
UBYTE word[5][12];
unsigned long int scores[5];

// these variable can only be used if no other function
// is being called while you are using them
UBYTE temp1, temp2; 

UBYTE players = 2;
UBYTE extra1 = 0;
UBYTE extra2 = 0;
UBYTE sound = NO;

UBYTE show_last_x;
UBYTE show_last_y;

UBYTE show_score_x;
UBYTE show_score_y;
UBYTE show_score_t;


UBYTE show_combo_x;
UBYTE show_combo_y;
UBYTE show_combo_t;

// these are variable to do with player input
UBYTE joy,last_joy;
UBYTE left_initial,right_initial,down_initial;
UBYTE left_secondary,right_secondary,down_secondary;
UBYTE left_timer,right_timer,down_timer;
UBYTE left_rep,right_rep,down_rep;

long display_number; // this is a parameter to displaynumber()
long sc_score, sc_lines, sc_pieces;
UBYTE sc_cheating, sc_gametype, sc_doiwin, sc_bonus_timer, sc_combo;

UBYTE piece[4]; // a 2x2 matrix of the piece colors
// 0,1
// 2,3
UBYTE nextpiece[4]; // the next piece that will appear

UBYTE list[100][2];

UBYTE board[BOARD_MAX_X][BOARD_MAX_Y];

int nextincrease;
UBYTE linesperlevel;

UBYTE xoffset;
UBYTE nextxpos,nextypos;
UBYTE posx,posy;
UBYTE dead;
UBYTE length;
UBYTE dynatimer;
UBYTE dynax,dynay;
UBYTE extratimer;
UBYTE extrax,extray;
UBYTE countdown;
UBYTE area_box_counter,area_box_timer;

// game options
UBYTE gametype;
UBYTE shownext;
UBYTE startlines;

UBYTE speed;
UBYTE startspeed;
UBYTE maxspeed;
UBYTE resetspeed;
UBYTE speed_increase;

UBYTE linesperlevel;
UBYTE wantstoplay;
UBYTE music;
UBYTE sound;
UBYTE cheating;


/* puts a line of 20 chars onto the window or bkg */
void putln (char str[], UBYTE y, UBYTE wb)
{
  UBYTE c,strx;

  for (strx = 0 ;strx<20;strx++)
  {
    c = str[strx]+128;
    if (wb == 1)
      set_win_tiles (strx,y,1,1,(unsigned char *) &c);
    else
      set_bkg_tiles (strx,y,1,1,(unsigned char *) &c);
  }
}

char p1[] = "       Paused       ";
void pause ( void )
{
  UBYTE tmp1, tmp2;

  SHOW_WIN;
  HIDE_SPRITES;
  move_win(7,0);
  VBK_REG = 0;
  putln (p1,7,1);  
  VBK_REG = 1;

  while (joypad() >0);
  while (joypad() == 0);
  while (joypad() > 0);

  HIDE_WIN;
  SHOW_SPRITES;
}

void init_score( void )
{
	sc_score = 0;
	sc_lines = 0;
  sc_combo = 0;
	sc_doiwin = NO;
	sc_pieces = -1;
	sc_cheating = 0;
	sc_gametype = FAST;
}

void create_board( void )
{
  UBYTE x,y;
	

	for (x=0;x<BOARD_MAX_X;x++)
	{
		for (y=0;y<BOARD_MAX_Y;y++)
		{
			if (y>BOARD_MAX_Y-startlines-3 && y<BOARD_MAX_Y-2 && x>0 &&
					x<BOARD_MAX_X-1 &&  (cheating&CHEAT_RANDOM_BOARD) != 0)
			{
				if (rand()%3 == 1)
				{
					board[x][y] = rand()%NUM_COLORS+1;
					displaysquare(x,y);
				}
				else
				{
					board[x][y]=0;
				}
			}
			else if (y>BOARD_MAX_Y-startlines-3 &&
					y<BOARD_MAX_Y-2 &&
					y % 2 ==1 &&
					x > 0 &&
					x < BOARD_MAX_X-1)
			{
				board[x][y]=rand()%NUM_COLORS+1;
				displaysquare(x,y);
			}
			else
			{
				board[x][y]=0;
			}
		}
	}
}

void rotate ( void )
{
	if (piece[1] != 0)
	{
		piece[2] = piece[0];
		piece[0] = piece[1];
		piece[1] = 0;
	}
	else
	{
		piece[1] = piece[2];
		piece[2] = 0;
	}
}

UBYTE canrotate ( void )
{
  if (piece[2] != 0)
	{
		if (posx == BOARD_MAX_X-2)
			return 1;
		return board[posx+1][posy];
	}
	if (posy==BOARD_MAX_Y-3)
		return 1;
	return board[posx][posy+1];
}

UBYTE canleft ( void )
{
	temp1 = 0;

	if (posx == 1)
		return 1;
	temp1 = board[posx-1][posy];
	if( piece[1]!=0)
	{
		return temp1;
	}
	else
		return temp1 + board[posx-1][posy+1];
}

UBYTE canright ( void )
{
	if (piece[1] != 0)
	{
		if (posx==BOARD_MAX_X-3)
			return 1;
		return board[posx+2][posy];
	}
	else
	{
		if (posx == BOARD_MAX_X-2)
			return 1;
		return board[posx+1][posy] + board[posx+1][posy+1];
	}
}

UBYTE candrop ( void )
{

	if (piece[2] != 0)
	{
		if (posy == BOARD_MAX_Y-4)
			return 1;
		return board[posx][posy+2];
	}
	else
	{
		temp1 = board[posx][posy+1];
		temp1 += board[posx+1][posy+1];
		if (posy == BOARD_MAX_Y-3)
			temp1 = 1;
		return temp1;
	}
}

UBYTE inlist (UBYTE x, UBYTE y, UBYTE len)
/* 0 = in list, 1= not in list */
{
	int temp1;
	for (temp1 = 0 ; temp1 <= len ; temp1++)
	{
		if ((list[temp1][0] == x) && (list[temp1][1] == y))
			return 0;
	}
	return 1;
}

void initlist( void )
{
	for (temp1 = 0 ; temp1 < 100 ; temp1++)
	{
		list[temp1][0]=0;
		list[temp1][1]=0;
	}
}

UWORD checkpos (UBYTE posx,UBYTE posy,UBYTE length)
{
	UBYTE c,n;
	UBYTE color;
	UBYTE x,y;
	UWORD sc = 0;

	color = board[posx][posy];
	c=n=0;

	if (color == 0)
		return 0;

	if (color == 8) // dynamite
	{
		BYTE x1;
		BYTE y1;
		for ( y1 = -1 ; y1 < 2 ; y1++)
			for (x1 = -1 ; x1 < 2 ; x1++)
				board[posx+x1][posy+y1] = 0;

		//put_explosion(posx,posy);
		if (sound)
			play_sound(1);

		dynax = posx;
		dynay = posy;
		dynatimer = 3;
		return 0;
	}

	list[n][0]=posx;
	list[n][1]=posy;

	while (c <= n)
	{
		x = list[c][0];
		y = list[c][1];

		if (board[x-1][y] == color)
		{
			if (inlist(x-1,y,n)==1)
			{
				n++;
				list[n][0]=x-1;
				list[n][1]=y;
			}
		}
		if (board[x+1][y] == color)
		{
			if (inlist(x+1,y,n)==1)
			{
				n++;
				list[n][0]=x+1;
				list[n][1]=y;
			}
		}
		if (board[x][y-1] == color)
		{
			if (inlist(x,y-1,n)==1)
			{
				n++;
				list[n][0]=x;
				list[n][1]=y-1;
			}
		}
		if (board[x][y+1] == color)
		{
			if (inlist(x,y+1,n)==1)
			{
				n++;
				list[n][0]=x;
				list[n][1]=y+1;
			}
		}
		c++;
	}
	if (n>length)
	{
		c=n;
		delay(20);

		for (n=0;c>=n;n++)
		{
			sound_pop();
			x=list[n][0];
			y=list[n][1];
			erasesquare(x,y);
			sc = sc+n+1;
			board[x][y]=0;
		}
    show_last_x = x;
    show_last_y = y;
		return sc;
	}

	return 0;

}

int piecetoboard (int x, int y,int length)
{
	UWORD sc1=0;
	UWORD sc2=0;
	UBYTE got_a_line = NO;
	UWORD total = 0;

	board[x][y] = piece[0];

	if (piece[2] != 0)
	{
		board[x][y+1] = piece[2];
	}
	else
	{
		board[x+1][y] = piece[1];
	}
	sc1 = checkpos(x,y,length);

	if (piece[2]!=0)
	{
		sc2 = checkpos(x,y+1,length);
	}
	else
	{
		sc2 = checkpos(x+1,y,length);
	}

	if (sc1>0)
	{
		sc_lines++;
		got_a_line=YES;
	}

	if (sc2>0)
	{
		sc_lines++;
		got_a_line=YES;
	}

	total = sc1+sc2;

  // bonus points for getting two lines at once
	if (sc1>0 && sc2>0)
	{
		total=total*4;
  	//print_str("Two Lines * 4",10,160,100,4,0);
		//sc_bonus_timer=35;
	}

  // bonus points if show_next is off
	if (!shownext)
		total = total + (total>>3);
  
  // bonus points for getting 2 or more lines in a row
  if (sc1>0 || sc2>0)
  {
    sc_combo ++;

    // put the combo display up
    show_combo_x = 140;
    show_combo_y = 140;
 
    set_sprite_tile (5,11);
    temp1 = sc_combo+1;
    if (temp1 > 4)
      temp1 = 4;
    set_sprite_tile (6,temp1);
    show_combo();
  
    // if this is a combo, then add the bonus points
    if (sc_combo > 1)
    {
      // if this is 2nd or 3rd line X2
      if (sc_combo==2)
        total = total + total;
      else if (sc_combo == 3)
        total = total + total +total;
      else // 4th line and above X4
        total = total<<2;
    }
  }
  else
  {
    // remove the combo display
    sc_combo = 0;
    show_combo_y = 200;
    show_combo();
  }

	sc_score +=total;

	if (total >0)
	{
    // put the total up on the screen
    // get the 100's
    temp1 = 0;
    while ( total > 99)
    {
      total -= 100;
      temp1++;
    }
    if (temp1 == 0)
      temp1 = 10;
    set_sprite_tile(0,temp1);

    temp1 = 0;
  	while ( total > 9)
    {      
      total -= 10;
      temp1++;
    }
    set_sprite_tile(1,temp1);

    temp1 = total;
    set_sprite_tile(2,temp1);

    show_score_x = show_last_x*8;
    show_score_y = show_last_y*8;
    show_score_t = 61;
    show_score ();
 	}

  if (got_a_line)
  {
    display_number = sc_lines;
    displaynumber (13);
  }
	return got_a_line;
}

void newpiece (void)
{
	nextpiece [0] = rand()%NUM_COLORS+1;
	nextpiece [1] = nextpiece[3] = 0;
	nextpiece [2] = rand()%NUM_COLORS+1;

  sc_pieces ++;
  display_number = sc_pieces;
  displaynumber (16);
}

void trydown (void)
{
	if (candrop() == 0)
	{
		erasepiece(posx,posy);
		posy++;
		displaypiece(posx,posy);
    countdown = speed +1;
	}
  else
  {
		countdown = speed +1;
		piecefall();
    down_rep = 2;
    // give the player lots of time before the next piece drops
    down_timer = down_secondary+1; 
  }
}

void player_input (void)
{
  joy = joypad();

	if (joy & J_LEFT)
	{
		if (!(last_joy & J_LEFT))
    {
      if (canleft() == 0)
		  {
				erasepiece(posx,posy);
				posx--;
				displaypiece(posx,posy);
		  }
      left_timer = 0;
      left_rep = 1;
	  }
    else 
    {
      if (left_rep == 1) 
      {
        left_timer++;
        if (left_timer == left_initial)
        {
          left_timer = 0;
          left_rep = 2;
          if (canleft() == 0)
		      {
				    erasepiece(posx,posy);
				    posx--;
				    displaypiece(posx,posy);
		      }
        } 
      }
      else // left_rep = 2 
      {
        left_timer++;
        if (left_timer == left_secondary)
        {
          left_timer = 0;
          if (canleft() == 0)
		      {
				    erasepiece(posx,posy);
				    posx--;
				    displaypiece(posx,posy);
		      }
        } 
      }
    }
  }

	if (joy & J_RIGHT) 
	{
    if (!(last_joy & J_RIGHT))
    {
  		if (canright() == 0)
	  	{
		  	erasepiece(posx,posy);
			  posx++;
			  displaypiece(posx,posy);
		  }
      right_rep = 1;
      right_timer = 0;
	  }
    else
    {
      if (right_rep == 1)
      {
        right_timer++;
        if (right_timer == right_initial)
        {
          right_timer = 0;
          right_rep = 2;
          if (canright() == 0)
		      {
				    erasepiece(posx,posy);
				    posx++;
				    displaypiece(posx,posy);
		      }
        }
      }
      else
      {
        right_timer++;
        if (right_timer == right_secondary)
        {
          right_timer = 0;
          if (canright() == 0)
		      {
				    erasepiece(posx,posy);
				    posx++;
				    displaypiece(posx,posy);
		      }
        }
      }
    }
  }

  if ((joy & J_A) && !(last_joy & J_A))
	{
	  if (canrotate() == 0)
	  {
			erasepiece(posx,posy);
			rotate ();
			displaypiece(posx,posy);
		}
	}
  
  if ((joy & J_START) && !(last_joy & J_START))
  {
    pause ();
  }
  
  if (joy & J_DOWN)
	{
    if (!(last_joy & J_DOWN))
    {
      trydown();
      down_timer = 0;
      down_rep = 1;
    }
    else
    {
      if (down_rep == 1)
      {
        down_timer ++;
        if (down_timer == down_initial)
        {
          trydown();
          down_rep = 2;
          down_timer = 0;
        }
      }
      else
      {
        down_timer ++;
        if (down_timer == down_secondary)
        {
          trydown();
          down_timer = 0;
        }
      }
    }
	}

/*  if (((joy & J_B) && !(last_joy & J_B)) &&
		 ((sc_score > 49) ||
		 ((sc_cheating & DYNAMITE) == DYNAMITE)))
	{
		piece[0] = 8;
		displaypiece(posx,posy);
		if ((sc_cheating & DYNAMITE) != DYNAMITE)
		{
			sc_score -=50;
      display_number = sc_score;
			displaynumber (7);
		}
	}
*/
  last_joy = joy;

}

void piecefall ( void )
{
	UBYTE did_score;

	erasepiece(posx, posy);
	if (candrop() == 0)
	{
		posy++;
		displaypiece(posx, posy);
	}
	else
	{
		displaypiece(posx, posy);
		sound_click();
    did_score = piecetoboard(posx,posy,length);
		if (did_score == YES)
		{
			if (sc_gametype == FAST && sc_lines>49)
			{
				sc_doiwin=YES;
				dead = YES;
			}
			if (sc_lines >= nextincrease)
			{
				speed = speed - speed_increase;
				nextincrease += linesperlevel;

				if (speed < maxspeed)
				{
					speed = resetspeed;
					length++;
				}

				if (music)
				{
					if (speed == resetspeed)
					{
						ChangeTempo(3);
					}
					else if (speed ==5)
					{
						ChangeTempo(2);
					}
					else if (speed ==3)
					{
						ChangeTempo(1);
					}
				}

        display_number = speed;
				displaynumber (10);
			}
      
      display_number = sc_score;
			displaynumber (7);

		}

		posx = 7;
		posy = 2;
    for ( temp1 = 0 ; temp1 < 4 ; temp1++)
  		piece[temp1] = nextpiece[temp1];
	
  	newpiece();
		if (shownext==YES)
			displaynextpiece();
		
    if ((board[7][3]!=0) || (board[7][2]!=0))
			dead=YES;
		displaypiece(posx, posy);
	}	
}

/* this is only needed in the 2 player game
   This function hasn't been converted for the gameboy
void extra_piece ()
{
	int p = b->posx;
	int c = BOARD_MAX_Y-3;

	while (p == b->posx)
		p = random(BOARD_MAX_X-4)+2;

	while (b->a[p][c] !=0)
		c--;

	if (c==0 && (b->gameops->issoundon== YES))
		play_sound(1);

	if (c!=0)
	{
		b->a[p][c] = random(NUM_COLORS-1)+1;
		//put_explosion(p,c,b->xoffset);
		displaysquare(b,p,c,b->xoffset);

		b->extrax = p;
		b->extray = c;
	}
	fflush(stdin);
}
*/

void update_board ()
{
	if (sc_bonus_timer > 0)
	{
		sc_bonus_timer--;
		if (sc_bonus_timer ==0)
		{
			//erase_bonus_text();
		}
	}

	if (dynatimer > 0)
	{
		dynatimer --;
		if (dynatimer ==0)
		{
			//erase_explosion(dynax,dynay);
		}
	}

  // this is to change the face of one of the pieces
  // not implemented in the gameboy version
	// displaysquare(b,random(BOARD_MAX_X),random(BOARD_MAX_Y),b->xoffset);

}

void init_board(UBYTE x)
{

  shownext = YES;
  sound = YES;

  startspeed = 40;
  maxspeed = 10;
  resetspeed = 40;
  speed_increase = 5;
  linesperlevel = 6;
  if (x & J_A)
  {
    startlines = 13;
    cheating = CHEAT_RANDOM_BOARD;
  }
  else
  {
    startlines = 6;
    cheating = 0;
  }

  area_box_counter = 9;
  area_box_timer = 0;

  left_timer = right_timer = down_timer = 0;
  left_initial = right_initial = 20;
  down_initial = 15;
  left_secondary = right_secondary = down_secondary = 6;
  left_rep = right_rep = down_rep = 0;

	length = 2;
	nextincrease = linesperlevel;
	speed = startspeed;
	dead = NO;
	posx = 7;
	posy = 2;
	dynatimer = 0;
	dynax = dynay = 0;

  show_score_x = show_score_y = show_score_t = 0;
  show_combo_x = show_combo_y = show_combo_t = 0;

	init_score();
	newpiece();
  for ( temp1 = 0 ; temp1 < 4 ; temp1++)
		piece[temp1] = nextpiece[temp1];
  	
  newpiece();

  create_board();

}

void play (UBYTE x)
{
	UBYTE loops = 0;

  //turn on the speakers

  // start the music


  init_board (x);

	initrand ((UWORD) clock());
  countdown = speed+1;

  display_number = speed;
	displaynumber (10);

  display_number = sc_score;
	displaynumber (7);

  display_number = sc_lines;
  displaynumber (13);

	displaypiece (posx,posy);

	if (shownext)
	{
		displaynextpiece();
	}



	while (dead==NO)
	{
		loops ++;
	
  	player_input ();

    wait_vbl_done();
		// erase score board
  	update_board();
		loops=0;
		countdown--;
  	if (countdown == 0)
		{
			countdown = speed +1;
			piecefall();
		}

    // if a score is being shown then count that down
    if (show_score_t > 0)
    {
      show_score_t --;
      if (show_score_t == 0)
      {
        show_score_y = 200;
        show_score();
      }
      else if (show_score_t % 10 == 0)
      {
        if (joy & J_LEFT)
          show_score_x --;
        if (joy & J_RIGHT)
          show_score_x ++;

        show_score_y--;
        show_score();
      }
    }

    // the sides of the board scroll
    area_box_timer ++;
    if (area_box_timer == 20)
    {
      area_box_timer = 0;
      area_box_counter++;
      if (area_box_counter == 13)
        area_box_counter = 9;
      VBK_REG = 0;
      set_bkg_data (9,1,&gametiles[16*area_box_counter]);      
      VBK_REG = 1;
    }

	}

  empty_board ();

  if (music)
  {
    ;// turn off the music
  }
	if (sound)
	{
	  ;	// turn off the sound
	}
}

void main ( void )
{
  UBYTE x;
  UBYTE rc;

  // turn on the speakers 
  NR52_REG = 0xF8U;
  NR51_REG = 0x00U;
  NR50_REG = 0xFFU;
 

  load_hiscore(0);

  skull_screen();
  
  // load the font data
  set_win_data ((UBYTE)-128,128,font);

  set_bkg_data (1,1,font);
 
  check_cgb ();
 
  while (1 == 1) 
	{
  	x = title ();
    init_graphics ();
		play (x);
		gameover ();

    rc = add_new_score(sc_score);
    show_scores(rc);
    save_hiscore(0);
	}
}


static const unsigned char cEMPTY[] = 
{ 0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0}; 
/* an empty line for the background */

static const unsigned char GAME_SCREEN[] = 
{ 9,0,0,0,0,0,0,0,0,0,0,0,0,0,9,0,0,0,0,0}; 
static const unsigned char GAME_SCREEN_PAL[] = 
{ 7,0,0,0,0,0,0,0,0,0,0,0,0,0,7,7,7,7,7,7}; 

static const unsigned char GAME_WIN_PAL[] = 
{ 7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7,7}; 

void empty_screen (void)
{
 
  HIDE_BKG;
  HIDE_SPRITES;

  VBK_REG = 0;

  for (temp1=0; temp1<40; temp1++)
  {
    move_sprite(temp1,0,200);
    set_sprite_prop (temp1,0);
  }

  for (temp1=0; temp1<20; temp1++)
  {
    set_bkg_tiles (0,temp1,20,1,(unsigned char *) &cEMPTY[0]);   
    set_win_tiles (0,temp1,20,1,(unsigned char *) &cEMPTY[0]);   

    VBK_REG = 1;
    set_bkg_tiles (0,temp1,20,1,(unsigned char *) &cEMPTY[0]);   
    set_win_tiles (0,temp1,20,1,(unsigned char *) &GAME_WIN_PAL[0]);   
    VBK_REG = 0;
  }

  move_bkg (0,0);
  
  SHOW_BKG;
  SHOW_SPRITES;
}

char GS1[] = "Next ";
char GS2[] = "Score";
char GS3[] = "Speed";
char GS4[] = "Lines";
char GS5[] = "Piece";

void init_graphics (void)
{
  empty_screen ();

  set_bkg_data (0,13,gametiles);
  set_sprite_data (0,13,numbers);

  for (temp1=0; temp1<20; temp1++)
  {
    set_bkg_tiles (0,temp1,20,1,(unsigned char *) &GAME_SCREEN[0]);   
    set_win_tiles (0,temp1,20,1,(unsigned char *) &cEMPTY[0]);   

    VBK_REG = 1;
    set_bkg_tiles (0,temp1,20,1,(unsigned char *) &GAME_SCREEN_PAL[0]);   
    VBK_REG = 0;
  }
  
  for (temp1 = 0; temp1 < 5 ; temp1++)
  {
    temp2 = GS1[temp1];
    temp2 = temp2 + 128;
    set_bkg_tiles (15+temp1,2,1,1,(unsigned char *) &temp2);
  }

  for (temp1 = 0; temp1 < 5 ; temp1++)
  {
    temp2 = GS2[temp1];
    temp2 = temp2 + 128;
    set_bkg_tiles (15+temp1,6,1,1,(unsigned char *) &temp2);
  }
  for (temp1 = 0; temp1 < 5 ; temp1++)
  {
    temp2 = GS3[temp1];
    temp2 = temp2 + 128;
    set_bkg_tiles (15+temp1,9,1,1,(unsigned char *) &temp2);
  }
  for (temp1 = 0; temp1 < 5 ; temp1++)
  {
    temp2 = GS4[temp1];
    temp2 = temp2 + 128;
    set_bkg_tiles (15+temp1,12,1,1,(unsigned char *) &temp2);
  }
  for (temp1 = 0; temp1 < 5 ; temp1++)
  {
    temp2 = GS5[temp1];
    temp2 = temp2 + 128;
    set_bkg_tiles (15+temp1,15,1,1,(unsigned char *) &temp2);
  }

  // the sprite palette
  set_sprite_palette_entry(0,0,RGB(0,0,0)); 
  set_sprite_palette_entry(0,1,RGB(31,31,0)); 
  set_sprite_palette_entry(0,2,RGB(31,0,0)); 
  set_sprite_palette_entry(0,3,RGB(0,0,0)); 

  set_sprite_prop (0,0);
  set_sprite_prop (1,0);
  set_sprite_prop (2,0);

  //  blank
  set_bkg_palette_entry(0,0,RGB(0,0,0)); 

  //  red
  set_bkg_palette_entry(1,0,RGB(0,0,0)); 
  set_bkg_palette_entry(1,1,RGB(31,0,0)); 
  set_bkg_palette_entry(1,2,RGB(0,0,0)); 
  set_bkg_palette_entry(1,3,RGB(0,0,0)); 

  // green
  set_bkg_palette_entry(2,0,RGB(0,0,0)); 
  set_bkg_palette_entry(2,1,RGB(0,31,0)); 
  set_bkg_palette_entry(2,2,RGB(0,0,0)); 
  set_bkg_palette_entry(2,3,RGB(0,0,0)); 

  // blue
  set_bkg_palette_entry(3,0,RGB(0,0,0)); 
  set_bkg_palette_entry(3,1,RGB(0,0,31)); 
  set_bkg_palette_entry(3,2,RGB(0,0,0)); 
  set_bkg_palette_entry(3,3,RGB(31,31,0)); 

  // grey
  set_bkg_palette_entry(4,0,RGB(0,0,0)); 
  set_bkg_palette_entry(4,1,RGB(10,10,10)); 
  set_bkg_palette_entry(4,2,RGB(0,0,0)); 
  set_bkg_palette_entry(4,3,RGB(0,0,0)); 

  // yellow
  set_bkg_palette_entry(5,0,RGB(0,0,0)); 
  set_bkg_palette_entry(5,1,RGB(31,31,0)); 
  set_bkg_palette_entry(5,2,RGB(0,0,0)); 
  set_bkg_palette_entry(5,3,RGB(0,0,0)); 

  // ??
  set_bkg_palette_entry(6,0,RGB(0,0,0)); 
  set_bkg_palette_entry(6,1,RGB(31,31,0)); 
  set_bkg_palette_entry(6,2,RGB(0,0,0)); 
  set_bkg_palette_entry(6,3,RGB(0,0,0)); 

  // score text and shit
  set_bkg_palette_entry(7,0,RGB(0,0,0)); 
  set_bkg_palette_entry(7,1,RGB(31,0,0));
  set_bkg_palette_entry(7,2,RGB(23,23,23));
  set_bkg_palette_entry(7,3,RGB(31,31,31));  

  VBK_REG = 1;

  move_bkg (0,16);
}

// vbk_reg must be 1
void displaysquare(UBYTE posx, UBYTE posy)
{
  temp1 = board[posx][posy];

  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);
  VBK_REG = 0;
  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);
  VBK_REG = 1;
}

// vbk_reg must be 1
void displaypiece (UBYTE posx, UBYTE posy)
{
  temp1 = piece[0];
  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);
  VBK_REG = 0;
  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);
  VBK_REG = 1;

  if (piece[1] != 0)
  {
    temp1 = piece[1];  
    set_bkg_tiles (posx+1,posy,1,1,(unsigned char *)&temp1);
    VBK_REG = 0;
    set_bkg_tiles (posx+1,posy,1,1,(unsigned char *)&temp1);
    VBK_REG = 1;
  }
  else
  {
    temp1 = piece[2];
    set_bkg_tiles (posx,posy+1,1,1,(unsigned char *)&temp1);
    VBK_REG = 0;
    set_bkg_tiles (posx,posy+1,1,1,(unsigned char *)&temp1);
    VBK_REG = 1;
  }
}

// vbk_reg must be 1
void displaynextpiece ()
{
  temp1 = nextpiece[0];
  set_bkg_tiles (17,3,1,1,(unsigned char *)&temp1);
  temp1 = nextpiece[2];
  set_bkg_tiles (17,4,1,1,(unsigned char *)&temp1);
  VBK_REG = 0;

  temp1 = nextpiece[0];
  set_bkg_tiles (17,3,1,1,(unsigned char *)&temp1);
  temp1 = nextpiece[2];
  set_bkg_tiles (17,4,1,1,(unsigned char *)&temp1);
  VBK_REG = 1;

}

// erasepiece only sets the tile to 0, which is a blank tile in all palettes
// saves a bit of time
void erasepiece (UBYTE posx, UBYTE posy)
{
  temp1 = 0;
  VBK_REG = 0;
  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);

  if (piece[1] != 0)
  {
    set_bkg_tiles (posx+1,posy,1,1,(unsigned char *)&temp1);
  }
  else
  {
    set_bkg_tiles (posx,posy+1,1,1,(unsigned char *)&temp1);
  }
  VBK_REG = 1;
}

void erasesquare (UBYTE posx, UBYTE posy)
{

  VBK_REG = 0;
  temp1 = 0;
  set_bkg_tiles (posx,posy,1,1,(unsigned char *)&temp1);
  delay(50);

  VBK_REG = 1;
}

/* haven't converted this yet
void put_explosion (int x,int y,int xoffset){
	int top,left;
	int grabtop = 0;
	int grabbottom = 30;
	int grableft = 270;
	int grabright= 300;

	left = (-9+(x-1)*10) + xoffset  ;
	top = -9+(y-1)*10;

	if (x == 1)
	{
		left = left +10;
		grableft = 280;
	}
	else if (x ==13  )
		grabright = 290;


	if (y==1)
	{
		top = top+10;
		grabtop = 10;
	}
	else if (y ==  19)
		grabbottom = 19;
	else if (y==18)
		grabbottom= 29;
	if (grableft == 270)
	{
		if (left%4==1)
			copy_bitmap(1,grableft+3,grabtop+30,grabright+2,grabbottom+30,
								0,left,top);
		else
			copy_bitmap(1,grableft+1,grabtop,grabright,
								grabbottom,0,left,top );
	}
	else
	{
		if (left%4==3)
			copy_bitmap(1,grableft+3,grabtop+30,grabright+2,grabbottom+30,
								0,left,top);
		else
			copy_bitmap(1,grableft+1,grabtop,grabright,
								grabbottom,0,left,top );
	}
}


void erase_explosion (int x, int y,int xoffset)
{
	int top,left,right,bottom;

	left = (-10+(x-1)*10) +xoffset ;
	top = -10+(y-1)*10;
	if (x == 1)
	{
		left = left +11;
		right = left + 20;
	}
	else if (x == 2)
	{	left=left+1;
		right= left+30;
	}
	else if (x ==12)
		right = left+30;
	else if (x ==13)
		right = left +20;
	else
		right = left + 31;

	if (y==1)
	{
		top = top+11;
		bottom=top+20;
	}
	else if (y==2)
	{
		top = top+1;
		bottom = top+30;
	}
	else if (y==18)
		bottom=top+30;
	else if (y ==  19)
		bottom=top+20;
	else
		bottom = top+31;

	fill_block(left,top,right,bottom,0);

}

void erase_extra (int x, int y)
{
	int xstart,xend;
	int ystart,yend;
	erase_explosion (x,y,b->xoffset);

	if (x != 1)
		xstart = x-1;
	else
		xstart = x;

	if (x!=13)
		xend = x+1;
	else
		xend = x;

	if (y !=1)
		ystart = y-1;
	else
		ystart = y;

	if (y !=19)
		yend = y+1;
	else
		yend = y;

	for (x=xstart;x<=xend;x++)
		for (y=ystart;y<=yend;y++)
			displaysquare(b,x,y,b->xoffset);

}

void erase_bonus_text(){

	fill_block(150,100,250,130,0);
}
*/

// puts a floating score on the screen at the show_score pos
void show_score (void)
{
  move_sprite (0,show_score_x,show_score_y);
  move_sprite (1,show_score_x+5,show_score_y);
  move_sprite (2,show_score_x+10,show_score_y);
}

// puts the combo display on the screen
void show_combo (void)
{
  move_sprite (5,show_combo_x,show_combo_y);
  move_sprite (6,show_combo_x+6,show_combo_y);
}

void displaynumber ( UBYTE y )
{
  long x;
  VBK_REG = 0;

  /*put the number on the screen */  
  if (display_number >9999) 
  {
    x = (display_number / 10000) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
  }
  else 
    temp1 = 160;
  set_bkg_tiles (15,y,1,1,(unsigned char *)&temp1);

  if (display_number > 999)
  {
    x = (display_number / 1000) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
  }
  else 
    temp1 = 160;
  set_bkg_tiles (16,y,1,1,(unsigned char *)&temp1);
  
  if (display_number > 99)
  {
    x = (display_number / 100) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
  }
  else 
    temp1 = 160;
  set_bkg_tiles (17,y,1,1,(unsigned char *)&temp1);

  if (display_number > 9)
  {
    x = (display_number / 10) % 10;
    temp1 = (unsigned char) x;
    temp1 = temp1+176;
  }
  else 
    temp1 = 160;
  set_bkg_tiles (18,y,1,1,(unsigned char *)&temp1);
    
  x = (display_number ) % 10;
  temp1 = (unsigned char) x;
  temp1 = temp1+176;
  set_bkg_tiles (19,y,1,1,(unsigned char *)&temp1);

  VBK_REG = 1;

}

void play_sound (UBYTE s)
{
 // play some different sound
}

void sound_click (void)
{
  //if (sound==YES)
  {
    NR41_REG = 0x37U;
    NR42_REG = 0xF8U;
    NR43_REG = 0x07U;
    NR44_REG = 0xC0U;
    NR51_REG = 0xF7;
/*    NR41_REG = 0x39U;
    NR42_REG = 0xFBU;
    NR43_REG = 0x00U;
    NR44_REG = 0xC0U;
    NR51_REG = 0xF7;
*/  }
} 

void sound_pop (void)
{
  //if (sound==YES)
  {
    NR21_REG = 0x7AU;
    NR22_REG = 0xF8U;
    NR23_REG = 0xFFU;
    NR24_REG = 0xC6U;
/*
    NR10_REG = 0x04U;
    NR11_REG = 0xFEU;
    NR12_REG = 0xA1U;
    NR13_REG = 0x8FU;
    NR14_REG = 0x86U;
    NR51_REG = 0xF7;
*/  }
} 

void changetempo (UBYTE tempo)
{
  // change the speed the music is playing at
}

UBYTE wait_for_button (void)
{
  UBYTE j;

  j = 0;

  while (joypad() != 0);
  // wait for the user to press a button
  while (j < 16)
    j=joypad();
  // wait for the user to release the button
  while (joypad() != 0);

  return j;
}



