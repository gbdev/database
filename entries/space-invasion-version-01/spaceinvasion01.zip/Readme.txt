
Space Invasion - V0.1 - 19/03/00

Copyright 1999/2000 Thalamus Interactive Ltd.



Controls:

Title Screen:
Up / Down    - Move highlight Up / Down
A / B        - Select Option
Start        - Return to Title Screen / Start Game

Options Screen:
Up / Down    - Move highlight Up / Down
A / B        - Toggle Option
Left / Right - Toggle Option
Start        - Return to Title Screen

In-Game:
Left / Right - Move ship Left / Right
A / B        - Fire
Start        - Pause Game

Hold A, B, Start, and Select to reset.



Options:

Lives        - Choose between 1, 3, or 5 lives
Skill        - Choose EASY, NORMAL, or HARD difficulty setting
Sound        - Choose OFF, MUSIC, SFX, or BOTH (music & sfx)
Style        - Choose between CLASSIC or MODERN alien movement style



Acknowledgements:

Rob Hubbard's music used by kind permission of High Technology Publishing Ltd.



This demo is Freeware. It may not be sold, hired, leased, or otherwise distributed for profit or any form of financial gain.

All Rights Reserved.



www.thalamusinteractive.com
