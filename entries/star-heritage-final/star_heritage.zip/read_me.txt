-+- Star Heritage final ------------------------------------------+-

This is the final version of our adventure for Gameboy Color.
Now we're concentrated on GBA entirely, and we have no more time
to work on this game so some bugs are still exist.

There are 2 versions for different methods of game saving
(cart RAM and password saving)

 Star Heritage is a quest game where player becomes the secret agent
of Earthen Resistance who bumps into an unexpected accident to dive
into the world of the distant future, where high technologies come
along with partisan wars and post-industrial decay.

 Lots of dangerous places and situations are awaiting for player,
alone on an unknown planet not far from the centre of invasion of
brutal enemies who had already destroyed and conquered the Earthen
Federation. Moving from location to location, exploring the world
around, using unrevealed objects and tools, and talking to the
inhabitants of this unexplored world player should survive and
get back to the Federation's base. While discovering this hostile
world, player accumulate experience and receive some knowledge which
might turn your goal into something far more important.

Hope you'll find it interesting :)

-+- Legal --------------------------------------------------------+-

The game is distributed as freeware.
Commercial usage is possible only after concordance with authors.

-+- Contact ------------------------------------------------------+-

e-mail:r-lab@mail.ru
http://r-lab.8m.com