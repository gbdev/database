/* 
 @todo save checksum!!! - weak battery kills save
 @todo decrease save enable/disable calls
 @todo shapes instead of balls for game boy pocket/classic
 
 @todo prng rejection sampling, droping high order bits to the closest not under. rerand until in range.
 @todo chopin music?
 @todo paint 9th balls - use sprites to paint the rarest color, possibly sprite pool(pessimistic 20 sprites in the line)
 */

#include <gb/gb.h>
#include <gb/emu_debug.h>

#include <limits.h>
#include <rand.h>
#include <time.h>

#include "astar.h"
#include "combo.h"
#include "drawing.h"
#include "definitions.h"
#include "main.h"
#include "saveproc.h"

enum GAME_STATE game_state;
const uint8_t levelcolors[3] = {5, 7, 8};
const uint8_t levelscore[3] = {1, 2, 3};

const uint8_t select_ball_anim_y[4] = {0, 1, 2, 1};
uint16_t anim_next;
uint16_t anim_prev;
bool anim_overflow = false;
uint8_t select_ball_x;
uint8_t select_ball_y;
uint8_t select_ball_frame = 0;
uint8_t cursor_x;
uint8_t cursor_y;
uint8_t selected_x;
uint8_t selected_y;
uint8_t joy_old;
bool is_shapes;

uint32_t hiscore = 0;
uint32_t score = 0;
uint8_t game_board[81];
uint8_t futureballs[RAND_BALLS] = {0, 0, 0};
bool hint = true;
level_t level = LEVEL_SANE;
bool is_saved;
bool save_enabled;

uint8_t parents[81];


void add_score(uint8_t score);
void add_start_balls(void);
void eliminate_combo(combo_t combo);
void end_game(uint32_t endscore);
uint8_t empty_cells(void);
static inline uint8_t game_board_get(uint8_t x, uint8_t y);
static inline void game_board_set(uint8_t x, uint8_t y, uint8_t value);
void init_start_menu(void);
void init_load_game(void);
void joy_to_cursor(const uint8_t joy, const uint8_t old);
void joy_to_menu(const uint8_t joy, const uint8_t old);
void joy_to_pause_menu(const uint8_t joy, const uint8_t old);
static inline uint8_t my_min(uint8_t a, uint8_t b);
void new_game(void);
void place_futures(void);
void rand_futures(void);
void select_ball(uint8_t x, uint8_t y, uint8_t color);
void select_ball_animate(void);
void select_ball_clear(void);
void select_ball_move(uint8_t sel);
bool try_remove_balls(void);

void 
main (void)
{
    SHOW_SPRITES;
    SHOW_BKG;
    show_splash();
    DISPLAY_ON;
    waitpad(J_START);
    waitpadup();
    
    init_bkg(0);
    init_sprites();
    is_shapes = CGB_TYPE != _cpu;
    init_balls(is_shapes);
    
    save_enabled = is_saving_enabled();
    if (save_enabled)
    {
        hiscore = do_load_hiscore();
    }

    if(save_enabled && has_saved_game())
    {
        init_load_game();
    }
    else
    {
        init_start_menu();
    }

    for(;;)
    {
        vsync();
        uint8_t joy = joypad();
        if (joy & J_SELECT && ~joy_old & J_SELECT)
        {
            is_shapes = !is_shapes;
            init_balls(is_shapes);
        }
        if (GAME_SELECT_BALL == game_state || GAME_SELECT_CELL == game_state)
        {
            select_ball_animate();
            joy_to_cursor(joy, joy_old);
        }
        else if (GAME_MENU == game_state)
        {
            joy_to_menu(joy, joy_old);
        }
        else if (GAME_OVER == game_state)
        {
            if (joy & J_START && ~joy_old & J_START)
            {
                clear_future_balls();
                init_start_menu();
            }
        }
        else if (GAME_PAUSE == game_state)
        {
            joy_to_pause_menu(joy, joy_old);
        }
        else {}
        joy_old = joy;
    }
}

void 
add_score (uint8_t balls)
{
    uint8_t bonus = balls * levelscore[level];
    if (hint)
    {
        bonus = bonus - bonus / 3;
    }
    while (bonus > 0)
    {
        ++score;
        print_score(score);
        perform_delay(ANIM_SPEED_SCORE);
        --bonus;
    }
}

void 
add_start_balls (void)
{
    uint8_t i = 0;
    while (i < START_BALLS)
    {
        uint8_t adr = rand() % 81;
        if(0 == game_board[adr])
        {
            game_board[adr] = rand() % levelcolors[level] + 1;
            ++i;
        }
    }
}

void
eliminate_combo (combo_t combo)
{
    switch (combo.dir)
    {
        case COMBODIR_HORIZ:
            for (uint8_t colmark = combo.col; colmark < combo.col + combo.len; ++colmark)
            {
                game_board_set(colmark, combo.row, 0);
                draw_mini_ball(colmark * 2, combo.row * 2);
            }
            perform_delay(ANIM_SPEED_MINIBALL);
            for (uint8_t colmark = combo.col; colmark < combo.col + combo.len; ++colmark)
            {
                draw_ball(colmark * 2, combo.row * 2, 0);
            }
        break;

        case COMBODIR_VERT:
            for (uint8_t rowmark = combo.row; rowmark < combo.row + combo.len; ++rowmark)
            {
                game_board_set(combo.col, rowmark, 0);
                draw_mini_ball(combo.col * 2, rowmark * 2);
            }
            perform_delay(ANIM_SPEED_MINIBALL);
            for (uint8_t rowmark = combo.row; rowmark < combo.row + combo.len; ++rowmark)
            {
                draw_ball(combo.col * 2, rowmark * 2, 0);
            }
        break;

        case COMBODIR_DIAG:
            for (uint8_t idx = 0; idx < combo.len; ++idx)
            {
                game_board_set(combo.col + idx, combo.row + idx, 0);
                draw_mini_ball((combo.col + idx) * 2, (combo.row + idx) * 2);
            }
            perform_delay(ANIM_SPEED_MINIBALL);
            for (uint8_t idx = 0; idx < combo.len; ++idx)
            {
                draw_ball((combo.col + idx) * 2, (combo.row + idx) * 2, 0);
            }
        break;

        case COMBODIR_DIAG2:
            for (uint8_t idx = 0; idx < combo.len; ++idx)
            {
                game_board_set(combo.col - idx, combo.row + idx, 0);
                draw_mini_ball((combo.col - idx) * 2, (combo.row + idx) * 2);
            }
            perform_delay(ANIM_SPEED_MINIBALL);
            for (uint8_t idx = 0; idx < combo.len; ++idx)
            {
                draw_ball((combo.col - idx) * 2, (combo.row + idx) * 2, 0);
            }
        break;
        
        default:
        break;
    }    
}

uint8_t
empty_cells (void)
{
    uint8_t empty = 0;
    for (uint8_t i = 0; i < 81; ++i)
    {
        if (0 == game_board[i])
        {
            ++empty;
        }
    }
    return empty;
}

void
end_game (uint32_t endscore)
{
    cursor_hide();
    if(endscore > hiscore)
    {
        hiscore = endscore;
        if (save_enabled)
        {
            do_save_hiscore(hiscore);
        }
    }
    futureballs[0] = futureballs[1] = futureballs[2] = 0;
    draw_future_balls(futureballs);
    print_text_vert(18, 12, "END", 2);
}

static inline uint8_t
game_board_get (uint8_t x, uint8_t y)
{
    return game_board[x + mul_9_lut[y]];
}

static inline void 
game_board_set (uint8_t x, uint8_t y, uint8_t value)
{
    game_board[x + mul_9_lut[y]] = value;
}

void 
init_start_menu (void)
{
    init_bkg(0);
    game_state = GAME_MENU;
    draw_start_menu(hint, level, hiscore);
}

void
init_load_game (void)
{
    game_state = GAME_STARTING;
    initrand(clock());
    
    do_load_game(&score, futureballs, game_board, &level, &hint);

    clear_score_bar(hint);
    print_score(score);
    if (hint) 
    {
        draw_future_balls(futureballs);
    }

    draw_game_board(game_board);
    
    cursor_x = 4;
    cursor_y = 4;
    selected_x = ERRNUMBER;
    selected_y = ERRNUMBER;
    cursor_show(cursor_x, cursor_y);
    game_state = GAME_SELECT_BALL;
}

void 
joy_to_cursor (const uint8_t joy, const uint8_t old)
{
    if (joy == old)
    {
        return;
    }
    
    if (joy & J_START && ~old & J_START)
    {
        game_state = GAME_PAUSE;
        init_bkg(0);
        clear_future_balls();
        cursor_hide();
        selection_clear();
        is_saved = false;
        draw_pause_menu(is_saved, save_enabled);
        return;
    }
    
    if (GAME_SELECT_BALL != game_state && GAME_SELECT_CELL != game_state)
    {
        return;
    }

    if (joy & J_LEFT && ~old & J_LEFT)
    {
        cursor_x = cursor_x > 0 ? cursor_x-1 : 8;
        cursor_show(cursor_x, cursor_y);
    }
    if (joy & J_RIGHT && ~old & J_RIGHT)
    {
        cursor_x = cursor_x < 8 ? cursor_x+1 : 0;
        cursor_show(cursor_x, cursor_y);
    }
    if (joy & J_UP && ~old & J_UP)
    {
        cursor_y = cursor_y > 0 ? cursor_y-1 : 8;
        cursor_show(cursor_x, cursor_y);
    }
    if (joy & J_DOWN && ~old & J_DOWN)
    {
        cursor_y = cursor_y < 8 ? cursor_y+1 : 0;
        cursor_show(cursor_x, cursor_y);
    }
    if (joy & J_A && ~old & J_A)
    {
        const uint8_t color = game_board_get(cursor_x, cursor_y);
        if (GAME_SELECT_BALL == game_state)
        {
            if (color != 0)
            {
                select_ball(cursor_x, cursor_y, color);
                game_state = GAME_SELECT_CELL;
            }
        } 
        else if (GAME_SELECT_CELL == game_state) 
        {
            if (color != 0)
            {
                select_ball(cursor_x, cursor_y, color);
            }
            else
            {
                const uint8_t sel = selected_x + mul_9_lut[selected_y];
                const uint8_t cur = cursor_x + mul_9_lut[cursor_y];
                if (findpath(game_board, parents, cur, sel))
                {
                    select_ball_move(sel);
                }
                else
                {
                    cursor_hide();
                    perform_delay(ANIM_SPEED);
                    cursor_show(cursor_x, cursor_y);
                }
            }
        }
    }
}

void
joy_to_menu (const uint8_t joy, const uint8_t old)
{
    if (joy == old)
    {
        return;
    }
    
    if (joy & J_START && ~old & J_START)
    {
        animate_start_menu();
        new_game();
        return;
    }

    if (joy & J_B && ~old & J_B)
    {
        hint = !hint;
        draw_start_menu(hint, level, hiscore);
        return;
    }

    if (joy & J_A && ~old & J_A)
    {
        if (LEVEL_EASY == level)
        {
            level = LEVEL_SANE;
        }
        else if (LEVEL_SANE == level)
        {
            level = LEVEL_HARD;
        }
        else
        {
            level = LEVEL_EASY;
        }
        draw_start_menu(hint, level, hiscore);
    }
}

void
joy_to_pause_menu (const uint8_t joy, const uint8_t old)
{
    if (joy & J_START && ~old & J_START)
    {
        init_bkg(0);
        draw_game_board(game_board);
        if (ERRNUMBER == selected_x)
        {
            game_state = GAME_SELECT_BALL;
        }
        else
        {
            game_state = GAME_SELECT_CELL;
            selection_init(selected_x, selected_y, game_board_get(selected_x, selected_y));
            draw_ball(selected_x * 2, selected_y * 2, 0);
        }
        draw_future_balls(futureballs);
        draw_tray();
        print_score(score);
        cursor_show(cursor_x, cursor_y);
        return;
    }

    if (joy & J_B && ~old & J_B)
    {
        if (score > hiscore)
        {
            hiscore = score;
            if (is_saving_enabled)
            {
                do_save_hiscore(hiscore);
            }
        }
        init_start_menu();
        return;
    }

    if (save_enabled && !is_saved && (joy & J_A) && (~old & J_A))
    {
        do_save_game(score, futureballs, game_board, level, hint);
        is_saved = true;
        draw_pause_menu(is_saved, save_enabled);
        return;
    }
}

static inline uint8_t
my_min (uint8_t a, uint8_t b)
{
    return a < b ? a : b;
}

void
new_game (void)
{
    game_state = GAME_STARTING;
    initrand(clock());
    do_erase_save();
    
    score = 0;
    rand_futures();
    for (int i=0; i<81; ++i)
    {
        game_board[i] = 0;
    }

    clear_score_bar(hint);
    print_text_vert(18, 0, "0", 2);
    add_start_balls();
    if (hint) 
    {
        draw_future_balls(futureballs);
    }

#ifdef STRESSTEST
#	define STRESSTESTNR(S) STRESS_AGAIN (S)
#	define STRESS_AGAIN(VAR) stress ## VAR
    for(int i = 0; i<81; i++)
    {
        game_board[i] = STRESSTESTNR(STRESSTEST)[i];
    }
#endif

    draw_game_board(game_board);
    if (try_remove_balls())
    {
        perform_delay(ANIM_SPEED);
        draw_game_board(game_board);
    }

    cursor_x = 4;
    cursor_y = 4;
    selected_x = ERRNUMBER;
    selected_y = ERRNUMBER;
    cursor_show(cursor_x, cursor_y);
    game_state = 81 == empty_cells() ? GAME_OVER : GAME_SELECT_BALL;
    if(GAME_OVER == game_state)
    {
        end_game(score);
    }
}

void
place_futures (void)
{
    uint8_t futuresleft = my_min(empty_cells(), RAND_BALLS);
    cursor_hide();
    while (futuresleft > 0)
    {
        uint8_t adr = rand() % 81;		
        if (0 == game_board[adr])
        {
            --futuresleft;
            game_board[adr] = futureballs[futuresleft];
            transfer_future(adr, futuresleft, futureballs[futuresleft]);
        }
    }
    cursor_show(cursor_x, cursor_y);
}

void
rand_futures (void) 
{
    for (uint8_t i = 0; i < 3; ++i)
    {
        futureballs[i] = rand() % levelcolors[level] + 1;
    }
}

void
select_ball (uint8_t x, uint8_t y, uint8_t color)
{
    if (selected_x != ERRNUMBER)
    {
        draw_ball(selected_x * 2, selected_y * 2, game_board_get(selected_x, selected_y));
    }
    
    draw_ball(x * 2, y * 2, 0);
    selection_init(x, y, color);
    selected_x = x;
    selected_y = y;
    select_ball_x = x * 16;
    select_ball_y = y * 16;
    
    anim_prev = clock();
    anim_next = anim_prev + ANIM_SPEED_JUMP;
    anim_overflow = anim_next < anim_prev;
}

void
select_ball_animate (void)
{
    if (ERRNUMBER != selected_x)
    {
        clock_t now = clock();
        bool isnextframe = (anim_overflow && now > anim_next && now < anim_prev) ||
                        (!anim_overflow && (now > anim_next || now < anim_prev));
        if (isnextframe)
        {
            ++select_ball_frame;
            select_ball_frame %= 4;
            selection_move(select_ball_x + SPR_OFFS_X, 
                select_ball_y - select_ball_anim_y[select_ball_frame] + SPR_OFFS_Y);
            anim_prev = now;
            anim_next = now + ANIM_SPEED_JUMP;
            anim_overflow = anim_next < anim_prev;
        }
    }
}

void
select_ball_clear (void)
{
    selection_clear();
    selected_x = ERRNUMBER;
    selected_y = ERRNUMBER;
}

void
select_ball_move (uint8_t sel)
{
    const uint8_t colr = game_board_get(selected_x, selected_y);
    game_board_set(cursor_x, cursor_y, colr);
    game_board_set(selected_x, selected_y, 0);
    animatemove(sel, parents);
    select_ball_clear();
    draw_game_board(game_board);
    perform_delay(ANIM_SPEED);

    if (try_remove_balls())
    {
        perform_delay(ANIM_SPEED);
        draw_game_board(game_board);
        game_state = GAME_SELECT_BALL;
    }
    else
    {
        place_futures();
        if (try_remove_balls())
        {
            perform_delay(ANIM_SPEED);
            draw_game_board(game_board);
        }

        rand_futures();
        if (hint)
        {
            draw_future_balls(futureballs);
        }
        
        uint8_t empty = empty_cells();
        game_state = (0 == empty || 81 == empty) ? GAME_OVER : GAME_SELECT_BALL;
        if (GAME_OVER == game_state)
        {
            end_game(score);
        }
    }
}

bool
try_remove_balls (void)
{
    bool is_eliminated = false;
    for(;;)
    {
        combo_t combo = best_combo(game_board);
        if(combo.len >= COMBO_LEN_MIN)
        {
            eliminate_combo(combo);
            is_eliminated = true;
            add_score(combo.len);
        } 
        else
        {
            break;
        }
    }
    return is_eliminated;
}
