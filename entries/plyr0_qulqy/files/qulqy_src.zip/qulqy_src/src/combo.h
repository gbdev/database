#ifndef H_COMBO
#define H_COMBO

/* get best bool combo(*orientation, *length, *startcell) */

#define COMBO_LEN_MIN   5

typedef enum
{
    COMBODIR_NONE = 0,
    COMBODIR_HORIZ,
    COMBODIR_VERT,
    COMBODIR_DIAG,
    COMBODIR_DIAG2
} combo_direction_t;

typedef struct
{
    uint8_t row;
    uint8_t col;
    uint8_t len;
    combo_direction_t dir;
} combo_t;

combo_t best_combo(const uint8_t game_board[81]);

#endif
