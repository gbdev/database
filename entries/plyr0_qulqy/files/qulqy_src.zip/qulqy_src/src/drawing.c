#include <ctype.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>

#include <gb/gb.h>
#include <gb/cgb.h>

#include "drawing.h"
#include "definitions.h"
#include "res/balls.h"
#include "res/cursor.h"
#include "res/gbcompo2c.h"
#include "res/letters.h"
#include "res/tray.h"
#include "res/shapes.h"

#define FUTURE_OFFSET_Y ((uint8_t)(SPR_OFFS_Y + 144 - 3 * 16))

#define TILE_CURSOR     ((uint8_t)0)

#define BALLS_COUNT     ((uint8_t)41)
#define TILE_EMPTY      ((uint8_t)128)
#define TILE_BALL       ((uint8_t)129)
#define TILE_MINIBALL   ((uint8_t)(128 + 37))

#define LETTERS_COUNT   ((uint8_t)88)
#define TILE_LETTERS    ((uint8_t)1)
#define TILE_TRAY       ((uint8_t)89)

static int8_t letters_lut['Z' - '0' + 1] =
{
     0,  1,  2,  3,  4,  5,  6,  7,  8,  9, 32, 32, 32, 32, 32, 32, 
    32, 11, 12, 32, 13, 14, 32, 32, 15,  1, 32, 32, 16, 32, 17,  0,
    18, 19, 20,  5,  7, 21, 32, 32, 32, 10,  2
};

static const uint16_t palettes[8 * 4] = 
{
    ballsCGBPal0c0, ballsCGBPal0c1, ballsCGBPal0c2, ballsCGBPal0c3, /* 1 orange */
    ballsCGBPal1c0, ballsCGBPal1c1, ballsCGBPal1c2, ballsCGBPal1c3, /* 2 red */
    ballsCGBPal2c0, ballsCGBPal2c1, ballsCGBPal2c2, ballsCGBPal2c3, /* 3 blue */
    ballsCGBPal3c0, ballsCGBPal3c1, ballsCGBPal3c2, ballsCGBPal3c3, /* 4 yellow */
    ballsCGBPal4c0, ballsCGBPal4c1, ballsCGBPal4c2, ballsCGBPal4c3, /* 5 green */
    ballsCGBPal5c0, ballsCGBPal5c1, ballsCGBPal5c2, ballsCGBPal5c3, /* 6 purple */
    ballsCGBPal6c0, ballsCGBPal6c1, ballsCGBPal6c2, ballsCGBPal6c3, /* 7 cyan */
    ballsCGBPal7c0, ballsCGBPal7c1, ballsCGBPal7c2, ballsCGBPal7c3  /* 8 gray */
};

typedef enum COLOR {
    COLOR_ORANGE,
    COLOR_RED,
    COLOR_BLUE,
    COLOR_YELLOW,
    COLOR_GREEN,
    COLOR_PURPLE,
    COLOR_CYAN,
    COLOR_GRAY
} mycolor_t;

void 
animatemove (uint8_t start, const uint8_t parents[81])
{
    uint8_t cell = start;
    while (parents[cell] != 128)
    {
        const uint8_t x = SPR_OFFS_X + mod_9_lut[cell] * 16;
        const uint8_t y = SPR_OFFS_Y + div_9_lut[cell] * 16;
        const uint8_t parentscell = parents[cell];
        int8_t dx = mod_9_lut[myabs(parentscell - cell)];
        dx *= (parentscell - cell) > 0 ? 1 : -1;
        int8_t dy = div_9_lut[myabs(parentscell - cell)];
        dy *= (parentscell - cell) > 0 ? 1 : -1;

        for(int i = 0; i < 16; ++i)
        {
            move_sprite(16, x + i * dx, y + i * dy);
            move_sprite(17, x + 8 + i * dx, y + i * dy);
            move_sprite(18, x + i * dx, y + 8 + i * dy);
            move_sprite(19, x + 8 + i * dx, y + 8 + i * dy);
            delay(ANIM_SPEED_MOVE);
        }
        cell = parentscell;
    }
}

void
animate_start_menu (void)
{
    for(uint8_t i = 0; i < 4; ++i)
    {
        draw_ball(7 + i * 2, 15, 3);
        perform_delay(ANIM_SPEED);
    }
    perform_delay(ANIM_SPEED);
    print_text(7, 15, "     ", 3);
    perform_delay(ANIM_SPEED);
}

void 
clear_future_balls (void)
{
    /* sprites 4567 8-9-10-11 12-13-14-15 */
    for (int i = 0; i < 3; ++i) {
        uint8_t spr = 4 + i * 4;
        move_sprite(spr, 0, 0);
        move_sprite(spr + 1, 0, 0);
        move_sprite(spr + 2, 0, 0);
        move_sprite(spr + 3, 0, 0);
    }
}

void
clear_score_bar (bool hint)
{
    for (uint8_t i = 0; i<9; ++i)
    {
        draw_ball(18, i * 2, 0);
    }

    if (hint)
    {
        draw_tray();
        if(CGB_TYPE == _cpu)
        {
            set_bkg_attribute_xy(18, 12, 7);
            set_bkg_attribute_xy(18, 13, 7);
            set_bkg_attribute_xy(18, 14, 7);
            set_bkg_attribute_xy(18, 15, 7);
            set_bkg_attribute_xy(18, 16, 7);
            set_bkg_attribute_xy(18, 17, 7);
        }
    }
}

void
cursor_hide (void)
{
    move_sprite(0, 0, 0);
    move_sprite(1, 0, 0);
    move_sprite(2, 0, 0);
    move_sprite(3, 0, 0);
}

void
cursor_show (uint8_t x, uint8_t y)
{
    move_sprite(0, SPR_OFFS_X + x * 16, SPR_OFFS_Y + y * 16);
    move_sprite(1, SPR_OFFS_X + 8 + x * 16, SPR_OFFS_Y + y * 16);
    move_sprite(2, SPR_OFFS_X + x * 16, SPR_OFFS_Y + 8 + y * 16);
    move_sprite(3, SPR_OFFS_X + 8 + x * 16, SPR_OFFS_Y + 8 + y * 16);
}

void
draw_ball (uint8_t x, uint8_t y, uint8_t number)
{
    if (0 == number)
    {
        set_bkg_tile_xy(x, y, 0);
        set_bkg_tile_xy(x+1, y, 0);
        set_bkg_tile_xy(x, y+1, 0);
        set_bkg_tile_xy(x+1, y+1, 0);
    }
    else
    {
        --number;
        uint8_t nr_adr = TILE_BALL + number * 4;
        set_bkg_tile_xy(x, y, nr_adr);
        set_bkg_tile_xy(x+1, y, nr_adr+1);
        set_bkg_tile_xy(x, y+1, nr_adr+2);
        set_bkg_tile_xy(x+1, y+1, nr_adr+3);
        if (CGB_TYPE == _cpu)
        {
            set_bkg_attribute_xy(x, y, number);
            set_bkg_attribute_xy(x+1, y, number);
            set_bkg_attribute_xy(x, y+1, number);
            set_bkg_attribute_xy(x+1, y+1, number);
        }
    }
}

void
draw_future_balls (const uint8_t futureballs[3])
{
    for (int i = 0; i < 3; ++i) {
        uint8_t spr = 4 + i * 4;
        uint8_t idx = futureballs[i] - 1;
        set_sprite_tile(spr, TILE_BALL + idx * 4);
        set_sprite_prop(spr, idx);
        move_sprite(spr, SPR_OFFS_X + 144u, FUTURE_OFFSET_Y + 16 * i);

        set_sprite_tile(spr + 1, TILE_BALL + idx * 4 + 1);
        set_sprite_prop(spr + 1, idx);
        move_sprite(spr + 1, SPR_OFFS_X + 152u, FUTURE_OFFSET_Y + 16 * i);

        set_sprite_tile(spr + 2, TILE_BALL + idx * 4 + 2);
        set_sprite_prop(spr + 2, idx);
        move_sprite(spr + 2, SPR_OFFS_X + 144u, FUTURE_OFFSET_Y + 8 + 16 * i);

        set_sprite_tile(spr + 3, TILE_BALL + idx * 4 + 3);
        set_sprite_prop(spr + 3, idx);
        move_sprite(spr + 3, SPR_OFFS_X + 152u, FUTURE_OFFSET_Y + 8 + 16 * i);
    }
}

void
draw_game_board (const uint8_t game_board[81])
{
    for (uint8_t i = 0; i<81; ++i)
    {
        draw_ball(mod_9_lut[i] * 2, div_9_lut[i] * 2, game_board[i]);
    }
}

void
draw_mini_ball (uint8_t x, uint8_t y)
{
    set_bkg_tile_xy(x, y, TILE_MINIBALL);
    set_bkg_tile_xy(x+1, y, TILE_MINIBALL + 1u);
    set_bkg_tile_xy(x, y+1, TILE_MINIBALL + 2u);
    set_bkg_tile_xy(x+1, y+1, TILE_MINIBALL + 3u);   
}

void
draw_pause_menu (bool issaved, bool issaveenabled)
{
    print_text(5, 2, "pause", COLOR_GRAY);
    print_text(1, 8, "sta play", COLOR_BLUE);
    
    if(issaveenabled)
    {
        if (issaved)
        {
            print_text(1, 10, "    SAuED", COLOR_GREEN);
        }
        else
        {
            print_text(1, 10, " A  SAuE", COLOR_RED);
        }
    }
    
    print_text(1, 12, " B  quit", COLOR_ORANGE);
}

void
draw_start_menu (bool hint, level_t level, uint32_t score)
{
    draw_ball(1, 2, 2);
    print_text(5, 2, "q", 2);
    print_text(7, 1, "ul", 2);
    print_text(11, 2, "qy", 2);
    draw_ball(17, 2, 1);
    print_text(1, 4, "BY  plyr0", 7);

    char hiscore[7];
    itoa(score, hiscore, 10);
    uint8_t leftpad = 6 - strlen(hiscore);
    char scorestring[10] = "HI ";
    for (uint8_t i = 0; i < leftpad; ++i)
    {
        strcat(scorestring, " ");
    }
    strcat(scorestring, hiscore);
    print_text(1, 7, scorestring, 3);

    print_text(1, 10, hint ? " B  HINT " : " B  BLIND", 0);
    if (LEVEL_EASY == level)
    {
        print_text(1, 12, " A  EASY", 4);
        draw_ball(17, 12, 5);
    }
    else if (LEVEL_SANE == level)
    {
        print_text(1, 12, " A  SANE", 4);
        draw_ball(17, 12, 7);
    }
    else
    {
        print_text(1, 12, " A  HARD", 4);
        draw_ball(17, 12, 8);
    }

    draw_ball(15, 15, 3);
    print_text(5, 15, "START", 1);
}

void 
init_balls (bool is_shapes)
{
    if (is_shapes)
    {
        set_bkg_data(128, 1, balls); /* empty */
        set_bkg_data(129, 36, shapes);
        set_bkg_data(129u + 36u, 4, &balls[16 + 16 * 36]); /* miniball */
    } 
    else
    {
        set_bkg_data(128, BALLS_COUNT, balls);
    }
}

void 
init_sprites (void)
{
    if (CGB_TYPE == _cpu)
    {
        set_bkg_palette(0, 8, palettes);
    }

    set_sprite_data(0, 4, cursor); 
    set_bkg_data(0, 1, balls); /* empty */
    set_bkg_data(1, LETTERS_COUNT, letters);
    set_bkg_data(TILE_TRAY, 2, tray);
    
    set_sprite_palette(0, 8, palettes);

    /* cursor sprites 0123 */
    set_sprite_tile(0, TILE_CURSOR);
    set_sprite_prop(0, 1);
    move_sprite(0, 0, 0);
    
    set_sprite_tile(1, TILE_CURSOR + 1);
    set_sprite_prop(1, 1);
    move_sprite(1, 0, 0);
    
    set_sprite_tile(2, TILE_CURSOR + 2);
    set_sprite_prop(2, 1);
    move_sprite(2, 0, 0);
    
    set_sprite_tile(3, TILE_CURSOR + 3);
    set_sprite_prop(3, 1);
    move_sprite(3, 0, 0);
}

void
print_letter (uint8_t x, uint8_t y, uint8_t tile_number, uint8_t color)
{
    uint8_t nr_adr = TILE_LETTERS + tile_number * 4;
    set_bkg_tile_xy(x, y, nr_adr);
    set_bkg_tile_xy(x+1, y, nr_adr+1);
    set_bkg_tile_xy(x, y+1, nr_adr+2);
    set_bkg_tile_xy(x+1, y+1, nr_adr+3);
    if (CGB_TYPE == _cpu)
    {
        set_bkg_attribute_xy(x, y, color);
        set_bkg_attribute_xy(x+1, y, color);
        set_bkg_attribute_xy(x, y+1, color);
        set_bkg_attribute_xy(x+1, y+1, color);
    }
}

void 
print_score (uint32_t score)
{
    if (score > 999999u)
    {
        print_text_vert(18, 0, "Err   ", 2);
    }
    else
    {
        uint8_t scorestr[7];
        itoa(score, scorestr, 10);
        print_text_vert(18, 0, scorestr, 2);
    }
}

void
print_text (uint8_t x, uint8_t y, const char *text, uint8_t color)
{
    uint8_t counter = 0;
    uint8_t ch = text[counter];
    while ('\0' != ch)
    {
        if (' ' == ch)
        {
            set_bkg_tile_xy(x + counter * 2, y, 0);
            set_bkg_tile_xy(x + counter * 2 + 1, y, 0);
            set_bkg_tile_xy(x + counter * 2, y + 1, 0);
            set_bkg_tile_xy(x + counter * 2 + 1, y + 1, 0);
        }
        else
        {
            ch = toupper(ch);
            uint8_t til = letters_lut[ch - '0'];
            print_letter(x + counter * 2, y, til, color);
        }
        ++counter;
        ch = text[counter];
    }
}

void
print_text_vert (uint8_t x, uint8_t y, const char *text, uint8_t color)
{
    uint8_t counter = 0;
    uint8_t ch = text[counter];
    while ('\0' != ch)
    {
        if (' ' == ch)
        {
            set_bkg_tile_xy(x, y + counter * 2, 0);
            set_bkg_tile_xy(x + 1, y + counter * 2 , 0);
            set_bkg_tile_xy(x , y + 1 + counter * 2, 0);
            set_bkg_tile_xy(x + 1, y + 1 + counter * 2, 0);
        }
        else
        {
            ch = toupper(ch);
            uint8_t til = letters_lut[ch - '0'];
            print_letter(x, y + counter * 2, til, color);
        }
        ++counter;
        ch = text[counter];
    }
}

void
draw_tray (void)
{
    set_bkg_tile_xy(18, 12, TILE_TRAY);
    set_bkg_tile_xy(18, 13, TILE_TRAY + 1);
    set_bkg_tile_xy(18, 14, TILE_TRAY);
    set_bkg_tile_xy(18, 15, TILE_TRAY + 1);
    set_bkg_tile_xy(18, 16, TILE_TRAY);
    set_bkg_tile_xy(18, 17, TILE_TRAY + 1);
}

void
selection_move(uint8_t x, uint8_t y)
{
    move_sprite(16, x, y);
    move_sprite(17, x + 8, y);
    move_sprite(18, x, y + 8);
    move_sprite(19, x + 8, y + 8);
}

void 
selection_init (uint8_t x, uint8_t y, uint8_t color)
{
    /* cursor sprites 16-17-18-19 */
    --color;
    set_sprite_tile(16, TILE_BALL + color * 4);
    set_sprite_prop(16, color);
    move_sprite(16, SPR_OFFS_X + x * 16, SPR_OFFS_Y + y * 16);
    
    set_sprite_tile(17, TILE_BALL + color * 4 + 1);
    set_sprite_prop(17, color);
    move_sprite(17, SPR_OFFS_X + x * 16 + 8, SPR_OFFS_Y + y * 16);

    set_sprite_tile(18, TILE_BALL + color * 4 + 2);
    set_sprite_prop(18, color);
    move_sprite(18, SPR_OFFS_X + x * 16, SPR_OFFS_Y + y * 16 + 8);

    set_sprite_tile(19, TILE_BALL + color * 4 + 3);
    set_sprite_prop(19, color);
    move_sprite(19, SPR_OFFS_X + x * 16 + 8, SPR_OFFS_Y + y * 16 + 8);
}

void
selection_clear (void)
{
    move_sprite(16, 0, 0);
    move_sprite(17, 0, 0);
    move_sprite(18, 0, 0);
    move_sprite(19, 0, 0);
}

void
show_splash (void)
{
    if (CGB_TYPE == _cpu)
    {
        set_bkg_palette(0, 1, gbcompo2c_palettes);
    }
    set_bkg_data(0, gbcompo2c_TILE_COUNT, gbcompo2c_tiles);
    set_bkg_tiles(0, 0, 20, 18, gbcompo2c_map);
}

void
transfer_future (uint8_t cell, uint8_t future, uint8_t color)
{
    uint8_t spr = 4 + future * 4;
    set_sprite_tile(spr, TILE_MINIBALL);
    set_sprite_tile(spr + 1, TILE_MINIBALL + 1u);
    set_sprite_tile(spr + 2, TILE_MINIBALL + 2u);
    set_sprite_tile(spr + 3, TILE_MINIBALL + 3u);
    perform_delay(ANIM_SPEED_MINIBALL);

    const uint8_t x = SPR_OFFS_X + mod_9_lut[cell] * 16;
    const uint8_t y = SPR_OFFS_Y + div_9_lut[cell] * 16;
    move_sprite(spr, x, y);
    move_sprite(spr + 1, x + 8, y);
    move_sprite(spr + 2, x, y + 8);
    move_sprite(spr + 3, x + 8, y + 8);
    perform_delay(ANIM_SPEED_MINIBALL);

    move_sprite(spr, 0, 0);
    move_sprite(spr + 1, 0, 0);
    move_sprite(spr + 2, 0, 0);
    move_sprite(spr + 3, 0, 0);
    draw_ball(mod_9_lut[cell] * 2, div_9_lut[cell] * 2, color);
    perform_delay(ANIM_SPEED_MINIBALL);
}
