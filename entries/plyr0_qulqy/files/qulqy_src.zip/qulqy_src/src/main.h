#ifndef H_MAIN
#define H_MAIN

#if 0
#	include "tests.h"
#	define STRESSTEST    G
#endif

#define START_BALLS     ((uint8_t)5)
#define RAND_BALLS      ((uint8_t)3)

enum GAME_STATE
{ 
    GAME_MENU,
    GAME_STARTING,
    GAME_SELECT_BALL,
    GAME_SELECT_CELL,
    GAME_OVER,
    GAME_PAUSE,
};

#endif