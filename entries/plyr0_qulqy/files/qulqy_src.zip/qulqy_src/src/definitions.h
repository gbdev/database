#ifndef H_DEFINITIONS
#define H_DEFINITIONS

#include <stdint.h>
#include <gb/gb.h>

#define ERRNUMBER           ((uint8_t)128)

#define ANIM_SPEED          ((uint16_t)12)  /* perform_delay in vblanks */
#define ANIM_SPEED_MINIBALL ((uint16_t)7)   /* perform_delay in vblanks */
#define ANIM_SPEED_SCORE    ((uint16_t)5)   /* perform_delay in vblanks */
#define ANIM_SPEED_MOVE     ((uint16_t)8)   /* delay in ms */
#define ANIM_SPEED_JUMP     ((uint16_t)5)   /* clock in cycles */

typedef enum
{
    LEVEL_EASY = 0,
    LEVEL_SANE,
    LEVEL_HARD
} level_t;

extern const uint8_t mod_9_lut[81];
extern const uint8_t div_9_lut[81];
extern const uint8_t mul_9_lut[9];

static inline int8_t
myabs (int8_t a)
{
    return a < 0 ? -a : a;
}

static inline void
perform_delay (uint16_t num_loops)
{
    while (num_loops > 0)
    {
        vsync();
        --num_loops;
    }
}

#endif
