#ifndef H_ASTAR
#define H_ASTAR

#include <stdint.h>
#include <stdbool.h>

bool findpath(const uint8_t walls[81], uint8_t parents[81], uint8_t startcell, uint8_t endcell);

#endif
