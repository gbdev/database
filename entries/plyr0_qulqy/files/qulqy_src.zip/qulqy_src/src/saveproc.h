#ifndef H_SAVEPROC
#define H_SAVEPROC

#include <stdint.h>
#include <stdbool.h>

#include "definitions.h"

#define SAVE_MAGIC      ((uint8_t)0b01010011) /* 83 arbitrally */

void do_erase_save(void);
void do_load_game(
    uint32_t * score, uint8_t futures[3], uint8_t board[81], level_t * level, bool * hint);

uint32_t do_load_hiscore(void);
void do_save_game(
    uint32_t score, uint8_t futures[3], uint8_t board[81], level_t level, bool hint);

void do_save_hiscore(uint32_t hiscore);
bool has_saved_game(void);
bool is_saving_enabled(void);

#endif