extern const unsigned char shapes[576];
