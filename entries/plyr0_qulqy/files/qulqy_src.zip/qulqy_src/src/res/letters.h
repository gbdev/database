extern const unsigned char letters[1408];
