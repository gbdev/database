#include <stdint.h>
#include <stdbool.h>

#include <gb/gb.h>

#include "saveproc.h"
#include "definitions.h"

extern uint8_t  save_magic;

extern uint32_t save_hiscore;

extern uint8_t  save_has_save_state;
extern uint32_t save_score;
extern uint16_t save_level;
extern uint8_t  save_hint;
extern uint8_t  save_futures[3];
extern uint8_t  save_board[81];

void
do_erase_save (void)
{
    ENABLE_RAM;
    save_has_save_state = 0u;
    DISABLE_RAM;
}

void
do_load_game (
    uint32_t * score, uint8_t futures[3], uint8_t board[81], level_t * level, bool * hint)
{
    ENABLE_RAM;
    save_has_save_state = 0;
    *score = save_score;
    *level = (level_t)save_level;
    *hint = (1 == save_hint);

    futures[0] = save_futures[0];
    futures[1] = save_futures[1];
    futures[2] = save_futures[2];

    for (uint8_t cell = 0; cell < 81; ++cell)
    {
        board[cell] = save_board[cell]; /* memcpy? */
    }

    DISABLE_RAM;
}

uint32_t
do_load_hiscore (void)
{
    ENABLE_RAM;
    uint32_t hiscore = save_hiscore;
    DISABLE_RAM;
    return hiscore;
}

void
do_save_game (uint32_t score, uint8_t futures[3], uint8_t board[81], level_t level, bool hint)
{
    ENABLE_RAM;
    save_has_save_state = 1u;
    save_score = score;
    save_level = (uint16_t)level;
    save_hint = hint ? 1u : 0u;
    
    save_futures[0] = futures[0];
    save_futures[1] = futures[1];
    save_futures[2] = futures[2];

    for (uint8_t cell = 0; cell < 81; ++cell)
    {
        save_board[cell] = board[cell];
    }

    DISABLE_RAM;
}

void
do_save_hiscore (uint32_t hiscore)
{
    ENABLE_RAM;
    save_hiscore = hiscore;
    DISABLE_RAM;
}

bool
has_saved_game (void)
{
    ENABLE_RAM;
    bool has = 1 == save_has_save_state;
    DISABLE_RAM;
    return has;
}

bool
is_saving_enabled (void)
{
    ENABLE_RAM;
    if (SAVE_MAGIC != save_magic)
    {
        save_magic = SAVE_MAGIC;
        save_hiscore = 0u;
        save_has_save_state = 0u;
        DISABLE_RAM;
        vsync();
        ENABLE_RAM;
    }
    bool enabled = SAVE_MAGIC == save_magic;
    DISABLE_RAM;
    return enabled;
}

