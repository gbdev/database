#ifndef H_SAVEDATA
#define H_SAVEDATA

#include <stdint.h>

extern uint8_t  save_magic;

extern uint32_t save_hiscore;

extern uint8_t  save_has_save_state;
extern uint32_t save_score;
extern uint16_t save_level;
extern uint8_t  save_hint;
extern uint8_t  save_futures[3];
extern uint8_t  save_board[81];

#endif
