#include <stdbool.h>
#include <stdint.h>
#include <string.h>

#include "astar.h"
#include "definitions.h"

#define EDGECOST  ((uint8_t)1)

static enum astarstatus
{
    ASTAR_NEW = 0,
    ASTAR_OPEN,
    ASTAR_CLOSED,
    ASTAR_WALL,
    ASTAR_GROUND,
    ASTAR_HIT
};

static enum neighbors
{
    NUPPER = 0,
    NNEXT,
    NLOWER,
    NPREV
};

static enum astarstatus status[81];
static uint8_t fullcost[81];
static uint8_t groundexactcost[81];
static uint8_t hitheuristiccost[81];
static uint8_t start;
static uint8_t end;

static uint8_t 
heuristiccost (uint8_t cell)
{
    int8_t x = mod_9_lut[cell];
    int8_t y = div_9_lut[cell];
    
    int8_t x2 = mod_9_lut[end];
    int8_t y2 = div_9_lut[end];
    
    int dist = myabs(x - x2) + myabs(y - y2);
    return dist;
}

static uint8_t
getneighbor (uint8_t origin, enum neighbors neighbor)
{
    switch(neighbor)
    {
        case NUPPER:
            return origin < 9 || ASTAR_WALL == status[origin - 9] ? ERRNUMBER : (uint8_t)(origin - 9);
        
        case NNEXT:
            return 8 == mod_9_lut[origin] || ASTAR_WALL == status[origin + 1] ? ERRNUMBER : (uint8_t)(origin + 1);
                
        case NLOWER:
            return origin > 71 || ASTAR_WALL == status[origin + 9] ? ERRNUMBER : (uint8_t)(origin + 9);
        
        case NPREV:
            return 0 == mod_9_lut[origin] || ASTAR_WALL == status[origin - 1] ? ERRNUMBER : (uint8_t)(origin - 1);
        
        default:
            return ERRNUMBER;
    }
}

static uint8_t
getnextcandidate (void)
{
    uint8_t candidatecost = ERRNUMBER;
    uint8_t candidate = ERRNUMBER;
    for(int i = 0; i < 81; ++i)
    {
        if(ASTAR_HIT == status[i] || ASTAR_OPEN == status[i])
        {
            if(fullcost[i] < candidatecost ||
                (fullcost[i] == candidatecost && hitheuristiccost[i] < hitheuristiccost[candidate]))
            {
                candidatecost = fullcost[i];
                candidate = i;
            }
        }
    }
    return candidate;
}

static void 
init (uint8_t startcell, uint8_t endcell, const uint8_t walls[81])
{
    memset(groundexactcost, ERRNUMBER, 81);
    memset(hitheuristiccost, ERRNUMBER, 81);
    memset(fullcost, ERRNUMBER, 81);
    for(uint8_t i = 0; i < 81; ++i)
    {
        status[i] = (0 == walls[i] ? ASTAR_NEW : ASTAR_WALL);
    }
    
    start = startcell;
    status[start] = ASTAR_GROUND;
    end = endcell;
    status[end] = ASTAR_HIT;

    groundexactcost[start] = 0;
    hitheuristiccost[start] = heuristiccost(start);
}

bool
findpath (const uint8_t walls[81], uint8_t parents[81], uint8_t startcell, uint8_t endcell)
{
    if (ERRNUMBER == startcell || ERRNUMBER == endcell)
    {
        return false;
    }
    
    init(startcell, endcell, walls);
    parents[start] = ERRNUMBER;

    uint8_t candidate = start;
    while (candidate != end)
    {
        if(ERRNUMBER == candidate)
        {
            return false;
        }
        
        status[candidate] = ASTAR_CLOSED;
        for(uint8_t i = 0; i <= NPREV; ++i)
        {
            uint8_t neighbor = getneighbor(candidate, i);
            if(ERRNUMBER == neighbor)
            {
                continue;
            }
            
            const uint8_t cost = groundexactcost[candidate] + EDGECOST;
            if(cost < groundexactcost[neighbor] && 
                (ASTAR_OPEN == status[neighbor] || ASTAR_CLOSED == status[neighbor]))
            {
                status[neighbor] = ASTAR_NEW;
            }
            if(ASTAR_NEW == status[neighbor] || ASTAR_HIT == status[neighbor])
            {
                status[neighbor] = ASTAR_OPEN;
                parents[neighbor] = candidate;
                groundexactcost[neighbor] = cost;
                hitheuristiccost[neighbor] = heuristiccost(neighbor);
                fullcost[neighbor] = groundexactcost[neighbor] + hitheuristiccost[neighbor];
            }
        }
        candidate = getnextcandidate();
    }
    return true;
}
