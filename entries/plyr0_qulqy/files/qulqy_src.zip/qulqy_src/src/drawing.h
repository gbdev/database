#ifndef H_DRAWING
#define H_DRAWING

#include <stdint.h>

#include "definitions.h"

#define SPR_OFFS_X      ((uint8_t)8)
#define SPR_OFFS_Y      ((uint8_t)16)

void animatemove(uint8_t start, const uint8_t parents[81]);
void animate_start_menu(void);
void clear_future_balls(void);
void clear_score_bar(bool hint);
void cursor_hide(void);
void cursor_show(uint8_t x, uint8_t y);
void draw_ball(uint8_t x, uint8_t y, uint8_t number);
void draw_future_balls(const uint8_t futureballs[3]);
void draw_game_board(const uint8_t game_board[81]);
void draw_mini_ball(uint8_t x, uint8_t y);
void draw_pause_menu(bool issaved, bool issaveenabled);
void draw_start_menu(bool hint, level_t level, uint32_t score);
void draw_tray (void);
void init_balls(bool is_shapes);
void init_sprites(void);
void print_letter(uint8_t x, uint8_t y, uint8_t number, uint8_t color);
void print_score(uint32_t score);
void print_text (uint8_t x, uint8_t y, const char *text, uint8_t color);
void print_text_vert(uint8_t x, uint8_t y, const char *text, uint8_t color);
void selection_move(uint8_t x, uint8_t y);
void selection_clear(void);
void selection_init(uint8_t x, uint8_t y, uint8_t color);
void show_splash(void);
void transfer_future(uint8_t cell, uint8_t future, uint8_t color);

#endif
