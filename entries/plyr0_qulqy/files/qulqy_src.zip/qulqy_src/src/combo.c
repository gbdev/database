#include <stdint.h>
#include <stdbool.h>
#include <gb/emu_debug.h>

#include "combo.h"
#include "definitions.h"

static combo_t best_horizontal_combo(const uint8_t game_board[81]);
static uint8_t best_horizontal_combo_in_row(
    const uint8_t row[9], uint8_t * column_out);

static combo_t best_vertical_combo(const uint8_t game_board[81]);
static uint8_t best_vertical_combo_in_col(
    const uint8_t game_board[81], const uint8_t col, uint8_t * row_out);

static combo_t best_diag1_combo(const uint8_t game_board[81]);
static uint8_t
best_diag1_combo_in_pos(
    const uint8_t game_board[81],
    const uint8_t secondx,
    const uint8_t secondy,
    uint8_t * col_out, 
    uint8_t * row_out);

static combo_t best_diag2_combo(const uint8_t game_board[81]);
static uint8_t
best_diag2_combo_in_pos(
    const uint8_t game_board[81],
    const uint8_t negsecondx,
    const uint8_t negsecondy,
    uint8_t * col_out, 
    uint8_t * row_out);

combo_t
best_combo (const uint8_t game_board[81])
{
    combo_t best = best_horizontal_combo(game_board);
    combo_t next = best_vertical_combo(game_board);
    best = (next.len > best.len) ? next : best;
    next = best_diag1_combo(game_board);
    best = (next.len > best.len) ? next : best;
    next = best_diag2_combo(game_board);
    best = (next.len > best.len) ? next : best;
    return best;
}

static combo_t
best_horizontal_combo (const uint8_t game_board[81])
{
    combo_t combo;
    combo.dir = COMBODIR_HORIZ;
    combo.row = 0;
    combo.col = 0;
    combo.len = 0;
    
    for (uint8_t row = 0; row < 9; ++row )
    {
        uint8_t col;
        const uint8_t len = best_horizontal_combo_in_row (&game_board[mul_9_lut[row]], &col);
        if (len > combo.len)
        {
            combo.row = row;
            combo.col = col;
            combo.len = len;
        }
    }
    return combo;
}

static uint8_t
best_horizontal_combo_in_row (const uint8_t row[9], uint8_t * column_out)
{
    uint8_t bestcombomark = 0;
    uint8_t bestcombolen = 0;
    uint8_t combomark = 0;
    uint8_t combolen = 1;
    
    for (uint8_t col = 1; col < 9; ++col)
    {
        if (0 != row[col] && row[col] == row[col - 1])
        {
            ++combolen;
        }
        else
        {
            if (combolen > bestcombolen)
            {
                bestcombolen = combolen;
                bestcombomark = combomark;
            }
            combomark = col;
            combolen = 1;
        }
    }
    
    if (combolen > bestcombolen)
    {
        *column_out = combomark;
        return combolen;
    }
    else
    {
        *column_out = bestcombomark;
        return bestcombolen;    
    }
}

static combo_t
best_vertical_combo (const uint8_t game_board[81])
{
    combo_t combo;
    combo.dir = COMBODIR_VERT;
    combo.row = 0;
    combo.col = 0;
    combo.len = 0;
    
    for (uint8_t col = 0; col < 9; ++col )
    {
        uint8_t row;
        const uint8_t len = best_vertical_combo_in_col (game_board, col, &row);
        if (len > combo.len)
        {
            combo.row = row;
            combo.col = col;
            combo.len = len;
        }
    }
    return combo;
}

static uint8_t
best_vertical_combo_in_col (const uint8_t game_board[81], const uint8_t col, uint8_t * row_out)
{
    uint8_t bestcombomark = 0;
    uint8_t bestcombolen = 0;
    uint8_t combomark = 0;
    uint8_t combolen = 1;
    
    for (uint8_t row = 1; row < 9; ++row)
    {
        if (0 != game_board[col + mul_9_lut[row]] && 
            game_board[col + mul_9_lut[row]] == game_board[col + mul_9_lut[row - 1]])
        {
            ++combolen;
        }
        else
        {
            if (combolen > bestcombolen)
            {
                bestcombolen = combolen;
                bestcombomark = combomark;
            }
            combomark = row;
            combolen = 1;
        }
    }
    
    if (combolen > bestcombolen)
    {
        *row_out = combomark;
        return combolen;
    }
    else
    {
        *row_out = bestcombomark;
        return bestcombolen;    
    }
}

/*
    diag 1
    5,6,7,8,1,0,0,0,0,
    4,5,6,7,8,1,0,0,0,
    3,4,5,6,7,8,1,0,0,
    2,3,4,5,6,7,8,1,0,
    1,2,3,4,5,6,7,8,1,
    0,1,2,3,4,5,6,7,8,
    0,0,1,2,3,4,5,6,7,
    0,0,0,1,2,3,4,5,6,
    0,0,0,0,1,2,3,4,5,
*/
static combo_t 
best_diag1_combo (const uint8_t game_board[81])
{
    static const uint8_t secondx[9] = {1, 1, 1, 1, 1, 2, 3, 4, 5};
    static const uint8_t secondy[9] = {5, 4, 3, 2, 1, 1, 1, 1, 1};
    /*                       maxlen =  5, 6, 7, 8, 9, 8, 7, 6, 5 */
    /*                       diff   = -4,-3,-2,-1, 0, 1, 2, 3, 4 */
    combo_t combo;
    combo.dir = COMBODIR_DIAG;
    combo.row = 0;
    combo.col = 0;
    combo.len = 0;
    
    for (uint8_t idx = 0; idx < 9; ++idx)
    {
        uint8_t row;
        uint8_t col;
        const uint8_t len = 
            best_diag1_combo_in_pos(game_board, secondx[idx], secondy[idx], &col, &row);
        if (len > combo.len)
        {
            combo.row = row;
            combo.col = col;
            combo.len = len;
        }
    }
    return combo;
}

static uint8_t
best_diag1_combo_in_pos (
    const uint8_t game_board[81],
    const uint8_t secondx,
    const uint8_t secondy,
    uint8_t * col_out, 
    uint8_t * row_out)
{
    uint8_t bestcombomarkx = secondx - 1;
    uint8_t bestcombomarky = secondy - 1;
    uint8_t bestcombolen = 1;
    uint8_t combomarkx = secondx - 1;
    uint8_t combomarky = secondy - 1;
    uint8_t combolen = 1;
    uint8_t maxcombo = 9 - myabs(secondx - secondy);

    for (uint8_t idx = 0; idx < maxcombo; ++idx)
    {
        const uint8_t x = secondx + idx;
        const uint8_t y = secondy + idx;
        const uint8_t curr = game_board[x + mul_9_lut[y]];
        const uint8_t prev = game_board[x - 1 + mul_9_lut[y - 1]];

        if (0 != curr && curr == prev)
        {
            ++combolen;
        }
        else
        {
            if (combolen > bestcombolen)
            {
                bestcombolen = combolen;
                bestcombomarkx = combomarkx;
                bestcombomarky = combomarky;
            }
            combomarkx = x;
            combomarky = y;
            combolen = 1;
        }
    }
    
    if (combolen > bestcombolen)
    {
        *row_out = combomarky;
        *col_out = combomarkx;
        return combolen;
    }
    else
    {
        *row_out = bestcombomarky;
        *col_out = bestcombomarkx;
        return bestcombolen;    
    }
}

/*
    diag 2
    0,0,0,0,1,2,3,4,5,
    0,0,0,1,2,3,4,5,6,
    0,0,1,2,3,4,5,6,7,
    0,1,2,3,4,5,6,7,8,
    1,2,3,4,5,6,7,8,1,
    2,3,4,5,6,7,8,1,0,
    3,4,5,6,7,8,1,0,0,
    4,5,6,7,8,1,0,0,0,
    5,6,7,8,1,0,0,0,0,
*/
static combo_t
best_diag2_combo (const uint8_t game_board[81])
{
    static const uint8_t negsecondx[9] = {3, 4, 5, 6, 7, 7, 7, 7, 7};
    static const uint8_t negsecondy[9] = {1, 1, 1, 1, 1, 2, 3, 4, 5};
    /*                          maxlen =  5, 6, 7, 8, 9, 8, 7, 6, 5 */
    /*                          diff   =  2, 3, 4, 5, 6, 5, 4, 3, 2 -> +3 */
    combo_t combo;
    combo.dir = COMBODIR_DIAG2;
    combo.row = 0;
    combo.col = 0;
    combo.len = 0;
    
    for (uint8_t idx = 0; idx < 9; ++idx)
    {
        uint8_t row;
        uint8_t col;
        const uint8_t len = 
            best_diag2_combo_in_pos(game_board, negsecondx[idx], negsecondy[idx], &col, &row);
        if (len > combo.len)
        {
            combo.row = row;
            combo.col = col;
            combo.len = len;
        }
    }
    return combo;
}

static uint8_t
best_diag2_combo_in_pos (
    const uint8_t game_board[81],
    const uint8_t negsecondx,
    const uint8_t negsecondy,
    uint8_t * col_out, 
    uint8_t * row_out)
{
    uint8_t bestcombomarkx = negsecondx + 1;
    uint8_t bestcombomarky = negsecondy - 1;
    uint8_t bestcombolen = 1;
    uint8_t combomarkx = negsecondx + 1;
    uint8_t combomarky = negsecondy - 1;
    uint8_t combolen = 1;
    
    uint8_t maxcombo = 3 + negsecondx - negsecondy;

    for (uint8_t idx = 0; idx < maxcombo - 1; ++idx)
    {
        const uint8_t x = negsecondx - idx;
        const uint8_t y = negsecondy + idx;
        const uint8_t curr = game_board[x + mul_9_lut[y]];
        const uint8_t prev = game_board[x + 1 + mul_9_lut[y - 1]];

        if (0 != curr && curr == prev)
        {
            ++combolen;
        }
        else
        {
            if (combolen > bestcombolen)
            {
                bestcombolen = combolen;
                bestcombomarkx = combomarkx;
                bestcombomarky = combomarky;
            }
            combomarkx = x;
            combomarky = y;
            combolen = 1;
        }
    }

    if (combolen > bestcombolen)
    {
        *row_out = combomarky;
        *col_out = combomarkx;
        return combolen;
    }
    else
    {
        *row_out = bestcombomarky;
        *col_out = bestcombomarkx;
        return bestcombolen;    
    }
}
