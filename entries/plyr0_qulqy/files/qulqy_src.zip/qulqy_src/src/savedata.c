#include <stdint.h>
#include <stdbool.h>

uint8_t  save_magic;

uint32_t save_hiscore;

uint8_t  save_has_save_state;
uint16_t save_level;
uint8_t  save_hint;
uint32_t save_score;
uint8_t  save_futures[3];
uint8_t  save_board[81];
