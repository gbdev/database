#gbcompo25 participant

* https://plyr0.itch.io/qulqy
* https://codeberg.org/plyr0/qulqy
* https://github.com/plyr0/qulqy

Game Boy Color demake/remake of Janusz Lewandowski's 1995 game "Kulki" for Windows 3.1.

Connect five or more balls in the row, horizontally, vertically  or diagonally.
Select a ball, then an empty space, to move that ball.

* Game starts with five radom balls.
* If the move did not removed any balls, three new random balls will be added to the board.
* If the move did removed some balls, the score is increased. No new balls are added.
* Game ends if there are no more possible moves.

Score
| Level | Colors | Score per ball |
|-------|--------|----------------|
| Easy  |   5    |       1        |
| Sane  |   7    |       2        |
| Hard  |   8    |       3        |

If the hint is enabled, there is a 30% penalty to the score.

Controls
| Game Boy | binjgb www emu | menu     | pause   | game             |
|----------|----------------|----------|---------|------------------|
|  A       |    x           | level    | save    | select/move ball |
|  B       |    z           | hint     | quit    |                  |
| START    |  enter         | new game | unpause | pause            |
| DPAD     |  arrows        |          |         |                  |

Made with GBDK-2020, VSCode and Aseprite.

https://plyr0.codeberg.page/
