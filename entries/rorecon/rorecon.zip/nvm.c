#include <gb.h>

UBYTE nvm_status;
UBYTE nvm_drive_mode;
UBYTE nvm_motor_sel[2];
UBYTE nvm_motor_dir[2];
UBYTE nvm_motor_pwr;
UBYTE nvm_task_num;

/* EOF */
