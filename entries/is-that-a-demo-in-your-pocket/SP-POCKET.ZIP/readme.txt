
    Is That a Demo in Your Pocket?

    Release Note:
    
     This demo is intended to be run on either
     the original "DMG" Game Boy, the Pocket
     or the Super Game Boy. This time it should
     be fully compatible with CGB/AGB as well,
     so feel free to take your pick. On AGB it
     looks and sounds pretty horrible though.

     This demo relies on real hardware to run,
     sound and display correctly but if you
     haven't got the means to run the demo from
     a cartridge... I strongly recommend using
     the BGB emulator (http://bgb.bircd.org)

     There we go,
     Snorpung.