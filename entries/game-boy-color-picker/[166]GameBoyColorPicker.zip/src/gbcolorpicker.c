#include <gb/gb.h>
#include <gb/cgb.h>
#include <stdint.h>
#include <stdbool.h>
#include <gbdk/console.h>
#include <stdio.h>

#define PALETTE_TEXT_NORMAL 0U
#define PALETTE_TEXT_HIGHLIGHT 7U
#define PALETTE_COLOR_1 1U
#define PALETTE_COLOR_2 2U
#define PALETTE_COLOR_3 3U
#define PALETTE_COLOR_4 4U

typedef uint8_t uint5_t;
#define UINT5_MIN (0x00)
#define UINT5_MAX (0x1f)

void wait(uint8_t frames) {
    for (frames; frames != 0; --frames)
        wait_vbl_done();
}

char get_hex_digit(const uint8_t nibble)
{
    if (nibble < 10) {
        return (nibble + '0');
    } else {
        return (nibble + 'a' - 10);
    }
}

// Globals are faster than function arguments, especially when they rarely differ
static bool highlight = false;

void show_hex_byte_xy(const uint8_t x, const uint8_t y, const uint8_t byte) {
    static uint8_t palette;
    static uint8_t tile;

    // Print the digits
    gotoxy(x, y);
    setchar(get_hex_digit((byte >> 4) & 0x0f));
    gotoxy(x+1, y);
    setchar(get_hex_digit(byte & 0x0f));

    // Handle potential selected
    if (highlight) {
        highlight = false;
        palette = PALETTE_TEXT_HIGHLIGHT;
        tile = 0x67;
    } else {
        palette = PALETTE_TEXT_NORMAL;
        tile = 0x66;
    }

    // The font goes to the very top of the tile, so add a one px line across the top.
    set_tile_xy(x, y-1, tile);
    set_tile_xy(x+1, y-1, tile);

    // Set the palette for the digits.
    VBK_REG = 1;
    set_tile_xy(x, y, palette);
    set_tile_xy(x+1, y, palette);
    VBK_REG = 0;
}

// Print the passed in color formatted as a CGB 15 bit color
inline void print_raw(const uint8_t x, const uint8_t y, const palette_color_t raw)
{
    show_hex_byte_xy(x, y, (raw >> 8) & 0xff);
    show_hex_byte_xy(x+2, y, raw & 0xff);
}

// Print the passed in color formatted as an HTML color code
inline void print_html(const uint8_t x, const uint8_t y, const uint8_t *p)
{
    show_hex_byte_xy(x+0, y, (p[0] << 3) | (p[0] >> 2));
    show_hex_byte_xy(x+2, y, (p[1] << 3) | (p[1] >> 2));
    show_hex_byte_xy(x+4, y, (p[2] << 3) | (p[2] >> 2));
}

// Print the build date
void print_date()
{
    gotoxy(5,16);
    puts("2022-05-15");
}

void main()
{
    static const uint8_t const toptile[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0xff};
    static const uint8_t const toptile_invert[] = {0,0,0,0,0,0,0,0,0,0,0,0,0,0,0xff,0xff};

    static const uint8_t const loc_x[] = {1, 11, 1, 11};
    static const uint8_t const loc_y[] = {1, 1, 16, 16};
    static const uint8_t const raw_loc_x[] = {3, 13, 3, 13};
    static const uint8_t const raw_loc_y[] = {5, 5, 12, 12};
    static const uint8_t const html_loc_x[] = {2, 12, 2, 12};
    static const uint8_t const html_loc_y[] = {3, 3, 14, 14};

    static const palette_color_t const text_normal_colors[4] = {RGB_WHITE, RGB_LIGHTGRAY, RGB_DARKGRAY, RGB_BLACK};
    static const palette_color_t const text_invert_colors[4] = {RGB_BLACK, RGB_DARKGRAY, RGB_LIGHTGRAY, RGB_WHITE};

    static palette_color_t raw_colors[4] = {RGB_WHITE, RGB_WHITE, RGB_WHITE, RGB_BLACK};

    // Set default colors
    static uint5_t colors[][] = {
        {UINT5_MAX, UINT5_MAX, UINT5_MAX}, // white
        {UINT5_MAX, UINT5_MIN, UINT5_MIN}, // red
        {UINT5_MIN, UINT5_MAX, UINT5_MIN}, // green
        {UINT5_MIN, UINT5_MIN, UINT5_MAX}  // blue
    };

    static uint8_t selected_color, selected_component;
    static uint8_t new_buttons, old_buttons;
    static uint8_t i, j;

    // Load a couple tiles so the top of numbers do not touch the colors
    set_bkg_data(0x66, 1, toptile);
    set_bkg_data(0x67, 1, toptile_invert);

    // Turn everything on. Sprites are not used.
    SHOW_BKG;
    DISPLAY_ON;

    // Only supports GBC/GBA
    if (!DEVICE_SUPPORTS_COLOR) {
        puts("\n\n  GB Color Picker\n  requires GameBoy\n  Color or Advance.\n  Sorry!");
        print_date();
        return;
    }

    // Initialize the color palettes for text
    set_bkg_palette(PALETTE_TEXT_NORMAL, 1, text_normal_colors);
    set_bkg_palette(PALETTE_TEXT_HIGHLIGHT, 1, text_invert_colors);

    // The four color palettes are mostly setup by the color picker its self, but they need black for text highlight
    for (i = PALETTE_COLOR_1; i <= PALETTE_COLOR_4; i++) {
        set_bkg_palette_entry(i, 3, RGB_BLACK);
    }

    // Display title and usage
    puts("\n\n  GB Color Picker\n  ---------------\n\n\n Use left/right to\n choose a component\n and up/down to\n change it.\n\n\n Press any button\n to continue.");
    print_date();
    do {
      wait(1);
    } while (joypad() == 0);
    wait(12);

    // clear screen
    cls();

    // Initialize background attributes. Each quadrant of the screen gets a different palette.
    VBK_REG = 1;
    fill_rect( 0, 0, 10, 9, PALETTE_COLOR_1);
    fill_rect(10, 0, 10, 9, PALETTE_COLOR_2);
    fill_rect( 0, 9, 10, 9, PALETTE_COLOR_3);
    fill_rect(10, 9, 10, 9, PALETTE_COLOR_4);
    VBK_REG = 0;

    // Main loop
    while(true) {
        // For each of the four colors...
        for (i = 0; i < 4; i++) {
            // Calculate the GBC 15 bit blue-green-red ordered color
            raw_colors[i] = RGB(colors[i][0], colors[i][1], colors[i][2]);

            // Set the newly calculated color into the first entry of a palette. Each selected color gets its own palette.
            set_bkg_palette_entry(PALETTE_COLOR_1 + i, 0, raw_colors[i]);

            // Display the hex value of the newly calculated color
            print_raw(raw_loc_x[i], raw_loc_y[i], raw_colors[i]);

            // Display it formatted as a 24 bit red-green-blue ordered hex value, like the commonly used HTML color codes
            print_html(html_loc_x[i], html_loc_y[i], colors[i]);

            // Display it as three separate 5 bit hex formatted components
            for (j = 0; j < 3; j++) {
                if ((i == selected_color) && (j == selected_component)) {
                    // If it is the selected component, give it a special palette
                    highlight = true;
                }
                show_hex_byte_xy(loc_x[i] + 3 * j, loc_y[i], colors[i][j]);
            }
        }

        // A repeat delay
        wait(1);

        // Add an initial delay before repeat when a button is newly pressed so you can make precise changes
        if (old_buttons != new_buttons) {
            old_buttons = new_buttons;
            for (i = 20; i != 0; --i) {
                if (joypad()) {
                    wait(1);
                } else {
                    old_buttons = 0;
                    break;
                }
            }
        }

        do {
            wait(1);
            new_buttons = joypad();
            new_buttons &= J_LEFT | J_RIGHT | J_UP | J_DOWN; // Only D-pad is used
        } while (!(new_buttons || old_buttons));

        // D-pad is pressed. Update.
        switch (new_buttons) {
            case J_LEFT:
            // De-select the current component
            show_hex_byte_xy(loc_x[selected_color] + 3 * selected_component, loc_y[selected_color], colors[selected_color][selected_component]);

            // Cycle to select the previous color component or color
            if (selected_component > 0) {
                selected_component -= 1;
            } else {
                selected_component = 2;
                if (selected_color > 0) {
                    selected_color -= 1;
                } else {
                    selected_color = 3;
                }
            }

            // Highlight the new component
            highlight = true;
            show_hex_byte_xy(loc_x[selected_color] + 3 * selected_component, loc_y[selected_color], colors[selected_color][selected_component]);

            // A slightly longer delay for switching components than changing a component
            wait(1);
            break;

            case J_RIGHT:
            // De-select the current component
            show_hex_byte_xy(loc_x[selected_color] + 3 * selected_component, loc_y[selected_color], colors[selected_color][selected_component]);

            // Cycle to select the previous color component or color
            if (selected_component < 2) {
                selected_component += 1;
            } else {
                selected_component = 0;
                if (selected_color < 3) {
                    selected_color += 1;
                } else {
                    selected_color = 0;
                }
            }

            // Highlight the new component
            highlight = true;
            show_hex_byte_xy(loc_x[selected_color] + 3 * selected_component, loc_y[selected_color], colors[selected_color][selected_component]);

            // A slightly longer delay for switching components than changing a component
            wait(1);
            break;

            case J_UP:
            // Increment the currently selected component if not already maxed
            if (colors[selected_color][selected_component] < UINT5_MAX) {
                colors[selected_color][selected_component] += 1;
            }
            break;

            case J_DOWN:
            // Decrement the currently selected component if not already zero
            if (colors[selected_color][selected_component] > UINT5_MIN) {
                colors[selected_color][selected_component] -= 1;
            }
            break;
        }
    }
}
