Game Boy Color Picker

Colors on the Game Boy Color (GBC) and Game Boy Advance are very different from typical monitors, and even from each other. It can take a surprising amount of time just to find colors that look good when run on original hardware (and in emulators like BGB). There are PC tools to help approximate what colors will look like under various conditions--which help greatly--but they are no substitute for seeing your choices as they will really look.

Game Boy Color Picker is a simple program (more of a utility than a game) that runs anywhere Game Boy Color games can run, including on the Game Boy Advance and emulators. It allows you to choose four colors at a time from the GBC's selection of 32,768. As you change the colors you can see them in GBC 15 bit format, ready to use in your Game Boy project, and also in HTML color code format, ready to use in any graphics editor.

Source code is included. It is written in C and compiles with GBDK because I wanted to try GBDK, and optimized assembly was not necessary for performance.

Potential Future Features:

* Dithering so you can see how colors mix.

* Simple SRAM support, but I do not expect most people to be swapping a cartridge between Game Boys very often.

* Super Game Boy support. It is an interesting problem, but I am not sure if anyone would use it. A better option would be to write something similar natively for Super Nintendo.

-xenophile 2022-05-14
