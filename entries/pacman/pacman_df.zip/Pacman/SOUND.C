//////////////////////////////////////////////////////////////////////////////
// SOUND.C                                                                  //
//////////////////////////////////////////////////////////////////////////////
#include <gb.h>
#include "sound.h"
#include "rumble.h"

//////////////////////////////////////////////////////////////////////////////
// InitSound                                                                //
//////////////////////////////////////////////////////////////////////////////
void InitSound()
{
	*(UBYTE*)0xFF26 = 1<<7; // all sound on
	*(UBYTE*)0xFF26 = 1<<7 | 1 | 2 | 4 | 8; // sounds 1-4 on
	*(UBYTE*)0xFF25 = 0xFF; // ouput all sounds
	*(UBYTE*)0xFF24 = 7<<4 | 7; // volume for SO1 & SO2
}

//////////////////////////////////////////////////////////////////////////////
// SndWon                                                                   //
//////////////////////////////////////////////////////////////////////////////
void SndWon()
{
	int n;
	*(UBYTE*)0xFF10 = 4<<4 | 1<<3 | 7; // sweep: time(0-7), inc/dec(0-1), shift(0-7)
	*(UBYTE*)0xFF11 = 2<<6 | 63; // wave pattern duty(0-3), sound length(0-63)
	*(UBYTE*)0xFF12 = 15<<4 | 0<<3 | 7; // envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
	for (n=0; n<20; n++)
	{
    	*(UBYTE*)0xFF13 = 2000 & 0xFF; // frequency
    	*(UBYTE*)0xFF14 = 128 | 2000>>8; // initial flag / frequency
    	delay(100);
  	}
}

//////////////////////////////////////////////////////////////////////////////
// SndStep                                                                  //
//////////////////////////////////////////////////////////////////////////////
void SndStep()
{
	*(UBYTE*)0xFF16 = 0<<6 | 63; // wave pattern duty / sound length
  	*(UBYTE*)0xFF17 = 15<<4 | 0<<3 | 1; // volume / envelope
  	*(UBYTE*)0xFF18 = 0 & 0xFF; // frequency
  	*(UBYTE*)0xFF19 = 128 | 0/256; // initial flag / frequency
}

//////////////////////////////////////////////////////////////////////////////
// SndMoveStone                                                             //
//////////////////////////////////////////////////////////////////////////////
void SndMoveStone()
{
	Rumble(2);
  	*(UBYTE*)0xFF10 = 4<<4 | 0<<3 | 1; // sweep: time(0-7), inc/dec(0-1), shift(0-7)
  	*(UBYTE*)0xFF11 = 0<<6 | 63; // wave pattern duty(0-3), sound length(0-63)
  	*(UBYTE*)0xFF12 = 15<<4 | 0<<3 | 2; // envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  	*(UBYTE*)0xFF13 = 256 & 0xFF; // frequency
  	*(UBYTE*)0xFF14 = 128 | 256>>8; // initial flag / frequency
}

//////////////////////////////////////////////////////////////////////////////
// SndDiamond                                                               //
//////////////////////////////////////////////////////////////////////////////
void SndDiamond()
{
  	*(UBYTE*)0xFF10 = 0<<4 | 0<<3 | 0; // sweep: time(0-7), inc/dec(0-1), shift(0-7)
  	*(UBYTE*)0xFF11 = 2<<6 | 63; // wave pattern duty(0-3), sound length(0-63)
  	*(UBYTE*)0xFF12 = 15<<4 | 0<<3 | 2; // envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  	*(UBYTE*)0xFF13 = 2000 & 0xFF; // frequency
  	*(UBYTE*)0xFF14 = 128 | 2000>>8; // initial flag / frequency
}

//////////////////////////////////////////////////////////////////////////////
// SndExplosion                                                             //
//////////////////////////////////////////////////////////////////////////////
void SndExplosion()
{
	Rumble(5);
  	*(UBYTE*)0xFF20 =  63; // length(0-63)
  	*(UBYTE*)0xFF21 = 15<<4 | 0<<3 | 7; // envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  	*(UBYTE*)0xFF22 = 4<<4 | 0<<3 | 5; // polynomial frequency(0-13), counter step(0-1:15/7), divide ratio(0-7)
  	*(UBYTE*)0xFF23 = 1<<7 | 0<<6; // initial(0-1), consecutive(0-1)
}

//////////////////////////////////////////////////////////////////////////////
// SndFallBrick                                                             //
//////////////////////////////////////////////////////////////////////////////
void SndFallBrick()
{
	Rumble(2);
  	*(UBYTE*)0xFF20 =  63; // length(0-63)
  	*(UBYTE*)0xFF21 =  15<<4 | 0<<3 | 1; // envelope: initial volume(0-15), down/up(0-1), number of sweeps(0-7)
  	*(UBYTE*)0xFF22 =  2<<4 | 0<<3 | 7; // polynomial frequency(0-13), counter step(0-1:15/7), divide ratio(0-7)
  	*(UBYTE*)0xFF23 =  1<<7 | 0<<6; // initial(0-1), consecutive(0-1)
}
