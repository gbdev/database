Hello!! Thank you for downloading my game =)

Run!! is a gameboy game so you'll need an emulator in order to run it.
You'll find Visual Boy Advance in the folder, just open it, got to Files->Open and select Run!!.gb. 
(or you can just drag and drop Run!!.gb on VisualBoyAdvance.exe)

QWERTY:
	A button = Z
	B Button = X

	Start Button = ENTER


AZERTY:
	A button = W
	B Button = X

	Start Button = ENTER

Enjoy !!

PS: My personal best is 32 =p