#include <gb.h>

struct BGM_type {
 int on;
 UBYTE index;
 int delay;
 int delayidx;
};

struct BGM_type BGM;

// global
int speedy = 0;
UWORD frequencies[] = {
  44, 156, 262, 363, 457, 547, 631, 710, 786, 854, 923, 986,
  1046, 1102, 1155, 1205, 1253, 1297, 1339, 1379, 1417, 1452, 1486, 1517,
  1546, 1575, 1602, 1627, 1650, 1673, 1694, 1714, 1732, 1750, 1767, 1783,
  1798, 1812, 1825, 1837, 1849, 1860, 1871, 1881, 1890, 1899, 1907, 1915,
  1923, 1930, 1936, 1943, 1949, 1954, 1959, 1964, 1969, 1974, 1978, 1982,
  1985, 1988, 1992, 1995, 1998, 2001, 2004, 2006, 2009, 2011, 2013, 2015
};

UBYTE music1[] = {
40,38,36,31,31,31,31,31, 38,36,35,31,31,31,31,31,
36,35,33,28,28,28,28,28, 35,33,31,28,28,28,28,28,   
29,29,29,29,29,31,33,31, 31,31,36,36,35,35,36,36,
40,40,40,38,38,38,38,38, 36,36,36,38,38,38,38,38,

40,38,36,31,31,31,31,31, 38,36,35,31,31,31,31,31, 
36,35,33,28,28,28,28,28, 35,33,31,28,28,28,28,28,   
29,29,29,29,29,31,33,31, 31,31,36,36,35,35,36,36,
40,40,40,38,38,38,38,38, 36,36,36,35,35,35,35,35,

36,36,36,36,36,35,33,31, 31,31,31,31,31,31,31,31,
33,33,33,33,33,31,29,28, 28,28,28,28,28,28,28,28,
29,29,29,29,29,31,33,31, 31,31,36,36,35,35,36,36,
40,40,40,38,38,38,38,38, 36,36,36,38,38,38,38,38

};

UBYTE music1len = 192; // num_element

//-----
void play_BGM();
void BGM_stop();
void BGM_reset();
void BGM_on();
void BGM_off();

//-----
//void BGM_init()
//{
//  *(UBYTE*)0xFF26 = 0x80;  // all sound on
//  *(UBYTE*)0xFF25 = 0xFF;                   // ouput all sounds
//  *(UBYTE*)0xFF24 = 0xFF;               // volume for SO1 & SO2
//
//  disable_interrupts();
//  add_TIM(play_BGM);
//  enable_interrupts();
//  TMA_REG = 0x00U; //???
//  TAC_REG = 0x04U; //???
//  set_interrupts(TIM_IFLAG | VBL_IFLAG);
//  BGM_off();
//}

void play_BGM() {
 if (BGM.on) {
   // sound B
   *(UBYTE*)0xFF16 = 0xc0;
   *(UBYTE*)0xFF17 = 0x72;
   *(UBYTE*)0xFF18 = frequencies[music1[BGM.index]] & 0xFF; // frequency
   *(UBYTE*)0xFF19 = 128 | frequencies[music1[BGM.index]]>>8; // initial flag / frequency

   BGM.delay = ((BGM.delay + 1) % 10);
   if (BGM.delay == 0) {
     BGM.index++;
     if (BGM.index >= music1len) BGM.index = 0;
   }
 }
}

void BGM_reset() {
 BGM.index = 0;
 BGM.delay = 0;
}

void BGM_on() {
 BGM.on = 1;
 BGM.index = 0;
 BGM.delay = 0;
}

void BGM_off() {
 BGM.on = 0;
 BGM.index = 0;
 BGM.delay = 0;
} 

void BGM_stop() {
 *(UBYTE*)0xFF12 = 0<<4 | 1<<3 | 0;
}
