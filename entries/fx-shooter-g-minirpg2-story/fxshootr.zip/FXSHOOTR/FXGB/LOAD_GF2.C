// this is MBC 4

// load and copy to VRAM
// BG - stage 3, stage 4
// map - stage 3, stage 4
// cmap - stage 3, stage 4
// sprite - stage 3, stage 4
// palette  - stage 3, stage 4

#include <gb.h>

#include "globalx.h"

#include "tiles/t_stage3.h"
#include "tiles/t_stage3.c"
#include "tiles/c_stage3.h"
#include "tiles/c_stage3.c"
#include "tiles/c_stage4.h"
#include "tiles/c_stage4.c"
#include "tiles/m_stage3.h"
#include "tiles/m_stage3.c"
#include "tiles/m_stage4.h"
#include "tiles/m_stage4.c"
#include "tiles/s_stage3.h"
#include "tiles/s_stage3.c"

// I am new to extern stuff, but it seems to work fine.
extern UWORD black_pal[32]; // access array from main module. it works!!

UWORD stage3_bkg_pal[] = {
  t_stage3_labelCGBPal0c0, t_stage3_labelCGBPal0c1, t_stage3_labelCGBPal0c2, t_stage3_labelCGBPal0c3,
  t_stage3_labelCGBPal1c0, t_stage3_labelCGBPal1c1, t_stage3_labelCGBPal1c2, t_stage3_labelCGBPal1c3,
  t_stage3_labelCGBPal2c0, t_stage3_labelCGBPal2c1, t_stage3_labelCGBPal2c2, t_stage3_labelCGBPal2c3,
  t_stage3_labelCGBPal3c0, t_stage3_labelCGBPal3c1, t_stage3_labelCGBPal3c2, t_stage3_labelCGBPal3c3,
  t_stage3_labelCGBPal4c0, t_stage3_labelCGBPal4c1, t_stage3_labelCGBPal4c2, t_stage3_labelCGBPal4c3,
  t_stage3_labelCGBPal5c0, t_stage3_labelCGBPal5c1, t_stage3_labelCGBPal5c2, t_stage3_labelCGBPal5c3,
  t_stage3_labelCGBPal6c0, t_stage3_labelCGBPal6c1, t_stage3_labelCGBPal6c2, t_stage3_labelCGBPal6c3,
  t_stage3_labelCGBPal7c0, t_stage3_labelCGBPal7c1, t_stage3_labelCGBPal7c2, t_stage3_labelCGBPal7c3
};

UWORD stage3_spr_pal[] = {
  s_stage3_labelCGBPal0c0, s_stage3_labelCGBPal0c1, s_stage3_labelCGBPal0c2, s_stage3_labelCGBPal0c3,
  s_stage3_labelCGBPal1c0, s_stage3_labelCGBPal1c1, s_stage3_labelCGBPal1c2, s_stage3_labelCGBPal1c3,
  s_stage3_labelCGBPal2c0, s_stage3_labelCGBPal2c1, s_stage3_labelCGBPal2c2, s_stage3_labelCGBPal2c3,
  s_stage3_labelCGBPal3c0, s_stage3_labelCGBPal3c1, s_stage3_labelCGBPal3c2,  s_stage3_labelCGBPal3c3,
  s_stage3_labelCGBPal4c0, s_stage3_labelCGBPal4c1, s_stage3_labelCGBPal4c2, s_stage3_labelCGBPal4c3,
  s_stage3_labelCGBPal5c0, s_stage3_labelCGBPal5c1, s_stage3_labelCGBPal5c2, s_stage3_labelCGBPal5c3,
  s_stage3_labelCGBPal6c0, s_stage3_labelCGBPal6c1, s_stage3_labelCGBPal6c2, s_stage3_labelCGBPal6c3,
  s_stage3_labelCGBPal7c0, s_stage3_labelCGBPal7c1, s_stage3_labelCGBPal7c2, s_stage3_labelCGBPal7c3
};


void M4_load_gfx3() {
  
  game.bosstimer = 64;
  game.bosstimerdelay = 0;
  game.boss = 0;
  
  black_out_all();
  set_bkg_data(0, 128, t_stage3_label);
  VBK_REG = 1; // color map
  set_bkg_tiles(0, 0, 32, 18, c_stage3_label);
  VBK_REG = 0; // map
  set_bkg_tiles(0, 0, 32, 18, m_stage3_label);
  set_sprite_data(0, 255, s_stage3_label); //
  SHOW_WIN; 

  set_bkg_palette( 0, 1, &stage3_bkg_pal[0] );
  set_bkg_palette( 1, 1, &stage3_bkg_pal[4] );
  set_bkg_palette( 2, 1, &stage3_bkg_pal[8] );
  set_bkg_palette( 3, 1, &stage3_bkg_pal[12] );
  set_bkg_palette( 4, 1, &stage3_bkg_pal[16] );
  set_bkg_palette( 5, 1, &stage3_bkg_pal[20] );
  set_bkg_palette( 6, 1, &stage3_bkg_pal[24] );
  set_bkg_palette( 7, 1, &stage3_bkg_pal[28] );
 
  set_sprite_palette( 0, 1, &stage3_spr_pal[0] );
  set_sprite_palette( 1, 1, &stage3_spr_pal[4] );
  set_sprite_palette( 2, 1, &stage3_spr_pal[8] );
  set_sprite_palette( 3, 1, &stage3_spr_pal[12] );
  set_sprite_palette( 4, 1, &stage3_spr_pal[16] );
  set_sprite_palette( 5, 1, &stage3_spr_pal[20] );
  set_sprite_palette( 6, 1, &stage3_spr_pal[24] );
  set_sprite_palette( 7, 1, &stage3_spr_pal[28] );
}

void M4_load_gfx4() {
  
  game.bosstimer = 64;
  game.bosstimerdelay = 0;
  game.boss = 0;
  
  black_out_all();
  set_bkg_data(0, 128, t_stage3_label);
  VBK_REG = 1; // color map
  set_bkg_tiles(0, 0, 32, 18, c_stage4_label);
  VBK_REG = 0; // map
  set_bkg_tiles(0, 0, 32, 18, m_stage4_label);
  set_sprite_data(0, 255, s_stage3_label); // 
  SHOW_WIN;

  set_bkg_palette( 0, 1, &stage3_bkg_pal[0] );
  set_bkg_palette( 1, 1, &stage3_bkg_pal[4] );
  set_bkg_palette( 2, 1, &stage3_bkg_pal[8] );
  set_bkg_palette( 3, 1, &stage3_bkg_pal[12] );
  set_bkg_palette( 4, 1, &stage3_bkg_pal[16] );
  set_bkg_palette( 5, 1, &stage3_bkg_pal[20] );
  set_bkg_palette( 6, 1, &stage3_bkg_pal[24] );
  set_bkg_palette( 7, 1, &stage3_bkg_pal[28] );
 
  set_sprite_palette( 0, 1, &stage3_spr_pal[0] );
  set_sprite_palette( 1, 1, &stage3_spr_pal[4] );
  set_sprite_palette( 2, 1, &stage3_spr_pal[8] );
  set_sprite_palette( 3, 1, &stage3_spr_pal[12] );
  set_sprite_palette( 4, 1, &stage3_spr_pal[16] );
  set_sprite_palette( 5, 1, &stage3_spr_pal[20] );
  set_sprite_palette( 6, 1, &stage3_spr_pal[24] );
  set_sprite_palette( 7, 1, &stage3_spr_pal[28] );  
}
