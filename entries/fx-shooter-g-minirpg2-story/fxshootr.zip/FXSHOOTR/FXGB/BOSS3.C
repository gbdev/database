// MBC 8

#include <gb.h>
#include <rand.h>
#include "costable.c"
#include"globalx.h"

int kitewavey[] = {0,0,1,1,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,6,6,6,6,6,5,5,5,5,4,4,4,4,3,3,3,3,2,2,1,1,0,0,0};

void M8_put_boss3(long int x, long int y, int ptn) {
switch(ptn) {
 case(0):
  set_sprite_prop(20+4, (S_PALETTE) | 6); set_sprite_prop(21+4, (S_PALETTE) | 3); 
  set_sprite_prop(22+4, (S_PALETTE) | 6); set_sprite_prop(23+4, (S_PALETTE) | 6);
  set_sprite_prop(24+4, (S_PALETTE) | 6); set_sprite_prop(25+4, (S_PALETTE) | 5); 
  set_sprite_prop(26+4, (S_PALETTE) | 5); set_sprite_prop(27+4, (S_PALETTE) | 6);
  set_sprite_prop(28+4, (S_PALETTE) | 6); set_sprite_prop(29+4, (S_PALETTE) | 5); 
  set_sprite_prop(30+4, (S_PALETTE) | 3); set_sprite_prop(31+4, (S_PALETTE) | 3);
  set_sprite_prop(32+4, (S_PALETTE) | 6); set_sprite_prop(33+4, (S_PALETTE) | 6); 
  set_sprite_prop(34+4, (S_PALETTE) | 6); set_sprite_prop(35+4, (S_PALETTE) | 6); 

  set_sprite_tile(20+4, 103); set_sprite_tile(21+4, 104); 
  set_sprite_tile(22+4, 105); set_sprite_tile(23+4, 106); 
  set_sprite_tile(24+4, 107); set_sprite_tile(25+4, 108); 
  set_sprite_tile(26+4, 109); set_sprite_tile(27+4, 110); 
  set_sprite_tile(28+4, 111); set_sprite_tile(29+4, 112); 
  set_sprite_tile(30+4, 113); set_sprite_tile(31+4, 114); 
  set_sprite_tile(32+4, 115); set_sprite_tile(33+4, 116); 
  set_sprite_tile(34+4, 117); set_sprite_tile(35+4, 118); 
 
  move_sprite(20+4, x +    8, y + 16); move_sprite(21+4, x + 16, y + 16);
  move_sprite(22+4, x + 24-2, y + 16); move_sprite(23+4, x + 32-6, y + 16);
  move_sprite(24+4, x +    8, y + 24); move_sprite(25+4, x + 16, y + 24);
  move_sprite(26+4, x + 24-2, y + 24); move_sprite(27+4, x + 32-6, y + 24);
  move_sprite(28+4, x +    8, y + 32); move_sprite(29+4, x + 16, y + 32);
  move_sprite(30+4, x + 24-1, y + 32); move_sprite(31+4, x + 32-6, y + 32);
  move_sprite(32+4, x +    8, y + 40); move_sprite(33+4, x + 16, y + 40-1);
  move_sprite(34+4, x + 24-1, y + 40-1); move_sprite(35+4, x + 32-6, y + 40);
  break;

 case(1):
  set_sprite_prop(20+4, (S_PALETTE) | 6); set_sprite_prop(21+4, (S_PALETTE) | 3);   set_sprite_prop(22+4, (S_PALETTE) | 6); set_sprite_prop(23+4, (S_PALETTE) | 6);
  set_sprite_prop(24+4, (S_PALETTE) | 3); set_sprite_prop(25+4, (S_PALETTE) | 5);   set_sprite_prop(26+4, (S_PALETTE) | 5); set_sprite_prop(27+4, (S_PALETTE) | 3);
  set_sprite_prop(28+4, (S_PALETTE) | 6); set_sprite_prop(29+4, (S_PALETTE) | 6);   set_sprite_prop(30+4, (S_PALETTE) | 6); set_sprite_prop(31+4, (S_PALETTE) | 3);
  set_sprite_prop(32+4, (S_PALETTE) | 6); set_sprite_prop(33+4, (S_PALETTE) | 6);   set_sprite_prop(34+4, (S_PALETTE) | 6); set_sprite_prop(35+4, (S_PALETTE) | 6); 

  set_sprite_tile(20+4, 103);   set_sprite_tile(21+4, 104);   set_sprite_tile(22+4, 105);   set_sprite_tile(23+4, 106); 
  set_sprite_tile(24+4, 119);   set_sprite_tile(25+4, 120);   set_sprite_tile(26+4, 121);   set_sprite_tile(27+4, 122); 
  set_sprite_tile(28+4, 123);   set_sprite_tile(29+4, 124);   set_sprite_tile(30+4, 125);   set_sprite_tile(31+4, 126); 
  set_sprite_tile(32+4, 115);   set_sprite_tile(33+4, 127);   set_sprite_tile(34+4, 128);   set_sprite_tile(35+4, 118); 
 
  move_sprite(20+4, x +  8, y + 16); move_sprite(21+4, x + 16, y + 16);
  move_sprite(22+4, x + 24-2, y + 16); move_sprite(23+4, x + 32-6, y + 16);
  move_sprite(24+4, x +  8, y + 24); move_sprite(25+4, x + 16, y + 24);
  move_sprite(26+4, x + 24-2, y + 24); move_sprite(27+4, x + 32-6, y + 24);
  move_sprite(28+4, x +  8, y + 32); move_sprite(29+4, x + 16, y + 32);
  move_sprite(30+4, x + 24-1, y + 32); move_sprite(31+4, x + 32-6, y + 32);
  move_sprite(32+4, x +  8, y + 40); move_sprite(33+4, x + 16, y + 40);
  move_sprite(34+4, x + 24-1, y + 40); move_sprite(35+4, x + 32-6, y + 40);
  break;
  
 case(2):
  set_sprite_prop(20+4, (S_PALETTE) | 6); set_sprite_prop(21+4, (S_PALETTE) | 3);   set_sprite_prop(22+4, (S_PALETTE) | 3); set_sprite_prop(23+4, (S_PALETTE) | 6);
  set_sprite_prop(24+4, (S_PALETTE) | 6); set_sprite_prop(25+4, (S_PALETTE) | 3);   set_sprite_prop(26+4, (S_PALETTE) | 3); set_sprite_prop(27+4, (S_PALETTE) | 6);
  set_sprite_prop(28+4, (S_PALETTE) | 6); set_sprite_prop(29+4, (S_PALETTE) | 3);   set_sprite_prop(30+4, (S_PALETTE) | 3); set_sprite_prop(31+4, (S_PALETTE) | 6);
  set_sprite_prop(32+4, (S_PALETTE) | 6); set_sprite_prop(33+4, (S_PALETTE) | 3);   set_sprite_prop(34+4, (S_PALETTE) | 3); set_sprite_prop(35+4, (S_PALETTE) | 6); 

  set_sprite_tile(20+4, 129);   
  set_sprite_tile(21+4, 130); 
  set_sprite_tile(22+4, 131); 
  set_sprite_tile(23+4, 132); 
  set_sprite_tile(24+4, 133);   
  set_sprite_tile(25+4, 134); 
  set_sprite_tile(26+4, 135); 
  set_sprite_tile(27+4, 136); 
  set_sprite_tile(28+4, 137);   
  set_sprite_tile(29+4, 138);   
  set_sprite_tile(30+4, 139);   
  set_sprite_tile(31+4, 140); 
  set_sprite_tile(32+4, 141); 
  set_sprite_tile(33+4, 142); 
  set_sprite_tile(34+4, 143);   
  set_sprite_tile(35+4, 144); 

 move_sprite(28+4, 0,0);
 move_sprite(29+4, 0,0);
 move_sprite(30+4, 0,0);
 move_sprite(31+4, 0,0);
 move_sprite(32+4, 0,0);
 move_sprite(33+4, 0,0);
 move_sprite(34+4, 0,0);
 move_sprite(35+4, 0,0);
   
  move_sprite(20+4, x +  8, y + 16); move_sprite(21+4, x + 16-1, y + 16);  move_sprite(22+4, x + 24-1, y + 16); move_sprite(23+4, x + 32-1, y + 16);
  move_sprite(24+4, x +  8, y + 24); move_sprite(25+4, x + 16-1, y + 24);  move_sprite(26+4, x + 24-1, y + 24); move_sprite(27+4, x + 32-1, y + 24);
  move_sprite(28+4, x +  8, y + 32); move_sprite(29+4, x + 16-1, y + 32);  move_sprite(30+4, x + 24-1, y + 32); move_sprite(31+4, x + 32-1, y + 32);
  move_sprite(32+4, x +  8, y + 40); move_sprite(33+4, x + 16-1, y + 40);  move_sprite(34+4, x + 24-1, y + 40); move_sprite(35+4, x + 32-1, y + 40);
  break;

 case(3):
  set_sprite_prop(20+4, (S_PALETTE) | 6); set_sprite_prop(21+4, (S_PALETTE) | 6);   set_sprite_prop(22+4, (S_PALETTE) | 6); set_sprite_prop(23+4, (S_PALETTE) | 6);
  set_sprite_prop(24+4, (S_PALETTE) | 6); set_sprite_prop(25+4, (S_PALETTE) | 6);   set_sprite_prop(26+4, (S_PALETTE) | 6); set_sprite_prop(27+4, (S_PALETTE) | 6);
  set_sprite_prop(28+4, (S_PALETTE) | 6); set_sprite_prop(29+4, (S_PALETTE) | 6);   set_sprite_prop(30+4, (S_PALETTE) | 6); set_sprite_prop(31+4, (S_PALETTE) | 6);
  set_sprite_prop(32+4, (S_PALETTE) | 6); set_sprite_prop(33+4, (S_PALETTE) | 6);   set_sprite_prop(34+4, (S_PALETTE) | 6); set_sprite_prop(35+4, (S_PALETTE) | 6); 

  set_sprite_tile(20+4, 129);  set_sprite_tile(21+4, 145);  set_sprite_tile(22+4, 146);  set_sprite_tile(23+4, 132); 
  set_sprite_tile(24+4, 133);  set_sprite_tile(25+4, 147);  set_sprite_tile(26+4, 148);  set_sprite_tile(27+4, 136); 
  set_sprite_tile(28+4, 137);  set_sprite_tile(29+4, 149);  set_sprite_tile(30+4, 150);  set_sprite_tile(31+4, 140); 
  set_sprite_tile(32+4, 141);  set_sprite_tile(33+4, 151);  set_sprite_tile(34+4, 152);  set_sprite_tile(35+4, 144); 
   
  move_sprite(20+4, x +  8, y + 16); move_sprite(21+4, x + 16-1, y + 16);  move_sprite(22+4, x + 24-1, y + 16); move_sprite(23+4, x + 32-1, y + 16);
  move_sprite(24+4, x +  8, y + 24); move_sprite(25+4, x + 16-1, y + 24);  move_sprite(26+4, x + 24-1, y + 24); move_sprite(27+4, x + 32-1, y + 24);
  move_sprite(28+4, x +  8, y + 32); move_sprite(29+4, x + 16-1, y + 32);  move_sprite(30+4, x + 24-1, y + 32); move_sprite(31+4, x + 32-1, y + 32);
  move_sprite(32+4, x +  8, y + 40); move_sprite(33+4, x + 16-1, y + 40);  move_sprite(34+4, x + 24-1, y + 40); move_sprite(35+4, x + 32-1, y + 40);
  break;
 case(4): //break into pieces
  set_sprite_prop(20+4, (S_PALETTE) | 6); set_sprite_prop(21+4, (S_PALETTE) | 6);   set_sprite_prop(22+4, (S_PALETTE) | 6); set_sprite_prop(23+4, (S_PALETTE) | 6);
  set_sprite_prop(24+4, (S_PALETTE) | 6); set_sprite_prop(25+4, (S_PALETTE) | 6);   set_sprite_prop(26+4, (S_PALETTE) | 6); set_sprite_prop(27+4, (S_PALETTE) | 6);
  set_sprite_prop(28+4, (S_PALETTE) | 6); set_sprite_prop(29+4, (S_PALETTE) | 6);   set_sprite_prop(30+4, (S_PALETTE) | 6); set_sprite_prop(31+4, (S_PALETTE) | 6);
  set_sprite_prop(32+4, (S_PALETTE) | 6); set_sprite_prop(33+4, (S_PALETTE) | 6);   set_sprite_prop(34+4, (S_PALETTE) | 6); set_sprite_prop(35+4, (S_PALETTE) | 6); 

  set_sprite_tile(20+4, 172);  set_sprite_tile(21+4, 173);  set_sprite_tile(22+4, 174);  set_sprite_tile(23+4, 175); 
  set_sprite_tile(24+4, 176);  set_sprite_tile(25+4, 177);  set_sprite_tile(26+4, 178);  set_sprite_tile(27+4, 179); 
  set_sprite_tile(28+4, 180);  set_sprite_tile(29+4, 181);  set_sprite_tile(30+4, 182);  set_sprite_tile(31+4, 183); 
  set_sprite_tile(32+4, 184);  set_sprite_tile(33+4, 185);  set_sprite_tile(34+4, 186);  set_sprite_tile(35+4, 187); 
   
  move_sprite(20+4, kite[ 0].x +  8, kite[ 0].y + 16); 
  move_sprite(21+4, kite[ 1].x +  8, kite[ 1].y + 16);
  move_sprite(22+4, kite[ 2].x +  8, kite[ 2].y + 16);
  move_sprite(23+4, kite[ 3].x +  8, kite[ 3].y + 16);
  move_sprite(24+4, kite[ 4].x +  8, kite[ 4].y + 16);
  move_sprite(25+4, kite[ 5].x +  8, kite[ 5].y + 16);
  move_sprite(26+4, kite[ 6].x +  8, kite[ 6].y + 16);
  move_sprite(27+4, kite[ 7].x +  8, kite[ 7].y + 16);
  move_sprite(28+4, kite[ 8].x +  8, kite[ 8].y + 16);
  move_sprite(29+4, kite[ 9].x +  8, kite[ 9].y + 16);
  move_sprite(30+4, kite[10].x +  8, kite[10].y + 16);
  move_sprite(31+4, kite[11].x +  8, kite[11].y + 16);
  move_sprite(32+4, kite[12].x +  8, kite[12].y + 16);
  move_sprite(33+4, kite[13].x +  8, kite[13].y + 16);
  move_sprite(34+4, kite[14].x +  8, kite[14].y + 16);
  move_sprite(35+4, kite[15].x +  8, kite[15].y + 16);
  break;
 }
}

void M8_process_boss3() {
 int i;
 switch (boss.state) {
   case(0) : // remove boss sprite
     boss.interact = 0;
     boss.x = 0;
     boss.y = 0;
     boss.firsttalk = 1;
   case(1) : // init position for appearing then set 2
     boss.hp = 50;
     boss.x = 160;
     boss.y = 30;
     boss.state = 2;
     boss.statecounter = 40;
     boss.ptn = 0;
   case(2) : // appear x--; until statecounter is 0 then set 3
     boss.x--;
     boss.statecounter--;
     if (boss.statecounter == 0) {
       boss.state = 4;
       boss.dx = -1; // x direction
       boss.dy = 0; // y direction
       boss.dz = boss.y; // base y
       boss.idx = 0; // kitewave array index
       boss.statecounter = 0; // skip homing y 
       if (boss.firsttalk) { boss.firsttalk = 0; game.talkED = 1; }
     }     
     break;
     case (3) : // change direction, go up or down, 
       boss.interact = 1;
       boss.state = 4; // go back to swoop state
       boss.idx = 0; // reset kitewave index
       boss.dx = -boss.dx; // change direction
       boss.statecounter++; 
       if (boss.statecounter == 2) {
         boss.statecounter = 0;
         boss.dy = -mySGN(boss.dz - (ship.y - 8));
       } else {
         boss.dy = 0;
       }

     case (4) : //swoop!! 
       boss.x += boss.dx;
       boss.idx++; 
       if (boss.idx >= 43) boss.state = 3; 

       boss.dw++; 
       if (boss.dw == 2) {
         boss.dw = 0;
         boss.dz += boss.dy;
       }
       boss.y = boss.dz + kitewavey[boss.idx];
       break;
       
     case (5+15) : // death init
       boss.state = 6+15;
       boss.interact = 0;
       //boss.ptn = 4;
       kite[ 0].x = boss.x+ 0-3; kite[ 0].y = boss.y+ 0-1; kite[ 1].x = boss.x+ 8-3; kite[ 1].y = boss.y+ 0-1;
       kite[ 2].x = boss.x+16-3; kite[ 2].y = boss.y+ 0-1; kite[ 3].x = boss.x+24-3; kite[ 3].y = boss.y+ 0-1;
       kite[ 4].x = boss.x+24-3; kite[ 4].y = boss.y+ 8-1; kite[ 5].x = boss.x+16-3; kite[ 5].y = boss.y+ 8-1;
       kite[ 6].x = boss.x+ 8-3; kite[ 6].y = boss.y+ 8-1; kite[ 7].x = boss.x+ 0-3; kite[ 7].y = boss.y+ 8-1;
       kite[ 8].x = boss.x+ 0-3; kite[ 8].y = boss.y+16-1; kite[ 9].x = boss.x+ 8-3; kite[ 9].y = boss.y+16-1;
       kite[10].x = boss.x+16-3; kite[10].y = boss.y+16-1; kite[11].x = boss.x+24-3; kite[11].y = boss.y+16-1;
       kite[12].x = boss.x+24-3; kite[12].y = boss.y+24-1; kite[13].x = boss.x+16-3; kite[13].y = boss.y+24-1;
       kite[14].x = boss.x+ 8-3; kite[14].y = boss.y+24-1; kite[15].x = boss.x+ 0-3; kite[15].y = boss.y+24-1;
       boss.statecounter = 120;
       boss.ptndelay = 120;
     case (6+15) : // wait for sun
       boss.statecounter--;
       if (boss.statecounter == 0) {
         boss.statecounter = 0;
         boss.idx = 16;
         boss.state = 7+15;
       }
       break; 
     case (7+15) : // Dra-X fx start falling falling
       boss.statecounter++;
       
       if (boss.statecounter % 8 == 0) {
         boss.idx--;
         kite[boss.idx].move = 1;
         kite[boss.idx].dy = 1;
         kite[boss.idx].dx = 0;
         
         if (boss.idx ==0) boss.state = 8+15;
       }
       break;
     case (8+15) : // wait for finish fall
       if (kite[0].y >=120) boss.state = 9+15;
       break;
         
     case (9+15) :  // stage clear
       boss.state = 10+15;
       ship.state = 6;
       break;
     case (10+15) :  // stage clear
       break;
  }
       
  for (i=0; i!= 16; i++) {
    if (kite[i].move == 1) { 
      kite[i].y += kite[i].dy;
      kite[i].dx++; // accel timer
      if (kite[i].dx ==4) { 
        kite[i].dx = 0;
        kite[i].dy ++; if (kite[i].dy >= 3) kite[i].dy = 3; // falling accel speed
      }
        
      if (kite[i].y >= 140) kite[i].move = 0;
    }
  }  

  // for animation and attack  
  if (boss.state == 4) { // while moving swoop arc
    if ((boss.ptndelay == 0) && (shotB[0].used == 0) && (shotB[1].used == 0)
    && (shotB[2].used == 0) && (shotB[3].used == 0)) { // time to attack
      boss.ptn = 1; // attack animation frame
      boss.ptndelay = 127-32; // wait (attack animation frame)
      if (rand() % 2 == 0) { // big or small attack
        shotB[0].id = 3; // big shuriken
        shotB[0].used = 1; shotB[1].used = 0; shotB[2].used =0; shotB[3].used = 0;
        shotB[0].x = boss.x+8; // shuriken X
        shotB[0].y = boss.y+4; 
        shotB[0].pow = 4;
      } else {  
        // small shuriken
        shotB[0].id = 4; shotB[1].id = 4; shotB[2].id = 4; shotB[3].id = 4; 
        shotB[0].used = 0; shotB[1].used = 1; shotB[2].used =1; shotB[3].used = 0;
        shotB[0].x=boss.x+8; shotB[1].x=boss.x+8; shotB[2].x=boss.x+8; shotB[3].x=boss.x+8;
        shotB[0].y=boss.y+-4; shotB[1].y=boss.y+0; shotB[2].y=boss.y+4; shotB[3].y=boss.y+8; 
        shotB[0].dx= 0; shotB[1].dx= 0; shotB[2].dx=0; shotB[3].dx=0;
        shotB[0].pow = 2; shotB[1].pow = 2; shotB[2].pow = 2; shotB[3].pow = 2;
      }
    }  
    
  }
  if (boss.ptndelay >0) { // some animation in going on, reset it.
    boss.ptndelay--;
    if (boss.state < 20) {
      if (boss.ptndelay == 117-32) boss.ptn = 0;
    } else { // death animation
      if ((boss.ptndelay % 10 == 0) &&( boss.ptndelay > 40 )) toggle_explo((boss.x + rand() % 20), (boss.y + rand() % 20));
      if (boss.ptndelay ==  60) boss.ptn = 2;
      if (boss.ptndelay ==  50) boss.ptn = 3;
      if (boss.ptndelay == 0) boss.ptn = 4;
    }  
  }
  
  
  
  M8_put_boss3(boss.x, boss.y, boss.ptn);
}

