// MBC 7

#include <gb.h>
#include"globalx.h"

void M7_process_ship();
void M7_put_ship(long int x, long int y);
void M7_put_bulletP(int id);

//-----
void M7_process_ship() {
 int s; // joypad
 int i,j,k; // loop counter
 int bosshit; // hit or not
 
 switch (ship.state) {
   case (0) : // none.
     ship.firsttalk = 1; //
     ship.interact = 0;
   case (1) : // ship appear init , muteki on.
     stat.hp = 8;
     ship.power = 0;
     stat.updatedhp = 1;
     ship.x = -16;
     ship.y = 20;
     ship.control = 0; // no control yet
     ship.blinktimer = 6; 
     ship.statecounter = 40;
  case (2) : // when hit, start from here
     ship.interact = 0; // no hit by attack
     ship.muteki = 1;
     ship.blink = 0; // 
     ship.blinktimer += 6; 
     ship.blinkcounter = 0;
     ship.state = 3;
   case (3): // appear until ctr
     ship.x++;
     ship.statecounter--;
     if (ship.statecounter == 0) { // regain control
       ship.state = 4; 
       ship.control = 1; // regains control ,but still blinks
       if (ship.firsttalk) { ship.firsttalk = 0; game.talkOP = 1; }
     }  
     break;
   case (4) : // normal
     break; 
   case (5) : // hit init(blink)
     ship.interact = 0;
     ship.muteki = 1;
     ship.blink = 1; // 
     ship.blinktimer = 6; 
     ship.blinkcounter = 0;
     ship.state = 4;
     ship.power--; if (ship.power<=0) ship.power = 0;
     break;
   case (6) : // stage clear init
     ship.interact = 0;
     ship.control = 0;
     ship.dx = -5;
     ship.dy = 0;
     ship.state = 7;
   case (7) : // stage clear
     ship.x += ship.dx;
     ship.dx++; if (ship.dx >= 4) ship.dx = 4;
     if (ship.x >=174) {
       ship.state = 8;
       ship.x = 174;
       ship.statecounter = 0;
     }
     break;
   case (8) : // wait after stage clear
     ship.statecounter++;
     if (ship.statecounter == 45) {
       game.stageclear = 1;
     }
     break;
   case (8+12) : // death init
     ship.interact = 0;
     ship.dx = 1;
     ship.dy = -4;
     ship.control = 0;
     ship.state = 9+12;
   case (9+12) : // death
     ship.x += ship.dx;
     ship.y += ship.dy;
     ship.dy++; if (ship.dy>=4) ship.dy = 4;
     if (ship.y >= 140) { // ship hits ground
       ship.y=140;
       ship.state = 10+12; 
       
       if (stat.rest == 0) { // game over!!
         //while(1) {} // halt for now
         game.over = 1;
       } else { // decrease remaining player
         stat.rest--;
         stat.updatedrest = 1;
       }
     }
     break;
   case (10+12) : // wait init
     ship.state = 11+12;
     ship.statecounter = 0;
   case (11+12) : // wait then back to appear
     ship.statecounter++;
     if (ship.statecounter == 100) ship.state = 1;
     break;  
 }
 
 // now  animation | blink part
 if (ship.muteki == 1) {
   ship.blinkcounter++; 
   if (ship.blinkcounter == 5) {
     ship.blinkcounter = 0;
     ship.blink = 1 - ship.blink;
     if (ship.blink == 0) ship.blinktimer--; // blink 6 times
     if (ship.blinktimer==0) {
       ship.muteki = 0; // end of blink
       ship.interact = 1; // end of blink
     }
   }
   if (ship.blink) M7_put_ship (-16,-16); else M7_put_ship(ship.x, ship.y);
 } else { // notmal state
   M7_put_ship(ship.x, ship.y);
 }
 
 
 s = joypad(); 
 if (!(s & J_B)) game.btnreleased = 1;

 if (ship.control == 1) {
   if(s & J_UP)    ship.y-=2; if (ship.y <=  -5)  ship.y = -5;
   if(s & J_DOWN)  ship.y+=2; if (ship.y >=  92)  ship.y = 92;
   if(s & J_LEFT)  ship.x-=2; if (ship.x <=  -5)  ship.x = -5;
   if(s & J_RIGHT) ship.x+=2; if (ship.x >= 150) ship.x = 150;
   //if (s & J_A) toggle_item(0, 160, ship.y); // debug - item maker
   
   if ((s & J_B) && (game.btnreleased == 1) && !((shotP[0].used == 1) && (shotP[1].used == 1))) {
     game.btnreleased = 0;
    if (shotP[1].used == 1) {
      snd_shot();
      shotP[0].used = 1;
      shotP[0].x = ship.x ;
      shotP[0].y = ship.y + 8 ;
      shotP[0].pow = ship.power + 1;
      shotP[0].ptn = 0;
      shotP[0].ptndelay = 0;
    } else {
      snd_shot();
      shotP[1].used = 1;
      shotP[1].x = ship.x ;
      shotP[1].y = ship.y + 8;
      shotP[1].pow = ship.power + 1;
      shotP[1].ptn = 0;
      shotP[1].ptndelay = 0;
    }  
   }


 }

  // process bullets
  for (i=0; i!=2; i++) {   
    if (shotP[i].used) { // process bullet-A
      shotP[i].ptndelay++; if (shotP[i].ptndelay == 4) shotP[i].ptndelay = 0;
      if (shotP[i].ptndelay == 0) shotP[i].ptn = 1 - shotP[i].ptn; // update animation
    
      shotP[i].x += 2; 
      if (shotP[i].x >= 160) {
        shotP[i].used = 0;
        shotP[i].x = -16;
        shotP[i].y = -16;
      }
      if (game.boss == 1) {// if boss fight, select stage for size of hit-detection box
        bosshit = 0; // hit or not
        if (boss.interact != 0) { // boss hit detection is on
          switch(game.stage) {
            case(1): // namnam - normal size 16x16
              if ((shotP[i].x > boss.x) && (shotP[i].x < boss.x+ 12) && 
                  (shotP[i].y > boss.y-4) && (shotP[i].y < boss.y+12)) {
                bosshit = 1;
                shotP[i].used = 0;
                shotP[i].x = -16;
                shotP[i].y = -16;
              }
              break;
            case(2): // cindy - big 16x32
            case(3): // fuuma - when visible 16x32
              if ((shotP[i].x > boss.x) && (shotP[i].x < boss.x+ 12) && 
                  (shotP[i].y > boss.y) && (shotP[i].y < boss.y+24)) {
                bosshit = 1;
                shotP[i].used = 0;
                shotP[i].x = -16;
                shotP[i].y = -16;
              }
              break;
            case(4): // skull - normal 24x16
              // check if bullet hits boss or not
              if ((shotP[i].x > boss.x-4) && (shotP[i].x < boss.x+ 12) && 
                  (shotP[i].y > boss.y-6) && (shotP[i].y < boss.y+12)) {
                bosshit = 1;
                shotP[i].used = 0;
                shotP[i].x = -16;
                shotP[i].y = -16;
              }
              break;
          }
        }
        //if hit flag == 1 then boss hp-- then set boss state to 20(death)
        if (bosshit == 1) {
          switch (game.stage) {
            case(1): toggle_explo(boss.x, boss.y); break;
            case(2): toggle_explo(boss.x, boss.y+8); break;
            case(3): toggle_explo(boss.x, boss.y+8); break;
            case(4): toggle_explo(boss.x, boss.y+4); break;
          }
          boss.hp-= shotP[i].pow;
          if ((game.stage == 4) && (boss.angry == 0) && (boss.hp<50)) {
            boss.angry = 1;
            boss.state = 6;// blow front cover 
          }
          if (boss.hp <= 0) boss.state = 20;
        }
         
      } 
      for (j = 0; j!=3; j++) {
        if (enemy[j].used) {
          if ((shotP[i].x > enemy[j].x-4) && (shotP[i].x < enemy[j].x+ 12) && 
             (shotP[i].y > enemy[j].y-6) && (shotP[i].y < enemy[j].y+12)) { // hit enemy!!
            shotP[i].used = 0;
            shotP[i].x = -16;
            shotP[i].y = -16;
            toggle_explo(enemy[j].x, enemy[j].y);
            enemy[j].x += 8;
               
            k=shotP[i].pow; // temporary storage
            enemy[j].hp -= k;
              
            if (enemy[j].hp <= 0) {            
              toggle_explo(enemy[j].x, enemy[j].y);    
              if (enemy[j].id == 0) toggle_item(0, enemy[j].x, enemy[j].y); // changev
              if (enemy[j].id == 1) toggle_item(1, enemy[j].x, enemy[j].y); // changev
              enemy[j].used = 0;
              enemy[j].x = -16;
              enemy[j].y = 144;
                
              move_sprite(28+(j*4), enemy[j].x, enemy[j].y); //
              move_sprite(29+(j*4), enemy[j].x, enemy[j].y); //
              move_sprite(30+(j*4), enemy[j].x, enemy[j].y); //
              move_sprite(31+(j*4), enemy[j].x, enemy[j].y); //
              stat.score++;
              stat.updatedscore = 1;
            }


          }   
        }
      }
      M7_put_bulletP(i);
    }
  }


}

void M7_put_ship(long int x, long int y) {
 set_sprite_prop(10, (S_PALETTE) | 1); //rom stol
 set_sprite_prop(11, (S_PALETTE) | 1); 
 set_sprite_prop(12, (S_PALETTE) | 0); 
 set_sprite_prop(13, (S_PALETTE) | 1); 

 set_sprite_tile(10, 0x01); //rom stol
 set_sprite_tile(11, 0x02); 
 set_sprite_tile(12, 0x03); 
 set_sprite_tile(13, 0x04); 
 
 move_sprite(10, x +  8, y + 16);
 move_sprite(11, x +  8, y + 24);
 move_sprite(12, x + 16, y + 16);
 move_sprite(13, x + 16, y + 24);
}

void M7_put_bulletP(int id){

 set_sprite_prop(14-0 + id, (S_PALETTE) | 4);

 switch (shotP[id].pow) {
 case (1): set_sprite_tile(14 + id, 13); break;
 case (2): set_sprite_tile(14 + id, 14); break;
 case (3): set_sprite_tile(14 + id,  5 + shotP[id].ptn); break;
 }
 move_sprite(14-0 + id, shotP[id].x +  8, shotP[id].y + 16);
}
