// MBC 10

#include <gb.h>
#include"globalx.h"

#include "tiles/c_win.h"
#include "tiles/c_win.c"
#include "tiles/m_win.h"
#include "tiles/m_win.c"
#include "tiles/m_talk.c"
#include "tiles/m_talk.h"

unsigned char string[9]; // this is ram, can be modified.

void M10_my_wait(long int n) {long int i; for(i=0; i!=n; i++) my_delay();}

void M10_update_stat_rest(int n) {
  int i;
  for (i = 0; i != 2; i++) string[i] = 21; // fill blank
  string[0] = 21 + (n / 10) % 10;
  string[1] = 21 + (n / 1) % 10;
  set_win_tiles(17, 1, 2, 1, string);
}

void M10_update_stat_hp(int n) {
  int i;
  for (i=0; i!=8; i++) string[i] = 20; // fill blank
  for (i=0; i!=n; i++) string[i] = 19; // fill hp bar
  set_win_tiles(3, 1, 8, 1, string);
}

void M10_update_stat_score(long int n) {
  int i;
  for (i = 0; i != 2; i++) string[i] = 21; // fill blank
  string[0] = 21 + (n / 1000) % 10;
  string[1] = 21 + (n / 100) % 10;
  string[2] = 21 + (n / 10) % 10;
  string[3] = 21 + (n / 1) % 10;
  set_win_tiles(10, 3, 4, 1, string);
}


void M10_draw_stat_win(int n) {
 // draw frame only. for updating stat, call 3 other functions
 // n = 0 // draw normal stat frame
 // n = 1 // draw talk frame
 // use logic-calc to select 2 frame set later

 switch (n) {
   case (0) : 
     VBK_REG = 1; // color map
     set_win_tiles(0, 0, 20, 5, c_win_label);
     VBK_REG = 0; // map
     set_win_tiles(0, 0, 20, 5, m_win_label);
     M10_update_stat_rest(stat.rest);
     M10_update_stat_hp(stat.hp);
     M10_update_stat_score(stat.score);
     move_win(7, (13 * 8));
     break;
   case (1) : 
     VBK_REG = 1; // color map
     set_win_tiles(0, 0, 20, 5, &c_win_label[100]);
     VBK_REG = 0; // map
     set_win_tiles(0, 0, 20, 5, &m_win_label[100]);
     move_win(7, (13 * 8));
     break;
 }     
} // end of function - M10_draw_stat_win

void M10_put_head(int n) {
 switch (n) {
   case (0) : // rom
     set_sprite_prop(20, (S_PALETTE) | 2); 
     set_sprite_prop(21, (S_PALETTE) | 1); 
     set_sprite_prop(22, (S_PALETTE) | 0); 
     set_sprite_prop(23, (S_PALETTE) | 1); 
     set_sprite_tile(20, 65); 
     set_sprite_tile(21, 66); 
     set_sprite_tile(22, 67); 
     set_sprite_tile(23, 68); 
     break;
   case (1) : // namnam
     set_sprite_prop(20, (S_PALETTE) | 2); 
     set_sprite_prop(21, (S_PALETTE) | 0); 
     set_sprite_prop(22, (S_PALETTE) | 1); 
     set_sprite_prop(23, (S_PALETTE) | 0); 
     set_sprite_tile(20, 69); 
     set_sprite_tile(21, 70); 
     set_sprite_tile(22, 71); 
     set_sprite_tile(23, 72); 
     break;
   case (2) : // cindy
     set_sprite_prop(20, (S_PALETTE) | 7); 
     set_sprite_prop(21, (S_PALETTE) | 7); 
     set_sprite_prop(22, (S_PALETTE) | 7); 
     set_sprite_prop(23, (S_PALETTE) | 7); 
     set_sprite_tile(20, 73); 
     set_sprite_tile(21, 74); 
     set_sprite_tile(22, 75); 
     set_sprite_tile(23, 76); 
     break;
   case (3) : // fuuma
     set_sprite_prop(20, (S_PALETTE) | 5); 
     set_sprite_prop(21, (S_PALETTE) | 5); 
     set_sprite_prop(22, (S_PALETTE) | 5); 
     set_sprite_prop(23, (S_PALETTE) | 5); 
     set_sprite_tile(20, 69); 
     set_sprite_tile(21, 70); 
     set_sprite_tile(22, 71); 
     set_sprite_tile(23, 72); 
     break;
   case (4) : // skull - final boss in this unfinished game
     set_sprite_prop(20, (S_PALETTE) | 7); 
     set_sprite_prop(21, (S_PALETTE) | 7); 
     set_sprite_prop(22, (S_PALETTE) | 7); 
     set_sprite_prop(23, (S_PALETTE) | 7); 
     set_sprite_tile(20, 73); 
     set_sprite_tile(21, 74); 
     set_sprite_tile(22, 75); 
     set_sprite_tile(23, 76); 
     break;
   case (5) : // dummy
     set_sprite_prop(20, (S_PALETTE) | 7); 
     set_sprite_prop(21, (S_PALETTE) | 7); 
     set_sprite_prop(22, (S_PALETTE) | 7); 
     set_sprite_prop(23, (S_PALETTE) | 0); 
     set_sprite_tile(20, 69); 
     set_sprite_tile(21, 70); 
     set_sprite_tile(22, 71); 
     set_sprite_tile(23, 72); 
     break;
   case (6) : // z - final boss in this game
     set_sprite_prop(20, (S_PALETTE) | 5); 
     set_sprite_prop(21, (S_PALETTE) | 5); 
     set_sprite_prop(22, (S_PALETTE) | 5); 
     set_sprite_prop(23, (S_PALETTE) | 5); 
     set_sprite_tile(20, 69); 
     set_sprite_tile(21, 70); 
     set_sprite_tile(22, 71); 
     set_sprite_tile(23, 72); 
     break;
   case (7) : // dra
     set_sprite_prop(20, (S_PALETTE) | 1); 
     set_sprite_prop(21, (S_PALETTE) | 1); 
     set_sprite_prop(22, (S_PALETTE) | 1); 
     set_sprite_prop(23, (S_PALETTE) | 1); 
     set_sprite_tile(20, 73); 
     set_sprite_tile(21, 74); 
     set_sprite_tile(22, 75); 
     set_sprite_tile(23, 76); 
     break;
   case (8) : // change-V(?) secret boss (no plan yet)
   break;
 }
 move_sprite(20, 16, 132); 
 move_sprite(21, 16, 140);
 move_sprite(22, 24, 132); 
 move_sprite(23, 24, 140);
}

void M10_talk(int n) {
 
 M10_draw_stat_win(1); // make sure in talk window
 
 switch(n) {
   case (0) : // stage 1 intro
     M10_put_head(0);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[0]);
     M10_my_wait(100);
     break;
   case (1) : // stage 1 boss talk 
     M10_put_head(1);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[30]);
     M10_my_wait(100);
     M10_put_head(1);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[60]);
     M10_my_wait(100);
     M10_put_head(0);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[90]);
     M10_my_wait(100);
     break;
   case (2) : // stage 2 intro
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[120]);
     M10_my_wait(100);
     break;
   case (3) : // boss 2 talk
     M10_put_head(2); // cindy head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[150]);
     M10_my_wait(150);
     break;
   case (4) : // stage 3 intro
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[180]);
     M10_my_wait(100);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[210]);
     M10_my_wait(150);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[240]);
     M10_my_wait(100);
     break;
   case (5) : // boss 3 talk
     M10_put_head(3); // fuuma head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[270]);
     M10_my_wait(150);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[300]);
     M10_my_wait(100);
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[330]);
     M10_my_wait(100);
     break;
   case (6) : // stage 4 intro
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[360]);
     M10_my_wait(100);
     break;
   case (7) : // boss 4 talk
     M10_put_head(4); // skull head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[390]);
     M10_my_wait(100);
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[420]);
     M10_my_wait(150);
     M10_put_head(4); // skull head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[450]);
     M10_my_wait(100);
     break;
   case (8) : // stage 5 intro
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[480]);
     M10_my_wait(100);
     break;
   case (9) : // boss 5 talk
     M10_put_head(5); // dummy head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[510]);
     M10_my_wait(100);
     break;
   case (10) : // final stage intro
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[540]);
     M10_my_wait(100);
     break;
   case (11) : // final boss talk
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[570]);
     M10_my_wait(100);
     M10_put_head(6); // z head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[600]);
     M10_my_wait(100);
     break;
   case (12) : // ending
     M10_put_head(7); // dra head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[630]);
     M10_my_wait(100);
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[660]);
     M10_my_wait(100);
     M10_put_head(0); // rom head
     VBK_REG = 0; set_win_tiles(4, 2, 15, 2, &m_talk_label[690]);
     M10_my_wait(100);
     break;
 }
 M10_draw_stat_win(0); // back to normal stat window
} // end of function - M10_talk
