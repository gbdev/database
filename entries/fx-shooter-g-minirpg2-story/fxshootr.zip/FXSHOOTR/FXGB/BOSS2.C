// MBC 9 boss2 cindy 

#include <gb.h>
#include "costable.c"
#include"globalx.h"

//int kitewavey[] = {0,1,1,1,2,2,2,3,3,3,3,4,4,4,4,4,4,4,4,3,3,3,3,2,2,2,1,1,1,0,0,0,0,0};
//int kitewavey[] = {0,1,1,1,2,2,2,3,3,3,3,4,4,4,4,4,4,4,4,3,3,3,3,2,2,2,1,1,1,0,0,0,0,0};
//int kitewavey[] = {0,1,1,2,2,2,3,3,3,4,4,4,4,5,5,5,5,5,5,5,5,4,4,4,4,3,3,3,2,2,2,1,1,0,0,0};
//int kitewavey[] = {0,0,1,1,2,2,3,3,3,3,4,4,4,4,5,5,5,5,6,6,6,6,6,6,6,6,5,5,5,5,4,4,4,4,3,3,3,3,2,2,1,1,0,0,0};



// prototypes
void M9_put_boss1(long int x, long int y, int ptn);
void M9_put_boss2(long int x, long int y, int ptn);
void M9_put_drone(int layer, long int x, long int y, int ptn);
void M9_put_boss4(long int x, long int y, int ptn);
void M9_put_boss4cover(int layer, long int x, long int y, int ptn);

// 
void M9_process_boss2() {

 switch (boss.state) {
   case(0) : // remove boss sprite
     boss.interact = 0;
     boss.x = 0;
     boss.y = 0;
     boss.firsttalk = 1;
   case(1) : // init position for appearing then set 2
     boss.hp = 50;
     boss.x = 160;
     boss.y = 30;
     boss.state = 2;
     boss.statecounter = 60;

     // also initialize 3 drones
     drone[0].dx = boss.x + 6; drone[0].dy = boss.y + 15;
     drone[1].dx = boss.x + 6; drone[1].dy = boss.y + 15;
     drone[2].dx = boss.x + 6; drone[2].dy = boss.y + 15;

     drone[0].cosidx = 0;
     drone[1].cosidx = 22;
     drone[2].cosidx = 44;

     drone[0].ptn = 0;
     drone[1].ptn = 0;
     drone[2].ptn = 0;

     drone[0].x = drone[0].dx + costbl[drone[0].cosidx];
     drone[1].x = drone[1].dx + costbl[drone[1].cosidx];
     drone[2].x = drone[1].dx + costbl[drone[2].cosidx];
   case(2) : // appear x--; until statecounter is 0 then set 3
     boss.x--;
     boss.statecounter--;
     if (boss.statecounter == 0) {
       boss.state = 3;
       boss.interact = 1;
       boss.statecounter = 20; //
     if (boss.firsttalk) { boss.firsttalk = 0; game.talkED = 1; }
     }
     break;
   case(3) : // wait!! 
     if (boss.statecounter-- == 0) boss.state = 4; /// <<< stop!! >>>
     boss.dy = boss.x; // ?? store boss x pos to temporary dy variable
     boss.dx = 16;
     break;
     
   case(4) : // homing!!
     boss.y -= mySGN(boss.y - (ship.y - 8));
     if (++boss.dx == 64) boss.dx = 0;
     boss.x = boss.dy + cos64tbl8[boss.dx];
     
     // boss attack(always)
     if (shotB[0].used == 0) {
       shotB[0].used = 1;
       shotB[0].id = 1; // cindy simple shot
       shotB[0].x = boss.x;
       shotB[0].y = boss.y+15;
       shotB[0].dx = 0;
       shotB[0].dy = 0;
       shotB[0].pow = 2;
     }

     break;
   case(5+15) : // death init
     boss.interact = 0;
     boss.dx = 1;
     boss.dy = -8;
     boss.state = 6+15;
   case(6+15) : // arc
     boss.x += boss.dx;
     boss.dy++; if (boss.dy>4) boss.dy = 4;
     boss.y += boss.dy;
     if (boss.y>120) boss.state = 7+15;
     drone[0].cosidx += 3;
     drone[1].cosidx += 3;
     drone[2].cosidx += 3;
     break;
   case (7+15) : //stage clear... set global stage clear variable  
     boss.state = 8 + 15;
     ship.state = 6;
     break;
   case (8+15) : //halt!
     break;
 }
 
 // process drones
 // 1) move with boss
  drone[0].dx = boss.x + 6; drone[0].dy = boss.y + 15;
  drone[1].dx = boss.x + 6; drone[1].dy = boss.y + 15;
  drone[2].dx = boss.x + 6; drone[2].dy = boss.y + 15;

 drone[0].cosidx++; drone[0].cosidx &= 0x3f;
 drone[1].cosidx++; drone[1].cosidx &= 0x3f;
 drone[2].cosidx++; drone[2].cosidx &= 0x3f;

 drone[0].x = drone[0].dx + cos64tbl8[drone[0].cosidx];
 drone[1].x = drone[1].dx + cos64tbl8[drone[1].cosidx];
 drone[2].x = drone[2].dx + cos64tbl8[drone[2].cosidx];

 drone[0].y = drone[0].dy + sin64tbl8[drone[0].cosidx];
 drone[1].y = drone[1].dy + sin64tbl8[drone[1].cosidx];
 drone[2].y = drone[2].dy + sin64tbl8[drone[2].cosidx];

  if (++drone[0].ptn == 80) drone[0].ptn = 0;
  if (++drone[1].ptn == 80) drone[1].ptn = 0;
  if (++drone[2].ptn == 80) drone[2].ptn = 0;

  if ((boss.state == 4) && (shotB[1].used == 0)&&(shotB[2].used == 0)&&(shotB[3].used == 0)) {
       shotB[1].used = 1;       shotB[2].used = 1;       shotB[3].used = 1;
       shotB[1].id = 2;         shotB[2].id = 2;         shotB[3].id = 2; // drone beam
       shotB[1].dx = 0;         shotB[2].dx = 0;         shotB[3].dx = 0; 
       shotB[1].x = drone[0].x; shotB[2].x = drone[1].x; shotB[3].x = drone[2].x; 
       shotB[1].y = drone[0].y; shotB[2].y = drone[1].y; shotB[3].y = drone[2].y; 
       shotB[1].pow = 3;        shotB[2].pow = 3;        shotB[3].pow = 3; 
     }
   
  M9_put_boss2(boss.x, boss.y, 0);
  
  M9_put_drone(37, drone[0].x, drone[0].y, drone[0].ptn / 20);
  M9_put_drone(38, drone[1].x, drone[1].y, drone[1].ptn / 20);
  M9_put_drone(39, drone[2].x, drone[2].y, drone[2].ptn / 20);
}

void M9_put_boss2(long int x, long int y, int ptn) {
 set_sprite_prop(20+11, (S_PALETTE) | 0); set_sprite_prop(21+11, (S_PALETTE) | 7); 
 set_sprite_prop(22+11, (S_PALETTE) | 7); set_sprite_prop(23+11, (S_PALETTE) | 1); 
 set_sprite_prop(24+11, (S_PALETTE) | 0); set_sprite_prop(25+11, (S_PALETTE) | 0); 
 set_sprite_tile(20+11, 90); set_sprite_tile(21+11, 91); 
 set_sprite_tile(22+11, 92 + 4 * ptn);  set_sprite_tile(23+11, 93 + 4 * ptn); 
 set_sprite_tile(24+11, 94 + 4 * ptn);  set_sprite_tile(25+11, 95); 
 move_sprite(20+11, x + 17 + ptn*2, y + 16); move_sprite(21+11, x + 13 + ptn*2, y + 24);
 move_sprite(22+11, x + 21 + ptn*2, y + 24); move_sprite(23+11, x +  8 + ptn*3, y + 32);
 move_sprite(24+11, x + 16 + ptn*3, y + 32); move_sprite(25+11, x + 13 + ptn*3, y + 40);
}

void M9_put_drone(int layer, long int x, long int y, int ptn) {
 set_sprite_prop(layer, (S_PALETTE) | 0);
 set_sprite_tile(layer, 112 + ptn);
 move_sprite(layer, x + 8, y + 16);
}

void M9_process_boss4() {

 switch (boss.state) {
   case(0) : // remove boss sprite
     boss.interact = 0;
     boss.x = 0;
     boss.y = 0;
     boss.firsttalk = 1;
   case(1) : // init position for appearing then set 2
     boss.hp = 90;
     boss.x = 160;
     boss.y = 30;
     boss.state = 2;
     boss.statecounter = 50;
     boss.ptn = 0;
   case(2) : // appear x--; until statecounter is 0 then set 3
     boss.x--;
     boss.statecounter--;
     if (boss.statecounter == 0) {
       boss.state = 3;
       boss.statecounter = 40;
       if (boss.firsttalk) { boss.firsttalk = 0; game.talkED = 1; }
       boss.interact = 1;
     }
     break;
     case (3) : // move init
       boss.dy = (ship.y > boss.y) * 2 - 1; // direction 1 or -1
       boss.statecounter = 6; // length of vertical move
       boss.dx = boss.statecounter * boss.dy;
       boss.dy = 0;

       boss.state = 4;
     case (4) :  // move
       boss.y += boss.dx;
         if (boss.dx>1) boss.dx -= 1; else boss.dx += 1;
       boss.statecounter--;
       if (boss.statecounter == 0) { // stop moving, now rest few seconds for torpedo
         boss.state = 5;// wait init
         boss.statecounter = 80;
         
         // torpedo init!!
         
       }
       break;
     case (5) : //wait for tropedo    
       boss.statecounter--;
       if (boss.statecounter == 0) boss.state = 3;// back to movi init
       if ((boss.statecounter == 70) && (shotB[0].used == 0)) { // fire torpedo No.1
         shotB[0].used = 1;
         shotB[0].id = 5; // torpedo
         shotB[0].x = boss.x;
         shotB[0].y = boss.y+4;
         shotB[0].dx = 4;
         shotB[0].dy = 0;
         shotB[0].pow = 2;
       }
       if ((boss.statecounter == 60) && (shotB[1].used == 0)) { // fire torpedo No.2
         shotB[1].used = 1;
         shotB[1].id = 5; // torpedo
         shotB[1].x = boss.x;
         shotB[1].y = boss.y+4;
         shotB[1].dx = 4;
         shotB[1].dy = 0;
         shotB[1].pow = 2;
       }
       
       break;
       
     case (6) : // cover hit init
       boss.interact = 0; // you can't hit boss while its cover is blowing up
       boss.state = 7; // wait for removing cover
       boss.statecounter = 127;
       boss.ptn = 1;
       cover[0].used = 1;
       cover[0].x = boss.x;
       cover[0].y = boss.y;
       cover[0].dx = -3;
       cover[0].dy = -1;
       cover[0].ptn = 0;
       cover[1].x = boss.x;
       cover[1].y = boss.y + 8;
       cover[1].dx = -3;
       cover[1].dy = 1;
       cover[1].ptn = 1;
     case(7) : //wait for cover
       //if (--boss.statecounter == 0) boss.state = 8; // continue
       // cover blow up!!
       if (++cover[1].used == 3) { // use .used as timer
         cover[1].used = 0;
         cover[0].x += cover[0].dx;
         cover[0].y += cover[0].dy;
         cover[1].x += cover[1].dx;
         cover[1].y += cover[1].dy;
         cover[0].dx += 1; if (cover[0].dx >= 7) cover[0].dx = 7;
         cover[1].dx += 1; if (cover[1].dx >= 7) cover[1].dx = 7;
         if (cover[0].x >= 168) {
           cover[0].used = 0; cover[0].x = 0; cover[0].y = 0; cover[1].x = 0; cover[1].y = 0;
           boss.state = 8; // cont-move state with laser
           boss.interact = 1;
         }
       }
       break;
     case (8) : // cont move
       boss.y -= mySGN(boss.y - ship.y);
       boss.dy++; 
       if (boss.dy>=40) {
         boss.dy = 0;
       
         // laser
         if ((shotB[0].used == 0) && (shotB[1].used == 0)) {
           shotB[0].used = 1;     shotB[1].used = 1;
           shotB[0].id = 6;       shotB[1].id = 6; // laser
           shotB[0].x = boss.x;   shotB[1].x = boss.x+8;
           shotB[0].y = boss.y+6; shotB[1].y = boss.y+6;
           shotB[0].dx = 4;       shotB[1].dx = 4;
           shotB[0].dy = 0;       shotB[1].dy = 0;
           shotB[0].pow = 3;      shotB[1].pow = 3;
         }
       }
       
       break;

     case (9+11) : // death init
       boss.interact = 0;
       boss.dx = -1;
       boss.dy = 1;
       boss.state = 10+11;
       boss.statecounter = 0;
     case(10+11) : // death
       boss.statecounter++;
       if ((boss.statecounter % 4) == 0) { // time to add explosion
         stat.updateexplo = 1;
         stat.updateexplox = boss.x -4 + rand() % 8;
         stat.updateexploy = boss.y;
       }
 
       boss.x += boss.dx;
       boss.y += boss.dy;
       if (boss.y>120) boss.state = 11+11;
       break;
     case (11+11) : //stage clear... set global stage clear variable  
       ship.state = 6;
       boss.state = 12+11;
       break;
     case (12+11) : //halt!
       break;
  }
  
   
  if ((boss.state == 3) || (boss.state == 4) || (boss.state == 5) || (boss.state == 8)) {
    // skull shot
    if ((shotB[2].used == 0) && (shotB[3].used == 0)) {
      shotB[2].used = 1;      shotB[3].used = 1;     
      shotB[2].id = 7;        shotB[3].id = 8;
      shotB[2].x = boss.x+10; shotB[3].x = boss.x+10;   
      shotB[2].y = 0;         shotB[3].y = 0; 
      shotB[2].dx = 0;        shotB[3].dx = 0;       
      shotB[2].dy = boss.y+6; shotB[3].dy = boss.y+6;       
      shotB[2].pow = 2;       shotB[3].pow = 2;      
    }
  }
  
  M9_put_boss4(boss.x, boss.y, boss.ptn);
  if (cover[0].used) {
    M9_put_boss4cover(20, cover[0].x, cover[0].y, cover[0].ptn);
    M9_put_boss4cover(21, cover[1].x, cover[1].y, cover[1].ptn);
  }
}

void M9_put_boss4(long int x, long int y, int ptn) {
 set_sprite_prop(34, (S_PALETTE) | 7 - ptn * 5);
 set_sprite_prop(35, (S_PALETTE) | 7 - ptn * 5); 
 set_sprite_prop(36, (S_PALETTE) | 7);  
 set_sprite_prop(37, (S_PALETTE) | 7); 
 set_sprite_prop(38, (S_PALETTE) | 2); 
 set_sprite_prop(39, (S_PALETTE) | 2); 

 set_sprite_tile(34, 164 + ptn * 6);
 set_sprite_tile(35, 165 + ptn * 6); 
 set_sprite_tile(36, 166); 
 set_sprite_tile(37, 167); 
 set_sprite_tile(38, 168); 
 set_sprite_tile(39, 169); 
 
 move_sprite(34, x +  8, y + 16);
 move_sprite(35, x +  8, y + 24);
 move_sprite(36, x + 16, y + 16);
 move_sprite(37, x + 16, y + 24);
 move_sprite(38, x + 24, y + 16);
 move_sprite(39, x + 24, y + 24);
}

void M9_put_boss4cover(int layer, long int x, long int y, int ptn) {
 set_sprite_prop(layer, (S_PALETTE) | 7);
 set_sprite_tile(layer, 170 + ptn);
 move_sprite(layer, x +  8, y + 16);
}

void M9_process_boss1() {

 switch (boss.state) {
   case(0) : // remove boss sprite
     boss.x = 0;
     boss.y = 0;
     boss.hp = 25;
     boss.firsttalk = 1;
   case(1) : // init position for appearing then set 2
     boss.interact = 0;   
     boss.ptn = 0;
     boss.x = -16;
     boss.y = 95;
     boss.state = 2;
     boss.dx = 0;
     boss.dy = 0;
   case(2) : // appear x--; until statecounter is 0 then set 3
     boss.x++;
     boss.statecounter--;
     
     if (boss.x>90) {
       boss.x++;
       if (++boss.dx == 10) { //going up
         boss.dx = 0;
         if (++boss.dy == 3) boss.dy = 3;
       }
     }
     boss.y -= boss.dy;
     
     if (boss.x >= 168) { // 168
       boss.state = 3; // wait mode(outside of screen)
       boss.statecounter = 40; // for 40 seconds
     }
     break;     
   case (3) : // wait outside of screen for a few second to turn around
     if (--boss.statecounter == 0) {
       boss.state = 4; // appear from right!!
       boss.statecounter = 50; 
       boss.ptn = 1; // face left
     }
     break;
   case (4) : // appear from right
     boss.x--;
     if (--boss.statecounter == 0) {
       boss.state = 5; // heartwave start
       boss.interact = 1;
       boss.idx = 0; // heart wave array index
       boss.dx = boss.x - 8 * 2;
       boss.dy = boss.y;
       if (boss.firsttalk) { boss.firsttalk = 0; game.talkED = 1; }

     }
     break;
   case (5) : // heart wave
     boss.dy -= mySGN(boss.dy - ship.y);
     if (++boss.idx == 46) boss.idx = 0;
     boss.x = boss.dx + heartwavex[boss.idx] * 2;
     boss.y = boss.dy + heartwavey[boss.idx] * 2;
    
      // boss attack(always)
     if (shotB[0].used == 0) {
       shotB[0].used = 1;
       shotB[0].id = 0; // namnam heart sin wave id
       shotB[0].x = boss.x;
       shotB[0].y = 0;
       shotB[0].dx = 0;
       shotB[0].dy = boss.y;
       shotB[0].pow = 2;
     }

     break;
   case (6) : // run init
     boss.dx = 8;
     boss.state = 7;
   case (7) : // arc + run
     boss.x += boss.dx;
     
     if (boss.dx-- == -4) boss.dx = -4;
     if (boss.x<-16) { // wait 
       boss.state = 8;
       boss.statecounter = 40;
     }
     break;
   case (8) : // wait and here i go again!!
     if (--boss.statecounter == 0) boss.state = 1;
     break;  
   case (9+11) : // death init
     boss.interact = 0;
     boss.dx = boss.x;
     boss.dy = 0; // used as x++ timer
     boss.dz = 0; 
     boss.idx = 0;
     boss.state = 10+11;
     boss.statecounter = 0; // used for explosion
   case (10+11) : // good bye
     boss.statecounter++;
     if ((boss.statecounter % 16) == 0) { // time to add explosion
       stat.updateexplo = 1;
       stat.updateexplox = boss.x;
       stat.updateexploy = boss.y;
     }
     
     if (boss.dy++ == 4) {boss.dy = 0; boss.dx++;}
     boss.x = boss.dx + sin64tbl8[boss.idx];
     
     boss.idx++; if (boss.idx == 64) boss.idx = 0;
     boss.dz++; if (boss.dz == 2) {
       boss.dz = 0;
       boss.y++; if (boss.y >=120) boss.state = 11+11; // stage clear!!
     }
     break;
   case (11+11) : // stage clear
       boss.state = 12+11;
       ship.state = 6;
     break;     
   case (12+11) : // halt!
     break;
     
 }
 
 M9_put_boss1(boss.x, boss.y, boss.ptn);
}

void M9_put_boss1(long int x, long int y, int ptn) {
 set_sprite_prop(20+16, (S_PALETTE) | 2 - ptn); set_sprite_prop(21+16, (S_PALETTE) | 0);
 set_sprite_prop(22+16, (S_PALETTE) | 1 + ptn); set_sprite_prop(23+16, (S_PALETTE) | 0);
 
 set_sprite_tile(20+16,  99+ptn*4); set_sprite_tile(21+16, 100+ptn*4);
 set_sprite_tile(22+16, 101+ptn*4); set_sprite_tile(23+16, 102+ptn*4);
 set_sprite_tile(20+16,  0x63+ptn*4); set_sprite_tile(21+16, 0x64+ptn*4);
 set_sprite_tile(22+16, 0x65+ptn*4); set_sprite_tile(23+16, 0x66+ptn*4);
 move_sprite(20+16, x +  6+ptn*4, y + 16); move_sprite(21+16, x +  8, y + 24);
 move_sprite(22+16, x + 14+ptn*4, y + 16); move_sprite(23+16, x + 16, y + 24);
}
