#include <gb.h>

#include "globalx.h"

void M11_add_item(long int xx, long int yy, int id);
void M11_put_item(long int x, long int y, int id, int ptn);
void M11_process_item();
void M11_put_explo(int i, int ptn);
void M11_add_explo(long int xx, long int yy);
void M11_process_explo();

void M11_put_item(long int x, long int y, int id, int ptn) {
 switch (id) {
   case (0): //P
     set_sprite_prop(9, (S_PALETTE) | 3); 
     set_sprite_tile(9, 7 + ptn);
     break;
   case (1) : // +
     set_sprite_prop(9, (S_PALETTE) | 3); 
     set_sprite_tile(9, 11 + (ptn % 2));
     break;
   case (2) : // dust
     set_sprite_prop(9, (S_PALETTE) | 4); 
     set_sprite_tile(9, 23 + (ptn % 2));
     break;
 }
 move_sprite(9, x +  8, y + 16); 
}

void M11_add_item(long int xx, long int yy, int id) {
  if (item.used == 0) {
   item.used = 1;
   item.interact = 1;
   item.layer = 0; 
   item.id = id;
   item.ptn = 0;
   item.ptnindex = 0;
   item.ptndelay = 0;
   item.x = xx;
   item.y = yy;
   item.dx = 0;
 }
}

void M11_process_item() {
 if (item.used == 1) {
   item.x--;
   
   if (item.id == 2) {
     item.dx--;
     if (item.dx <= 0) {
       item.used = 0; 
       item.x = -8; 
       item.y = -8;
     }
   }
   
   if (item.x <= -16) {
     item.used = 0; 
     item.x = -8; 
     item.y = -8;
   }
   item.ptndelay++; 
   if (item.ptndelay >= 10) { // it's time to update animation
     item.ptndelay = 0;
     item.ptn++; if (item.ptn >= 4) item.ptn = 0;
     if ((item.id>0) && (item.ptn == 2)) item.ptn = 0;
   }

   // now, check for hit with ship!
   // 
   //  check for out of screen       
   if (item.interact == 1) { // check if item is alive
     if ((item.x <= ship.x+8) && (item.x >= ship.x)
         && (item.y <= ship.y+13) && (item.y >= ship.y-2)) { // hit by ship!!
       // which otem you just ate?
       switch (item.id) {
       case (0): // just ate the power up
         ship.power++; if (ship.power >= 2) ship.power = 2;
         break;
       case (1): // just ate the FirstAid
         stat.hp++; if (stat.hp > 8) stat.hp = 8;
         stat.updatedhp = 1; 

         break;
       }
       item.id = 2;
       item.interact = 0;
       item.dx = 20;
     }
   }
   
   
   
       
   M11_put_item(item.x, item.y, item.id, item.ptn);
 } else { 
   M11_put_item(item.x, item.y, item.id, item.ptn);
 }
}

void M11_put_explo(int i, int ptn) {
 set_sprite_prop(explo[i].layer+0, (S_PALETTE) | 2);  
 set_sprite_prop(explo[i].layer+1, (S_PALETTE) | 2); 
 set_sprite_prop(explo[i].layer+2, (S_PALETTE) | 2);  
 set_sprite_prop(explo[i].layer+3, (S_PALETTE) | 2); 
 set_sprite_tile(explo[i].layer+0, 15 + ptn * 4); 
 set_sprite_tile(explo[i].layer+1, 16 + ptn * 4);
 set_sprite_tile(explo[i].layer+2, 17 + ptn * 4); 
 set_sprite_tile(explo[i].layer+3, 18 + ptn * 4);
 move_sprite(explo[i].layer+0, explo[i].x +  8, explo[i].y + 16); 
 move_sprite(explo[i].layer+1, explo[i].x +  8, explo[i].y + 24); 
 move_sprite(explo[i].layer+2, explo[i].x + 16, explo[i].y + 16); 
 move_sprite(explo[i].layer+3, explo[i].x + 16, explo[i].y + 24); 
}

void M11_add_explo(long int xx, long int yy) {
 int i, freeid;
 // select feee slot
 
 //get free enemy slot
 freeid = -1;
 for (i=0; i != 2; i++) {
   if (explo[i].used == 0) freeid = i;
 }

 // set struct
 if (freeid > -1) { // free slot found!!
   explo[freeid].used = 1;
   //explo[freeid].interact = 1;
   explo[freeid].layer = freeid * 4; 
   //explo[freeid].id = 0;
   explo[freeid].ptn = 0;
   explo[freeid].ptnindex = 0;
   explo[freeid].ptndelay = 0;
   explo[freeid].x = xx;
   explo[freeid].y = yy;
   explo[freeid].dx = 12;
 }
}


void M11_process_explo() {
 int i;
 for (i=0; i!=2; i++) {
   if (explo[i].used == 1) {
     explo[i].dx--;
     if (explo[i].dx == 0) {
       explo[i].used = 0;
       explo[i].x = -16;
       explo[i].y = -16;
     }
   
     explo[i].ptndelay++; 
     if (explo[i].ptndelay >= 6) { // it's time to update animation
       explo[i].ptndelay = 0;
       explo[i].ptn++; if (explo[i].ptn >= 2) explo[i].ptn = 0;
     }
     M11_put_explo(i, explo[i].ptn);
   } else { 
     M11_put_explo(i, explo[i].ptn);
   } 
 }
}
 