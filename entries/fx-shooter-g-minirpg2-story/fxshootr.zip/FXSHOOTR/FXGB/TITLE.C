// this is MBC 2

#include <gb.h>

#include "tiles/t_warn.h"
#include "tiles/t_warn.c"
#include "tiles/m_warn.h"
#include "tiles/m_warn.c"
#include "tiles/c_warn.h"
#include "tiles/c_warn.c"

#include "tiles/t_title.h"
#include "tiles/t_title.c"
#include "tiles/c_title.h"
#include "tiles/c_title.c"
#include "tiles/m_title.h"
#include "tiles/m_title.c"
#include "tiles/s_title.h"
#include "tiles/s_title.c"

// I am new to extern stuff, but it seems to work fine.
extern UWORD black_pal[32]; // access array from main module. it works!!

UWORD warn_bkg_pal[] = {
  t_warn_labelCGBPal0c0, t_warn_labelCGBPal0c1, t_warn_labelCGBPal0c2, t_warn_labelCGBPal0c3,
  t_warn_labelCGBPal1c0, t_warn_labelCGBPal1c1, t_warn_labelCGBPal1c2, t_warn_labelCGBPal1c3,
  t_warn_labelCGBPal2c0, t_warn_labelCGBPal2c1, t_warn_labelCGBPal2c2, t_warn_labelCGBPal2c3,
  t_warn_labelCGBPal3c0, t_warn_labelCGBPal3c1, t_warn_labelCGBPal3c2, t_warn_labelCGBPal3c3,
  t_warn_labelCGBPal4c0, t_warn_labelCGBPal4c1, t_warn_labelCGBPal4c2, t_warn_labelCGBPal4c3,
  t_warn_labelCGBPal5c0, t_warn_labelCGBPal5c1, t_warn_labelCGBPal5c2, t_warn_labelCGBPal5c3,
  t_warn_labelCGBPal6c0, t_warn_labelCGBPal6c1, t_warn_labelCGBPal6c2, t_warn_labelCGBPal6c3,
  t_warn_labelCGBPal7c0, t_warn_labelCGBPal7c1, t_warn_labelCGBPal7c2, t_warn_labelCGBPal7c3
};

UWORD title_bkg_pal[] = {
  t_title_labelCGBPal0c0, t_title_labelCGBPal0c1, t_title_labelCGBPal0c2, t_title_labelCGBPal0c3,
  t_title_labelCGBPal1c0, t_title_labelCGBPal1c1, t_title_labelCGBPal1c2, t_title_labelCGBPal1c3,
  t_title_labelCGBPal2c0, t_title_labelCGBPal2c1, t_title_labelCGBPal2c2, t_title_labelCGBPal2c3,
  t_title_labelCGBPal3c0, t_title_labelCGBPal3c1, t_title_labelCGBPal3c2, t_title_labelCGBPal3c3,
  t_title_labelCGBPal4c0, t_title_labelCGBPal4c1, t_title_labelCGBPal4c2, t_title_labelCGBPal4c3,
  t_title_labelCGBPal5c0, t_title_labelCGBPal5c1, t_title_labelCGBPal5c2, t_title_labelCGBPal5c3,
  t_title_labelCGBPal6c0, t_title_labelCGBPal6c1, t_title_labelCGBPal6c2, t_title_labelCGBPal6c3,
  t_title_labelCGBPal7c0, t_title_labelCGBPal7c1, t_title_labelCGBPal7c2, t_title_labelCGBPal7c3
};

UWORD title_spr_pal[] = {
  s_title_labelCGBPal0c0, s_title_labelCGBPal0c1, s_title_labelCGBPal0c2, s_title_labelCGBPal0c3,
  s_title_labelCGBPal1c0, s_title_labelCGBPal1c1, s_title_labelCGBPal1c2, s_title_labelCGBPal1c3,
  s_title_labelCGBPal2c0, s_title_labelCGBPal2c1, s_title_labelCGBPal2c2, s_title_labelCGBPal2c3,
  s_title_labelCGBPal3c0, s_title_labelCGBPal3c1, s_title_labelCGBPal3c2, s_title_labelCGBPal3c3,
  s_title_labelCGBPal4c0, s_title_labelCGBPal4c1, s_title_labelCGBPal4c2, s_title_labelCGBPal4c3,
  s_title_labelCGBPal5c0, s_title_labelCGBPal5c1, s_title_labelCGBPal5c2, s_title_labelCGBPal5c3,
  s_title_labelCGBPal6c0, s_title_labelCGBPal6c1, s_title_labelCGBPal6c2, s_title_labelCGBPal6c3,
  s_title_labelCGBPal7c0, s_title_labelCGBPal7c1, s_title_labelCGBPal7c2, s_title_labelCGBPal7c3
};

void M2_check_gbc() ;
void M2_title() ;
void M2_set_all_BG_pal() ;
void M2_set_title_sprite() ;
void M2_put_sprite_hand(int x, int y) ;
void M2_put_sprite_ship(int x, int  y) ;
void M2_put_sprite_arm1(int x, int y) ;
void M2_put_sprite_arm2(int x, int y) ;
void M2_put_sprite_arm3(int x, int y) ;
void M2_put_sprite_arm4(int x, int y) ;
void M2_set_title_pal() ;

void M2_check_gbc() {
  if(_cpu != 0x11) {  // if not GBC, error!! show warning
    set_bkg_data(0, 127, t_warn_label); // load warning text tile
    set_bkg_data(0, 127, t_warn_label); // load warning text tile
    set_bkg_tiles(0, 0, 20, 18, m_warn_label);
    SHOW_BKG;
    DISPLAY_ON;
    while (!0) {}
  } else { // color GB init, show logo
    set_bkg_data(0, 127, t_warn_label); // load warning text tile
    VBK_REG = 1; // color map
    set_bkg_tiles(0, 0, 20, 18, c_warn_label);
    VBK_REG = 0; // map
    set_bkg_tiles(0, 0, 20, 18, m_warn_label);
    set_bkg_tiles(0, 7, 20, 5, &m_warn_label[(long int)(360)]);
    M2_set_all_BG_pal();
    SHOW_BKG;
    DISPLAY_ON;
  }
}



void M2_set_all_BG_pal() {
  set_bkg_palette( 0, 1, &warn_bkg_pal[ 0]);
  set_bkg_palette( 1, 1, &warn_bkg_pal[ 4]);
  set_bkg_palette( 2, 1, &warn_bkg_pal[ 8]);
  set_bkg_palette( 3, 1, &warn_bkg_pal[12]);
  set_bkg_palette( 4, 1, &warn_bkg_pal[16]);
  set_bkg_palette( 5, 1, &warn_bkg_pal[20]);
  set_bkg_palette( 6, 1, &warn_bkg_pal[24]);
  set_bkg_palette( 7, 1, &warn_bkg_pal[28]);
}


// set sprite prop + color
void M2_set_title_sprite() {
  set_sprite_prop( 0, (S_PALETTE) | 5); //hand
  set_sprite_prop( 1, (S_PALETTE) | 5); 
  set_sprite_prop( 2, (S_PALETTE) | 5); 
  set_sprite_prop( 3, (S_PALETTE) | 5); 
  set_sprite_prop( 4, (S_PALETTE) | 5); //arm
  set_sprite_prop( 5, (S_PALETTE) | 5); 
  set_sprite_prop( 6, (S_PALETTE) | 5); 
  set_sprite_prop( 7, (S_PALETTE) | 5); 
  set_sprite_prop( 8, (S_PALETTE) | 1); //rom stol
  set_sprite_prop( 9, (S_PALETTE) | 1); 
  set_sprite_prop(10, (S_PALETTE) | 0); 
  set_sprite_prop(11, (S_PALETTE) | 1); 

  set_sprite_tile( 0,  9); //rom stol
  set_sprite_tile( 1, 10); 
  set_sprite_tile( 2, 11); 
  set_sprite_tile( 3, 12); 
  set_sprite_tile( 4,  8); //rom stol
  set_sprite_tile( 5,  8); 
  set_sprite_tile( 6,  8); 
  set_sprite_tile( 7,  8); 
  set_sprite_tile( 8,  5); //rom stol
  set_sprite_tile( 9,  2); 
  set_sprite_tile(10,  6); 
  set_sprite_tile(11,  7); 
}

// put sprite  
void M2_put_sprite_hand(int x, int y) {
  move_sprite(0, x +  8, y + 16); 
  move_sprite(1, x +  8, y + 24); 
  move_sprite(2, x + 16, y + 16); 
  move_sprite(3, x + 16, y + 24); 
}
void M2_put_sprite_ship(int x, int  y) {
  move_sprite( 8, x +  8, y + 16); 
  move_sprite( 9, x +  8, y + 24); 
  move_sprite(10, x + 16, y + 16); 
  move_sprite(11, x + 16, y + 24); 
}

void M2_put_sprite_arm1(int x, int y) {   move_sprite(4, x + 8, y + 16);  }
void M2_put_sprite_arm2(int x, int y) {   move_sprite(5, x + 8, y + 16);  }
void M2_put_sprite_arm3(int x, int y) {   move_sprite(6, x + 8, y + 16);  }
void M2_put_sprite_arm4(int x, int y) {   move_sprite(7, x + 8, y + 16);  }

void M2_set_title_pal() {
  set_bkg_palette( 0, 1, &title_bkg_pal[0] );
  set_bkg_palette( 1, 1, &title_bkg_pal[4] );
  set_bkg_palette( 2, 1, &title_bkg_pal[8] );
  set_bkg_palette( 3, 1, &title_bkg_pal[12] );
  set_bkg_palette( 4, 1, &title_bkg_pal[16] );
  set_bkg_palette( 5, 1, &title_bkg_pal[20] );
  set_bkg_palette( 6, 1, &title_bkg_pal[24] );
  set_bkg_palette( 7, 1, &title_bkg_pal[28] );
 
  set_sprite_palette( 0, 1, &title_spr_pal[0] );
  set_sprite_palette( 1, 1, &title_spr_pal[4] );
  set_sprite_palette( 2, 1, &title_spr_pal[8] );
  set_sprite_palette( 3, 1, &title_spr_pal[12] );
  set_sprite_palette( 4, 1, &title_spr_pal[16] );
  set_sprite_palette( 5, 1, &title_spr_pal[20] );
  set_sprite_palette( 6, 1, &title_spr_pal[24] );
  set_sprite_palette( 7, 1, &title_spr_pal[28] );
}

void M2_title() {
      UBYTE j;
      black_out_all(); // call main function from MBC1-1!! and it works!!
      HIDE_WIN;

      delay(500);

      set_bkg_data(0, 255, t_title_label); // load warning text tile
      // set BKG color map
      VBK_REG = 1;
      set_bkg_tiles(0, 0, 20, 18, c_title_label); 
      // set BKG actual map  
      VBK_REG = 0;
      set_bkg_tiles(0, 0, 20, 18, m_title_label);
      set_sprite_data(0, 127, s_title_label); // 

      remove_sprite();


      M2_put_sprite_arm1(15*8 + 0, 7*8 + 4);
      M2_put_sprite_arm2(14*8 + 2 + 1, 8*8 + 2);
      M2_put_sprite_arm3(13*8 + 1 + 2, 8*8 + 3);
      M2_put_sprite_arm4(12*8 + 1 + 3, 7*8 + 7);
      M2_put_sprite_hand(11*8 + 2 + 4, 6*8 + 4);
      M2_put_sprite_ship(11*8 - 1 + 4, 6*8 - 6);

     M2_set_title_pal();
     M2_set_title_sprite();
     move_bkg(0,0);
     DISPLAY_ON;
}
