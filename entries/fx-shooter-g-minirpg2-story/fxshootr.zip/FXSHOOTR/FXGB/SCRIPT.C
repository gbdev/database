// MBC 15 script and enemies
#include <gb.h>
#include "costable.c"
#include"globalx.h"


// id(1-6. 0 = not enemy), moveptn(0-11), position(0-8)
UWORD stage1script[] = { 0,0,0, 1,3,4, 3,4,3, 3,4,4, 3,4,5, 3,4,4, 2,4,3, 3,4,4, 
                         3,4,5, 0,0,0, 1,1,3, 0,0,0, 2,2,5, 0,0,0, 4,6,4, 4,6,3, 
                         4,6,5, 4,6,4, 4,6,3, 4,6,5, 4,6,4, 3,4,4, 3,5,4, 3,4,4,
                         3,5,4, 0,0,0, 4,8,6, 1,8,6, 4,8,6, 4,7,2, 2,7,2, 4,7,2}; 
UWORD stage2script[] = { 3,0,3, 3,0,3, 3,0,4, 3,0,4, 3,0,5, 3,0,5, 0,0,0, 1,4,4, 
                         2,1,3, 2,2,5, 4,10,6,4,9,2, 4,10,6,4,9,2, 4,10,6,4,9,2, 
                         4,10,6,4,9,2, 1,0,3, 2,0,3, 0,0,0, 2,3,3, 1,3,4, 2,3,5, 
                         3,0,3, 1,1,3, 3,1,3, 3,2,5, 3,1,3, 3,2,5, 3,1,3, 3,2,5};
UWORD stage3script[] = { 5,11,3,5,11,5,1,3,4, 5,11,5, 5,11,3, 2,3,4, 3,9,2, 3,10,6, 
                         6,10,8, 1,10,7, 6,10,6, 6,10,8, 2,10,7, 6,10,6,6,10,8, 2,10,7, 
                         6,10,6, 0,0,0, 3,4,3, 3,4,5, 3,4,3, 3,4,5, 0,0,0, 1,7,2, 
                         2,7,2, 2,8,6, 1,8,6, 0,0,0, 5,0,3, 5,0,5, 3,0,4, 0,0,0}; 
UWORD stage4script[] = { 8,8,6, 8,8,7, 8,8,8, 0,0,0, 7,7,2, 7,7,1, 7,7,0, 0,0,0, 
                         7,3,3, 7,3,5, 8,0,4, 1,4,4, 3,0,3, 1,2,5, 2,1,3, 0,0,0, 
                         8,0,5, 8,0,4, 8,0,3, 1,1,3, 7,1,3, 7,1,3, 7,3,5, 2,2,5, 
                         8,8,8, 8,8,7, 8,8,6, 2,0,3, 1,0,4, 3,4,5, 0,0,0, 0,0,0}; 

int M15_get_event_info(int stagenum, int scriptpos, int which);
void M15_put_enemy(int alpha, long int x, long int y, int id, int ptn);
void M15_add_enemy(int alpha, long int x, long int y, int id, int moveptn);
void M15_process_enemy();
void M15_process_enemy_shot();

int M15_get_event_info(int stagenum, int scriptpos, int which) {
 switch(stagenum) {
  case(1) : return stage1script[scriptpos * 3 + which];
  case(2) : return stage2script[scriptpos * 3 + which];
  case(3) : return stage3script[scriptpos * 3 + which];
  case(4) : return stage4script[scriptpos * 3 + which];
 }
 return 0;
}

void M15_put_enemy(int alpha, long int x, long int y, int id, int ptn) {
int dx, dy;
 switch(id) { // which enemy? - set palette + pattern
   case (0) : // changeV UFO
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 0);
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 4); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 0);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 4); 
     set_sprite_tile(28+alpha*4, 25 ); 
     set_sprite_tile(29+alpha*4, 26 + ptn * 4);
     set_sprite_tile(30+alpha*4, 27 ); 
     set_sprite_tile(31+alpha*4, 28 + ptn * 4);
     break;
   case (1) : // Jaws-V
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 2); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 2); 
     set_sprite_tile(28+alpha*4, 33 + ptn * 4); 
     set_sprite_tile(29+alpha*4, 34 + ptn * 4);
     set_sprite_tile(30+alpha*4, 35 + ptn * 4); 
     set_sprite_tile(31+alpha*4, 36 + ptn * 4);
     break;
   case (2) : // cup
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 2); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 2); 
     set_sprite_tile(28+alpha*4, 41 + ptn * 4); 
     set_sprite_tile(29+alpha*4, 42 + ptn * 4);
     set_sprite_tile(30+alpha*4, 43 + ptn * 4); 
     set_sprite_tile(31+alpha*4, 44 + ptn * 4);
     break;
   case (3) : // shark
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 2+ptn*4);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 6); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 6-ptn*4); 
     set_sprite_tile(28+alpha*4, 77 + ptn * 4); 
     set_sprite_tile(29+alpha*4, 78 + ptn * 4);
     set_sprite_tile(30+alpha*4, 79 + ptn * 4); 
     set_sprite_tile(31+alpha*4, 80 + ptn * 4);
     break;
   case (4) : // sin
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 5);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 5); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 5);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 5); 
     set_sprite_tile(28+alpha*4, 77 + ptn * 4); 
     set_sprite_tile(29+alpha*4, 78 + ptn * 4);
     set_sprite_tile(30+alpha*4, 79 + ptn * 4); 
     set_sprite_tile(31+alpha*4, 80 + ptn * 4);
     break;
   case (5) : // arrow
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 4);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 4); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 4);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 4); 
     set_sprite_tile(28+alpha*4, 89 + ptn * 4); 
     set_sprite_tile(29+alpha*4, 90 + ptn * 4);
     set_sprite_tile(30+alpha*4, 91 + ptn * 4); 
     set_sprite_tile(31+alpha*4, 92 + ptn * 4);
     break;
   case (6) : // emeraldas
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 0);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 2); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 0);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 2); 
     set_sprite_tile(28+alpha*4, 153); 
     set_sprite_tile(29+alpha*4, 154);
     set_sprite_tile(30+alpha*4, 155); 
     set_sprite_tile(31+alpha*4, 156);
     break;
   case (7) : // death shadow
     set_sprite_prop(28+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(29+alpha*4, (S_PALETTE) | 2); 
     set_sprite_prop(30+alpha*4, (S_PALETTE) | 2);  
     set_sprite_prop(31+alpha*4, (S_PALETTE) | 2); 
     set_sprite_tile(28+alpha*4, 157);
     set_sprite_tile(29+alpha*4, 158);
     set_sprite_tile(30+alpha*4, 159);
     set_sprite_tile(31+alpha*4, 160);
     break;
 }
 
 if ((id == 4) && (ptn == 2)) dx = -2; else dx = 0;
 if ((id == 1) && (ptn == 1)) dy = -1; else dy = 0;
 
 
 // set position
 move_sprite(28+alpha*4, x+  8 + dx, y + 16 + dy); //
 move_sprite(29+alpha*4, x+  8, y + 24 + dy); 
 move_sprite(30+alpha*4, x+ 16 + dx, y + 16 + dy); //
 move_sprite(31+alpha*4, x+ 16, y + 24 + dy); 
}

void M15_add_enemy(int alpha, long int x, long int y, int id, int moveptn) {

 enemy[alpha].used = 1;
 enemy[alpha].id = id;
 enemy[alpha].moveptn = moveptn;
 enemy[alpha].x = x;
 enemy[alpha].y = y;
 enemy[alpha].ptn = 0;


 switch(moveptn) {
   case (0) : // default straight 
     enemy[alpha].dx = 0; enemy[alpha].dy = 0; enemy[alpha].hp = 2; break;
   case (1) : // stair
   case (2) : // stair
     enemy[alpha].dx = 0; enemy[alpha].dy = 50; enemy[alpha].hp = 2; break;
   case(3): // return
     enemy[alpha].dx = 0; enemy[alpha].dy = 0; enemy[alpha].hp = 2; break;
   case(4): // cosine wave small
   case(5): // cosine wave big
     enemy[alpha].dx = 0; enemy[alpha].dy = y; enemy[alpha].hp = 2; break;
   case(6): // bite
     enemy[alpha].dx = 0; enemy[alpha].dy = 0; enemy[alpha].hp = 3; break;
   case(7): // arc
   case(8): // arc
     enemy[alpha].dx = 8; enemy[alpha].dy = 0; enemy[alpha].hp = 1; break;
   case(9): // diag
   case(10): // diag
     enemy[alpha].dx = 0; enemy[alpha].dy = 0; enemy[alpha].hp = 1; break;
   case (11): // ninja (move+stop+move)
     enemy[alpha].dx = 0; enemy[alpha].dy = 0; enemy[alpha].hp = 4; break;
 } // end of switch(movement pattern)
}



void M15_process_enemy() {
 int i, freeid;
 
 for(i=0; i!=3; i++) {
   if (enemy[i].used) {
     // enemy movement
     switch(enemy[i].moveptn) { // check moveptn then move
       case (0) : // default straight 
         enemy[i].x--;
         if (enemy[i].x<=-16) enemy[i].used = 0;
         break;
       case (1) : // stair
       case (2) : // stair
         if (enemy[i].dx == 0) {
           enemy[i].x--;
           enemy[i].dy--;
           if (enemy[i].dy <= 0) {
             enemy[i].dy=20;
             enemy[i].dx=1;
           }
         } else {
           if (enemy[i].moveptn == 1) enemy[i].y++; else enemy[i].y--;
           enemy[i].x++;
           enemy[i].dy--;
           if (enemy[i].dy <= 0) {
             enemy[i].dy = 50;
             enemy[i].dx = 0;
           }
         }
         if (enemy[i].x <= -16) enemy[i].used = 0;
         break;     
       case(3):
         switch(enemy[i].dy) {
           case(0): // appear
             enemy[i].x-=3;
             if (enemy[i].x<=40) {enemy[i].dy = 1; enemy[i].dx = -3;}
             break;
           case(1): // arc
             enemy[i].x += enemy[i].dx;
             enemy[i].y--;
             enemy[i].dx++;
             if (enemy[i].dx>=4 ) {enemy[i].dy = 2;} 
             break;
           case(2): //run!!
             enemy[i].x+=5;
             if (enemy[i].x >165) enemy[i].used = 0;
             break;
         }
         break;         
       case(4): // cosine wave small
       case(5): // cosine wave big
         if (enemy[i].moveptn == 4) enemy[i].x--; else enemy[i].x-=2;
         enemy[i].dx++; if (enemy[i].dx == 32) enemy[i].dx=0;
         if (enemy[i].moveptn == 4)
           enemy[i].y = enemy[i].dy + costbl8[enemy[i].dx];
         else
           enemy[i].y = enemy[i].dy + costbl4[enemy[i].dx];
         if (enemy[i].x <= -16) enemy[i].used = 0;
         break;
       case(6): // bite
         enemy[i].x--;
         if ((enemy[i].x < ship.x + 48) && (enemy[i].x > ship.x - 8)) {
           enemy[i].ptn = 1;
           enemy[i].x--;
           enemy[i].y += mySGN(ship.y - enemy[i].y );
          } else { enemy[i].ptn = 0; }
         if (enemy[i].x <= -16) enemy[i].used = 0;
         break;
       case(7): // arc
       case(8): // arc
         if (enemy[i].moveptn == 7) enemy[i].y += 2; else enemy[i].y -= 2;
         enemy[i].x += enemy[i].dx;
         enemy[i].dx--;
         if (enemy[i].dx <= -5) enemy[i].dx = -5;
         if (enemy[i].x <= -16) enemy[i].used = 0;
         break;
       case(9): // diag
       case(10): // diag
         enemy[i].x-=2;
         if (enemy[i].moveptn == 9) enemy[i].y+=2; else enemy[i].y-=2;
         if (enemy[i].x <= -16) enemy[i].used = 0;
         break;
       case (11): // ninja (move+stop+move)
         switch (enemy[i].dx) {
           case (0) : // move
             enemy[i].x-=2; if (enemy[i].x <= 100) { // time to stop
               enemy[i].dx = 1;
               enemy[i].dy = 0;// wait 50 frames
             }
             break;
           case (1) : // stop(attack)
             enemy[i].dy++;
             if (enemy[i].dy >= 70) enemy[i].dx = 2; // time to move again
             if (enemy[i].dy == 50) enemy[i].ptn = 0; 
             if (enemy[i].dy == 20) enemy[i].ptn = 1; 
             if (enemy[i].dy == 30) {
               enemy[i].ptn = 2; 
               freeid = -1;
               if (shotE[0].used == 0) 
                 freeid = 0;
               else if (shotE[1].used == 0)
                 freeid = 1;
               else if (shotE[2].used == 0)
                 freeid = 2;
                 
               if (freeid !=-1) { // free slot found!! init shuriken
                 shotE[freeid].used = 1;
                 shotE[freeid].x = enemy[i].x;
                 shotE[freeid].y = enemy[i].y+2;
               }
             }
             break;
           case (2) : // move
             enemy[i].x-=2; 
             if (enemy[i].x <= -16) enemy[i].used = 0;
             break;
           } // end of switch(dx)
         break;
     } // end of switch(movement)
     
     if (enemy[i].id <=2) {// first 3 enemies have simple animation
       enemy[i].ptndelay++;
       if (enemy[i].ptndelay == 6) {
         enemy[i].ptndelay = 0;
         enemy[i].ptn++; 

         switch(enemy[i].id) {
           case(0):
           case(1): if (enemy[i].ptn == 2) enemy[i].ptn = 0; break;
           case(2): if (enemy[i].ptn == 6) enemy[i].ptn = 0; break;
         }
       }
     }
     // hit by ship
      if (ship.interact == 1) { 
       if ((enemy[i].x < ship.x+12) && (enemy[i].x > ship.x-16) && 
           (enemy[i].y < ship.y+16) && (enemy[i].y > ship.y-16)) {
         toggle_explo(enemy[i].x, enemy[i].y);
         enemy[i].x = -16;
         enemy[i].y = 144;
         enemy[i].used = 0;

         ship.interact = 1;
         if (stat.hp == 0) { // dead!! can't take any more
           ship.state = 20; // ship is dead!!!
         } else { // calculate hp-- stuff
           if (2 >= stat.hp) { // major damage
             stat.hp = 0;
           } else {
             stat.hp -= 2;
           }
           ship.state = 5; // ship is hit
           stat.updatedhp = 1; // register hp win update
         }

        }
      }

     M15_put_enemy(i, enemy[i].x, enemy[i].y,enemy[i].id, enemy[i].ptn);
          
   }
 }
}

void M15_process_enemy_shot() {
 int i;
 for (i=0; i!=3; i++) {
   // move
   // animation
   if (shotE[i].used) {
     shotE[i].x-=2;
     if (shotE[i].x<=-16) { // out of screen
       shotE[i].used = 0;
     }
     
     shotE[i].ptndelay++;
     if (shotE[i].ptndelay >= 4) {
       shotE[i].ptndelay = 0;
       shotE[i].ptn = 1 - shotE[i].ptn; 
     }

     // hit ship
     if (ship.interact == 1) { 
        if ((shotE[i].x < ship.x+12) && (shotE[i].x > ship.x-16) && 
            (shotE[i].y < ship.y+16) && (shotE[i].y > ship.y-16)) {
          toggle_explo(ship.x, ship.y);
          shotE[i].x = -16;
          shotE[i].y = 144;
          shotE[i].used = 0;
              
          ship.interact = 1;
          if (stat.hp == 0) { // dead!! can't take any more
            ship.state = 20; // ship is dead!!!
          } else { // calculate hp-- stuff
            if (1 >= stat.hp) { // major damage
              stat.hp = 0;
            } else {
              stat.hp--;
            }
            ship.state = 5; // ship is hit
            stat.updatedhp = 1; // register hp win update
          }
        }
      }

     set_sprite_prop(25 + i, (S_PALETTE) | 5); 
     set_sprite_tile(25 + i, 93 + shotE[i].ptn ); 
     move_sprite(25 + i, shotE[i].x+  8, shotE[i].y + 16);
   }
 }
}
