// MBC 13 shot - boss

#include <gb.h>
#include <rand.h>
#include "costable.c"
#include"globalx.h"

void M13_put_shot_boss(int layer, long int x,long int y,int id, int ptn);
void M13_add_shot_boss(int idx, long int x, long int y, int id);
void M13_process_shot_boss();

void M13_put_shot_boss(int layer, long int x,long int y,int id, int ptn) {
 switch(id) {
   case (0) : // namnam heart 1 frame
     set_sprite_prop(layer, (S_PALETTE) | 0);
     set_sprite_tile(layer,  107); 
     break;
   case (1) : // cindy simple shot
     set_sprite_prop(layer, (S_PALETTE) | 7);
     set_sprite_tile(layer,  85); 
     break;
   case (2) : // drone shot
     set_sprite_prop(layer, (S_PALETTE) | rand() & 3);
     set_sprite_tile(layer,  87); 
     break;
   case (3) : // big shuriken
     set_sprite_prop(layer  , (S_PALETTE) | 5);
     set_sprite_prop(layer+1, (S_PALETTE) | 5);
     set_sprite_prop(layer+2, (S_PALETTE) | 5);
     set_sprite_prop(layer+3, (S_PALETTE) | 5);
     set_sprite_tile(layer,  95+ptn*4); 
     set_sprite_tile(layer+1,  96+ptn*4);  
     set_sprite_tile(layer+2,  97+ptn*4); 
     set_sprite_tile(layer+3,  98+ptn*4); 
     break;
   case (4) : // small shuriken
     set_sprite_prop(layer, (S_PALETTE) | 5);
     set_sprite_tile(layer,  93+ptn); 
     break;
   case (5) : // torpedo
     set_sprite_prop(layer, (S_PALETTE) | 3);
     set_sprite_tile(layer,  162); 
     break;
   case (6) : // screw laser
     set_sprite_prop(layer, (S_PALETTE) | 5 + ((rand() % 2) * 2));
     set_sprite_tile(layer,  163); 
     break;
   case (7) : // skull
   case (8) : // skull
     set_sprite_prop(layer, (S_PALETTE) | 3);
     set_sprite_tile(layer,  161); 
     break;
     
   }
   
   move_sprite(layer, x + 8, y + 16);
   
   if (id == 3) { // put big sprite
     move_sprite(layer+1, x +  8, y + 24);
     move_sprite(layer+2, x + 16, y + 16);
     move_sprite(layer+3, x + 16, y + 24);
   }
}

void M13_process_shot_boss(){
 int i;
 for (i=0; i!=4; i++) {
   if (shotB[i].used) {
     // process move
     switch (shotB[i].id) {
       case (0) : // namnam heart wave attack
         shotB[i].x -= 2; 
         shotB[i].dx++; if (shotB[i].dx>=32) shotB[i].dx = 0; // calc sin wave idx
         shotB[i].y = shotB[i].dy + sintbl8[shotB[i].dx]; // calc sin wave
         break;
       case (1) : // sindy simple shot
         shotB[i].x -= 3; 
         break;
       case (2) : // drone simple shot(combine with above)
         shotB[i].dx++; if (shotB[i].dx == 1) {
           shotB[i].dx = 0; 
           shotB[i].x -= 1; 
         }
         break;
       case (3) : // big shuriken
         shotB[i].x -= 3;
         shotB[i].dx++; if (shotB[i].dx == 2) {
           shotB[i].dx=0;
           shotB[i].y -= mySGN(shotB[i].y - ship.y);
         }
         // shuriken animation
         shotB[i].dy++; if (shotB[i].dy == 3) {shotB[i].dy=0; shotB[i].ptn = 1- shotB[i].ptn ; }
           break;       
       case (4) : // small shuriken
         shotB[i].x -= 3;
         shotB[i].dx++;
         switch (i) {
           case (0): if (shotB[i].dx == 2) {shotB[i].dx = 0; shotB[i].y--;} break;
           case (1): if (shotB[i].dx == 4) {shotB[i].dx = 0; shotB[i].y--;} break;
           case (2): if (shotB[i].dx == 4) {shotB[i].dx = 0; shotB[i].y++;} break;
           case (3): if (shotB[i].dx == 2) {shotB[i].dx = 0; shotB[i].y++;} break;
         }
         if ((shotB[i].y <= -16) || (shotB[i].y >= 160)) { // if out of screen(up+down), turn off
           shotB[i].used = 0; 
           shotB[i].x = -16; 
           shotB[i].y = -16;
         }
         // shuriken animation         
         shotB[i].dy++; if (shotB[i].dy == 3) {shotB[i].dy=0;shotB[i].ptn = 1- shotB[i].ptn ; }
         break;
       case (5) : //torpedo
         shotB[i].x += shotB[i].dx;
         shotB[i].dx--; if (shotB[i].dx <= -6) shotB[i].dx = -6;
         break;
       case (6) : //laser
         shotB[i].x -= 4;
         break;
       case (7) : // skull sine
         shotB[i].x -= 2; 
         shotB[i].dx++; if (shotB[i].dx>=64) shotB[i].dx = 0; // calc sin wave idx
         shotB[i].y = shotB[i].dy + sin64tbl8[shotB[i].dx]; // calc sin wave
         break;
       case (8) : // skull -sine
         shotB[i].x -= 2; 
         shotB[i].dx++; if (shotB[i].dx>=64) shotB[i].dx = 0; // calc sin wave idx
         shotB[i].y = shotB[i].dy - sin64tbl8[shotB[i].dx]; // calc sin wave
         break;
     } // end of switch(shot movement)
     
     if (shotB[i].x <= -16) { // if out of left side of screen, turn off shot
        shotB[i].used = 0; 
        shotB[i].x = -16; 
        shotB[i].y = -16;
      }
      
     // if boss attack the ship
     if (ship.interact == 1) {
       if ((shotB[i].x < ship.x+12) && (shotB[i].x > ship.x-4) 
        && (shotB[i].y < ship.y + 12) && (shotB[i].y > ship.y-4)) { // arrrrrgh!! hit by boss attack!!
         shotB[i].used = 0; 
         shotB[i].x = -16; 
         shotB[i].y = -16;
         if (stat.hp == 0) { // dead!! can't take any more
           ship.state = 20; // ship is dead!!!
         } else { // calculate hp-- stuff
           if (shotB[i].pow >= stat.hp) { // major damage
             stat.hp = 0;
           } else {
             stat.hp -= shotB[i].pow;
           }
           ship.state = 5; // ship is hit
           stat.updatedhp = 1; // register hp win update
         }
         // add explosion to ship
         toggle_explo(ship.x, ship.y);

       }
     }       
     M13_put_shot_boss(20+i, shotB[i].x, shotB[i].y, shotB[i].id, shotB[i].ptn);
   }
 }
}
