void snd_shot()
{
//  *(UBYTE*)0xFF16 = 0<<6 | 63;          // wave pattern duty / sound length
//  *(UBYTE*)0xFF17 =  15<<4 | 0<<3 | 1; 	// volume / envelope
//  *(UBYTE*)0xFF18 = 0 | 0xFF;           // frequency
//  *(UBYTE*)0xFF19 = 128 | 1;        // initial flag / frequency

 *(UBYTE*)0xFF10 = 0x1f;         
 *(UBYTE*)0xFF11 = 0xbf;
 *(UBYTE*)0xFF12 = 0xf2;
 *(UBYTE*)0xFF13 = 0xff;
 *(UBYTE*)0xFF14 = 0x87;

}

void snd_henshin() {

 *(UBYTE*)0xFF20 = 0x00;
 *(UBYTE*)0xFF21 = 0xf4; // short0xf1 = hit, long0xf4 = dead
 *(UBYTE*)0xFF22 = 0x57; //0x46;
 *(UBYTE*)0xFF23 = 0x80;

// *(UBYTE*)0xFF20 = 0x00;
// *(UBYTE*)0xFF21 = 0xf2;
// *(UBYTE*)0xFF22 = 0x2d;
// *(UBYTE*)0xFF23 = 0x80;
}

