// this is MBC 2

#include <gb.h>

#include "tiles/t_liksng.h"
#include "tiles/t_liksng.c"
#include "tiles/c_liksng.h"
#include "tiles/c_liksng.c"
#include "tiles/m_liksng.h"
#include "tiles/m_liksng.c"

#include "tiles/t_yikes.h"
#include "tiles/t_yikes.c"
#include "tiles/c_yikes.h"
#include "tiles/c_yikes.c"
#include "tiles/m_yikes.h"
#include "tiles/m_yikes.c"

UWORD liksang_bkg_pal[] = {
  t_liksng_labelCGBPal0c0, t_liksng_labelCGBPal0c1, t_liksng_labelCGBPal0c2, t_liksng_labelCGBPal0c3,
  t_liksng_labelCGBPal1c0, t_liksng_labelCGBPal1c1, t_liksng_labelCGBPal1c2, t_liksng_labelCGBPal1c3,
  t_liksng_labelCGBPal2c0, t_liksng_labelCGBPal2c1, t_liksng_labelCGBPal2c2, t_liksng_labelCGBPal2c3,
  t_liksng_labelCGBPal3c0, t_liksng_labelCGBPal3c1, t_liksng_labelCGBPal3c2, t_liksng_labelCGBPal3c3,
  t_liksng_labelCGBPal4c0, t_liksng_labelCGBPal4c1, t_liksng_labelCGBPal4c2, t_liksng_labelCGBPal4c3,
  t_liksng_labelCGBPal5c0, t_liksng_labelCGBPal5c1, t_liksng_labelCGBPal5c2, t_liksng_labelCGBPal5c3,
  t_liksng_labelCGBPal6c0, t_liksng_labelCGBPal6c1, t_liksng_labelCGBPal6c2, t_liksng_labelCGBPal6c3,
  t_liksng_labelCGBPal7c0, t_liksng_labelCGBPal7c1, t_liksng_labelCGBPal7c2, t_liksng_labelCGBPal7c3
};

UWORD yikes_bkg_pal[] = {
  t_yikes_labelCGBPal0c0, t_yikes_labelCGBPal0c1, t_yikes_labelCGBPal0c2, t_yikes_labelCGBPal0c3,
  t_yikes_labelCGBPal1c0, t_yikes_labelCGBPal1c1, t_yikes_labelCGBPal1c2, t_yikes_labelCGBPal1c3,
  t_yikes_labelCGBPal2c0, t_yikes_labelCGBPal2c1, t_yikes_labelCGBPal2c2, t_yikes_labelCGBPal2c3,
  t_yikes_labelCGBPal3c0, t_yikes_labelCGBPal3c1, t_yikes_labelCGBPal3c2, t_yikes_labelCGBPal3c3,
  t_yikes_labelCGBPal4c0, t_yikes_labelCGBPal4c1, t_yikes_labelCGBPal4c2, t_yikes_labelCGBPal4c3,
  t_yikes_labelCGBPal5c0, t_yikes_labelCGBPal5c1, t_yikes_labelCGBPal5c2, t_yikes_labelCGBPal5c3,
  t_yikes_labelCGBPal6c0, t_yikes_labelCGBPal6c1, t_yikes_labelCGBPal6c2, t_yikes_labelCGBPal6c3,
  t_yikes_labelCGBPal7c0, t_yikes_labelCGBPal7c1, t_yikes_labelCGBPal7c2, t_yikes_labelCGBPal7c3
};

void M1_lik_sang();
void M1_set_bg_pal ();
void M1_yikes();
void M1_set_yikes_bg_pal ();

void M1_lik_sang() {
  set_bkg_data(0, 127, t_liksng_label);

  if(_cpu == 0x11) {
    M1_set_bg_pal();
    VBK_REG = 1;
    set_bkg_tiles(0, 0, 20, 18, c_liksng_label);
    VBK_REG = 0;
  }
  set_bkg_tiles(0, 0, 20, 18, m_liksng_label);
  SHOW_BKG;
  DISPLAY_ON;
}


void M1_yikes() {
  set_bkg_data(0, 255, t_yikes_label);

  if(_cpu == 0x11) {
    M1_set_yikes_bg_pal();
    VBK_REG = 1;
    set_bkg_tiles(0, 0, 20, 18, c_yikes_label);
    VBK_REG = 0;
  }
  set_bkg_tiles(0, 0, 20, 18, m_yikes_label);
  SHOW_BKG;
  DISPLAY_ON;
}

void M1_set_bg_pal () {
  set_bkg_palette( 0, 1, &liksang_bkg_pal[0] );
  set_bkg_palette( 1, 1, &liksang_bkg_pal[4] );
  set_bkg_palette( 2, 1, &liksang_bkg_pal[8] );
  set_bkg_palette( 3, 1, &liksang_bkg_pal[12] );
  set_bkg_palette( 4, 1, &liksang_bkg_pal[16] );
  set_bkg_palette( 5, 1, &liksang_bkg_pal[20] );
  set_bkg_palette( 6, 1, &liksang_bkg_pal[24] );
  set_bkg_palette( 7, 1, &liksang_bkg_pal[28] );
}

void M1_set_yikes_bg_pal () {
  set_bkg_palette( 0, 1, &yikes_bkg_pal[0] );
  set_bkg_palette( 1, 1, &yikes_bkg_pal[4] );
  set_bkg_palette( 2, 1, &yikes_bkg_pal[8] );
  set_bkg_palette( 3, 1, &yikes_bkg_pal[12] );
  set_bkg_palette( 4, 1, &yikes_bkg_pal[16] );
  set_bkg_palette( 5, 1, &yikes_bkg_pal[20] );
  set_bkg_palette( 6, 1, &yikes_bkg_pal[24] );
  set_bkg_palette( 7, 1, &yikes_bkg_pal[28] );
}
