// this is MBC 3

// load and copy to VRAM
// BG - stage 1, stasge 2
// map - stage 1, stage 2
// cmap - stage 1, stage 2
// sprite - stage 1, stage 2
// palette  - stage 1, stage 2

#include <gb.h>

#include "globalx.h"

#include "tiles/t_stage1.h"
#include "tiles/t_stage1.c"
#include "tiles/c_stage1.h"
#include "tiles/c_stage1.c"
#include "tiles/c_stage2.h"
#include "tiles/c_stage2.c"
#include "tiles/m_stage1.h"
#include "tiles/m_stage1.c"
#include "tiles/m_stage2.h"
#include "tiles/m_stage2.c"
#include "tiles/s_stage1.h"
#include "tiles/s_stage1.c"

// I am new to extern stuff, but it seems to work fine.
extern UWORD black_pal[32]; // access array from main module. it works!!

UWORD stage1_bkg_pal[] = {
  t_stage1_labelCGBPal0c0, t_stage1_labelCGBPal0c1, t_stage1_labelCGBPal0c2, t_stage1_labelCGBPal0c3,
  t_stage1_labelCGBPal1c0, t_stage1_labelCGBPal1c1, t_stage1_labelCGBPal1c2, t_stage1_labelCGBPal1c3,
  t_stage1_labelCGBPal2c0, t_stage1_labelCGBPal2c1, t_stage1_labelCGBPal2c2, t_stage1_labelCGBPal2c3,
  t_stage1_labelCGBPal3c0, t_stage1_labelCGBPal3c1, t_stage1_labelCGBPal3c2, t_stage1_labelCGBPal3c3,
  t_stage1_labelCGBPal4c0, t_stage1_labelCGBPal4c1, t_stage1_labelCGBPal4c2, t_stage1_labelCGBPal4c3,
  t_stage1_labelCGBPal5c0, t_stage1_labelCGBPal5c1, t_stage1_labelCGBPal5c2, t_stage1_labelCGBPal5c3,
  t_stage1_labelCGBPal6c0, t_stage1_labelCGBPal6c1, t_stage1_labelCGBPal6c2, t_stage1_labelCGBPal6c3,
  t_stage1_labelCGBPal7c0, t_stage1_labelCGBPal7c1, t_stage1_labelCGBPal7c2, t_stage1_labelCGBPal7c3
};

UWORD stage1_spr_pal[] = {
  s_stage1_labelCGBPal0c0, s_stage1_labelCGBPal0c1, s_stage1_labelCGBPal0c2, s_stage1_labelCGBPal0c3,
  s_stage1_labelCGBPal1c0, s_stage1_labelCGBPal1c1, s_stage1_labelCGBPal1c2, s_stage1_labelCGBPal1c3,
  s_stage1_labelCGBPal2c0, s_stage1_labelCGBPal2c1, s_stage1_labelCGBPal2c2, s_stage1_labelCGBPal2c3,
  s_stage1_labelCGBPal3c0, s_stage1_labelCGBPal3c1, s_stage1_labelCGBPal3c2,  s_stage1_labelCGBPal3c3,
  s_stage1_labelCGBPal4c0, s_stage1_labelCGBPal4c1, s_stage1_labelCGBPal4c2, s_stage1_labelCGBPal4c3,
  s_stage1_labelCGBPal5c0, s_stage1_labelCGBPal5c1, s_stage1_labelCGBPal5c2, s_stage1_labelCGBPal5c3,
  s_stage1_labelCGBPal6c0, s_stage1_labelCGBPal6c1, s_stage1_labelCGBPal6c2, s_stage1_labelCGBPal6c3,
  s_stage1_labelCGBPal7c0, s_stage1_labelCGBPal7c1, s_stage1_labelCGBPal7c2, s_stage1_labelCGBPal7c3
};


void M3_load_gfx1() {
  
  game.bosstimer = 27;
  game.bosstimerdelay = 0;
  game.boss = 0;
  
  black_out_all();
  set_bkg_data(0, 128, t_stage1_label);
  VBK_REG = 1; // color map
  set_bkg_tiles(0, 0, 32, 18, c_stage1_label);
  VBK_REG = 0; // map
  set_bkg_tiles(0, 0, 32, 18, m_stage1_label);
  set_sprite_data(0, 127, s_stage1_label); //
  SHOW_WIN;

  set_bkg_palette( 0, 1, &stage1_bkg_pal[0] );
  set_bkg_palette( 1, 1, &stage1_bkg_pal[4] );
  set_bkg_palette( 2, 1, &stage1_bkg_pal[8] );
  set_bkg_palette( 3, 1, &stage1_bkg_pal[12] );
  set_bkg_palette( 4, 1, &stage1_bkg_pal[16] );
  set_bkg_palette( 5, 1, &stage1_bkg_pal[20] );
  set_bkg_palette( 6, 1, &stage1_bkg_pal[24] );
  set_bkg_palette( 7, 1, &stage1_bkg_pal[28] );
 
  set_sprite_palette( 0, 1, &stage1_spr_pal[0] );
  set_sprite_palette( 1, 1, &stage1_spr_pal[4] );
  set_sprite_palette( 2, 1, &stage1_spr_pal[8] );
  set_sprite_palette( 3, 1, &stage1_spr_pal[12] );
  set_sprite_palette( 4, 1, &stage1_spr_pal[16] );
  set_sprite_palette( 5, 1, &stage1_spr_pal[20] );
  set_sprite_palette( 6, 1, &stage1_spr_pal[24] );
  set_sprite_palette( 7, 1, &stage1_spr_pal[28] );
}

void M3_load_gfx2() {
  
  game.bosstimer = 32;
  game.bosstimerdelay = 0;
  game.boss = 0;
  
  black_out_all();
  set_bkg_data(0, 128, t_stage1_label);
  VBK_REG = 1; // color map
  set_bkg_tiles(0, 0, 32, 18, c_stage2_label);
  VBK_REG = 0; // map
  set_bkg_tiles(0, 0, 32, 18, m_stage2_label);
  set_sprite_data(0, 127, s_stage1_label); // 
  SHOW_WIN;

  set_bkg_palette( 0, 1, &stage1_bkg_pal[0] );
  set_bkg_palette( 1, 1, &stage1_bkg_pal[4] );
  set_bkg_palette( 2, 1, &stage1_bkg_pal[8] );
  set_bkg_palette( 3, 1, &stage1_bkg_pal[12] );
  set_bkg_palette( 4, 1, &stage1_bkg_pal[16] );
  set_bkg_palette( 5, 1, &stage1_bkg_pal[20] );
  set_bkg_palette( 6, 1, &stage1_bkg_pal[24] );
  set_bkg_palette( 7, 1, &stage1_bkg_pal[28] );
 
  set_sprite_palette( 0, 1, &stage1_spr_pal[0] );
  set_sprite_palette( 1, 1, &stage1_spr_pal[4] );
  set_sprite_palette( 2, 1, &stage1_spr_pal[8] );
  set_sprite_palette( 3, 1, &stage1_spr_pal[12] );
  set_sprite_palette( 4, 1, &stage1_spr_pal[16] );
  set_sprite_palette( 5, 1, &stage1_spr_pal[20] );
  set_sprite_palette( 6, 1, &stage1_spr_pal[24] );
  set_sprite_palette( 7, 1, &stage1_spr_pal[28] );
}
