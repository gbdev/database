
#include <gb.h>
#include <rand.h>

#include"proto.h"
#include"global.h"
#include "bgm.c"
#include "sound.c"

void black_out_bkg() {set_bkg_palette( 0, 8, &black_pal[0] ); }
void black_out_spr() {set_sprite_palette( 0, 8, &black_pal[0] ); }
void black_out_all() {set_bkg_palette( 0, 8, &black_pal[0] ); 
                      set_sprite_palette( 0, 8, &black_pal[0] ); }
void remove_sprite() {int i; for (i = 0; i != 40; i++) move_sprite(i, 0, 0); }
void VBL_counter() {global_counter++;}
void my_delay() {while(1) {if (global_counter > 1) break;} global_counter = 1;}

//------------
void main() {
 int button;
 int i,j,k,l,ii;
 long int x;
 long int y;
 int freeid;
 int nnnnn;
 int s;

  // initialize sound
  *(UBYTE*)0xFF26 = 0x80;  // all sound on
  *(UBYTE*)0xFF25 = 0xFF;                   // ouput all sounds
  *(UBYTE*)0xFF24 = 0x8F;               // volume for SO1 & SO2
  
  // add VBL_TIMER + music engine
  disable_interrupts();  
  add_vbl(play_BGM);
  cpu_fast();
  add_vbl( VBL_counter );  
  enable_interrupts();

  BGM_off();
  
  DISPLAY_OFF;
  SPRITES_8x8;
  SHOW_BKG;
  SHOW_SPRITES;
  HIDE_WIN;

  SWITCH_ROM_MBC1(1); M1_lik_sang(); // 
  waitpad(J_START | J_A | J_B); waitpadup();
  if(_cpu == 0x11) black_out_all(); else DISPLAY_OFF;
  
  SWITCH_ROM_MBC1(1); M1_yikes(); // 
  waitpad(J_START | J_A | J_B); waitpadup();
  if(_cpu == 0x11) black_out_all(); else DISPLAY_OFF;

  // < LOGO >
  SWITCH_ROM_MBC1(2); M2_check_gbc(); // check GBC. put logo
  waitpad(J_START | J_A | J_B); waitpadup();
  
  while(1) { // infinite main loop
  
    // < TITLE >
    SWITCH_ROM_MBC1(2); M2_title();
    waitpad(J_START | J_A); waitpadup(); // wait for user input
    remove_sprite();  

    game.stage = 1;
    stat.score = 0;
    stat.hp = 8;
    stat.rest = 9;
    game.talkOP= 0;
    game.talkED= 0;
    shotB[0].used = 0; shotB[1].used = 0; shotB[2].used = 0; shotB[3].used = 0;
    shotE[0].used = 0; shotE[1].used = 0; shotE[2].used = 0;
    enemy[0].used = 0; enemy[1].used = 0; enemy[2].used = 0;
    explo[0].x = -16; explo[1].x = -16; explo[2].x = -16; item.x = -16;
    explo[0].y = 144; explo[1].y = 144; explo[2].y = 144; item.y = 144;
    
    BGM_on();


    SWITCH_ROM_MBC1(10); M10_draw_stat_win(0);
    
    game.stageclear = 0;
    game.dead = 0;

    load_stage_gfx(game.stage); // load tiles, load cmap, map, sprites and palette.
  
    game.bosstimerdelay = 0;
    game.bosstimer = 50;
    game.boss = 0;
    boss.state = 0;

    game. over = 0;
    boss.ready = 0;
    
    script.check.ctrdelay=0;
    script.check.ctr=0;
    
    while(game.over == 0) {  // while not game over  + not stage clear
      // scroll
      scroll_bkg(1,0);

      // update status window
      if (stat.updatedhp == 1) { stat.updatedhp = 0; SWITCH_ROM_MBC1(10); M10_update_stat_hp(stat.hp); }
      if (stat.updatedrest == 1) { stat.updatedrest = 0; SWITCH_ROM_MBC1(10); M10_update_stat_rest(stat.rest); }
      if (stat.updatedscore == 1) { stat.updatedscore = 0; SWITCH_ROM_MBC1(10); M10_update_stat_score(stat.score); }
      // ship
      SWITCH_ROM_MBC1(7); M7_process_ship(); // user input + calculate position
      
      // register sound effect(call this function from MBC)
      if (stat.updatesfx == 1) {
        stat.updatesfx = 0;
      }

      // register explosion (call this function from MBC)
      if (stat.updateexplo == 1) {
        stat.updateexplo = 0;
        snd_henshin();
        SWITCH_ROM_MBC1(11); M11_add_explo(stat.updateexplox, stat.updateexploy);
      }

      // register items (call this function from MBC)
      if (stat.updateitem == 1) {
        stat.updateitem = 0;
        SWITCH_ROM_MBC1(11); M11_add_item(stat.updateitemx, stat.updateitemy, stat.updateitemid);
      }
      
      // process item   + explosion + sound effect
      SWITCH_ROM_MBC1(11); M11_process_item();
      SWITCH_ROM_MBC1(11); M11_process_explo();

      // intro talk
      if (game.talkOP == 1) {
        game.talkOP = 0;
        // select stage then call right talk number
        switch (game.stage) { // ((stage - 1) * 2)
          case (1) : SWITCH_ROM_MBC1(10); M10_talk(0); break;
          case (2) : SWITCH_ROM_MBC1(10); M10_talk(2); break;
          case (3) : SWITCH_ROM_MBC1(10); M10_talk(4); break;
          case (4) : SWITCH_ROM_MBC1(10); M10_talk(6); break;
          case (5) : SWITCH_ROM_MBC1(10); M10_talk(8); break; // not used
          case (6) : SWITCH_ROM_MBC1(10); M10_talk(10); break; // not used
        }
      }
      
      // boss talk
      if (game.talkED == 1) {
        game.talkED = 0;
        // select stage then call right talk number
        switch (game.stage) { // ((stage * 2) - 1)
          case (1) : SWITCH_ROM_MBC1(10); M10_talk(1); break;
          case (2) : SWITCH_ROM_MBC1(10); M10_talk(3); break;
          case (3) : SWITCH_ROM_MBC1(10); M10_talk(5); break;
          case (4) : SWITCH_ROM_MBC1(10); M10_talk(7); break;
          case (5) : SWITCH_ROM_MBC1(10); M10_talk(9); break; // not used 
          case (6) : SWITCH_ROM_MBC1(10); M10_talk(11); break; // not used
        }  
      }

      if (game.boss == 0) { // if not boss then do script thing
        // check if it is time for boss
        game.bossdelay += 1; 
        if (game.bossdelay >= 50) {// speed of script advance
          game.bossdelay = 0; 
          game.bosstimer--;
          if (game.bosstimer <= 0) game.boss = 1;
        }
        // do script thing now!
        
        script.check.ctrdelay++;
        if (script.check.ctrdelay == 50) { // add enemy per 50 frames
          script.check.ctrdelay = 0;
          
          script.check.ctr++; // adjust script index
          
          if (script.check.ctr >= 32) script.check.ctr = 0; // make 32 script per stage
          
          //check for free id
          freeid = -1; for (i=0; i!=3; i++) { if (enemy[i].used == 0) freeid = i; }
          if (freeid!= -1) { // add enemy with script
            SWITCH_ROM_MBC1(15); j = M15_get_event_info(game.stage, script.check.ctr, 0);//id
            SWITCH_ROM_MBC1(15); k = M15_get_event_info(game.stage, script.check.ctr, 1);//move
            SWITCH_ROM_MBC1(15); l = M15_get_event_info(game.stage, script.check.ctr, 2);//where
            switch(l) { // calc enemy x, y position
              case (0): x= 40; y=-16; break;
              case (1): x= 80; y=-16; break;
              case (2): x=120; y=-16; break;
              case (3): x=160; y= 26; break;
              case (4): x=160; y= 52; break;
              case (5): x=160; y= 78; break;
              case (6): x=120; y=104; break;
              case (7): x= 80; y=104; break;
              case (8): x= 40; y=104; break;
            }
            
            if (k != 0 ) // if enemy id is valid
            SWITCH_ROM_MBC1(15); M15_add_enemy(freeid, x, y, j - 1, k);
          }
        }    
        
      } else { // do boss things
        if (boss.ready) { 
          scroll_bkg(1, 0);
          switch (game.stage) {
            case (1) : SWITCH_ROM_MBC1(9); M9_process_boss1(); break;
            case (2) : SWITCH_ROM_MBC1(9); M9_process_boss2(); break;
            case (3) : SWITCH_ROM_MBC1(8); M8_process_boss3(); break;
            case (4) : SWITCH_ROM_MBC1(9); M9_process_boss4(); break;
          } 
        } else { // boss is ready, but enemy is still on screen
          if ((enemy[0].used == 0) && (enemy[1].used == 0) && (enemy[2].used == 0)) boss.ready = 1;
        }
      }
      
        // enemy section even if boss is on(boss will wait)
        SWITCH_ROM_MBC1(15); M15_process_enemy();
        SWITCH_ROM_MBC1(15); M15_process_enemy_shot();

            // process boss attack even if boss is NOT on
      SWITCH_ROM_MBC1(13); M13_process_shot_boss();

      my_delay();
     
      // after stage clear do all thing here
      if (game.stageclear == 1) {
        game.stage++;
        if (game.stage == 5) { // end of demo
          bgm_off();
          SWITCH_ROM_MBC1(14); M14_tbc(); // 
          while(1) {}
        }
        game.stageclear = 0;
        load_stage_gfx(game.stage); // load tiles, load cmap, map, sprites and palette.    
        SWITCH_ROM_MBC1(10); M10_update_stat_hp(game.stage);

        ship.state = 0;
        boss.state = 0;
        boss.ready = 0;
        script.check.ctrdelay=0;
        script.check.ctr=0;
      }
    }
    BGM_off();

    SWITCH_ROM_MBC1(14); M14_over(); // 
    waitpad(J_START | J_A | J_B); waitpadup();
    black_out_all(); 

  }
} // EOF ------------------------------

void load_stage_gfx(int n) {
 switch (n) {// select stage
  case(1) : SWITCH_ROM_MBC1(3); M3_load_gfx1(); break;
  case(2) : SWITCH_ROM_MBC1(3); M3_load_gfx2(); break;
  case(3) : SWITCH_ROM_MBC1(4); M4_load_gfx3(); break;
  case(4) : SWITCH_ROM_MBC1(4); M4_load_gfx4(); break;
 }
}

void toggle_item(int id, long int x, long int y) {
 stat.updateitem = 1;
 stat.updateitemid = id ;
 stat.updateitemx = x;
 stat.updateitemy = y;
}

void toggle_explo(long int x, long int y) {
 stat.updateexplo = 1;
 stat.updateexplox = x;
 stat.updateexploy = y;
}

void toggle_sfx(int n) {
 stat.updatesfx = 1;
 stat.updatesfxid = n;
}
