+------ Alien  Planet ------+
| (c) 2001 by The New Image |
+---------------------------+

Alien Planet was created for Gambit Studios' Freedom 2001 GameBoy
Developers Competition.

All graphics, sound and programming by Patriek Lesparre.
                                                        
Alien Planet is compatible with Classic GameBoy and GameBoy Color.
The color palette looks best on GameBoy emulators or GameBoy Advance.

Tools used written by me: tniASM, GB Tracker
3rd party tools used: Paint Shop Pro, Tilebuddy, QBasic

Legal Stuff
-----------
Alien Planet is freeware and can be distributed freely as long as:
* it is not modified
* this file is included in the archive
* it is not part of a commercial product

All trademarks are property of their respective owners.


Instructions
------------

Alien Planet is a vertical shoot'em-up. You control the player ship with
the directional controls and use button B to shoot. Start Button pauses
the game.

The goal of the game is to score points. If you get hit you lose your
ship. You have 3 additional ships, lose them all and it's Game Over.

Some enemies and power-stations will emit Power-containers. Catch them to
raise the power of your bullets. Your bullets have 5 different levels
of power. Each next level is reached after collecting 100 P-points. Your
power decreases every few shots. Your power also decreases when you lose
a ship.

In addition to raising the bullet's power, catching a P-container will
make you invincible for a short period of time. When invincible, your ship
will flash.

At two points in the game, you will encounter a Boss Station. These MUST
be destroyed to be able to continue.


Scoring Overview
---------------------------
Power-Container   10 points
Large Bullet      10 points
Waving Enemy      50 points
Hovering Enemy    70 points
Power Station    150 points
Small Station    250 points
Small Bullet     250 points (only destroyable during invincibility)
Large Station    750 points
Boss Station    2500 points


Cheat Mode
----------
Activating the cheat mode will restore your 3 ships, give you 4 seconds of
invincibility, and raise bullet power by 50. You can do this as many times
as you want during the game.

:esuap gnirud ecneuqes gniwollof eht sserP
A ,B ,thgiR ,tfeL
