
    GEJMB�J - Release note:
    
     This demo is intended to be run on either
     the original "DMG" Game Boy, the Pocket
     or the Super Game Boy. It's not fully
     compatible with GBC nor GBA but it will
     run on these systems as well, although
     there will be glitches.

     This demo relies on real hardware to run,
     sound and display correctly but if you
     haven't got the means to run the demo from
     a cartridge... I strongly recommend using
     the BGB emulator (http://bgb.bircd.org)
     check the "Game Boy" option under the
     Options/System menu.

     That's all I got,
     Snorpung.