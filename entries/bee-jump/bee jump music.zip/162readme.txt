bee jump
(c)2012 celestina software(r)
intro:
plug in the cartridge into the gameboy then power on.
at the logo press start to continue.
how to play:
at title screen press start to play the game or left for istructions or right for highscore table.
into the game jump on the platforms moving the bee with left or right to go higher and earn points.
if you fall of screen or knock a enemy is gameover,here you can enter a name for highscore table and continue or return to main title.
this way scores are saved.
the game can be paused pressing start,while pause hit select to return main title(score arent saved).
