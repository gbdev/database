 __          _                                
(_  o ._ _  |_)     ._ _   _  ._ |/ o ._   _  
__) | | | | |_) |_| | (_| (/_ |  |\ | | | (_| 
                       _|                  _| 
by Joshua Wise
===========================================================
This document was designed for a 60-column screen.
Please maximize Notepad for best results.
===========================================================
Cook (SimBurgerKing) is a very simple game. Press the
button that is represented by the icon onscreen.

Note that it is very much a work in progress: it was
originally designed for Bung 2001, but I'm not a very good
time manager, so I ran out of time. I just wrapped it up
this final night, just to enter something. :) (That's why
it's named bungcook in some places.)
===========================================================
Full source is included, do with it as you wish, just tell
me if you do something with it.
===========================================================
A FEW LEGAL NOTES: JOSHUA WISE TAKES NO RESPONSIBILITY FOR
ANY DAMAGES AS A RESULT OF THE USE OF THIS GAME. (But
please, tell me if something does happen!!)

Joshua Wise is in no way associated with Burger King, inc.
or Electronic Arts, inc. or it's subsidiaries. If your
company is mentioned, please send me notice via e-mail, and
I will remove your name and logo from the project.

Please do not redistribute the "purple" title screen in
your project - it was made by a personal friend for me and
although he wishes to remain anonymous, he does not want
it redistributed.
===========================================================
COMMENTS TO:

Joshua Wise
wiseguy586@yahoo.[remove me].com

AUTOMAILERS TO:
abuse@[127.0.0.1]
===========================================================
GREETZ go out to: Jeff F., Credo (sorry, couldn't reg MB -
I haven't the money!! I promise royalties if I make
anything off of this :)), J. Crash/J.T./The Blue Hippo/
Whatever :-P, my parents, Otaku, Pascal Felber, Michael
Hope (yes, this game was made in ASM, but great starts from
their work!!), all of my wonderful teachers at WMS, and
everyone I missed!!! (Sorry! :) )
===========================================================
UNFINISHED SECTIONS:
1) You don't die when the time is up.
2) Uh, it's just a little game engine, no fancy UI, or
   stuff like that. Heh.
3) In the release directory, the ROM in there doesn't have
   it's GBC bit set.
4) The code doesn't exactly match the ROM - the NLogo is
   in the code, in the ROM, it's null.
===========================================================
STICK AROUND, KEEP CHECKING JOSHUAWISE.COM FOR MORE COOL
STUFF FROM ME LIKE PLANET80! (w00t, textlib runs :) )

Later all, hope you enjoy this!

--joshua
wiseguy586@yahoo.[spam proof].com

P.S. W00T! Grep /dev/hda1 recovered this document!! W00T!!
:)
P.P.S. D'oh!! I don't have a recompile environment handy
and I forgot to take out the NLogo. D'oh!! Oh well...