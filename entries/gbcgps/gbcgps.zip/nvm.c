#include <gb.h>

UWORD nvm_gGlobalCounter;           //
