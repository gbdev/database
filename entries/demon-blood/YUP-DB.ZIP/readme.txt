           _ _._ __ _                              _ __ _._ _
              |/(_///------------------------------\\\_)\|
              |                                          |
              |                                          |
              :_______  .____     ._______ ___.     .____|_,
           __\|_     /_\|_   \___\|_     //   |/____|      |
          _)   /    /    /    /    /    /      _/   |      |
          \_  /    /         /    /    /       \    _     _|
           /_    _/__________\_________\________\___\_____\
           --\___\---------------------------------------|--
              |                                          |
    ._______  :_______  .___     .__    __.       __.    :____    __.
 ___\|_     /_\|_     /_\|_ /____\|__)__/ _|/_____(__|/__\|_   \_ / _|/______
_)    /    /    /    /   _/    /       \__      /      (_  /    //  \_      /
\_   /    /    /_____\   \     \_      | /     /        / /     \    /     /
 /________\_______\_______\_____/______|_______\________\_\______\_________\
- -diP-----------------------------------------------------------------aSL- -

// Demon Blood by Youth Uprising - @party 2012 invitation
   - Released at Revision 2012
 .   Code, Music : Ferris
 . Art, Graphics : Blake Ridgewell
 . Moral Support : Metoikos, Dr. Claw

// Minimum Specs
 . Runs on a gameboy. And I don't mean one of those new-fangled gameboy color
   contraptions; I mean good old-fashined DMG-01. Seriously though, I have no
   idea if this works on other models than the original. I'm going to guess
   that it won't though; some really nasty hardware exploits in here :) .
   
// About teh partehhhh
 . BE THERE. That is all. Well, not really. Other information includes:
   - When: June 15-17, 2012 (Remote entry deadline June 13, 2012)
   - Where: 281 Summer St., Boston, MA, USA, Earth, Milky Way...
   - Compos:
     . Demo
	 . (6)4k Intro
	 . Oldschool Demo
	 . Freestyle Music
	 . 8-bit Music (oh yeeaaauhhh, show me yo groove!)
	 . Freestyle Graphics
	 . Browser Demo
	 . Wild
	 . Interactive Fiction
	 . *NEW* Overhead projector (onsite entries only)
	 . *NEW* Gamedev
	 . *NEW* Oldschool graphics (ASCII, ANSI, pixel-by-pixel)
	 . *NEW* Executable music
	 . *NEW* Executable graphics
   - Features:
     . Ten minute walk from a Red Line subway station (for those of you
	   unfamiliar with Boston, this is a GOOD THING)
	 . Only four miles from Logan International airport
	 . In the up-and-coming Fort Point district of Boston
	 . Liquor license
	 . Variety of nearby food options
	 . Near downtown Boston
	 . Many oldschool NTSC machines (understatement of the year!); available for
	   compo use with prior request (see list on website)
   - More info at http://atparty-demoscene.net !!

// Greetings
 . Outracks
 . Snorpung
 . �mla�t Design
 . bitFlavour
 . Andromeda Software Development
 . Conspiracy
 . Farbrausch
 . Plastic
 . MFX
 . Traction
 . Northern Dragons
 . Trailer Park Demos
 . Gravity
 . RGBA
 . TBC
 . Loonies
 . Portal Process
 . Kvasigen
 . Nazareth Creations (fucking lamers)
 . PlayPsyCo
 . Kvasigen
 . Disaster Area
 . Gravity
 . Quite
 . XPLSV
 . Keyboarders
 . Shitfaced Clowns
 . * Everyone at Revision, displayhack.org & dbfinteractive.com *

// More Info
 . Well this was fun :) . Finally released a more or less proper 8-bit prod. Ended
   up being tons more work than anticipated, both in terms of code and assets, but
   it was certainly enjoyable. Got a nice little deadline crunch out of it too :P .
   Anyways, I think it turned out nice. Hope the Revision peeps agree :) . Also,
   there WILL be a displayhack article covering most of the technical stuff in this.
   Why? Because it was written in C#. Buahaha. Will probably also include source
   with said article. Because I can.
 . MAD PROPS to Blake Ridgewell. Seriously, what a beast. When I had asked him to
   do some pixel art for an upcoming gameboy demo, I had no idea that he'd come back
   11 murals and otherwise, haha! Kid's a machine. This will NOT be our last demo
   together.
 . Small note about the music: It may or may not be an adaptation/interpretation of
   Philip Glass' Metamorphosis. Just so you know :) .
 . Oh, and GO TO @PARTY 2012!!!!

// Eof
 . (C) 2012 Youth Uprising
 . http://youth-uprising.com
 . http://atparty-demoscene.net