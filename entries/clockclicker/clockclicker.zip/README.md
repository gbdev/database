# gameboy-emulator

Gameboy Emulator for Firefox OS

Marketplace: https://marketplace.firefox.com/app/gameboy-emulator/

MexMod: http://mexmod.com/apps.html
