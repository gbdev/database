----------------------------------
Peggy - 2002 Minigame Compo Entry
----------------------------------

Author   : Tomasz Slanina  dox@space.pl
Platform : Gameboy Color

<<<Peggy Solitaire>>>

The goal is to remove pegs from the board by jumping over each peg
with another peg - this removes the "jumped" peg. 
Only horizontal and vertical jumps are allowed.

Controls are :
 Cursor Keys - movement up/down/left/right
 A/B         - select
 Start       - restart game




