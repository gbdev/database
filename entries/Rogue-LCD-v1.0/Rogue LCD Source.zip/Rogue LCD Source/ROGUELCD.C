
#include <gb.h>
#include "ascii.h"
#include "roguetil.h"
#include "titletil.h"

UBYTE i, j, k, l; // In GBDK, global vars are faster than local ones.
UBYTE x, y;
UBYTE joy;
UBYTE framectrl, pagenum;
UWORD n, m;
char *o, *d, **currtext;

unsigned char text_buffer[2][20];

#define TEXTPAGES 9
char *scroller_text[] =
{
   "www.consolefever.com",
   "www.consolefever.com",
   "      ROGUE LCD     ",
   "     version 1.0    ",
   "    programmed by   ",
   " Haroldo O. Pinheiro",
   "  for PDRoms Coding ",
   "   Competition 2.5  ",
   "this game took about",
   " 8 hours to be made ",
   "       Enjoy!       ",
   "                    ",
   "   Get treasure to  ",
   "   increase score   ",
   "   Find stairs to   ",
   "   complete stage   ",
   "  PRESS ANY BUTTON  ",
   "  TO START PLAYING  "
};

void loadtext(char *line1, char *line2)
{
   for(i = 0; i != 2; i++){
      for(j = 0; j != 2; j++){
         text_buffer[i][j] = 0;    
      }
   }

   d = (char *)text_buffer[0];

   o = line1;
   while(*o){
      *d = *o;
      d++;
      o++;
   }

   o = line2;
   while(*o){
      *d = *o;
      d++;
      o++;
   }
}

void intro() 
{
   disable_interrupts();
   DISPLAY_OFF;
   LCDC_REG = 0x63;
   /*
    * LCD        = Off
    * WindowBank = 0x9C00
    * Window     = On
    * BG Chr     = 0x8800
    * BG Bank    = 0x9800
    * OBJ        = 8x8
    * OBJ        = On
    * BG         = On
    */

   /* Set palettes */
   BGP_REG = 0xD8U;
   OBP0_REG = 0xD8U;
   OBP1_REG = 0xE4U;

   SCX_REG = 0;
   SCY_REG = 0;

   WX_REG = MAXWNDPOSX;
   WY_REG = MAXWNDPOSY;

   set_bkg_data(0x00, 0xFF, title_tiles);
   set_bkg_tiles(0, 0, 20, 16, title_map);

   set_sprite_data(0x00U, 0x7F, ascii_tiles);
   for(i = 0; i != 40; i++){
      move_sprite(i, 0, 0);
      set_sprite_tile(i, 0);
   }

   DISPLAY_ON;
   enable_interrupts();

   NR50_REG=0x00;
   NR51_REG=0x00;
   NR52_REG=0x00;

   pagenum = TEXTPAGES;
   currtext = scroller_text;
   d = *currtext;
   currtext++;   
   loadtext(d, *currtext);
   currtext++;
   pagenum--;

   framectrl = 0;
   while(!(joypad() & (J_START|J_SELECT|J_A|J_B))){
	  wait_vbl_done();

      k = 0;
      x = 8;
      y = 136;
      for(i = 0; i != 2; i++){
         x = 8+(((framectrl+i) & 0x01) << 3);
         for(j = 0; j != 10; j++){                          
            l = (j << 1)+((framectrl+i) & 0x01);
            move_sprite(k, x, y);
            set_sprite_tile(k, text_buffer[i][l]);
	        x += 16;
            k++;
         }
         y += 8;
      }

      framectrl++;
      if(!framectrl){
         d = *currtext;
         currtext++;   
         loadtext(d, *currtext);
         currtext++;
         pagenum--;
         if(!pagenum){
            currtext = scroller_text;
            pagenum = TEXTPAGES;
         }
      }
   }

   while(joypad());
}

unsigned char playfield[32][32];
unsigned char status_bar[32];
UBYTE currstage;
UBYTE stage_clear;
UBYTE hp;
UBYTE map_x, map_y;
UBYTE ply_x, ply_y;
UBYTE enemies[64][4];
UBYTE enmcount;
UWORD score;
UBYTE enmdelay;

unsigned char room_links[32][2];

void make_room(UBYTE n, UBYTE x, UBYTE y, UBYTE w, UBYTE h)
{
   UBYTE i, j, k, l;

   if(x+w > 32) {
      x = 32 - w;
   }

   if(y+h > 32) {
      y = 32 - h;
   }

   l = y;
   for(i = w; i; i--){
      k = x;
      for(j = h; j; j--){
         if(playfield[l][k] == 14){
            playfield[l][k] = 0;
         }
         k++;
      }
      l++;
   }

   k = rand();
   w -= 2;
   while(k > w){
      k -= w;
   } 

   l = rand();
   h -= 2;
   while(l > h){
      l -= h;
   }

   room_links[n][0] = x+k+1;
   room_links[n][1] = y+l+1;
}

void link_rooms(UBYTE x1, UBYTE y1, UBYTE x2, UBYTE y2){
   while(x1 != x2){
      if(playfield[y1][x1] == 14){
         playfield[y1][x1] = 0;
      }

      if(x1 > x2){
         x1--;
      }else{
         x1++;
      }
   }

   while(y1 != y2){
      if(playfield[y1][x1] == 14){
         playfield[y1][x1] = 0;
      }

      if(y1 > y2){
         y1--;
      }else{
         y1++;
      }
   }
}

void choose_free_spot()
{
    x = rand() & 0x1F;
    y = rand() & 0x1F;
    while(playfield[y][x]){
       x = rand() & 0x1F;
       y = rand() & 0x1F;
    }
}

void draw_playfield()
{
   for(i = 0; i != 32; i++) {
      for(j = 0; j != 32; j++) {
         if((playfield[i][j] == 11)||
            (playfield[i][j] == 12)){
            playfield[i][j] = 0;
         }
      }
   }

   set_bkg_tiles(0, 0, 32, 32, *playfield);
}

void draw_status_bar()
{
   o = (char *)status_bar;
   for(i = 32; i; i--){
      *o = 0;
      o++;
   }

   o = (char *)status_bar; 
   o += 2;
   *o = 16;
   o += 3;
   i = hp;
   if(!i){
      *o = 10;
   }else{
      while(i){
         j = i % 10;
         if(!j){
            j = 10;
         }
         *o = j;
         o--;
         i /= 10;
      }
   }

   o = (char *)status_bar; 
   o += 8;
   *o = 17;
   o += 6;
   n = score;
   if(n == 0UL){
      *o = 10;
   }else{
      while(n){
         m = n % 10UL;
         if(m == 0UL){
            m = 10UL;
         }
         *o = (UBYTE)m;
         o--;
         n /= 10UL;
      }
   }

   o = (char *)status_bar; 
   o += 16;
   *o = 15;
   o += 4;
   i = currstage;
   if(!i){
      *o = 10;
   }else{
      while(i){
         j = i % 10;
         if(!j){
            j = 10;
         }
         *o = j;
         o--;
         i /= 10;
      }
   }

   set_win_tiles(0, 0, 32, 1, status_bar);
}

void build_stage()
{
   for(i = 0; i != 32; i++) {
      for(j = 0; j != 32; j++) {
         playfield[i][j] = 14;
      }
   }

   for(l = 0; l != 32; l++){
      make_room(l, rand()&0x1F, rand()&0x1F, 3+(rand()&0x3), 3+(rand()&0x3));
   }

   for(l = 0; l != 31; l++){
      link_rooms(room_links[l][0],room_links[l][1],
                 room_links[l+1][0],room_links[l+1][1]);
   }

   choose_free_spot();
   ply_x = x;
   ply_y = y;
   playfield[y][x] = 11;

   for(l = 0; l != 32; l++){
      choose_free_spot();
      playfield[y][x] = 13;
   }


   enmcount = 16+(currstage >> 1);
   if(enmcount > 64){
      enmcount = 64;
   }
   for(l = 0; l != enmcount; l++){
      choose_free_spot();
      playfield[y][x] = 12;
      enemies[l][0] = x;
      enemies[l][1] = y;
      enemies[l][2] = 1;
   }

   choose_free_spot();
   playfield[y][x] = 15;

   draw_playfield();

   map_x = ply_x - 9;
   map_y = ply_y - 8;
}

void position_viewport()
{
   SCX_REG = map_x << 3;
   SCY_REG = map_y << 3;
}

void place_sprites()
{
   playfield[ply_y][ply_x] = 11;

   x = ply_x+1;
   x -= map_x;
   x = (x&0x1F) << 3;
   y = ply_y+2;
   y -= map_y;
   y = (y&0x1F) << 3;
   move_sprite(0, x, y);
   set_sprite_tile(0, 11);

   j = 39;
   for(i = 0; (i != enmcount)&&j; i++){
      if(enemies[i][2]){
         x = enemies[i][0];
         y = enemies[i][1];
         playfield[y][x] = 12;

         x -= map_x;
         x &= 0x1F;
         y -= map_y;
         y &= 0x1F;
         if((x < 20)&&(y < 17)){
            x++;
            x = (x&0x1F) << 3;
            y += 2;
            y = (y&0x1F) << 3;
            move_sprite(j, x, y);
            set_sprite_tile(j, 12);
            j--;
         }
      }
   }

   for(; j; j--){
      move_sprite(j, 0, 0);
   }
}

void sound_1(){
   NR10_REG = 0x00;
   NR11_REG = 0xAF;
   NR12_REG = 0xF0;
   NR13_REG = 0x00;
   NR14_REG = 0xC6;
}

void sound_2(){
   NR10_REG = 0x00;
   NR11_REG = 0xA5;
   NR12_REG = 0xF0;
   NR13_REG = 0x00;
   NR14_REG = 0xC7;
}

void sound_3(){
   NR10_REG = 0x00;
   NR11_REG = 0xA0;
   NR12_REG = 0xF0;
   NR13_REG = 0x00;
   NR14_REG = 0xC2;
}

void kill_player()
{
   if(!hp){
      return;
   }

   move_sprite(0, 0, 0);

   choose_free_spot();
   ply_x = x;
   ply_y = y;
   playfield[y][x] = 11;

   map_x = ply_x - 9;
   map_y = ply_y - 8;

   enmdelay = 16;

   hp--;
   draw_status_bar();

   sound_3();
   delay(70);
}

void move_enemies()
{
   for(i = 0; i != enmcount; i++){
      x = enemies[i][0];
      y = enemies[i][1];
      playfield[y][x] = 0;

      if((rand()&0x1F) < ((currstage >> 1)+8)){
         if(rand()&0x01){
            if(((BYTE)(x-ply_x)) < 0){
               x--;
            }else{
               x++;
            }
         }else{
            if(((BYTE)(y-ply_y)) < 0){
               y--;
            }else{
               y++;
            }
         }
      }else{
         switch(rand()&0x03){
            case 0:
               x--;
            break;

            case 1:
               x++;
            break;

            case 2:
               y--;
            break;

            case 3:
               y++;
            break;
         }
      }

      x &= 0x1F;
      y &= 0x1F;

      if(!playfield[y][x]){
         enemies[i][0] = x;
         enemies[i][1] = y;
      }else if(playfield[y][x] == 11){
         if(rand() < 64){
            kill_player();
            return;
         }
      }

      x = enemies[i][0];
      y = enemies[i][1];
      playfield[y][x] = 12;
   }

   sound_1();
}

void play()
{
   disable_interrupts();
   DISPLAY_OFF;
   LCDC_REG = 0x73;
   /*
    * LCD        = Off
    * WindowBank = 0x9C00
    * Window     = On
    * BG Chr     = 0x8000
    * BG Bank    = 0x9800
    * OBJ        = 8x8
    * OBJ        = On
    * BG         = On
    */

   /* Set palettes */
   BGP_REG = 0xD8U;
   OBP0_REG = 0xD8U;
   OBP1_REG = 0xE4U;

   SCX_REG = 0;
   SCY_REG = 0;

   WX_REG = 0;
   WY_REG = MAXWNDPOSY-8;

   set_bkg_data(0x00, 0xFF, rogue_tiles);

   for(i = 0; i != 40; i++){
      move_sprite(i, 0, 0);
   }

   DISPLAY_ON;
   enable_interrupts();

   NR50_REG=0xFF;
   NR51_REG=0xFF;
   NR52_REG=0xFF;

   pagenum = TEXTPAGES;
   currtext = scroller_text;
   d = *currtext;
   currtext++;   
   loadtext(d, *currtext);
   currtext++;
   pagenum--;

   initrand(framectrl);

   framectrl = 0;
   hp = 8;   
   score = 0;
   currstage = 1;
   while(hp){
      DISPLAY_OFF;
      build_stage();
      draw_status_bar();
      DISPLAY_ON;

      enmdelay = 16;

      stage_clear = FALSE;
      while(hp && (!stage_clear)) {
         if(!enmdelay){
            move_enemies();

            if(currstage < 14){
               enmdelay = 8-(currstage >> 1);
            }else{
               enmdelay = 1;
            }
         }
         enmdelay--;

         joy = joypad();

         x = ply_x;
         y = ply_y;
         if(joy & J_UP){
            y--;
         }else if(joy & J_DOWN){
            y++;
         }else if(joy & J_LEFT){
            x--;
         }else if(joy & J_RIGHT){
            x++;
         }else{
         }

         x &= 0x1F;
         y &= 0x1F;
         switch(playfield[y][x]){
            case 0:
               ply_x = x;
               ply_y = y;
            break;

            case 13:
               playfield[y][x] = 0;
               score += 10+currstage;
               draw_status_bar();
               ply_x = x;
               ply_y = y;
			   draw_playfield();
               sound_2();
            break;

            case 15:
               playfield[y][x] = 0;
               stage_clear = TRUE;
               score += 100*currstage;
               draw_status_bar();
               ply_x = x;
               ply_y = y;
			   draw_playfield();
            break;
         }

         x = ply_x;
         x -= map_x;
         x -= 6;
         if(x > 8){
            map_x = ply_x - 9;
         }

         y = ply_y;
         y -= map_y;
         y -= 5;
         if(y > 7){
            map_y = ply_y - 8;
         }

         o = (char *)playfield[0];
         for(i = 0; i != 32; i++) {
            for(j = 0; j != 32; j++) {
               if((*o == 11)||
                  (*o == 12)){
                  *o = 0;
               }
               o++;
            }
         }

	     wait_vbl_done();

         position_viewport();
         place_sprites();
      }

      currstage++;

      if(hp&&(currstage&0x01)){
         hp++;
      }
   }

   for(i = 255; i; i--){
	  wait_vbl_done();
   }

   while(joypad());
}

void main()
{
  UBYTE i, j;

  while(1){
     intro();
     play();
  }
}
