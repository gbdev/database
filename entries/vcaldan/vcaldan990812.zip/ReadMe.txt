Portugu�s  
---------  

	12 de agosto de 1999
	--------------------

	  Depois de um longo e muita modifica��o no projeto, finalmente um nova vers�o dispon�vel.
	  Est� vers�o para teste, mas o que voc� ir� ver se tornar� a hist�ria jogo.
	  Bem ainda ando meio sem tempo e procurando emprego.
	  Se souber de alguma vaga n�o deixe de me avisar. :)
	  Pe�o desculpas por n�o ter conseguido responder alguns dos e-mails que voc�s me mandaram.
	  Estamos preparando um FAQ com as perguntas mais frequ�ntes e logo estar� dispon�vel.
	  Demoramos para lan�ar uma nova vers�o ao p�blico pelo fato de termos mudado os desenhos e
	tamb�m pelo fato de estarmos fazendo um outro jogo tamb�m, quase todos os gr�ficos desse
	outro jogo j� est�o prontos.
	  O nome desse novo jogo se assim eu puder cham�-lo � METAL GEAR, isso mesmo que voc� 
	acabou de ler.
	 Mande-nos as sua sujest�es em rela��o a esses dois jogos.

	20 de mar�o de 1999
	-------------------

	O personagem est� andando um pouco melhor no cen�rio.
	O inimigo est� com anima��o certa agora.
	Arrumado um bug no scroll, quem quizer testar o bug, fa�a o seguinte quando chegar na 
	ponte movimente-se r�pido para direita e esquerda e voc�s veram o bug.

	20 de mar�o de 1999.  
	--------------------

	Aqui est� a vers�o para Gameboy Color.  

	Se voc� � uma empresa e necessita de programador ou designer para Gameboy ou PC por favor  
	mande seu e-mail.  
  
	N�o deixem de visitar para saber das ultimas novidades.  
	http://www.geocities.com/SiliconValley/Park/4823/  
  
	Por favor qualquer d�vida ou sugest�o mande para n�s atrav�s do e-mail.  
  
	julio_lemos@geocities.com  
  
		Muito obrigado por pegar meu projeto.  
		Por favor pegue tamb�m a vers�o para PC.


English  
---------  

	August 12, 1999.
	---------------

	  After long time of much modification in project, finally a new version available.
	  This version is for test, but that you it will go to see it will become history of game. 
	  Well still i walk half without time and looking for job. 
	  If you know of some vacant does not leave to inform to me. :)
	  My excuses for not having obtained to answer some of e-mail that all pleople send to me.
	  We're prepating a FAQ with some questions and soon it'll be available.
	  We delay to launch a new version to the public for the fact of terms changed the 
	drawings and also for the fact to be making one another game also, almost all the 
	graphs of this another game already are ready.
	  The name of this new game if thus I will be able to call it is METAL GEAR, 
	this exactly that you finished to read. 
 	 Send for us yours suggestions in relation to these two games. 



	March 20, 1999.  
	---------------

	Here it is the version for Gameboy Color.  

	If you are a company and you needs one programmer or designer for Gameboy or PC please 
	send me an e-mail.
  
	Don't stop visiting to know of the last novelties.  
	http://www.geocities.com/SiliconValley/Park/4823/  
  
	Please any doubt or suggestion sends for us through the e-mail.  
  
	julio_lemos@geocities.com  
  
		Thank you very much for catching my project.  
		Please also catch the version for PC.
