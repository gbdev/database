# Namihey for Gameboy color
Namihey is Gunpey like puzzle game, Gunpey is killer software of Wonder Swan by BANDAI. This software is ported to GBC. As same rule as Gunpey but re-born to Namihey by changing character. 

<table>
<tr>
<td><img src="./pics/namihey.jpg"></td>
</tr>
</table>

# License
Copyright (c) Osamu OHASHI  
Distributed under the MIT License either version 1.0 or any later version. 
