#include <gb.h>

UWORD max_score;

/* EOF */
